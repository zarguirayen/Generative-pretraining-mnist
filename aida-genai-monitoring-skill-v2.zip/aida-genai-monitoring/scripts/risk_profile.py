#!/usr/bin/env python3
"""Rate the risk of a GenAI system and scale its monitoring to it (template §5).

    python risk_profile.py --context aida/context.json [--risk-category high]
                           [--users external] [--inference-frequency daily]

The monitoring is proportionate to the system. Three dimensions are rated, each from the
code's evidence or from the risk owner's answer:

- stakes - what a wrong output or action costs: the AI Act risk category, and the
  irreversible side effects the code can trigger;
- complexity - how much the system decides by itself: autonomy level and tools;
- exposure - who reaches it and how often: endpoints, inference frequency, users.

A dimension nobody has rated is "to confirm", never "low": its additions stay applied
until the risk owner rates it low. Only the additions are scaled; the metrics and the
drift the guideline makes mandatory for the family (tool-set drift, MON-DRIFT-TOOLSET)
are never dropped.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HIGH, LOW, TO_CONFIRM = "high", "low", "to confirm"
IRREVERSIBLE = ("send_email", "delete", "http_write", "db_write")
REVIEW_SAMPLE = 20

# Additions beyond the family minimum, and the dimension whose rating turns each one on.
SCALED_BY = {
    "knowledge base drift": "stakes",
    "tool description drift": "complexity",
    "tool response drift": "complexity",
    "queries drift": "exposure",
    "question test set drift": "exposure",
    "human review sample": "stakes",
}
QUERY_DRIFT_KINDS = ("queries drift", "question test set drift")


def proofs(block: dict, limit: int = 4) -> list[str]:
    """The `path:line` proofs of a scan block `{name: {"evidence": [...]}}`, at most `limit`."""
    found = [item for entry in (block or {}).values() for item in entry.get("evidence") or []]
    return list(dict.fromkeys(found))[:limit]


def rating(level: str, why: str, evidence: list[str]) -> dict:
    """One rated dimension: its level, the reason, and the evidence behind it."""
    return {"rating": level, "why": why, "evidence": evidence}


def stakes(ctx: dict, risk_category: str | None) -> dict:
    """High for a high-risk category or an irreversible side effect; low only when the
    risk owner gave a lower category and the code can do nothing irreversible."""
    effects = {k: v for k, v in (ctx.get("side_effects") or {}).items() if k in IRREVERSIBLE}
    if risk_category == "high":
        return rating(HIGH, "high-risk AI Act category, per the risk owner", proofs(effects))
    if effects:
        kinds = ", ".join(k.replace("_", " ") for k in effects)
        return rating(HIGH, f"the code can take irreversible actions ({kinds})", proofs(effects))
    if risk_category in ("limited", "minimal"):
        return rating(LOW, f"{risk_category}-risk category per the risk owner, and no "
                           f"irreversible side effect in the code", [])
    return rating(TO_CONFIRM, "no irreversible side effect in the code; the risk category "
                              "is the risk owner's to give", [])


def complexity(ctx: dict) -> dict:
    """High for autonomy L2/L3 or several tools; low for a system that calls no tool."""
    cls = ctx.get("classification") or {}
    level = cls.get("agentic_level")
    tools = (cls.get("signal_counts") or {}).get("tools", 0)
    if level in ("L2", "L3") or tools > 1:
        return rating(HIGH, f"autonomy {level or 'L1'} with {tools} tool signal(s): the "
                            f"system chooses its own actions",
                      proofs(ctx.get("tool_definitions") or {}))
    if not tools and cls.get("family") in ("prompt", "rag"):
        return rating(LOW, f"a {cls['family']} system with no tool: it answers, it does not "
                           f"act", (cls.get("family_evidence") or [])[:2])
    return rating(TO_CONFIRM, "one tool at autonomy L1, or a family not established",
                  proofs(ctx.get("tool_definitions") or {}))


def exposure(ctx: dict, frequency: str | None, users: str | None) -> dict:
    """High for external users or an endpoint called daily; low for internal users."""
    endpoints = ctx.get("endpoints") or []
    evidence = [e["evidence"] for e in endpoints][:4]
    if users == "external":
        return rating(HIGH, "external users, per the risk owner", evidence)
    if endpoints and frequency == "daily":
        return rating(HIGH, f"{len(endpoints)} endpoint(s) in the code, called daily", evidence)
    if users == "internal":
        return rating(LOW, "internal users, per the risk owner, and no daily public "
                           "endpoint", evidence)
    return rating(TO_CONFIRM, "who uses the system is the risk owner's to say", evidence)


def profile(ctx: dict, frequency: str | None, risk_category: str | None,
            users: str | None) -> dict:
    """The three rated dimensions of §5."""
    return {"stakes": stakes(ctx, risk_category), "complexity": complexity(ctx),
            "exposure": exposure(ctx, frequency, users)}


def decision(addition: str, risk: dict, without_ground_truth: bool = False) -> dict:
    """Whether one addition applies, and why: it does unless its dimension is rated low,
    and query drift always does when there is no ground truth to measure quality with."""
    dimension = SCALED_BY[addition]
    level = risk[dimension]["rating"]
    why = f"{dimension} {level}: {risk[dimension]['why']}"
    on = level != LOW
    if level == TO_CONFIRM:
        why += " - applied until the risk owner rates it low"
    elif not on and without_ground_truth and addition in QUERY_DRIFT_KINDS:
        on, why = True, why + " - applied anyway: without ground truth, drift is how a " \
                                "degradation shows"
    return {"addition": addition, "dimension": dimension, "applied": on, "why": why}


def scale(risk: dict, drift: list[tuple[str, str]],
          without_ground_truth: bool = False) -> tuple[list[dict], list[dict]]:
    """(the drift to monitor, every addition with its decision).

    Drift the family must monitor is always kept; scaled drift is kept only when its
    dimension is not rated low. The query-drift test and the human review sample are
    decided for every family. Without ground truth, query drift stays: the guideline
    makes drift analysis necessary when ground truth is hard to collect.
    """
    kept, decisions = [], []
    for kind, how in drift:
        if kind not in SCALED_BY:
            kept.append({"kind": kind, "how": how, "mandatory": True})
            continue
        choice = decision(kind, risk, without_ground_truth)
        decisions.append(choice)
        if choice["applied"]:
            kept.append({"kind": kind, "how": how, "scaled_by": choice["dimension"]})
    if not any(kind in QUERY_DRIFT_KINDS for kind, _ in drift):
        decisions.append(decision("queries drift", risk, without_ground_truth))
    decisions.append(decision("human review sample", risk))
    return kept, decisions


def applied(decisions: list[dict], *additions: str) -> bool:
    """True when any of these additions was applied."""
    return any(d["applied"] for d in decisions if d["addition"] in additions)


def main() -> int:
    """Command line: print the three ratings and what they add."""
    parser = argparse.ArgumentParser(description="Rate the risk and scale the monitoring (§5).")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--risk-category", choices=["high", "limited", "minimal"])
    parser.add_argument("--users", choices=["internal", "external"])
    parser.add_argument("--inference-frequency", choices=["daily", "weekly", "monthly", "quarterly"])
    args = parser.parse_args()
    context = Path(args.context)
    if not context.exists():
        print(f"error: context not found: {context}", file=sys.stderr)
        return 2
    risk = profile(json.loads(context.read_text(encoding="utf-8")), args.inference_frequency,
                   args.risk_category, args.users)
    for dimension, rated in risk.items():
        print(f"{dimension:<11} {rated['rating']:<11} {rated['why']}")
    _, decisions = scale(risk, [])
    for choice in decisions:
        print(f"  {'+' if choice['applied'] else '-'} {choice['addition']}: {choice['why']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
