---
description: Builds the AIDA evidence base for the current project and reports its compliance posture. Produces the context, the template field coverage and the ML-BOM, then states what only the risk owner can answer. Takes no input beyond the open workspace.
---

Build the AIDA compliance context for this project, using the `aida-core` skill.

Run the three scripts in order from the project root, and read the summary each one
prints rather than loading the JSON files into context:

1. `scan_codebase.py` → `aida/context.json`
2. `placeholder_map.py --report` → `aida/placeholders.json`
3. `aida_bom.py --summary` → `aida/ml-bom.json`

Then report, in this order and nothing more:

- The system classification, its certainty, and the verbatim reason the script gave.
- The models, vector stores and reference framework found, each with its evidence.
- Whether the reference stack matches what the Building Agentic AI Systems guideline
  expects for that autonomy level, and say so plainly if it does not.
- How many technical documentation fields are auto-fillable, and how many need a human.
- The compliance gaps already visible from the scan alone: missing structured logging,
  missing observability, irreversible side effects with no approval gate, and an L2 or
  L3 classification with no documented justification for the autonomy.
- The three things you need from the risk owner before any document can be written:
  intended purpose and target users, the AI Act / VRM risk category, and the system
  owner plus the named human overseers.

Do not write any deliverable yet, and do not guess any value the scan did not prove.
