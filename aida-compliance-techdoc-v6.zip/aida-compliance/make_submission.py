#!/usr/bin/env python3
"""Package the plugin as the .zip the challenge submission form expects.

    python make_submission.py [--out ../../../../submission]

Builds a clean archive: no __pycache__, no .pytest_cache, no `aida/` output from a
previous run, no git metadata. Then verifies the archive by extracting it to a temporary
directory and running the test suite inside it - an archive that does not pass its own
tests is not worth uploading.

Standard library only.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

PLUGIN = Path(__file__).resolve().parent
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", "aida", ".git", ".mypy_cache", ".ruff_cache"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".zip"}
EXCLUDE_NAMES = {".DS_Store", "Thumbs.db"}


def wanted(path: Path, lean: bool = False) -> bool:
    relative = path.relative_to(PLUGIN)
    if any(part in EXCLUDE_DIRS for part in relative.parts):
        return False
    if lean:
        # The lean archive is what Copilot needs to run the skills, plus the behavioural
        # evaluations that specify how the agent must use them. The unit-test suite and
        # the packaging tool stay in the repository.
        if relative.parts[0] == "tests" and "evals" not in relative.parts:
            return False
        if relative.name == "make_submission.py":
            return False
    return path.suffix not in EXCLUDE_SUFFIXES and path.name not in EXCLUDE_NAMES


def build(archive: Path, lean: bool = False) -> list[Path]:
    files = sorted(p for p in PLUGIN.rglob("*") if p.is_file() and wanted(p, lean))
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            zf.write(path, Path("aida-compliance") / path.relative_to(PLUGIN))
    return files


def verify(archive: Path, lean: bool = False) -> bool:
    """Extract, then prove the extracted copy works on its own.

    The full archive runs its own test suite. The lean one has no suite, so it runs the
    whole chain on the repository's agentic fixture instead and checks the document.
    """
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(root)
        extracted = root / "aida-compliance"

        for required in ("plugin.json", "plugin.yaml", "README.md", "CHANGELOG.md",
                         "skills/aida-core/SKILL.md",
                         "skills/aida-core/assets/templates/technical_documentation.docx"):
            if not (extracted / required).exists():
                print(f"  MISSING from the archive: {required}")
                return False

        if lean:
            project = root / "sample"
            shutil.copytree(PLUGIN / "tests" / "fixtures" / "agentic_assistant", project)
            result = subprocess.run([sys.executable, str(extracted / "run_all.py"),
                                     str(project)], capture_output=True, text=True)
            document = project / "aida" / "technical_documentation.docx"
            ok = (result.returncode == 0 and document.exists()
                  and zipfile.ZipFile(document).testzip() is None)
            print(f"  full chain from the archive on a sample project: "
                  f"{'document produced' if ok else 'FAILED'}")
            return ok

        result = subprocess.run([sys.executable, "-m", "pytest", "tests/", "-q"],
                                cwd=extracted, capture_output=True, text=True)
        tail = (result.stdout or result.stderr).strip().splitlines()[-1:]
        print(f"  tests inside the archive: {tail[0] if tail else 'no output'}")
        return result.returncode == 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Build and verify the submission archive.")
    parser.add_argument("--out", default=str(PLUGIN.parents[3] / "submission"))
    parser.add_argument("--name", default="aida-compliance")
    parser.add_argument("--skip-verify", action="store_true")
    parser.add_argument("--lean", action="store_true",
                        help="leave the unit-test suite out of the archive")
    args = parser.parse_args()

    out = Path(args.out)
    archive = out / f"{args.name}.zip"
    if archive.exists():
        archive.unlink()

    print(f"Building {archive}")
    files = build(archive, args.lean)
    size_mb = archive.stat().st_size / 1_000_000
    print(f"  {len(files)} files, {size_mb:.1f} MB (limit: 60 MB)")

    skills = sorted(p.parent.name for p in PLUGIN.glob("skills/*/SKILL.md"))
    print(f"  {len(skills)} skills: {', '.join(skills)}")

    if size_mb > 60:
        print("  ERROR: over the 60 MB limit")
        return 1

    if args.skip_verify:
        return 0

    print("\nVerifying the archive is self-contained")
    if not verify(archive, args.lean):
        print("\nThe archive does not pass its own tests - do not upload it.")
        return 1

    print(f"\nReady: {archive}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
