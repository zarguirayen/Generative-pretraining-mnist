#!/usr/bin/env python3
"""Emit a CycloneDX 1.6 ML-BOM for the scanned system.

    python aida_bom.py [--context aida/context.json] [--out aida/ml-bom.json] [--summary]

Why an ML-BOM and not just the Word document: the technical documentation asks for the
software dependencies and their versions (2.2), the third-party models, tools and
frameworks (3.2), and the model artefacts (3.4). CycloneDX is the standard machine
readable form of exactly that, so the same inventory serves three purposes at once -
it fills those sections, it is itself a record under the record keeping guideline, and
it is auditable by tooling the bank already uses for SBOMs.

Scope note: only what the scan proved is emitted. Fields that need a human (intended
purpose, technical limitations, ethical considerations) are left out rather than
guessed - the Word document is where they get asked for.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

SPEC_VERSION = "1.6"

# AI Factory family -> CycloneDX modelParameters. `task` uses CycloneDX vocabulary.
FAMILY_TO_MODEL_PARAMS = {
    "rag": {"task": "text-generation", "approach": {"type": "unsupervised"},
            "architectureFamily": "transformer"},
    "prompt": {"task": "text-generation", "approach": {"type": "unsupervised"},
               "architectureFamily": "transformer"},
    "agentic": {"task": "text-generation", "approach": {"type": "unsupervised"},
                "architectureFamily": "transformer"},
    "hybrid": {"task": "text-generation", "approach": {"type": "unsupervised"},
               "architectureFamily": "transformer"},
}

# Vector stores hold the knowledge base, which CycloneDX represents as a data component.
DATA_COMPONENT_KEYS = ("vector_stores",)


def purl_for(name: str, version: str | None) -> str:
    base = f"pkg:generic/{name}"
    return f"{base}@{version.lstrip('=<>~^ ')}" if version else base


def model_components(ctx: dict) -> list[dict]:
    """One machine-learning-model component per model id found in the code."""
    classification = ctx.get("classification", {})
    family = classification.get("family", "unknown")
    params = dict(FAMILY_TO_MODEL_PARAMS.get(family, {}))

    components = []
    for model_id, evidence in (ctx.get("models") or {}).items():
        provider = model_id.split(".")[0] if "." in model_id else None
        card: dict = {"modelParameters": dict(params)}

        # Datasets: the knowledge base a RAG system retrieves from.
        datasets = [{"type": "other", "name": f"knowledge base ({store})"}
                    for store in (ctx.get("vector_stores") or {})]
        if datasets:
            card["modelParameters"]["datasets"] = datasets
        card["modelParameters"]["inputs"] = [{"format": "text"}]
        card["modelParameters"]["outputs"] = [{"format": "text"}]

        components.append({
            "type": "machine-learning-model",
            "bom-ref": f"model/{model_id}",
            "name": model_id,
            "publisher": provider,
            "description": f"Model invoked by the system ({family} family).",
            "modelCard": card,
            "properties": [
                {"name": "aida:evidence", "value": ", ".join(evidence)},
                {"name": "aida:family", "value": family},
                *([{"name": "aida:agentic_level", "value": classification["agentic_level"]}]
                  if classification.get("agentic_level") else []),
            ],
        })
    return components


def library_components(ctx: dict) -> list[dict]:
    out = []
    for name, meta in sorted((ctx.get("dependencies") or {}).items()):
        version = (meta or {}).get("version")
        clean = version.lstrip("=<>~^! ").strip() if version else None
        out.append({
            "type": "library",
            "bom-ref": f"lib/{name}",
            "name": name,
            **({"version": clean} if clean else {}),
            "purl": purl_for(name, clean),
            "properties": [{"name": "aida:evidence", "value": (meta or {}).get("evidence", "")}],
        })
    return out


def data_components(ctx: dict) -> list[dict]:
    out = []
    for key in DATA_COMPONENT_KEYS:
        for store, meta in (ctx.get(key) or {}).items():
            out.append({
                "type": "data",
                "bom-ref": f"data/{store}",
                "name": f"{store} knowledge base",
                "description": "Retrieval corpus - contents and provenance to be confirmed "
                               "by the risk owner (technical documentation 3.1).",
                "properties": [{"name": "aida:evidence",
                                "value": ", ".join(meta.get("evidence", []))}],
            })
    return out


def service_components(ctx: dict) -> list[dict]:
    """Endpoints are the system's exposed surface - useful for the access log records."""
    endpoints = ctx.get("endpoints") or []
    if not endpoints:
        return []
    # `authenticated` is deliberately omitted: the scan cannot prove it, and the schema
    # expects a boolean - asserting false would be a claim we have no evidence for.
    return [{
        "bom-ref": "service/api",
        "name": f"{ctx['project']['name']} API",
        "endpoints": [e["route"] for e in endpoints],
        "properties": [{"name": "aida:evidence",
                        "value": ", ".join(e["evidence"] for e in endpoints[:8])}],
    }]


def build_bom(ctx: dict) -> dict:
    project = ctx.get("project", {})
    git = ctx.get("git", {})
    version = git.get("tag") or (git.get("commit") or "")[:12] or "unknown"

    components = model_components(ctx) + data_components(ctx) + library_components(ctx)
    root_ref = f"system/{project.get('name', 'ai-system')}"

    bom = {
        "bomFormat": "CycloneDX",
        "specVersion": SPEC_VERSION,
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "tools": {"components": [{
                "type": "application",
                "name": "aida-compliance",
                "publisher": "CACIB / DS Community",
            }]},
            "component": {
                "type": "application",
                "bom-ref": root_ref,
                "name": project.get("name", "ai-system"),
                "version": version,
                "description": "AI system inventoried from its codebase for AIDA technical "
                               "documentation. Every entry is backed by a file:line reference.",
                "properties": [
                    {"name": "aida:classification",
                     "value": ctx.get("classification", {}).get("family", "unknown")},
                    {"name": "aida:certainty",
                     "value": ctx.get("classification", {}).get("certainty", "low")},
                    {"name": "aida:scanned_at", "value": ctx.get("generated_at", "")},
                    *([{"name": "aida:repository", "value": git["remote"]}]
                      if git.get("remote") else []),
                ],
            },
        },
        "components": components,
        "dependencies": [
            {"ref": root_ref, "dependsOn": [c["bom-ref"] for c in components]},
            *[{"ref": c["bom-ref"], "dependsOn": []} for c in components],
        ],
    }
    services = service_components(ctx)
    if services:
        bom["services"] = services
    return bom


def summarise(bom: dict) -> str:
    kinds: dict[str, int] = {}
    for component in bom["components"]:
        kinds[component["type"]] = kinds.get(component["type"], 0) + 1
    lines = [
        f"CycloneDX {bom['specVersion']} ML-BOM for {bom['metadata']['component']['name']}"
        f" v{bom['metadata']['component']['version']}",
        f"serial : {bom['serialNumber']}",
        "components:",
    ]
    for kind, count in sorted(kinds.items()):
        lines.append(f"  {kind:<24} {count}")
    if not kinds.get("machine-learning-model"):
        lines.append("  (no model component - no model id was found in the code)")
    lines.append(f"services   : {len(bom.get('services', []))}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Emit a CycloneDX ML-BOM from the AIDA context.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--out", default="aida/ml-bom.json")
    parser.add_argument("--summary", action="store_true")
    args = parser.parse_args()

    context_path = Path(args.context)
    if not context_path.exists():
        print(f"error: context not found: {context_path}\n"
              f"       run scan_codebase.py first", file=sys.stderr)
        return 2

    ctx = json.loads(context_path.read_text(encoding="utf-8"))
    bom = build_bom(ctx)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(bom, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    if args.summary:
        print(summarise(bom))
    print(f"\nML-BOM written to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
