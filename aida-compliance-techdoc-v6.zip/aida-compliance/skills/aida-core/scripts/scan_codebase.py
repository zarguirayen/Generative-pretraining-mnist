#!/usr/bin/env python3
"""Scan a project and emit the evidence-backed context the AIDA skills consume.

    python scan_codebase.py [project_dir] [--out aida/context.json] [--quiet]

Every fact recorded here carries the file and line that proves it. A fact with no
evidence is never written, so the downstream skills cannot state anything about the
system that is not grounded in the code. Standard library only - no install step.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", "env",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "dist", "build", ".next",
    ".idea", ".vscode", "site-packages", ".tox", "target", ".gradle", "coverage",
    # This tool's own output. Reading it back made a second run classify the project
    # from the words in the first run's reports - the scan must be idempotent.
    "aida",
    # Tests exercise the system, frequently with mocks and sample strings; counting them
    # as evidence made a download utility come out as a RAG system from its test file.
    "tests", "test",
}
TEST_FILE = re.compile(r"^(test_.*|.*_test|conftest)\.py$")
# Only files that make the system behave are evidence of what it is. Documentation is left
# out on purpose: a README or a SKILL.md that *describes* LangGraph agents and `@tool`
# functions made a plain download utility come out as a hybrid L3 agent. Dependencies
# declared in requirements.txt are still read, by read_dependencies().
TEXT_SUFFIXES = {
    ".py", ".ipynb", ".js", ".ts", ".tsx", ".jsx", ".java", ".scala", ".go", ".rb",
    ".yaml", ".yml", ".json", ".toml", ".cfg", ".ini", ".env", ".sh", ".ps1",
    ".sql", ".tf", ".dockerfile",
}
MAX_FILE_BYTES = 1_500_000

# name -> (compiled pattern, category). Ordered scan over every text line.
PATTERNS: dict[str, tuple[re.Pattern, str]] = {
    # --- orchestration frameworks -------------------------------------------
    "langgraph":      (re.compile(r"\blanggraph\b|\bStateGraph\b|\bcreate_react_agent\b", re.I), "framework"),
    "langchain":      (re.compile(r"\blangchain\b|\bAgentExecutor\b|\binitialize_agent\b", re.I), "framework"),
    "crewai":         (re.compile(r"\bcrewai\b", re.I), "framework"),
    "llamaindex":     (re.compile(r"\bllama_index\b|\bllamaindex\b", re.I), "framework"),
    "dataiku":        (re.compile(r"\bdataiku\b|\bdataikuapi\b", re.I), "framework"),
    "semantic_kernel": (re.compile(r"\bsemantic_kernel\b", re.I), "framework"),
    "autogen":        (re.compile(r"\bautogen\b", re.I), "framework"),
    # --- model providers ------------------------------------------------------
    "bedrock":        (re.compile(r"bedrock[-\w]*|\banthropic\.claude[-.\w:]*|\bmistral\.[-\w]+", re.I), "model_provider"),
    "openai":         (re.compile(r"\bopenai\b|\bAzureOpenAI\b|\bgpt-[45][\w.-]*", re.I), "model_provider"),
    "anthropic_sdk":  (re.compile(r"\banthropic\b(?!\.claude)", re.I), "model_provider"),
    "huggingface":    (re.compile(r"\btransformers\b|\bhuggingface\b|\bAutoModel\w*\b", re.I), "model_provider"),
    "vertexai":       (re.compile(r"\bvertexai\b|\bgoogle\.generativeai\b", re.I), "model_provider"),
    "ollama":         (re.compile(r"\bollama\b", re.I), "model_provider"),
    # --- retrieval ------------------------------------------------------------
    "chroma":         (re.compile(r"\bchromadb\b|\bChroma\b", re.I), "vector_store"),
    "faiss":          (re.compile(r"\bfaiss\b", re.I), "vector_store"),
    "pinecone":       (re.compile(r"\bpinecone\b", re.I), "vector_store"),
    "qdrant":         (re.compile(r"\bqdrant\b", re.I), "vector_store"),
    "weaviate":       (re.compile(r"\bweaviate\b", re.I), "vector_store"),
    "pgvector":       (re.compile(r"\bpgvector\b|\bvector\(\d+\)", re.I), "vector_store"),
    "opensearch":     (re.compile(r"\bopensearch\b|\belasticsearch\b", re.I), "vector_store"),
    "embeddings":     (re.compile(r"\bembed_documents\b|\bembed_query\b|\bEmbeddings\b|\bSentenceTransformer\b", re.I), "retrieval_signal"),
    "similarity":     (re.compile(r"similarity_search|\bas_retriever\b|\bvectorstore\b|\bretriever\b"
                                  # native vector-store APIs, not only the LangChain vocabulary
                                  r"|\bquery_texts\b|\bn_results\b|\bget_or_create_collection\b"
                                  r"|\bquery_embeddings\b|\btop_k\b|\.search\(\s*collection_name", re.I), "retrieval_signal"),
    # --- agentic signals ------------------------------------------------------
    "tool_decorator": (re.compile(r"^\s*@tool\b|@tool\(|\bStructuredTool\b|\bTool\.from_function\b"), "tool_definition"),
    "tool_binding":   (re.compile(r"\bbind_tools\b|\btools\s*=\s*\[|\btool_choice\b|\bfunction_call\b"), "tool_definition"),
    "mcp":            (re.compile(r"\bmcp\b|\bModelContextProtocol\b|\bmcp\.json\b", re.I), "tool_definition"),
    "react_loop":     (re.compile(r"\bReAct\b|\bAgentExecutor\b|\bcreate_react_agent\b|\bagent_scratchpad\b"), "autonomy_signal"),
    "planning":       (re.compile(r"\bplanner\b|\bdecompose\b|\bsubtask\b|\bsub_?agent\b|\bspawn\w*\b"
                                  r"|\breplan\w*\b|\bcreate_plan\b|\btask_graph\b|\bdelegate\b"
                                  r"|\borchestrator\b|\btrajectory\b", re.I), "autonomy_signal"),
    "memory":         (re.compile(r"\bConversationBufferMemory\b|\bcheckpointer\b|\bMemorySaver\b"
                                  r"|\blong_?term_?memory\b|\bpersistent_?memory\b|\bepisodic\b"
                                  r"|\bsession_recall\b|\bmemory_store\b", re.I), "autonomy_signal"),
    # An agent that writes its own tools or skills at runtime is self-directed by
    # definition - the strongest L3 marker there is, and one that name-based planning
    # patterns miss entirely.
    "self_extension": (re.compile(r"\bcreate_skill\b|\bregister_skill\b|\bskill_creation\b"
                                  r"|\bwrite_tool\b|\bgenerate_tool\b|\bself_?improv\w*\b"
                                  r"|\bskills?_dir\b|\bautonomous_?skill\w*\b", re.I), "autonomy_signal"),
    "prompt_template": (re.compile(r"\bPromptTemplate\b|\bChatPromptTemplate\b|\bsystem_prompt\b|\bSYSTEM_PROMPT\b"), "prompt_signal"),
    # --- observability / evaluation ------------------------------------------
    "mlflow":         (re.compile(r"\bmlflow\b", re.I), "observability"),
    "langfuse":       (re.compile(r"\blangfuse\b", re.I), "observability"),
    "langsmith":      (re.compile(r"\blangsmith\b|LANGCHAIN_TRACING", re.I), "observability"),
    "opentelemetry":  (re.compile(r"\bopentelemetry\b|\botel\b", re.I), "observability"),
    "deepeval":       (re.compile(r"\bdeepeval\b", re.I), "evaluation"),
    "ragas":          (re.compile(r"\bragas\b", re.I), "evaluation"),
    "deepteam":       (re.compile(r"\bdeepteam\b", re.I), "security"),
    "guardrails":     (re.compile(r"\bguardrail\w*\b|\bnemoguardrails\b|\bllm_guard\b", re.I), "security"),
    # --- record keeping signals ----------------------------------------------
    "logging_call":   (re.compile(r"\blogger\.(debug|info|warning|error|critical)\b|\blogging\.(debug|info|warning|error|critical)\b"), "logging"),
    "structured_log": (re.compile(r"\bstructlog\b|\bjson_?log\w*\b|JsonFormatter|\bpython-json-logger\b", re.I), "logging"),
    "print_log":      (re.compile(r"^\s*print\("), "logging"),
    "audit_trail":    (re.compile(r"\baudit\w*\b|\btrace_id\b|\bcorrelation_id\b|\bsession_id\b", re.I), "logging"),
    # --- human oversight signals ---------------------------------------------
    "feedback":       (re.compile(r"thumbs?_?(up|down)|\bfeedback\b|\brating\b|\bflag_output\b", re.I), "oversight"),
    "kill_switch":    (re.compile(r"\bkill_switch\b|\bemergency_stop\b|\bdisable_system\b|\bcircuit_breaker\b", re.I), "oversight"),
    "human_approval": (re.compile(r"\bhuman_in_the_loop\b|\brequire_approval\b|\bconfirm\w*\(|\binterrupt\b", re.I), "oversight"),
    "citation":       (re.compile(r"\bsource_documents\b|\bcitations?\b|\breferences?\b\s*[:=]", re.I), "oversight"),
    # --- side effects ---------------------------------------------------------
    "send_email":     (re.compile(r"\bsmtplib\b|\bsend_email\b|\bsendmail\b|\bsend_message\b", re.I), "side_effect"),
    "file_write":     (re.compile(r"open\([^)]*['\"][wax]|\.write_text\(|\.to_csv\(|shutil\.(move|copy)"), "side_effect"),
    "delete":         (re.compile(r"\bos\.remove\b|\bshutil\.rmtree\b|\bunlink\(|\bDELETE\s+FROM\b", re.I), "side_effect"),
    "http_write":     (re.compile(r"requests\.(post|put|patch|delete)\(|httpx\.(post|put|patch|delete)\("), "side_effect"),
    "db_write":       (re.compile(r"\bINSERT\s+INTO\b|\bUPDATE\s+\w+\s+SET\b|\.commit\(\)", re.I), "side_effect"),
    # --- API surface ----------------------------------------------------------
    "fastapi_route":  (re.compile(r"@\w+\.(get|post|put|patch|delete)\(['\"]([^'\"]+)"), "endpoint"),
    "flask_route":    (re.compile(r"@\w+\.route\(['\"]([^'\"]+)"), "endpoint"),
    "health_probe":   (re.compile(r"['\"]/(health|healthz|ready|readyz|livez|ping)['\"]", re.I), "endpoint"),
}

MODEL_ID = re.compile(
    r"(anthropic\.claude[\w.\-:]+|mistral\.[\w.\-:]+|meta\.llama[\w.\-:]+|amazon\.titan[\w.\-:]+"
    r"|gpt-[45][\w.\-]*|o[13]-[\w.\-]+|gemini-[\w.\-]+|claude-[\w.\-]+)", re.I,
)
AWS_REGION = re.compile(
    r"\b((?:eu|us|ap|ca|sa|me|af)-(?:central|west|east|north|south|northeast|southeast)-\d)\b"
)


def rel(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.as_posix()


def iter_text_files(root: Path):
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        # Filter the path below the root only: testing the absolute path would skip
        # every file of a project living under a directory called build, env or venv.
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        if TEST_FILE.match(path.name):
            continue
        name = path.name.lower()
        if path.suffix.lower() in TEXT_SUFFIXES or name in {"dockerfile", "makefile", "pipfile"}:
            try:
                if path.stat().st_size > MAX_FILE_BYTES:
                    continue
            except OSError:
                continue
            yield path


def scan_files(root: Path) -> tuple[dict, dict, int]:
    """Return (findings, endpoints, files_scanned).

    findings: pattern name -> {"category": str, "hits": int, "evidence": [ "path:line", ... ]}
    """
    findings: dict[str, dict] = {}
    endpoints: list[dict] = []
    models: dict[str, list[str]] = defaultdict(list)
    regions: dict[str, list[str]] = defaultdict(list)
    scanned = 0

    for path in iter_text_files(root):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        scanned += 1
        where = rel(path, root)
        for lineno, line in enumerate(text.splitlines(), 1):
            if len(line) > 1000:
                line = line[:1000]
            for name, (pattern, category) in PATTERNS.items():
                m = pattern.search(line)
                if not m:
                    continue
                entry = findings.setdefault(name, {"category": category, "hits": 0, "evidence": []})
                entry["hits"] += 1
                if len(entry["evidence"]) < 8:          # keep proof, not a dump
                    entry["evidence"].append(f"{where}:{lineno}")
                if category == "endpoint" and m.groups():
                    route = next((g for g in m.groups() if g and g.startswith("/")), None)
                    if route and not any(e["route"] == route for e in endpoints):
                        method = m.group(1).upper() if m.group(1) and not m.group(1).startswith("/") else "ANY"
                        endpoints.append({"route": route, "method": method, "evidence": f"{where}:{lineno}"})
            for mid in MODEL_ID.findall(line):
                if len(models[mid]) < 4:
                    models[mid].append(f"{where}:{lineno}")
            for reg in AWS_REGION.findall(line):
                if len(regions[reg]) < 2:
                    regions[reg].append(f"{where}:{lineno}")

    return findings, {"endpoints": endpoints, "models": dict(models), "regions": dict(regions)}, scanned


def read_dependencies(root: Path) -> dict:
    deps: dict[str, dict] = {}

    req = root / "requirements.txt"
    if req.exists():
        for lineno, line in enumerate(req.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
            line = line.split("#")[0].strip()
            if not line or line.startswith("-"):
                continue
            m = re.match(r"^([A-Za-z0-9_.\-\[\]]+)\s*([=<>!~]=?.*)?$", line)
            if m:
                deps[m.group(1).lower()] = {"version": (m.group(2) or "").strip() or None,
                                            "evidence": f"requirements.txt:{lineno}"}

    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8", errors="ignore")
        for lineno, line in enumerate(text.splitlines(), 1):
            m = re.match(r'^\s*["\']?([A-Za-z0-9_.\-]+)["\']?\s*[=><~^]+\s*["\']([^"\']+)["\']', line)
            if m and m.group(1).lower() not in {"name", "version", "description", "requires-python"}:
                deps.setdefault(m.group(1).lower(), {"version": m.group(2), "evidence": f"pyproject.toml:{lineno}"})
            m2 = re.match(r'^\s*["\']([A-Za-z0-9_.\-\[\]]+)\s*([=<>!~][^"\']*)?["\'],?\s*$', line)
            if m2:
                deps.setdefault(m2.group(1).lower(), {"version": (m2.group(2) or "").strip() or None,
                                                      "evidence": f"pyproject.toml:{lineno}"})

    pkg = root / "package.json"
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8", errors="ignore"))
            for section in ("dependencies", "devDependencies"):
                for name, version in (data.get(section) or {}).items():
                    deps.setdefault(name.lower(), {"version": version, "evidence": "package.json"})
        except json.JSONDecodeError:
            pass

    return deps


def read_git(root: Path) -> dict:
    def run(*args: str) -> str | None:
        try:
            out = subprocess.run(["git", "-C", str(root), *args],
                                 capture_output=True, text=True, timeout=10)
            return out.stdout.strip() or None if out.returncode == 0 else None
        except (OSError, subprocess.SubprocessError):
            return None

    if run("rev-parse", "--is-inside-work-tree") != "true":
        return {"available": False}
    return {
        "available": True,
        "commit": run("rev-parse", "HEAD"),
        "branch": run("rev-parse", "--abbrev-ref", "HEAD"),
        "remote": run("config", "--get", "remote.origin.url"),
        "last_commit_date": run("log", "-1", "--format=%cI"),
        "tag": run("describe", "--tags", "--abbrev=0"),
        "contributors": (run("shortlog", "-sne", "HEAD") or "").splitlines()[:10],
    }


def detect_infrastructure(root: Path) -> dict:
    def present(*names: str) -> list[str]:
        found = []
        for name in names:
            hits = [rel(p, root) for p in root.rglob(name)
                    if p.is_file() and not any(part in SKIP_DIRS for part in p.parts)]
            found.extend(hits[:3])
        return found

    return {
        "docker": present("Dockerfile", "docker-compose.yml", "docker-compose.yaml"),
        "kubernetes": present("*.k8s.yaml", "deployment.yaml", "helmfile.yaml", "Chart.yaml"),
        "ci": present(".gitlab-ci.yml", "*.github/workflows/*.yml", "Jenkinsfile"),
        "tests": present("test_*.py", "*_test.py", "conftest.py")[:5],
        "iac": present("*.tf", "serverless.yml"),
        "env_files": present(".env.example", ".env.sample"),
    }


def classify(findings: dict, deps: dict) -> dict:
    """Apply the AI Factory taxonomy: family, then agentic autonomy level."""
    def hit(name: str) -> int:
        return findings.get(name, {}).get("hits", 0)

    def ev(*names: str) -> list[str]:
        out: list[str] = []
        for n in names:
            out.extend(findings.get(n, {}).get("evidence", [])[:3])
        return out[:8]

    retrieval = hit("similarity") + hit("embeddings") + sum(
        hit(v) for v in ("chroma", "faiss", "pinecone", "qdrant", "weaviate", "pgvector", "opensearch")
    )
    tools = hit("tool_decorator") + hit("tool_binding") + hit("mcp")
    react = hit("react_loop")
    self_extension = hit("self_extension")
    deep = hit("planning") + hit("memory") + self_extension
    prompts = hit("prompt_template")

    is_rag = retrieval >= 2
    is_agentic = tools >= 1

    if is_rag and is_agentic:
        family, family_ev = "hybrid", ev("similarity", "tool_decorator", "tool_binding")
    elif is_rag:
        family, family_ev = "rag", ev("similarity", "embeddings", "chroma", "faiss", "qdrant")
    elif is_agentic:
        family, family_ev = "agentic", ev("tool_decorator", "tool_binding", "mcp")
    elif prompts:
        family, family_ev = "prompt", ev("prompt_template")
    else:
        family, family_ev = "unknown", []

    level = None
    level_reason = None
    level_ev: list[str] = []
    if is_agentic:
        if self_extension >= 1:
            level = "L3"
            level_reason = ("The system creates or registers its own tools or skills at runtime, so "
                            "its capability set is not fixed at design time - Deep Agent.")
            level_ev = ev("self_extension", "planning", "memory")
        elif deep >= 2 and hit("planning") >= 1:
            level = "L3"
            level_reason = ("Autonomous planning and/or sub-agent spawning with long-horizon memory "
                            "detected - Deep Agent.")
            level_ev = ev("planning", "memory")
        elif react >= 1:
            level = "L2"
            level_reason = ("The LLM drives tool selection (ReAct loop). Per the escalation rule, this "
                            "makes the whole system L2 even if it sits inside a deterministic workflow.")
            level_ev = ev("react_loop", "tool_binding")
        else:
            level = "L1"
            level_reason = ("Tools are invoked on hardcoded paths; no evidence the LLM chooses the "
                            "execution path.")
            level_ev = ev("tool_decorator", "tool_binding")

    signals = {"retrieval": retrieval, "tools": tools, "react": react, "deep": deep,
               "self_extension": self_extension, "prompts": prompts}
    strong = max(signals.values()) if signals else 0
    certainty = "high" if strong >= 5 else "medium" if strong >= 2 else "low"

    return {
        "family": family,
        "family_evidence": family_ev,
        "agentic_level": level,
        "agentic_level_reason": level_reason,
        "agentic_level_evidence": level_ev,
        "certainty": certainty,
        "signal_counts": signals,
        "reference_framework": next(
            (f for f in ("langgraph", "langchain", "crewai", "llamaindex", "dataiku", "autogen")
             if f in findings or f in deps), None,
        ),
        "note": ("Classification is derived from code signals only. Confirm with the risk owner before "
                 "writing it into the technical documentation."),
    }


def build_context(root: Path) -> dict:
    findings, extra, scanned = scan_files(root)
    deps = read_dependencies(root)
    by_category: dict[str, dict] = defaultdict(dict)
    for name, data in findings.items():
        by_category[data["category"]][name] = {"hits": data["hits"], "evidence": data["evidence"]}

    logging_cat = by_category.get("logging", {})
    return {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "project": {
            "path": str(root.resolve()),
            "name": root.resolve().name,
            "files_scanned": scanned,
        },
        "git": read_git(root),
        "classification": classify(findings, deps),
        "frameworks": by_category.get("framework", {}),
        "model_providers": by_category.get("model_provider", {}),
        "models": extra["models"],
        "regions": extra["regions"],
        "vector_stores": by_category.get("vector_store", {}),
        "retrieval_signals": by_category.get("retrieval_signal", {}),
        "tool_definitions": by_category.get("tool_definition", {}),
        "autonomy_signals": by_category.get("autonomy_signal", {}),
        "prompt_signals": by_category.get("prompt_signal", {}),
        "observability": by_category.get("observability", {}),
        "evaluation": by_category.get("evaluation", {}),
        "security": by_category.get("security", {}),
        "logging": {
            "calls": logging_cat,
            "structured": "structured_log" in logging_cat,
            "uses_print": "print_log" in logging_cat,
            "has_correlation_id": "audit_trail" in logging_cat,
        },
        "oversight_signals": by_category.get("oversight", {}),
        "side_effects": by_category.get("side_effect", {}),
        "endpoints": extra["endpoints"],
        "endpoint_signals": by_category.get("endpoint", {}),
        "infrastructure": detect_infrastructure(root),
        "dependencies": deps,
    }


def summarise(ctx: dict) -> str:
    c = ctx["classification"]
    level = f" / {c['agentic_level']}" if c["agentic_level"] else ""
    lines = [
        f"Project           : {ctx['project']['name']}  ({ctx['project']['files_scanned']} files scanned)",
        f"Classification    : {c['family']}{level}   (certainty: {c['certainty']})",
        f"Reference stack   : {c['reference_framework'] or 'none detected'}",
        f"Models            : {', '.join(list(ctx['models'])[:4]) or 'none detected'}",
        f"Vector stores     : {', '.join(ctx['vector_stores']) or 'none'}",
        f"Observability     : {', '.join(ctx['observability']) or 'NONE - record keeping gap'}",
        f"Evaluation        : {', '.join(ctx['evaluation']) or 'NONE'}",
        f"Endpoints         : {len(ctx['endpoints'])} found",
        f"Structured logging: {'yes' if ctx['logging']['structured'] else 'NO - REC-FORMAT not met'}",
        f"Side-effect kinds : {', '.join(ctx['side_effects']) or 'none'}",
        f"Dependencies      : {len(ctx['dependencies'])}",
    ]
    if c["agentic_level_reason"]:
        lines.append(f"Level rationale   : {c['agentic_level_reason']}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Scan a project into an AIDA context file.")
    parser.add_argument("project", nargs="?", default=".", help="project directory (default: .)")
    parser.add_argument("--out", default="aida/context.json", help="output path (default: aida/context.json)")
    parser.add_argument("--quiet", action="store_true", help="write the file, print nothing")
    args = parser.parse_args()

    root = Path(args.project).expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    ctx = build_context(root)
    # A relative --out is relative to the current directory, never to the scanned
    # project: scanning a repository must not write anything into it.
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(ctx, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    if not args.quiet:
        print(summarise(ctx))
        print(f"\ncontext written to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
