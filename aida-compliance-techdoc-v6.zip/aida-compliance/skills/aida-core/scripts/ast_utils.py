"""Syntax-tree helpers shared by the audits that read Python source.

Standard library only.
"""

from __future__ import annotations

import ast


def dotted(node: ast.AST) -> str:
    """Best-effort dotted name of a call target, lowercased: requests.post, shutil.rmtree.

    A call on anything that is not a plain name chain (a subscript, a call result) keeps
    only the attribute part, so `clients[0].post` gives `post`.
    """
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return ".".join(reversed(parts)).lower()
