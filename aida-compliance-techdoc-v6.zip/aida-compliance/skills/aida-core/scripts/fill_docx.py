#!/usr/bin/env python3
"""Write values into the official AIDA template without disturbing its formatting.

    python fill_docx.py --values aida/values.json --out aida/technical_documentation.docx
    python fill_docx.py --values aida/values.json --dry-run

Two things make this harder than a string replace, and both are handled here:

* Word splits a single visible `{placeholder}` across several <w:r> runs, so the braces
  are rarely adjacent in the XML. Paragraph text is reassembled, matched, then written
  back into the first run of the span - which keeps that run's formatting.
* ElementTree rewrites namespace prefixes on round-trip and Word refuses the result.
  Every prefix declared in the document is re-registered before parsing.

Anything without a value becomes `[A CONFIRMER - ...]`. Nothing is ever invented.
Standard library only.
"""

from __future__ import annotations

import argparse
import copy
import json
import re
import shutil
import sys
import zipfile
from datetime import date
from pathlib import Path
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
XML_NS = "{http://www.w3.org/XML/1998/namespace}"
PLACEHOLDER = re.compile(r"\{([^{}]{3,})\}")
NS_DECL = re.compile(rb'xmlns:([A-Za-z0-9_.\-]+)="([^"]+)"')
XML_DECL = b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from placeholder_map import is_instruction  # noqa: E402  (sibling script, same folder)

DEFAULT_TEMPLATE = HERE.parent / "assets" / "templates" / "technical_documentation.docx"
PARTS_TO_FILL = ("word/document.xml", "word/header1.xml", "word/header2.xml", "word/header3.xml")


def register_namespaces(raw: bytes) -> None:
    """Keep w:, r:, mc: ... intact. Without this the output does not open in Word."""
    for prefix, uri in NS_DECL.findall(raw):
        try:
            ET.register_namespace(prefix.decode(), uri.decode())
        except ValueError:
            pass


def paragraph_runs(para: ET.Element) -> list[ET.Element]:
    return [t for t in para.iter(W + "t")]


def splice(texts: list[str], start: int, end: int, value: str) -> None:
    """Replace characters [start, end) of the concatenated run texts with `value`.

    The value goes into the run where the placeholder starts, so it keeps that run's
    formatting; the runs the placeholder spanned are emptied, not removed.
    """
    offsets, cursor = [], 0
    for text in texts:
        offsets.append(cursor)
        cursor += len(text)

    def locate(pos: int) -> tuple[int, int]:
        index = max(i for i, offset in enumerate(offsets) if offset <= pos)
        return index, pos - offsets[index]

    first, head = locate(start)
    last, tail = locate(end - 1)
    if first == last:
        texts[first] = texts[first][:head] + value + texts[first][tail + 1:]
        return
    texts[first] = texts[first][:head] + value
    for middle in range(first + 1, last):
        texts[middle] = ""
    texts[last] = texts[last][tail + 1:]


def fill_paragraph(para: ET.Element, resolver) -> int:
    """Replace every {placeholder} in one paragraph. Returns how many were replaced."""
    nodes = paragraph_runs(para)
    texts = [n.text or "" for n in nodes]
    matches = list(PLACEHOLDER.finditer("".join(texts)))
    # Reverse order so the offsets of earlier matches stay valid while we mutate.
    for match in reversed(matches):
        splice(texts, match.start(), match.end(), resolver(" ".join(match.group(1).split())))
    for node, text in zip(nodes, texts):
        node.text = text
        if text != text.strip():
            node.set(XML_NS + "space", "preserve")
    return len(matches)


def fill_part(raw: bytes, resolver) -> tuple[bytes, int]:
    register_namespaces(raw)
    root = ET.fromstring(raw)
    replaced = sum(fill_paragraph(para, resolver) for para in root.iter(W + "p"))
    if not replaced:
        return raw, 0
    return XML_DECL + ET.tostring(root, encoding="utf-8"), replaced


def build_resolver(values: dict, routing: dict, missing: list, kept: list):
    """placeholder text -> the string that replaces it in the document."""
    def resolve(key: str) -> str:
        if is_instruction(key):               # author guidance: keep the text, drop the braces
            kept.append(key)
            return key
        entry = values.get(key)
        if isinstance(entry, dict):
            value = entry.get("value")
            evidence = entry.get("evidence") or []
            if value:
                text = f"{value} [{', '.join(evidence)}]" if evidence else str(value)
                return number_embedded(text, key)
        elif isinstance(entry, str) and entry.strip():
            return number_embedded(entry, key)
        route = routing.get(key, {})
        source = route.get("source", "human")
        note = route.get("note") or DEFAULT_NOTES[source]
        return open_point(key, source, note)

    def open_point(key: str, source: str, note: str) -> str:
        # Every open point gets a reference number, so the closing section of the document
        # can list them and a reader can find each one in the text.
        ref = f"#{len(missing) + 1:02d}"
        missing.append({"ref": ref, "placeholder": key, "source": source, "note": note,
                        "section": routing.get(key, {}).get("section", "")})
        return f"[A CONFIRMER {ref} - {note}]"

    def number_embedded(text: str, key: str) -> str:
        """An answered field can still contain an open point - the autonomy justification
        inside the model logic, the rollback inside the CI/CD answer. Number those too, or
        the closing section would miss them."""
        return EMBEDDED.sub(lambda m: open_point(key, "partial", m.group(1).strip()), text)

    resolve.number_embedded = number_embedded
    return resolve


def insert_figures(raw: bytes, figures: list[dict], resolver) -> tuple[bytes, int]:
    """Place each generated figure at the end of its section.

    A figure is its Mermaid source, one monospace line per paragraph, framed by a title and
    a caption that cites the evidence. Word does not render Mermaid, so the source is the
    figure itself, reproducible in any Mermaid viewer; the chart is also written as SVG.
    """
    register_namespaces(raw)
    root = ET.fromstring(raw)
    body = root.find(W + "body")
    if body is None:
        return raw, 0

    def is_heading(element) -> bool:
        ppr = element.find(W + "pPr") if element.tag == W + "p" else None
        style = ppr.find(W + "pStyle") if ppr is not None else None
        return style is not None and bool(
            re.match(r"(?:Heading|Titre|heading)\d", style.get(W + "val") or ""))

    def text_of(element) -> str:
        return "".join(node.text or "" for node in element.iter(W + "t")).strip()

    def run(parent, text: str, *, bold=False, italic=False, mono=False):
        node = ET.SubElement(parent, W + "r")
        if bold or italic or mono:
            props = ET.SubElement(node, W + "rPr")
            if mono:
                fonts = ET.SubElement(props, W + "rFonts")
                for attr in ("ascii", "hAnsi", "cs"):
                    fonts.set(W + attr, "Courier New")
            if bold:
                ET.SubElement(props, W + "b")
            if italic:
                ET.SubElement(props, W + "i")
            if mono:
                ET.SubElement(props, W + "sz").set(W + "val", "16")
        leaf = ET.SubElement(node, W + "t")
        leaf.text = text
        leaf.set(XML_NS + "space", "preserve")

    def paragraph(text: str, **style) -> ET.Element:
        para = ET.Element(W + "p")
        run(para, text, **style)
        return para

    placed = 0
    for figure in figures:
        children = list(body)
        start = next((i for i, el in enumerate(children) if is_heading(el)
                      and text_of(el).lower().startswith(figure["section"].lower())), None)
        if start is None:
            continue
        end = next((i for i in range(start + 1, len(children)) if is_heading(children[i])),
                   len(children) - 1)
        block = [paragraph(figure["title"], bold=True)]
        for line in (figure.get("source") or "").splitlines():
            block.append(paragraph(line, mono=True))
        caption = resolver.number_embedded(figure.get("caption", ""), figure["title"])
        block.append(paragraph(caption, italic=True))
        for offset, element in enumerate(block):
            body.insert(end + offset, element)
        placed += 1
    return XML_DECL + ET.tostring(root, encoding="utf-8"), placed


W14 = "{http://schemas.microsoft.com/office/word/2010/wordml}"


def fill_journal(raw: bytes, rows: list[dict], resolver) -> tuple[bytes, int]:
    """Write the AI System Journal rows into the appendix table (DOC-JOURNAL).

    The template's table has a header, an "(Example: ...)" row and an empty row. The empty
    row is the prototype: it is copied once per entry, so every row keeps the template's
    cell widths and styles, and the example row - guidance, not an event - is removed.
    """
    register_namespaces(raw)
    root = ET.fromstring(raw)
    body = root.find(W + "body")
    if body is None or not rows:
        return raw, 0
    children = list(body)
    heading = next((i for i, el in enumerate(children) if el.tag == W + "p"
                    and "".join(n.text or "" for n in el.iter(W + "t")).strip()
                    .startswith("Appendix")), None)
    table = next((el for el in children[(heading or 0) + 1:] if el.tag == W + "tbl"), None)
    if heading is None or table is None:
        return raw, 0
    template_rows = table.findall(W + "tr")
    if len(template_rows) < 2:
        return raw, 0
    prototype = template_rows[-1]
    for row in template_rows[1:]:
        table.remove(row)

    for entry in rows:
        row = copy.deepcopy(prototype)
        for element in row.iter():             # paragraph ids must stay unique in Word
            for attr in (W14 + "paraId", W14 + "textId"):
                element.attrib.pop(attr, None)
        cells = row.findall(W + "tc")
        texts = (entry["event"], entry["description"], entry["measures"])
        for cell, text in zip(cells, texts):
            para = cell.find(W + "p")
            if para is None:
                para = ET.SubElement(cell, W + "p")
            run = ET.SubElement(para, W + "r")
            leaf = ET.SubElement(run, W + "t")
            leaf.text = resolver.number_embedded(text, "AI System Journal")
            leaf.set(XML_NS + "space", "preserve")
        table.append(row)
    return XML_DECL + ET.tostring(root, encoding="utf-8"), len(rows)


DEFAULT_NOTES = {
    "human": "to be provided by the risk owner",
    "external": "link to the internal system holding this",
    "rule": "derive from the guideline rule",
    "code": "not found in the codebase",
}
EMBEDDED = re.compile(r"\[A CONFIRMER - ([^\]]+)\]")
OWNERS = {
    "human": "Risk owner",
    "partial": "Risk owner",
    "rule": "Risk owner - apply the guideline rule",
    "external": "Owner of the internal document (GAD, RPAD, MESARI, NSU, MLflow run)",
    "code": "Development team - no evidence found in the code",
}
FOLLOW_UP = [
    "The risk owner answers the open points assigned to them and each answer is recorded "
    "with who confirmed it and when.",
    "The internal documents referenced as external open points are linked in place.",
    "The answers are re-validated (validate_values.py) and the document regenerated; "
    "answers already confirmed are kept.",
    "The freshness state is recorded, and the document is regenerated after any "
    "substantial change to the system (DOC-UPDATE-ON-CHANGE).",
    "Once no open point remains, the document is submitted to the AIDA validation process "
    "and the outcome recorded in the Model Validation section.",
]


def closing_section(raw: bytes, missing: list[dict], fields: int, filled: int) -> bytes:
    """Append a completion status section at the end of the document body.

    The template has no field for it, but a technical documentation that leaves open points
    must say so where a reader will look last: how complete it is, what is still missing and
    from whom, and what happens next.
    """
    register_namespaces(raw)
    root = ET.fromstring(raw)
    body = root.find(W + "body")
    if body is None:
        return raw

    heading_ppr = None
    for para in body.iter(W + "p"):
        ppr = para.find(W + "pPr")
        style = ppr.find(W + "pStyle") if ppr is not None else None
        if style is not None and re.match(r"(?:Heading|Titre|heading)1$", style.get(W + "val") or ""):
            heading_ppr = copy.deepcopy(ppr)
            numbering = heading_ppr.find(W + "numPr")
            if numbering is not None:            # an unnumbered heading, after the appendix
                heading_ppr.remove(numbering)
            break

    def paragraph(text: str, ppr=None, bold: bool = False) -> ET.Element:
        para = ET.Element(W + "p")
        if ppr is not None:
            para.append(copy.deepcopy(ppr))
        run = ET.SubElement(para, W + "r")
        if bold:
            ET.SubElement(ET.SubElement(run, W + "rPr"), W + "b")
        node = ET.SubElement(run, W + "t")
        node.text = text
        node.set(XML_NS + "space", "preserve")
        return para

    by_owner: dict[str, int] = {}
    for item in missing:
        owner = OWNERS.get(item["source"], "Risk owner")
        by_owner[owner] = by_owner.get(owner, 0) + 1

    added = [paragraph("Document completion status", heading_ppr, bold=heading_ppr is None)]
    added.append(paragraph(
        f"Generated on {date.today().isoformat()} from the codebase. {filled} of {fields} "
        f"fields are answered from evidence found in the code or from a guideline rule, each "
        f"with its source. {len(missing)} open point(s) remain; each is marked in the text "
        f"with the reference number listed below."))
    if missing:
        added.append(paragraph("Open points by owner", bold=True))
        for owner, count in sorted(by_owner.items(), key=lambda item: -item[1]):
            added.append(paragraph(f"{owner}: {count}"))
        added.append(paragraph("Open points", bold=True))
        for item in missing:
            where = f"{item['section']} - " if item.get("section") else ""
            question = item["placeholder"] if len(item["placeholder"]) <= 90 \
                else item["placeholder"][:87] + "..."
            added.append(paragraph(
                f"{item['ref']}  {where}{question} - owner: "
                f"{OWNERS.get(item['source'], 'Risk owner')} - {item['note']}"))
    added.append(paragraph("Follow-up actions", bold=True))
    for number, action in enumerate(FOLLOW_UP, 1):
        added.append(paragraph(f"{number}. {action}"))
    added.append(paragraph(
        "This document is not final while an open point remains. It is an input to the AIDA "
        "validation, not a substitute for it."))

    section_properties = body.find(W + "sectPr")
    position = list(body).index(section_properties) if section_properties is not None else len(body)
    for offset, element in enumerate(added):
        body.insert(position + offset, element)
    return XML_DECL + ET.tostring(root, encoding="utf-8")


def load_routing(path: Path) -> dict:
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return {p["placeholder"]: p for p in data.get("placeholders", [])}


def main() -> int:
    parser = argparse.ArgumentParser(description="Fill the AIDA technical documentation template.")
    parser.add_argument("--template", default=str(DEFAULT_TEMPLATE))
    parser.add_argument("--values", default="aida/values.json",
                        help="placeholder -> value (or {value, evidence}) mapping")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json",
                        help="placeholder map from placeholder_map.py, used for the [A CONFIRMER] notes")
    parser.add_argument("--out", default="aida/technical_documentation.docx")
    parser.add_argument("--figures", default="aida/figures.json",
                        help="figures from render_figures.py, inserted into their sections")
    parser.add_argument("--journal", default="aida/journal.json",
                        help="AI System Journal rows from write_journal.py (appendix)")
    parser.add_argument("--dry-run", action="store_true", help="report coverage, write nothing")
    args = parser.parse_args()

    template = Path(args.template)
    if not template.exists():
        print(f"error: template not found: {template}", file=sys.stderr)
        return 2

    values_path = Path(args.values)
    values = json.loads(values_path.read_text(encoding="utf-8")) if values_path.exists() else {}
    if isinstance(values, dict) and "values" in values:
        values = values["values"]
    routing = load_routing(Path(args.routing))

    missing: list[dict] = []
    kept: list[str] = []
    resolver = build_resolver(values, routing, missing, kept)

    with zipfile.ZipFile(template) as src:
        parts = {name: src.read(name) for name in src.namelist()}

    total = 0
    rewritten: dict[str, bytes] = {}
    for name in PARTS_TO_FILL:
        if name in parts:
            new_raw, count = fill_part(parts[name], resolver)
            rewritten[name] = new_raw
            total += count

    fields = total - len(kept)
    filled = fields - len({item["placeholder"] for item in missing
                           if item["source"] != "partial"})
    pct = (filled * 100 // fields) if fields else 0
    print(f"Placeholders in document : {total}   ({len(kept)} template guidance, kept as-is)")
    print(f"Fields to answer         : {fields}")
    print(f"Filled from evidence     : {filled}  ({pct}%)")
    print(f"Left as [A CONFIRMER]    : {len(missing)}")
    if missing:
        by_source: dict[str, int] = {}
        for item in missing:
            by_source[item["source"]] = by_source.get(item["source"], 0) + 1
        print("  " + ", ".join(f"{k}: {v}" for k, v in sorted(by_source.items())))

    if args.dry_run:
        print("\ndry run - no file written")
        return 0

    figures_path = Path(args.figures)
    if figures_path.exists() and "word/document.xml" in rewritten:
        figures = json.loads(figures_path.read_text(encoding="utf-8"))
        rewritten["word/document.xml"], placed = insert_figures(
            rewritten["word/document.xml"], figures, resolver)
        print(f"Figures inserted         : {placed}")

    journal_path = Path(args.journal)
    if journal_path.exists() and "word/document.xml" in rewritten:
        journal = json.loads(journal_path.read_text(encoding="utf-8"))
        rewritten["word/document.xml"], written = fill_journal(
            rewritten["word/document.xml"], journal, resolver)
        print(f"Journal rows written     : {written}")

    if "word/document.xml" in rewritten:
        rewritten["word/document.xml"] = closing_section(
            rewritten["word/document.xml"], missing, fields, filled)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        backup = out.with_suffix(out.suffix + ".bak")
        shutil.copy2(out, backup)
        print(f"\nprevious version kept as {backup}")

    # Rebuild the package: same entries, same order, only the filled parts differ.
    with zipfile.ZipFile(template) as src, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            payload = rewritten.get(info.filename, parts[info.filename])
            dst.writestr(info, payload)

    print(f"\ndocument written to {out}")
    if missing:
        report = out.with_name(out.stem + "_a_confirmer.json")
        report.write_text(json.dumps(missing, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"open points listed in {report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
