#!/usr/bin/env python3
"""Generate the two figures the technical documentation needs, from evidence only.

    python render_figures.py --context aida/context.json [--aida aida]

* Section 3.5 - an architecture diagram in Mermaid, built from what the scan found:
  entry points, orchestration, models, knowledge base, the tools the model can call
  (irreversible ones without a gate are marked), MCP servers and observability.
* Section 3.4 - a chart of the build-phase evaluation: each metric's measured baseline next
  to the alert threshold derived from it, as Mermaid and as an SVG image.

Nothing is drawn that the code does not show. A component that was not found is absent from
the diagram, and with no measured baseline there is no chart - the section says why instead.

Writes aida/architecture.mmd, aida/performance_chart.mmd, aida/performance_chart.svg and
aida/figures.json, which fill_docx.py inserts into the document. Standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from xml.sax.saxutils import escape

ARCHITECTURE_SECTION = "AI System Architecture"
PERFORMANCE_SECTION = "Design Specifications and Model Performance"


def load(path: Path) -> dict | None:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def label(*lines: str) -> str:
    """Quote the given lines as one Mermaid node label, joined by line breaks.

    Text from the scanned code (a model id, a tool name) may contain quotes, brackets or
    pipes, any of which would close the label early and break the diagram; they are
    replaced with an apostrophe. Empty lines are dropped.
    """
    clean = [re.sub(r'["\[\]{}|<>]', "'", line) for line in lines if line]
    return '"' + "<br/>".join(clean) + '"'


def architecture(ctx: dict, oversight: dict | None) -> tuple[str, list[str]]:
    lines = ["flowchart LR"]
    edges: list[str] = []
    legend: list[str] = []
    cls = ctx.get("classification") or {}

    lines.append(f'  caller(["Caller"])')
    entry = "caller"

    endpoints = ctx.get("endpoints") or []
    if endpoints:
        routes = " · ".join(f"{e['method']} {e['route']}" for e in endpoints[:4])
        lines.append(f"  api[{label('API', routes)}]")
        edges.append(f"  caller --> api")
        legend.append(f"API - {', '.join(e['evidence'] for e in endpoints[:3])}")
        entry = "api"

    framework = cls.get("reference_framework")
    level = cls.get("agentic_level")
    core_title = "Orchestration" if framework else "Application"
    lines.append(f"  core[{label(core_title, framework or '', level and f'autonomy {level}')}]")
    edges.append(f"  {entry} --> core")
    if cls.get("family_evidence"):
        legend.append(f"{core_title} - {', '.join(cls['family_evidence'][:3])}")

    models = ctx.get("models") or {}
    regions = list(ctx.get("regions") or {})
    for index, (model_id, evidence) in enumerate(list(models.items())[:3], 1):
        lines.append(f"  model{index}[({label('Model', model_id, regions[0] if regions else '')})]")
        edges.append(f"  core --> model{index}")
        legend.append(f"Model {model_id} - {', '.join(evidence[:2])}")

    for index, store in enumerate(list(ctx.get("vector_stores") or {})[:2], 1):
        lines.append(f"  kb{index}[({label('Knowledge base', store)})]")
        edges.append(f"  core --> kb{index}")
        evidence = ctx["vector_stores"][store].get("evidence", [])
        legend.append(f"Knowledge base {store} - {', '.join(evidence[:2])}")

    dangerous: list[str] = []
    for index, tool in enumerate((oversight or {}).get("tools", [])[:8], 1):
        effects = ", ".join(tool["effects"]) or "read-only"
        gate = "approval gate" if tool["approval_gate"] else (
            "NO APPROVAL GATE" if tool["irreversible"] else "")
        lines.append(f"  tool{index}[{label('Tool: ' + tool['name'], effects, gate)}]")
        edges.append(f"  core --> tool{index}")
        legend.append(f"Tool {tool['name']} - {tool['file']}:{tool['line']}")
        if tool["irreversible"] and not tool["approval_gate"]:
            dangerous.append(f"tool{index}")

    for index, declared in enumerate((oversight or {}).get("declared_tools", [])[:6], 1):
        lines.append(f"  decl{index}[{label('Declared tool: ' + declared['name'], 'effect to confirm')}]")
        edges.append(f"  core -.-> decl{index}")
        legend.append(f"Declared tool {declared['name']} - {declared['file']}:{declared['line']}")

    servers = sorted({s for e in (oversight or {}).get("mcp", []) for s in e["servers"]})
    for index, server in enumerate(servers[:6], 1):
        lines.append(f"  mcp{index}[[{label('MCP server', server)}]]")
        edges.append(f"  core -.-> mcp{index}")

    for index, name in enumerate(list(ctx.get("observability") or {})[:2], 1):
        lines.append(f"  obs{index}[{label('Observability', name)}]")
        edges.append(f"  core -. traces .-> obs{index}")

    lines += edges
    if dangerous:
        lines.append("  classDef ungated fill:#fde2e1,stroke:#c0392b,color:#7b241c")
        lines.append(f"  class {','.join(dangerous)} ungated")
    return "\n".join(lines) + "\n", legend


def performance(plan: dict | None) -> tuple[str | None, str | None, list[dict]]:
    measured = [m for m in (plan or {}).get("metrics", []) if m.get("baseline") is not None]
    if not measured:
        return None, None, []

    top = max(1.0, max(m["baseline"] for m in measured)) * 1.1
    names = ", ".join(f'"{m["metric"]}"' for m in measured)
    bars = ", ".join(f"{m['baseline']:g}" for m in measured)
    thresholds = ", ".join(f"{(m['alert_threshold'] or 0):g}" for m in measured)
    mermaid = (
        "xychart-beta\n"
        '  title "Build-phase baseline (bars) and alert threshold (line)"\n'
        f"  x-axis [{names}]\n"
        f'  y-axis "score" 0 --> {top:.2f}\n'
        f"  bar [{bars}]\n"
        f"  line [{thresholds}]\n"
    )

    # The same data as an image a reader can open without a Mermaid renderer.
    width, row, left, bar_width = 720, 34, 220, 440
    height = 70 + row * len(measured)
    scale = bar_width / top
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'font-family="Arial, sans-serif" font-size="12">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{left}" y="22" font-size="14" font-weight="bold">Build-phase baseline and '
        f'alert threshold ({escape(str(plan.get("threshold_rule", "")))})</text>',
    ]
    for index, metric in enumerate(measured):
        y = 40 + index * row
        base = metric["baseline"] * scale
        parts.append(f'<text x="{left - 8}" y="{y + 16}" text-anchor="end">'
                     f'{escape(metric["metric"])}</text>')
        parts.append(f'<rect x="{left}" y="{y + 4}" width="{base:.1f}" height="18" '
                     f'fill="#2e7d6b"/>')
        parts.append(f'<text x="{left + base + 6:.1f}" y="{y + 17}">{metric["baseline"]:g}</text>')
        if metric.get("alert_threshold") is not None:
            x = left + metric["alert_threshold"] * scale
            parts.append(f'<line x1="{x:.1f}" y1="{y}" x2="{x:.1f}" y2="{y + 26}" '
                         f'stroke="#c0392b" stroke-width="2"/>')
    parts.append(f'<text x="{left}" y="{height - 10}" fill="#555555">bars: measured baseline · '
                 f'red marks: alert threshold, {plan.get("relative_drop_pct", 0):g}% below it'
                 f'</text>')
    parts.append("</svg>")
    return mermaid, "\n".join(parts) + "\n", measured


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the architecture and performance figures.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--aida", default="aida", help="folder holding the other analyses")
    args = parser.parse_args()

    ctx = load(Path(args.context))
    if ctx is None:
        print(f"error: context not found: {args.context}\n"
              f"       run the aida-core skill first", file=sys.stderr)
        return 2
    folder = Path(args.aida)
    folder.mkdir(parents=True, exist_ok=True)
    oversight = load(folder / "oversight_audit.json")
    plan = load(folder / "monitoring_plan.json")

    figures = []
    diagram, legend = architecture(ctx, oversight)
    (folder / "architecture.mmd").write_text(diagram, encoding="utf-8")
    figures.append({
        "section": ARCHITECTURE_SECTION,
        "title": "Figure 1 - Architecture, generated from the codebase (Mermaid)",
        "source": diagram,
        "caption": "Components and the evidence behind each: " + "; ".join(legend)
                   if legend else "Only the components above were found in the code.",
        "file": f"{folder.as_posix()}/architecture.mmd",
    })
    print(f"architecture diagram: {len(diagram.splitlines())} lines -> {folder / 'architecture.mmd'}")

    chart, svg, measured = performance(plan)
    if chart:
        (folder / "performance_chart.mmd").write_text(chart, encoding="utf-8")
        (folder / "performance_chart.svg").write_text(svg, encoding="utf-8")
        figures.append({
            "section": PERFORMANCE_SECTION,
            "title": "Figure 2 - Build-phase evaluation: baseline and alert threshold (Mermaid)",
            "source": chart,
            "caption": (f"{len(measured)} metric(s) from {plan.get('baseline_source')}. The same "
                        f"chart as an image: {folder.as_posix()}/performance_chart.svg."),
            "file": f"{folder.as_posix()}/performance_chart.mmd",
        })
        print(f"performance chart   : {len(measured)} metric(s) -> "
              f"{folder / 'performance_chart.mmd'}, {folder / 'performance_chart.svg'}")
    else:
        figures.append({
            "section": PERFORMANCE_SECTION,
            "title": "Figure 2 - Build-phase evaluation",
            "source": None,
            "caption": "[A CONFIRMER - no build-phase evaluation was found, so there is no "
                       "measured performance to chart; run the evaluation and regenerate]",
            "file": None,
        })
        print("performance chart   : not generated - no measured baseline in the project")

    (folder / "figures.json").write_text(json.dumps(figures, indent=2, ensure_ascii=False) + "\n",
                                         encoding="utf-8")
    print(f"figures listed in {folder / 'figures.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
