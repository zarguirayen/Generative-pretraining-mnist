#!/usr/bin/env python3
"""Inventory the guardrails and security controls the code shows (section 3.10).

    python audit_security.py . --context aida/context.json --values aida/values.json --map aida/placeholders.json

Section 3.10 asks for the guardrails employed and any red- or blue-team tests. Both leave
traces in a repository - a guardrail library, a moderation call, bounded inputs, validated
outputs, authenticated endpoints, a rate limiter, a red-teaming suite - so they are read
from it, and each is mapped to the OWASP Top 10 for LLM applications, the attack library
the Building guideline points to (BUILD-REDTEAM names DeepTeam, grounded in it).

A control the scan did not find is reported as a gap to confirm, never as proof of absence:
guardrails are often configured on the platform (a Bedrock guardrail, a gateway) rather than
in code. The ISS opinion, MESARI and CAGIP penetration reports stay external links.

Writes aida/security_audit.json. Standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

GUARDRAILS = ("Details about employed guardrails or any red teaming or blue teaming tests "
              "(where applicable).")

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "env", "aida",
             "site-packages", "dist", "build", ".tox", ".mypy_cache", ".pytest_cache"}
SUFFIXES = {".py", ".yaml", ".yml", ".json", ".toml", ".tf", ".cfg", ".ini", ".txt"}

# control -> (pattern, what it is, OWASP LLM Top 10 risk it mitigates)
CONTROLS: dict[str, tuple[re.Pattern, str, str]] = {
    "guardrail_framework": (re.compile(
        r"nemoguardrails|\bguardrails\b\s*(?:import|\.)|from guardrails|llm_guard|\bpresidio|"
        r"\brebuff\b|\blakera|guardrailIdentifier|guardrail_?config|contentsafety", re.I),
        "guardrail framework or platform guardrail", "LLM01 prompt injection"),
    "moderation": (re.compile(r"moderations\.create|ModerationChain|\bmoderat\w+\(", re.I),
                   "content moderation call", "LLM01 prompt injection"),
    "prompt_injection": (re.compile(r"prompt[_ ]?injection|jailbreak", re.I),
                         "prompt-injection handling or test", "LLM01 prompt injection"),
    "output_validation": (re.compile(
        r"with_structured_output|PydanticOutputParser|output_parser|jsonschema\.validate|"
        r"model_validate\(", re.I), "validated model output", "LLM05 improper output handling"),
    "input_bounds": (re.compile(r"max_length\s*=|constr\(|max_items\s*=", re.I),
                     "bounded input size", "LLM10 unbounded consumption"),
    "token_budget": (re.compile(r"max_tokens\s*=|max_output_tokens|recursion_limit|max_iterations",
                                re.I), "token / step budget", "LLM10 unbounded consumption"),
    "rate_limit": (re.compile(r"slowapi|\bLimiter\(|rate_?limit|RateLimiter", re.I),
                   "rate limiting", "LLM10 unbounded consumption"),
    "endpoint_auth": (re.compile(
        r"HTTPBearer|OAuth2PasswordBearer|APIKeyHeader|login_required|"
        r"Depends\(\s*\w*(?:auth|token|api_key|verify|current_user)\w*", re.I),
        "authenticated endpoint", "access control"),
    "red_teaming": (re.compile(r"\bdeepteam\b|\bgarak\b|\bpromptfoo\b|\bpyrit\b|red_?team", re.I),
                    "red-teaming suite", "BUILD-REDTEAM"),
}
SECRET = re.compile(r"""(?i)\b(api[_-]?key|secret|password|access[_-]?token)\b\s*[:=]\s*["'][^"'\s]{16,}["']""")
OWASP_EXPECTED = ("LLM01 prompt injection", "LLM05 improper output handling",
                  "LLM10 unbounded consumption", "access control")


def iter_files(root: Path):
    for path in sorted(root.rglob("*")):
        if (path.is_file() and path.suffix.lower() in SUFFIXES
                and not any(p in SKIP_DIRS for p in path.relative_to(root).parts)):
            yield path


def scan(root: Path) -> tuple[dict[str, list[str]], list[str]]:
    found: dict[str, list[str]] = {name: [] for name in CONTROLS}
    secrets: list[str] = []
    for path in iter_files(root):
        relative = path.relative_to(root).as_posix()
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        for lineno, line in enumerate(lines, 1):
            for name, (pattern, _, _) in CONTROLS.items():
                if pattern.search(line):
                    found[name].append(f"{relative}:{lineno}")
            if path.suffix == ".py" and SECRET.search(line):
                secrets.append(f"{relative}:{lineno}")   # the value itself is never copied
    return {k: v for k, v in found.items() if v}, secrets


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def assess(found: dict, secrets: list[str], ctx: dict, oversight: dict) -> dict:
    family = (ctx.get("classification") or {}).get("family")
    covered = {CONTROLS[name][2] for name in found}
    findings = []
    # Access control only means something where the system is reachable over an API.
    expected = [r for r in OWASP_EXPECTED if r != "access control" or ctx.get("endpoints")]
    for risk in expected:
        if risk not in covered:
            findings.append({"rule": "BUILD-REDTEAM", "severity": "advisory",
                             "summary": f"no control found in the code for {risk}",
                             "detail": "Confirm whether it is enforced on the platform "
                                       "(gateway, managed guardrail); otherwise add one."})
    if secrets:
        findings.append({"rule": "BUILD-REDTEAM", "severity": "blocking",
                         "summary": f"{len(secrets)} credential-like literal(s) in the code "
                                    f"(LLM02 sensitive information disclosure)",
                         "detail": ", ".join(secrets[:5]) + " - move to a secret store."})
    ungated = (oversight.get("counts") or {}).get("ungated", 0)
    if ungated:
        findings.append({"rule": "OVERSIGHT-INTERVENTION", "severity": "blocking",
                         "summary": f"{ungated} irreversible tool(s) with no approval gate "
                                    f"(LLM06 excessive agency)",
                         "detail": "See section 3.9."})
    if "red_teaming" not in found and family in ("agentic", "hybrid"):
        findings.append({"rule": "BUILD-REDTEAM", "severity": "advisory",
                         "summary": "no red-teaming suite in the repository",
                         "detail": "DeepTeam is the reference framework for agentic systems; "
                                   "its attack library follows the OWASP LLM Top 10."})
    return {"controls": found, "secrets": secrets, "ungated_tools": ungated,
            "findings": findings}


def describe(result: dict) -> tuple[str, list[str]]:
    found = result["controls"]
    parts, evidence = [], []
    if found:
        items = []
        for name, where in found.items():
            _, what, risk = CONTROLS[name]
            items.append(f"{what} ({risk}; {', '.join(where[:2])})")
            evidence += where[:1]
        parts.append("Guardrails and security controls found in the code: "
                     + "; ".join(items) + ".")
    else:
        parts.append("No guardrail, moderation, input or output validation, rate limiting or "
                     "red-teaming control was found in the code.")
    gaps = [f["summary"] for f in result["findings"]]
    if gaps:
        parts.append("Gaps against the OWASP Top 10 for LLM applications: " + "; ".join(gaps) + ".")
    parts.append("[A CONFIRMER - guardrails configured on the platform, and the results of any "
                 "red- or blue-team exercise run outside the repository]")
    return " ".join(parts), evidence


def main() -> int:
    parser = argparse.ArgumentParser(description="Inventory guardrails and security controls (3.10).")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json")
    parser.add_argument("--out", default="aida/security_audit.json")
    args = parser.parse_args()

    root = Path(args.project).resolve()
    ctx = load(Path(args.context))
    oversight = load(Path(args.out).parent / "oversight_audit.json")
    found, secrets = scan(root)
    result = assess(found, secrets, ctx, oversight)

    value, evidence = describe(result)
    # A statement of absence still needs something to point at: the model calls it covers.
    evidence = evidence or [e for ev in (ctx.get("models") or {}).values() for e in ev][:2] \
        or (ctx.get("classification") or {}).get("family_evidence", [])[:2]
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"security controls found : {', '.join(found) or 'none'}")
    for finding in result["findings"]:
        print(f"  [{finding['severity'].upper()}] {finding['summary']}")
    if evidence:
        print(report(merge(Path(args.values), {GUARDRAILS: entry(value, source="code",
                                                                  evidence=evidence)},
                           Path(args.routing)), "3.10 Cybersecurity", Path(args.values)))
    else:
        print("  nothing to cite - 3.10 guardrails stay an open point")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
