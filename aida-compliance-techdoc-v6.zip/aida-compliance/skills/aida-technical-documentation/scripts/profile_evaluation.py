#!/usr/bin/env python3
"""Describe the evaluation data and the experiment runs the project actually holds (3.3).

    python profile_evaluation.py . --context aida/context.json --values aida/values.json --map aida/placeholders.json

Section 3.3 asks for the main characteristics of the validation and testing data, and
for dated experiment logs. Both exist as files in a project that has been evaluated, so
both are read rather than asked for:

* the evaluation dataset (.jsonl / .json / .csv with a question-like column): size, the
  fields each case carries, question length, distribution over any category column,
  reference-answer and context coverage, duplicates - compared with the dataset size and
  categories the Evaluation guideline requires (EVAL-RAG-QUERIES, EVAL-AGENTIC-QUERIES,
  EVAL-AGENTIC-CATEGORIES) and, for RAG, the corpus size (EVAL-RAG-CORPUS);
* the experiment runs: evaluation summaries under eval/outputs, and local MLflow runs
  under mlruns/ - each dated, with its metrics.

What the files cannot say stays open: how the cases were selected, the MLflow URL, and the
signature of the logs. Writes aida/evaluation_profile.json. Standard library only.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

CHARACTERISTICS = ("Provide information about the main characteristics of the validation "
                   "and testing data used (e.g. data distribution).")
EXPERIMENT_LOGS = ("Include dated and signed model experiments logs and reports (e.g. link "
                   "to ML flow experiment tracking).")

EVAL_DIRS = {"eval", "evals", "evaluation", "evaluations", "golden", "benchmark", "benchmarks",
             "testsets", "test_sets", "datasets"}
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "aida", "outputs",
             "mlruns", "site-packages"}
QUESTION_KEYS = ("question", "query", "input", "prompt", "user_input", "instruction")
ANSWER_KEYS = ("expected", "expected_answer", "ground_truth", "reference", "answer",
               "expected_output", "reference_answer")
CONTEXT_KEYS = ("context", "contexts", "reference_contexts", "source", "sources",
                "documents", "expected_tools", "tools")
CATEGORY_KEYS = ("category", "type", "difficulty", "complexity", "tag", "kind", "scenario")
CORPUS_DIRS = {"corpus", "documents", "docs_corpus", "knowledge_base", "kb", "knowledge"}
AGENTIC_CATEGORIES = ("simple", "multi", "edge")


def read_cases(path: Path) -> list[dict]:
    """Rows of an evaluation file, or [] when it is not one."""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    rows: list = []
    if path.suffix == ".jsonl":
        for line in text.splitlines():
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    elif path.suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
        if isinstance(data, dict):
            data = next((v for v in data.values() if isinstance(v, list)), [])
        rows = data if isinstance(data, list) else []
    elif path.suffix == ".csv":
        rows = list(csv.DictReader(text.splitlines()))
    rows = [r for r in rows if isinstance(r, dict)]
    return rows if rows and question_key(rows[0]) else []


def question_key(row: dict) -> str | None:
    return next((k for k in QUESTION_KEYS if k in row), None)


def first_key(rows: list[dict], keys: tuple[str, ...]) -> str | None:
    return next((k for k in keys if any(k in r for r in rows)), None)


def find_datasets(root: Path) -> list[tuple[Path, list[dict]]]:
    found = []
    for path in sorted(root.rglob("*")):
        parts = path.relative_to(root).parts
        if (not path.is_file() or path.suffix not in (".jsonl", ".json", ".csv")
                or any(p in SKIP_DIRS for p in parts)
                or not any(p.lower() in EVAL_DIRS for p in parts[:-1])):
            continue
        cases = read_cases(path)
        if cases:
            found.append((path, cases))
    return found


def profile(path: Path, cases: list[dict], root: Path) -> dict:
    qkey = question_key(cases[0])
    questions = [str(c.get(qkey, "")) for c in cases]
    words = [len(q.split()) for q in questions]
    answer, context, category = (first_key(cases, keys)
                                 for keys in (ANSWER_KEYS, CONTEXT_KEYS, CATEGORY_KEYS))
    return {
        "file": path.relative_to(root).as_posix(),
        "cases": len(cases),
        "fields": sorted({k for c in cases for k in c}),
        "question_words": {"min": min(words), "median": statistics.median(words),
                           "max": max(words)},
        "with_reference_answer": sum(1 for c in cases if answer and c.get(answer)),
        "reference_field": answer,
        "with_context": sum(1 for c in cases if context and c.get(context)),
        "context_field": context,
        "category_field": category,
        "distribution": dict(Counter(str(c.get(category, "unlabelled")).lower()
                                     for c in cases).most_common(8)) if category else {},
        "duplicates": len(questions) - len({q.strip().lower() for q in questions}),
    }


def corpus_size(root: Path) -> tuple[int, str | None]:
    for path in sorted(root.rglob("*")):
        if path.is_dir() and path.name.lower() in CORPUS_DIRS and not any(
                p in SKIP_DIRS for p in path.relative_to(root).parts):
            files = [f for f in path.rglob("*") if f.is_file()]
            if files:
                return len(files), path.relative_to(root).as_posix()
    return 0, None


def stamp(seconds: float) -> str:
    return datetime.fromtimestamp(seconds, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def evaluation_runs(root: Path) -> list[dict]:
    """Summaries under */outputs/*/summary.json, dated by their own timestamp if any."""
    runs = []
    for path in sorted(root.glob("**/outputs/*/summary.json")):
        if any(p in SKIP_DIRS - {"outputs"} for p in path.relative_to(root).parts):
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        metrics = data.get("metrics", data) if isinstance(data, dict) else {}
        scores = {k: (v.get("score") if isinstance(v, dict) else v) for k, v in metrics.items()
                  if isinstance(v, (int, float, dict)) and not isinstance(v, bool)}
        date = next((str(data[k]) for k in ("timestamp", "date", "created_at", "run_date")
                     if isinstance(data, dict) and k in data), None)
        runs.append({"run": path.parent.name, "kind": "evaluation summary",
                     "file": path.relative_to(root).as_posix(),
                     "date": date or f"{stamp(path.stat().st_mtime)} (file date)",
                     "metrics": {k: v for k, v in scores.items() if v is not None}})
    return runs


def mlflow_runs(root: Path) -> list[dict]:
    """Local MLflow file store: mlruns/<experiment>/<run>/meta.yaml and metrics/."""
    runs = []
    for meta in sorted(root.glob("**/mlruns/*/*/meta.yaml")):
        fields = {}
        for line in meta.read_text(encoding="utf-8", errors="ignore").splitlines():
            key, _, value = line.partition(":")
            fields[key.strip()] = value.strip().strip("'\"")
        metrics = {}
        for metric in sorted((meta.parent / "metrics").glob("*")):
            last = metric.read_text(encoding="utf-8", errors="ignore").split()
            if len(last) >= 2:
                metrics[metric.name] = float(last[-2]) if len(last) % 3 == 0 else last[-1]
        start = fields.get("start_time", "")
        runs.append({"run": fields.get("run_name") or meta.parent.name, "kind": "MLflow run",
                     "file": meta.relative_to(root).as_posix(),
                     "date": stamp(int(start) / 1000) if start.isdigit() else "undated",
                     "status": fields.get("status"), "metrics": metrics})
    return runs


def required_size(family: str | None, rules: dict) -> tuple[int | None, str | None]:
    rule_id = {"rag": "EVAL-RAG-QUERIES", "hybrid": "EVAL-RAG-QUERIES",
               "agentic": "EVAL-AGENTIC-QUERIES"}.get(family or "")
    if not rule_id:
        return None, None
    threshold = next(r["threshold"] for r in rules["rules"] if r["id"] == rule_id)
    return next(iter(threshold.values())), rule_id


def describe_data(profiles: list[dict], family: str | None, rules: dict,
                  corpus: tuple[int, str | None]) -> str:
    total = sum(p["cases"] for p in profiles)
    parts = [f"Evaluation data: {total} case(s) in {len(profiles)} file(s)."]
    for p in profiles:
        text = (f"{p['file']}: {p['cases']} cases; fields {', '.join(p['fields'][:8])}; "
                f"question length {p['question_words']['min']}-{p['question_words']['max']} "
                f"words (median {p['question_words']['median']:g})")
        if p["reference_field"]:
            text += f"; {p['with_reference_answer']}/{p['cases']} with a reference answer"
        if p["context_field"]:
            text += f"; {p['with_context']}/{p['cases']} with {p['context_field']}"
        if p["distribution"]:
            text += "; distribution by " + p["category_field"] + ": " + ", ".join(
                f"{k} {v} ({v * 100 // p['cases']}%)" for k, v in p["distribution"].items())
        if p["duplicates"]:
            text += f"; {p['duplicates']} duplicate question(s)"
        parts.append(text + ".")

    minimum, rule_id = required_size(family, rules)
    if minimum:
        verdict = "meets" if total >= minimum else "is BELOW"
        parts.append(f"Size {verdict} the guideline minimum of {minimum} ({rule_id}).")
    if family == "agentic":
        labels = " ".join(k for p in profiles for k in p["distribution"])
        missing = [c for c in AGENTIC_CATEGORIES if c not in labels]
        parts.append("Simple, multi-step and edge cases are all labelled "
                     "(EVAL-AGENTIC-CATEGORIES)." if not missing else
                     f"No case labelled {', '.join(missing)} - EVAL-AGENTIC-CATEGORIES "
                     f"requires simple, multi-step and edge cases.")
    if family in ("rag", "hybrid"):
        need = next(r["threshold"]["min_documents"] for r in rules["rules"]
                    if r["id"] == "EVAL-RAG-CORPUS")
        count, where = corpus
        parts.append(f"Knowledge-base corpus: {count} document(s) in {where} "
                     f"({'meets' if count >= need else 'BELOW'} the {need} of EVAL-RAG-CORPUS)."
                     if where else f"[A CONFIRMER - corpus size; EVAL-RAG-CORPUS requires "
                                   f"at least {need} documents]")
    parts.append("[A CONFIRMER - how the cases were selected and whether they represent "
                 "real usage]")
    return " ".join(parts)


def describe_runs(runs: list[dict]) -> str:
    lines = [f"{len(runs)} experiment run(s) found in the repository:"]
    for run in runs[:6]:
        metrics = ", ".join(f"{k} {v:g}" if isinstance(v, float) else f"{k} {v}"
                            for k, v in list(run["metrics"].items())[:5])
        lines.append(f"{run['kind']} '{run['run']}', {run['date']}"
                     + (f": {metrics}" if metrics else "") + f" ({run['file']}).")
    lines.append("[A CONFIRMER - MLflow experiment URL and the sign-off of these logs]")
    return " ".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Profile the evaluation data and runs (3.3).")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json")
    parser.add_argument("--rules", default=str(HERE.parent.parent / "aida-core" / "references"
                                               / "aida_rules.json"))
    parser.add_argument("--out", default="aida/evaluation_profile.json")
    args = parser.parse_args()

    root = Path(args.project).resolve()
    context = Path(args.context)
    family = ((json.loads(context.read_text(encoding="utf-8")) if context.exists() else {})
              .get("classification") or {}).get("family")
    rules = json.loads(Path(args.rules).read_text(encoding="utf-8"))

    datasets = find_datasets(root)
    profiles = [profile(path, cases, root) for path, cases in datasets]
    runs = evaluation_runs(root) + mlflow_runs(root)
    corpus = corpus_size(root)

    entries = {}
    if profiles:
        entries[CHARACTERISTICS] = entry(describe_data(profiles, family, rules, corpus),
                                         source="code",
                                         evidence=[f"{p['file']}:1" for p in profiles])
    if runs:
        entries[EXPERIMENT_LOGS] = entry(describe_runs(runs), source="code",
                                         evidence=[f"{r['file']}:1" for r in runs])

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"datasets": profiles, "runs": runs,
                               "corpus": {"documents": corpus[0], "path": corpus[1]}},
                              indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"evaluation datasets : {len(profiles)} ({sum(p['cases'] for p in profiles)} cases)")
    print(f"experiment runs     : {len(runs)}")
    if not profiles:
        print("  no evaluation dataset found - 3.3 data characteristics stay an open point")
    if entries:
        print(report(merge(Path(args.values), entries, Path(args.routing)),
                     "3.3 Validation and testing", Path(args.values)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
