#!/usr/bin/env python3
"""Select operational metrics the project can actually compute, and emit their alerts.

    python plan_operational.py --context aida/context.json \
        [--records aida/records_audit.json] [--inference-frequency daily]

The guideline's operational table lists twelve metrics and asks for at least one. Picking
from it is easy; picking one the system can measure is the part that gets skipped. Every
metric is fed by a record, and a project that never logs a timeout cannot report a timeout
rate no matter what its documentation claims.

So each metric is reported with the record it needs and whether that record exists. What
comes out is a plan that can be implemented, plus the alert rules for it.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RULES = HERE.parent.parent / "aida-core" / "references" / "aida_rules.json"

# metric name in the guideline table -> the record that feeds it, and how to compute it.
FEEDS: dict[str, tuple[str, str]] = {
    "average_inference_latency": ("inference_latency", "mean of the per-request duration"),
    "data_processing_duration": ("data_processing_duration", "mean pre- and post-processing time"),
    "output_size": ("system_output_size", "mean output size, or output tokens per request"),
    "uptime_pct": ("system_uptime", "operational time over elapsed time"),
    "timeout_rate": ("timeout_event", "timeouts over total requests"),
    "error_rate": ("error_event", "failed operations over total requests"),
    "system_crashes": ("incident_event", "count of unplanned shutdowns per 24h"),
    "resource_utilization": ("resource_utilization", "peak CPU, GPU and memory"),
    "unauthorized_access_pct": ("security_event", "failed or unrecognised access attempts"),
    "token_usage": ("inference_input_data", "input and output tokens per day, against a quota"),
    "average_usage_duration_per_user": ("system_usage", "mean session duration per user"),
    "average_usage_time": ("system_usage", "mean usage time"),
    "active_users_trend": ("system_access_log", "distinct actors month over month"),
    "request_spike": ("inference_request", "requests per hour against the recent mean"),
}
# Records the audit reports on, mapped to the operational ones it does not name directly.
RECORD_ALIASES = {
    "inference_latency": ("inference_input_data",),
    "system_uptime": (),
    "timeout_event": (),
    "error_event": (),
    "incident_event": (),
    "resource_utilization": (),
    "security_event": ("system_access_log",),
    "system_usage": ("system_access_log",),
    "inference_request": ("inference_input_data",),
    "data_processing_duration": (),
    "system_output_size": ("inference_output_data",),
}


def rule(rules: dict, rule_id: str) -> dict:
    for item in rules["rules"]:
        if item["id"] == rule_id:
            return item
    return {}


def record_present(records_audit: dict | None, record_id: str) -> bool | None:
    """True, False, or None when no record audit was supplied."""
    if not records_audit:
        return None
    known = records_audit.get("records", {})
    for candidate in (record_id, *RECORD_ALIASES.get(record_id, ())):
        entry = known.get(candidate)
        if entry and entry.get("present"):
            return True
    return False


def alert_rule(metric: dict, computable: bool | None) -> dict:
    """A machine-readable alert rule, ready to be loaded into a monitoring platform."""
    return {
        "name": metric["name"],
        "category": metric["category"],
        "condition": metric["alert"],
        "description": metric.get("description", ""),
        "source_record": FEEDS.get(metric["name"], ("unknown", ""))[0],
        "computable_today": computable,
        "notify": "human overseers, by mail or system notification",
        "on_trigger": "investigate the cause, justify whether corrective measures are "
                      "taken, and record the outcome in the AI System Journal",
    }


def build_plan(ctx: dict, rules: dict, records_audit: dict | None,
               inference_frequency: str | None) -> dict:
    table = rule(rules, "MON-OPERATIONAL-MINIMUM")
    frequency = rule(rules, "MON-FREQUENCY")
    schedule = frequency.get("mapping", {}).get(inference_frequency) if inference_frequency else None

    metrics: list[dict] = []
    for metric in table.get("metrics", []):
        feed, how = FEEDS.get(metric["name"], ("unknown", ""))
        computable = record_present(records_audit, feed)
        metrics.append({
            "metric": metric["name"],
            "category": metric["category"],
            "alert": metric["alert"],
            "needs_record": feed,
            "how": how,
            "computable_today": computable,
        })

    computable = [m for m in metrics if m["computable_today"] is True]
    selected = computable or [m for m in metrics
                              if m["metric"] in ("error_rate", "average_inference_latency",
                                                 "uptime_pct")]

    return {
        "rule": table.get("id"),
        "source": table.get("source"),
        "requirement": table.get("requirement"),
        "metrics": metrics,
        "selected": [m["metric"] for m in selected],
        "alert_rules": [alert_rule(m, record_present(records_audit,
                                                     FEEDS.get(m["name"], ("unknown", ""))[0]))
                        for m in table.get("metrics", [])
                        if m["name"] in {s["metric"] for s in selected}],
        "schedule": {
            "inference_frequency": inference_frequency,
            "monitoring_frequency": schedule,
            "rule": frequency.get("id"),
        },
        "findings": build_findings(metrics, computable, schedule, records_audit),
    }


def build_findings(metrics, computable, schedule, records_audit) -> list[dict]:
    findings: list[dict] = []
    if records_audit is None:
        findings.append({
            "rule": "MON-OPERATIONAL-MINIMUM", "severity": "advisory",
            "summary": "no record audit supplied, so computability is unknown",
            "detail": "Run the aida-record-keeping skill and pass --records; a metric "
                      "without the record that feeds it cannot be computed."})
    elif not computable:
        findings.append({
            "rule": "MON-OPERATIONAL-MINIMUM", "severity": "blocking",
            "summary": "no metric from the guideline table can be computed today",
            "detail": "At least one is mandatory. None of the records that feed the table "
                      "exist yet - close that gap first, in record keeping."})
    else:
        missing = [m["metric"] for m in metrics if m["computable_today"] is False]
        if missing:
            findings.append({
                "rule": "REC-OPERATIONAL-MANDATORY", "severity": "advisory",
                "summary": f"{len(missing)} metric(s) need a record the project does not keep",
                "detail": ", ".join(missing)})
    if not schedule:
        findings.append({
            "rule": "MON-FREQUENCY", "severity": "blocking",
            "summary": "monitoring frequency not determined",
            "detail": "It follows inference frequency: daily to weekly, weekly to monthly, "
                      "monthly to quarterly, quarterly to yearly."})
    return findings


def render(plan: dict) -> str:
    lines = [
        f"Rule     : {plan['rule']} - {plan['source']}",
        f"Schedule : {plan['schedule']['monitoring_frequency'] or 'to determine'}"
        f"  (inference: {plan['schedule']['inference_frequency'] or 'unknown'})",
        "",
        f"{'METRIC':<32} {'ALERT':<34} {'FEEDS FROM':<26} OK",
    ]
    for metric in plan["metrics"]:
        state = {True: "yes", False: "NO", None: "?"}[metric["computable_today"]]
        lines.append(f"{metric['metric'][:31]:<32} {metric['alert'][:33]:<34} "
                     f"{metric['needs_record'][:25]:<26} {state}")

    lines.append(f"\nSELECTED: {', '.join(plan['selected']) or 'none'}")
    lines.append(f"{len(plan['alert_rules'])} alert rule(s) written.")

    if plan["findings"]:
        lines.append(f"\nFINDINGS ({len(plan['findings'])})")
        for finding in plan["findings"]:
            marker = finding["severity"].upper()
            lines.append(f"  [{marker}] [{finding['rule']}] {finding['summary']}")
            lines.append(f"      {finding['detail']}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Plan operational system monitoring.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--records", default="aida/records_audit.json",
                        help="record keeping audit, used to check what is computable")
    parser.add_argument("--rules", default=str(DEFAULT_RULES))
    parser.add_argument("--inference-frequency",
                        choices=["daily", "weekly", "monthly", "quarterly"])
    parser.add_argument("--out", default="aida/operational_plan.json")
    parser.add_argument("--rules-out", default="aida/alert_rules.json")
    args = parser.parse_args()

    context_path = Path(args.context)
    if not context_path.exists():
        print(f"error: context not found: {context_path}\n"
              f"       run the aida-core skill first", file=sys.stderr)
        return 2

    ctx = json.loads(context_path.read_text(encoding="utf-8"))
    rules = json.loads(Path(args.rules).read_text(encoding="utf-8"))
    records_path = Path(args.records)
    records_audit = (json.loads(records_path.read_text(encoding="utf-8"))
                     if records_path.exists() else None)

    plan = build_plan(ctx, rules, records_audit, args.inference_frequency)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(plan, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    rules_out = Path(args.rules_out)
    rules_out.parent.mkdir(parents=True, exist_ok=True)
    rules_out.write_text(
        json.dumps({"alert_rules": plan["alert_rules"]}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8")

    print(render(plan))
    print(f"\nplan written to {out}\nalert rules written to {args.rules_out}")
    return 1 if any(f["severity"] == "blocking" for f in plan["findings"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
