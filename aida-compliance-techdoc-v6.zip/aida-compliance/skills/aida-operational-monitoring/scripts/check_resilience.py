#!/usr/bin/env python3
"""Ask what happens when a dependency the system needs stops answering.

    python check_resilience.py [project] [--out aida/resilience.json]

Operational monitoring exists to catch degradation, and the most common cause of
degradation in a GenAI system is not the model: it is a call to something else that got
slow or stopped answering. A model endpoint, a vector store, a tool behind an MCP server.

For every outbound call this reports three things the guideline's reliability metrics
depend on — is there a timeout, a retry, a fallback — because a call with none of them
turns a dependency incident into an outage, and an uptime metric cannot fix that after
the fact.

The check is done on the syntax tree, so a timeout set on the client rather than at the
call site is found too.

Standard library only.
"""

from __future__ import annotations

import argparse
import ast
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "aida-core" / "scripts"))
from ast_utils import dotted  # noqa: E402  (shared with the other syntax-tree audits)

SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env", "dist", "build",
    ".mypy_cache", ".pytest_cache", "site-packages", "aida", ".tox", "tests",
}

# dotted call name fragment -> what the dependency is
OUTBOUND = {
    "requests.get": "HTTP", "requests.post": "HTTP", "requests.put": "HTTP",
    "requests.patch": "HTTP", "requests.delete": "HTTP", "requests.request": "HTTP",
    "httpx.get": "HTTP", "httpx.post": "HTTP", "httpx.request": "HTTP",
    "urlopen": "HTTP", "session.get": "HTTP", "session.post": "HTTP",
    "invoke_model": "model endpoint", "converse": "model endpoint",
    "chat.completions.create": "model endpoint", "messages.create": "model endpoint",
    "generate_content": "model endpoint", "invoke": "model endpoint",
    "ainvoke": "model endpoint",
    "similarity_search": "vector store", "as_retriever": "vector store",
    "get_relevant_documents": "vector store", "similarity_search_with_score": "vector store",
}
TIMEOUT_KEYS = ("timeout", "read_timeout", "connect_timeout", "request_timeout",
                "deadline", "timeout_seconds")
RETRY_MARKERS = ("retry", "retrying", "tenacity", "backoff", "max_retries", "max_attempts",
                 "reraise", "stop_after_attempt")
FALLBACK_MARKERS = ("fallback", "with_fallbacks", "default_response", "degraded",
                    "circuit", "cache")


def kind_of(name: str) -> str | None:
    """Match the whole signature, never just its last segment.

    Matching on the last segment alone reported `os.environ.get` as an HTTP call, because
    it ends in `.get` like `requests.get` does. A dotted signature must match the tail of
    the name; a single-word one must match the called attribute exactly.
    """
    last = name.rsplit(".", 1)[-1]
    for signature, kind in OUTBOUND.items():
        if name == signature or name.endswith("." + signature):
            return kind
        if "." not in signature and last == signature:
            return kind
    return None


def enclosing(tree: ast.AST, target: ast.AST):
    """The function that contains `target`, so retries and fallbacks around it count."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for child in ast.walk(node):
                if child is target:
                    return node
    return None


def analyse(path: Path, relative: str) -> list[dict]:
    try:
        source = path.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(source)
    except (OSError, SyntaxError):
        return []

    module_text = source.lower()
    calls: list[dict] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = dotted(node.func)
        kind = kind_of(name) if name else None
        if not kind:
            continue

        has_timeout = any(kw.arg and kw.arg.lower() in TIMEOUT_KEYS for kw in node.keywords)
        owner = enclosing(tree, node)
        scope_text = ast.unparse(owner).lower() if owner else module_text
        decorators = " ".join(dotted(d.func if isinstance(d, ast.Call) else d)
                              for d in getattr(owner, "decorator_list", []))

        # A timeout configured once on the client counts for calls made through it.
        if not has_timeout and any(key in scope_text for key in TIMEOUT_KEYS):
            has_timeout = True

        calls.append({
            "call": name,
            "dependency": kind,
            "file": relative,
            "line": node.lineno,
            "timeout": has_timeout,
            "retry": any(marker in scope_text or marker in decorators
                         for marker in RETRY_MARKERS),
            "fallback": any(marker in scope_text for marker in FALLBACK_MARKERS)
                        or bool(owner and any(isinstance(n, ast.Try) for n in ast.walk(owner))),
        })
    return calls


def check(root: Path) -> dict:
    calls: list[dict] = []
    for path in root.rglob("*.py"):
        # Only the path *below* the project root is filtered. Testing the absolute path
        # would skip every file of a project that happens to live under a directory
        # called build, env or tests.
        relative = path.relative_to(root)
        if any(part in SKIP_DIRS for part in relative.parts):
            continue
        calls.extend(analyse(path, relative.as_posix()))

    unprotected = [c for c in calls if not c["timeout"]]
    findings: list[dict] = []
    if unprotected:
        findings.append({
            "rule": "MON-OPERATIONAL-MINIMUM", "severity": "blocking",
            "summary": f"{len(unprotected)} outbound call(s) with no timeout",
            "detail": "A call that can hang has no bounded latency, so the latency and "
                      "timeout-rate metrics cannot hold. " +
                      ", ".join(f"{c['call']} ({c['file']}:{c['line']})"
                                for c in unprotected[:5]),
        })
    no_fallback = [c for c in calls if not c["fallback"]]
    if no_fallback:
        findings.append({
            "rule": "MON-OPERATIONAL-MINIMUM", "severity": "advisory",
            "summary": f"{len(no_fallback)} call(s) with no fallback or error handling",
            "detail": "When this dependency is down the system fails rather than degrades. "
                      "Decide what a degraded answer looks like, and document it.",
        })
    return {
        "project": str(root.resolve()),
        "calls": sorted(calls, key=lambda c: (c["timeout"], c["file"], c["line"])),
        "counts": {
            "outbound": len(calls),
            "with_timeout": sum(1 for c in calls if c["timeout"]),
            "with_retry": sum(1 for c in calls if c["retry"]),
            "with_fallback": sum(1 for c in calls if c["fallback"]),
        },
        "findings": findings,
    }


def render(result: dict) -> str:
    counts = result["counts"]
    lines = [
        f"Outbound calls   : {counts['outbound']}",
        f"  with timeout   : {counts['with_timeout']}",
        f"  with retry     : {counts['with_retry']}",
        f"  with fallback  : {counts['with_fallback']}",
        "",
    ]
    if result["calls"]:
        lines.append(f"{'DEPENDENCY':<16} {'CALL':<26} {'T':<3} {'R':<3} {'F':<3} WHERE")
        for call in result["calls"]:
            mark = lambda flag: "y" if flag else "-"  # noqa: E731
            lines.append(f"{call['dependency'][:15]:<16} {call['call'][:25]:<26} "
                         f"{mark(call['timeout']):<3} {mark(call['retry']):<3} "
                         f"{mark(call['fallback']):<3} {call['file']}:{call['line']}")
        lines.append("  T = timeout, R = retry, F = fallback or error handling")
    else:
        lines.append("No outbound call recognised. If the system calls a model or a store "
                     "through a client this check does not know, say so rather than "
                     "reporting the system as having no dependencies.")

    if result["findings"]:
        lines.append(f"\nFINDINGS ({len(result['findings'])})")
        for finding in result["findings"]:
            lines.append(f"  [{finding['severity'].upper()}] [{finding['rule']}] "
                         f"{finding['summary']}")
            lines.append(f"      {finding['detail']}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Check dependency resilience.")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--out", default="aida/resilience.json")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    root = Path(args.project).expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    result = check(root)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(result, indent=2, ensure_ascii=False) if args.json else render(result))
    print(f"\nwritten to {out}")
    return 1 if any(f["severity"] == "blocking" for f in result["findings"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
