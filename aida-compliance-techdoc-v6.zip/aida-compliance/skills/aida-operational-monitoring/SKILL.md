---
name: aida-operational-monitoring
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: experimental
compatibility: Requires Python 3.10+
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*)
description: >-
  Plans the operational system monitoring of an AI system and writes the AI System
  Operational Monitoring part of section 3.8 of the AIDA technical documentation.
  Selects metrics from the guideline table, checks for each one whether the record that
  feeds it actually exists, emits the alert rules, sets the monitoring frequency, and
  checks whether outbound calls have a timeout, a retry and a fallback. Use it when
  asked about operational monitoring, system health, uptime, latency, error rate,
  timeouts, resource usage, token cost or FinOps of an AI system, when asked what
  happens if a dependency goes down, and when writing the operational monitoring
  section of AIDA documentation.
tags:
  - aida
  - monitoring
  - operational
  - sre
  - uptime
  - latency
  - finops
  - eu-ai-act
---

# aida-operational-monitoring

Covers the health of the system, not the quality of its answers. Its job is to make sure
the metrics chosen can actually be computed, and that a dependency going down degrades the
system instead of ending it.

---

## Absolute rules

- **Never select a metric the project cannot compute.** Every metric is fed by a record;
  without the record, the metric is a sentence in a document and nothing more.
- **Never state a threshold that is not the guideline's.** Latency ≥ 3 s, uptime < 99% per
  week, timeout ≥ 5%, error rate ≥ 2%, one crash, resources ≥ 90%, and a token quota.
- **Model quality is not this section.** Faithfulness and task completion belong to AI
  Model Monitoring. The two halves of 3.8 stay separate.
- **A call with no timeout has no bounded latency.** Report it as blocking; a latency
  metric over an unbounded call means nothing.
- **Never report a system as having no dependencies** because the check did not recognise
  its client. Say what was not recognised.

---

## Purpose

Section 3.8 of the AIDA template has two halves; this skill owns the second one, **AI
System Operational Monitoring**: reliability, availability, usage deviation and cost.

The guideline's table holds twelve metrics and requires at least one
(`MON-OPERATIONAL-MINIMUM`). Choosing from a list is easy; choosing one the system can
measure is the step that gets skipped, so each metric is reported with the record that
feeds it and whether that record exists — which is why this skill reads the record keeping
audit.

The three categories, in the guideline's own terms: **operational usage** (deviation in
how much the system is used), **operational reliability** (latency, uptime, errors,
resources, unauthorised access), and **FinOps / GreenOps** (token consumption against a
quota).

### When not to use

- Model quality (faithfulness, task completion, drift) - use `aida-genai-monitoring`.
- What the system must log - use `aida-record-keeping`; this skill only reads that audit.

---

## Workflow

Copy this checklist and tick items off as you go:

```
Operational monitoring:
- [ ] Phase 1: record keeping audit available
- [ ] Phase 2: build the plan and the alert rules
- [ ] Phase 3: check dependency resilience
- [ ] Phase 4: report
- [ ] Phase 5: write section 3.8, operational monitoring
```

### Phase 1 — Record keeping audit available

Run the `aida-record-keeping` skill first. Without it, computability is unknown and the
plan degrades to a list of good intentions.

### Phase 2 — Build the plan and the alert rules

```bash
python scripts/plan_operational.py --context aida/context.json --records aida/records_audit.json --inference-frequency daily
```

Writes the plan and `aida/alert_rules.json`, ready to load into a monitoring platform.
Each rule carries its condition, the record it needs, and what to do when it fires.

### Phase 3 — Check dependency resilience

```bash
python scripts/check_resilience.py . --out aida/resilience.json
```

For every outbound call — model endpoint, vector store, HTTP — it reports whether there is
a timeout, a retry, and a fallback:

```
DEPENDENCY       CALL                T   R   F   WHERE
model endpoint   agent.invoke        -   -   -   agent.py:44
HTTP             requests.post       -   -   -   agent.py:50
HTTP             requests.get        y   -   -   agent.py:20
```

### Phase 4 — Report

Lead with what can be measured today, not with the full table:

```
3 of 13 metrics computable today; the rest need records the project does not keep.
Selected: error_rate, average_inference_latency, uptime_pct
Schedule: weekly (inference: daily)
2 outbound calls with no timeout - latency and timeout-rate cannot hold until fixed.
```

### Phase 5 — Write the section

```bash
python scripts/write_section.py --plan aida/operational_plan.json --resilience aida/resilience.json --values aida/values.json --map aida/placeholders.json
```

It writes this section's fields into the shared values file. The placeholder map decides where each answer may come from: a field the template routes to a human is left as an open point, and one routed to the codebase is skipped unless there is something to cite. Answers carrying `confirmed_by` are never overwritten.

Then run the shared chain from `aida-core`:
`validate_values.py`, then `fill_docx.py`. State the metrics selected and why, the
thresholds with their justification, the tools and processes, the logging mechanisms, and
the alert procedure.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/write_section.py`](scripts/write_section.py) | Writes section 3.8 operational monitoring into `aida/values.json` |
| [`scripts/plan_operational.py`](scripts/plan_operational.py) | Metric selection by computability, alert rules, schedule |
| [`scripts/check_resilience.py`](scripts/check_resilience.py) | Timeout, retry and fallback on every outbound call |
| [`references/operational_monitoring.md`](references/operational_monitoring.md) | The twelve metrics, their thresholds, and the record each one needs |

From `aida-core`: `scan_codebase.py`, `validate_values.py`, `fill_docx.py`,
`references/aida_rules.json`. From `aida-record-keeping`: `aida/records_audit.json`.

---

## Quality checklist

- [ ] At least one metric is selected, and it is computable today
- [ ] Every metric is reported with the record that feeds it
- [ ] Thresholds are the guideline's numbers, not rounded ones
- [ ] The schedule follows the inference frequency, and both are stated
- [ ] Alert rules were written to `aida/alert_rules.json`
- [ ] Every outbound call was checked for timeout, retry and fallback
- [ ] Quality metrics were not mixed into this section
