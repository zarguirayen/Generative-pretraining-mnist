#!/usr/bin/env python3
"""Write section 3.7 of the AIDA technical documentation from the record audit.

    python write_section.py --audit aida/records_audit.json --values aida/values.json

The audit knows which of the nine mandatory records have a mechanism, which of the twelve
required fields are actually carried, and whether the format, retention and storage hold.
This turns that into the four fields the official template asks for - naming what exists,
naming what is missing, and giving the guideline's own deadline for closing it.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

HISTORIZATION = "Input, output, and ground truth data collection and historization mechanisms"
EVENTS = "Logs of the main events on the AI system, including event type, date and who made it"
FEEDBACK = "Methods to log users feedback and alerts"
TOOLS = ("Detail the tools used for record keeping and link to the emplacement of the "
         "records (where applicable)")

DEADLINE = ("Record keeping must be in place before the end of the build phase, and records "
            "made available on demand once the system is in use (REC-SCOPE).")


def readable(name: str) -> str:
    return name.replace("_", " ")


def group_state(audit: dict, rule_id: str) -> tuple[list[str], list[str], list[str]]:
    present, missing, evidence = [], [], []
    for record_id, record in audit["records"].items():
        if record["rule"] != rule_id:
            continue
        if record["present"]:
            present.append(readable(record_id))
            evidence.extend(record["evidence"][:1])
        else:
            missing.append(readable(record_id))
    return present, missing, evidence


def build(audit: dict) -> dict[str, dict]:
    fields = audit["fields"]
    logged = [name for name, field in fields.items() if field["present"]]
    absent = [name for name, field in fields.items() if not field["present"]]
    field_evidence = [item for field in fields.values() for item in field["evidence"][:1]][:4]

    model_present, model_missing, model_ev = group_state(audit, "REC-MODEL-MANDATORY")
    ops_present, ops_missing, ops_ev = group_state(audit, "REC-OPERATIONAL-MANDATORY")
    oversight_present, oversight_missing, _ = group_state(audit, "REC-OVERSIGHT-MANDATORY")

    historization = (
        f"Mandatory model records (REC-MODEL-MANDATORY): "
        f"{', '.join(model_present) or 'none found'} have a mechanism in the codebase"
        + (f"; {', '.join(model_missing)} have none and are gaps to close. " if model_missing
           else ". ")
        + f"Each inference record must carry the fields monitoring needs. Currently "
          f"recorded: {', '.join(logged) or 'none'}. "
        + (f"Missing: {', '.join(absent)}. " if absent else "")
        + "Model version is required on every inference record: a score that cannot be "
          "attributed to a version cannot be compared to a baseline. " + DEADLINE)

    events = (
        f"Every record answers what (event type), when (timestamp) and who (actor). "
        f"Mandatory operational records (REC-OPERATIONAL-MANDATORY): "
        f"{', '.join(ops_present) or 'none found'}"
        + (f"; missing: {', '.join(ops_missing)}. " if ops_missing else ". ")
        + ("Logging is structured. " if audit["format"]["structured"]
           else "Logging is not structured; the guideline requires structured, timestamped, "
                "standardised records so they can be parsed and traced (REC-FORMAT). ")
        + f"Human oversight records (REC-OVERSIGHT-MANDATORY): "
          f"{', '.join(oversight_present) or 'none found'}"
        + (f"; missing: {', '.join(oversight_missing)}." if oversight_missing else "."))

    feedback = (
        "User feedback is the ground-truth path the guideline relies on: a thumbs up / "
        "thumbs down control where a negative signal lets the user say whether the problem "
        "is the generated answer, the retrieval or the tool sequence (MON-USER-FEEDBACK). "
        + ("A feedback mechanism was found in the codebase."
           if audit["records"]["observed_ground_truth_collection"]["present"]
           else "No feedback mechanism was found; this is a gap to close."))

    retention = "10 years for documentation and at least 1 year for automatic logs"
    tools_text = (
        ("Record keeping relies on the mechanisms found above. "
         if model_present or ops_present else
         "No record keeping tool was found in the codebase. ")
        + f"Retention (REC-RETENTION): {retention}, in secure and immutable storage with "
          f"NTP-synchronised timestamps. "
        + ("A retention policy was found. " if audit["retention"]["configured"]
           else "No retention policy was found. ")
        + ("Tamper-evident storage was found. " if audit["immutability"]["configured"]
           else "No tamper-evident storage was found: a log an engineer can edit proves "
                "nothing to an auditor. The generated journal chains each entry to the hash "
                "of the previous one, so an alteration or a deletion is detectable from the "
                "file alone."))

    return {
        HISTORIZATION: entry(historization,
                             source="code" if (model_ev or field_evidence) else "rule",
                             evidence=(model_ev + field_evidence)[:4]),
        EVENTS: entry(events, source="code" if ops_ev else "rule", evidence=ops_ev),
        FEEDBACK: entry(feedback, source="rule"),
        TOOLS: entry(tools_text, source="rule"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Write section 3.7 from the record audit.")
    parser.add_argument("--audit", default="aida/records_audit.json")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json",
                        help="placeholder map - the authority on where an answer may come from")
    args = parser.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"error: audit not found: {audit_path}\n"
              f"       run audit_records.py first", file=sys.stderr)
        return 2

    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    values_path = Path(args.values)
    result = merge(values_path, build(audit), Path(args.routing))
    print(report(result, "3.7 Record Keeping", values_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
