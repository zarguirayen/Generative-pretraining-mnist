#!/usr/bin/env python3
"""Write the record keeping the audit found missing, and show where to call it.

    python generate_records.py --audit aida/records_audit.json --project .

The audit says which of the nine mandatory records have no mechanism and which fields the
inference log never carries. This writes a module that covers them, and prints the call
for each gap - at the endpoint, at deployment, at review time.

It never edits the project's own source: where those calls belong is a decision about the
application, not about compliance.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "assets" / "aida_records.py.template"

# record id -> (where the call belongs, the call itself)
CALL_SITES: dict[str, tuple[str, str]] = {
    "inference_input_data": (
        "in the request handler, once the answer is produced",
        'records.inference(session_id=session_id, request_id=request_id,\n'
        '                  model_version=MODEL_ID, input=question, output=answer,\n'
        '                  latency_ms=elapsed_ms, tokens=usage, actor=caller)'),
    "inference_output_data": (
        "same call as the input - one record holds both",
        'records.inference(... output=answer ...)'),
    "observed_ground_truth_collection": (
        "in the feedback endpoint, when a user corrects an answer",
        'records.ground_truth(request_id=request_id, observed=correction, source="user")'),
    "model_training_data": (
        "wherever a dataset version is pinned for a model version",
        'records.model_dataset("training", uri=DATASET_URI, version=DATASET_VERSION)'),
    "model_validation_test_data": (
        "next to the training dataset record",
        'records.model_dataset("validation", uri=EVAL_URI, version=EVAL_VERSION)'),
    "model_training_performance_metrics": (
        "after the evaluation run, before a version goes to production",
        'records.model_performance(model_version=MODEL_ID, metrics=summary,\n'
        '                          deployed_at=deploy_date)'),
    "change_deployment_record": (
        "in the deployment pipeline, or at application startup",
        'records.deployment(from_version=previous, to_version=current,\n'
        '                   reason=release_note, actor=deployer)'),
    "system_access_log": (
        "in the authentication middleware",
        'records.access(actor=caller, access_type="API call", resource=path,\n'
        '               status=outcome)'),
    "human_review_record": (
        "wherever a person accepts, overrides or escalates an output",
        'records.human_review(item_id=request_id, reviewer=reviewer,\n'
        '                     verdict="overridden", comment=note)'),
}


def render_plan(audit: dict, target: Path, written: bool) -> str:
    missing = [rid for rid, record in audit["records"].items() if not record["present"]]
    missing_fields = [name for name, field in audit["fields"].items() if not field["present"]]

    lines = [f"{'Wrote' if written else 'Would write'}: {target}", ""]
    lines.append("It provides one helper per mandatory record, and a hash-chained journal:")
    lines.append("  record()            append-only, credentials redacted, prev hash on every entry")
    lines.append("  verify()            walks the chain and reports where it stops holding")
    lines.append("  require_intact()    raises at startup if the journal was altered")
    lines.append("  nine record helpers covering REC-MODEL, REC-OPERATIONAL and REC-OVERSIGHT")

    if missing:
        lines.append("")
        lines.append(f"Add {len(missing)} missing record(s):")
        for record_id in missing:
            where, call = CALL_SITES.get(record_id, ("", ""))
            if not call:
                continue
            lines.append("")
            lines.append(f"# {record_id.replace('_', ' ')} - {where}")
            lines.append("import aida_records as records")
            lines.append(call)
    else:
        lines.append("\nEvery mandatory record already has a mechanism.")

    if missing_fields:
        lines.append("")
        lines.append(f"The inference record must also carry {len(missing_fields)} field(s) "
                     f"never logged today:")
        lines.append(f"  {', '.join(missing_fields)}")
        lines.append("  `model_version` is a required argument of records.inference() for "
                     "that reason: a score that cannot be attributed to a version cannot be "
                     "compared to a baseline.")

    lines.append("")
    lines.append("Still to decide, because code cannot decide it:")
    lines.append("  - where the journal lives: the guideline expects secure, immutable storage")
    lines.append("  - retention: 10 years for documentation, at least 1 year for automatic logs")
    lines.append("  - whether the actor must be anonymised or hashed for your data policy")
    lines.append("  - NTP synchronisation on the hosts, so timestamps are comparable")
    lines.append("")
    lines.append("Verify the journal at any time, with nothing but the file:")
    lines.append("  python verify_chain.py logs/aida_records.jsonl")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the missing record keeping.")
    parser.add_argument("--audit", default="aida/records_audit.json")
    parser.add_argument("--project", default=".")
    parser.add_argument("--out", default="aida/generated/aida_records.py")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"error: audit not found: {audit_path}\n"
              f"       run audit_records.py first", file=sys.stderr)
        return 2
    if not TEMPLATE.exists():
        print(f"error: template missing: {TEMPLATE}", file=sys.stderr)
        return 2

    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    target = Path(args.project) / args.out

    written = False
    if not args.dry_run:
        if target.exists():
            print(f"{target} already exists - not overwriting. Delete it to regenerate.")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(TEMPLATE.read_text(encoding="utf-8"), encoding="utf-8")
            written = True

    print(render_plan(audit, target, written))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
