# Human oversight requirements

Source: AI Factory, *Monitoring and Human Oversight* guideline, section 6 — EU AI Act
Articles 14 and 72. Applies to **VRM risk categories 1 and 2**.

## Contents

- [The six capabilities](#the-six-capabilities)
- [Transparency for the overseer](#transparency-for-the-overseer)
- [Explainability — pick at least one](#explainability--pick-at-least-one)
- [Intervention mechanisms](#intervention-mechanisms)
- [Automation bias](#automation-bias)
- [Biometric systems](#biometric-systems)
- [What gets recorded](#what-gets-recorded)
- [How the audit maps to all this](#how-the-audit-maps-to-all-this)

---

## The six capabilities

The system must be built so that a natural person can:

1. understand its capabilities and limits;
2. interpret its results, and stay aware of the risk of misinterpreting them;
3. detect anomalies using factual, interpretable and intelligible indicators;
4. **override or reverse** a result;
5. **interrupt** operations, through a stop button or an equivalent procedure;
6. stay aware of the tendency to rely automatically or excessively on the output.

Rule id: `OVERSIGHT-CAPABILITIES`. Four and five are the two that need code; the others
need interface and training.

## Transparency for the overseer

- **Dashboards** showing model and operational metrics over time, accessible to overseers,
  risk challengers and assessors.
- **Automated alerts** when a threshold is crossed.
- **Audit logs of alerts** — the trigger, the justification, and what was done.
- **Human oversight logs** — interventions and their justification, in the AI System
  Journal of the technical documentation.
- **Accessible documentation** — the methodology, thresholds and rationale, in language an
  overseer can read.

## Explainability — pick at least one

Rule id: `OVERSIGHT-EXPLAINABILITY`.

| Option | When it fits |
|---|---|
| Confidence scores | a score or probability accompanies the output |
| Feature importance (SHAP, LIME) | tabular or classical ML |
| **Reference links or sources** | **the guideline's named option for GenAI** — show the retrieved evidence behind the answer |
| Decision logic and lineage | access to training and inference lineage |
| Error and limit warnings | signal when the system runs outside its training scope |

For a RAG system, showing sources is both the cheapest and the one the guideline names.

## Intervention mechanisms

Rule id: `OVERSIGHT-INTERVENTION`.

- **Stop / override control** — a secure control that halts the system immediately, and
  the ability to disregard, override or reverse an output at any moment.
- **Granular controls** — pause or quarantine a single output, session or account without
  shutting the whole system down.
- **User alert mechanism** — an in-app report or flag for PII, toxic, biased or
  copyright-infringing content.
- **Escalation pathways** — who is alerted, and within what time.
- **Automatic escalation** — user-submitted alerts routed to the designated overseers.
- **Alert logging and tracking** — every alert, intervention and override, kept.

## Automation bias

Reduce over-reliance with warnings, disclaimers, confidence thresholds or training. For
autonomous or automatic decision-making, include a method to evaluate automation bias —
user feedback counts, random sample testing, adversarial campaigns.

Oversight must be proportionate to the risk, the degree of autonomy and the context.

## Biometric systems

For biometric identification, any decision or action based on the system's result must be
verified by **at least two separate competent persons** (`OVERSIGHT-BIOMETRIC-4EYES`).

## What gets recorded

From the Record Keeping guideline, mandatory for internally developed systems:

- **Human Review Record*** — a human reviewed an output: reviewer, item, date, verdict.
- Oversight Feedback Record — structured feedback that feeds future improvements.
- Alert Trigger Record — the alert, its severity, when, and who it went to.
- Alert Follow-up Record — what was done, the justification, whether it is resolved.

Substantial interventions also go into the **AI System Journal** of the technical
documentation (`DOC-JOURNAL`). That is what turns oversight from a claim into an
auditable fact.

## How the audit maps to all this

`audit_oversight.py` checks what code can show, and nothing else:

| Requirement | How it is checked | Reported as |
|---|---|---|
| override / stop (capability 4 and 5) | search for a stop, disable or circuit-breaker control | blocking when absent and tools exist |
| approval before an irreversible action | per tool, on the syntax tree | blocking, listed tool by tool |
| explainability | search for source citation in the outputs | blocking when nothing is found |
| user alert mechanism | search for a feedback or flag path | blocking when absent |
| named overseers | **not checkable from code** | asked from the risk owner |
| training and awareness | **not checkable from code** | asked from the risk owner |

The last two rows matter as much as the others: a tool that reported them as satisfied
would be lying.

## Three things the audit reports but does not judge

**Tools behind an MCP server.** Their definitions live outside the codebase, so the audit
cannot see what they do or whether they are irreversible. When an MCP configuration is
found, the server names are reported and the tool count is stated as a **floor, not a
total**. The monitoring guideline treats these as black-box tools whose responses must be
watched for drift; their irreversibility has to be established with the server owner, and
they belong in section 3.9 by name.

**A project-level approval policy.** Some systems gate actions through an allowlist of
permitted commands or a permission layer rather than a decorator on each tool. That is a
real control, so it is reported when found — but it does not close a per-tool finding,
because a policy existing is not the same as a policy covering the tool in question. The
finding stays blocking and asks for that coverage to be confirmed.

**Isolated execution.** Running tool calls in a container limits what an unreviewed action
can reach, and the evaluation guideline wants tool calls sandboxed during evaluation
precisely for that reason. The audit reports the marker it found and **asks whether tool
calls really execute in isolation** rather than asserting it — the word `docker` appearing
in a repository proves nothing. Either way, isolation never replaces the approval
`OVERSIGHT-INTERVENTION` requires: a sandboxed agent that sends the wrong email has still
sent it.
