#!/usr/bin/env python3
"""Run every AIDA analysis on a project and rule on each requirement.

    python run_audit.py [project] [--inference-frequency daily] [--out aida/audit.json]

This orchestrates; it does not analyse. Each skill owns its own check, and re-implementing
any of them here would create a second opinion that could disagree with the first.

Every rule in `aida_rules.json` gets one of four verdicts:

    met          the evidence shows the requirement is satisfied
    not_met      the evidence shows it is not
    needs_human  code cannot answer it - only the risk owner can
    n/a          the rule does not apply to this system

The fourth status is what keeps the score honest. Roughly a third of the requirements are
organisational: whether records are truly kept in production, whether overseers were
trained, what the intended purpose is. A tool that scored those would be inventing a
verdict, so they are counted apart and never folded into the percentage.

Exit code 0 when nothing is `not_met`, 1 otherwise, 2 on a usage error.
Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILLS = HERE.parent.parent
RULES_PATH = SKILLS / "aida-core" / "references" / "aida_rules.json"

for skill in ("aida-core", "aida-human-oversight", "aida-record-keeping",
              "aida-genai-monitoring", "aida-operational-monitoring"):
    sys.path.insert(0, str(SKILLS / skill / "scripts"))

MET, NOT_MET, NEEDS_HUMAN, NOT_APPLICABLE = "met", "not_met", "needs_human", "n/a"

AREA_LABELS = {
    "architecture": "Architecture and autonomy",
    "observability": "Observability",
    "evaluation": "Evaluation",
    "security": "Security",
    "monitoring": "Model monitoring",
    "genai_monitoring": "GenAI quality monitoring",
    "operational_monitoring": "Operational monitoring",
    "human_oversight": "Human oversight",
    "record_keeping": "Record keeping",
    "documentation": "Documentation",
}


def collect(project: Path, inference_frequency: str | None) -> dict:
    """Run each skill's analysis. A failing analysis is reported, never silently skipped."""
    from audit_oversight import audit as audit_oversight
    from audit_records import audit as audit_records
    from check_resilience import check as check_resilience
    from plan_monitoring import build_plan as plan_genai
    from plan_operational import build_plan as plan_operational
    from scan_codebase import build_context

    rules = json.loads(RULES_PATH.read_text(encoding="utf-8"))
    artefacts: dict[str, dict] = {"errors": {}}

    def step(name: str, fn):
        try:
            artefacts[name] = fn()
        except Exception:                              # noqa: BLE001 - reported, not hidden
            artefacts[name] = None
            artefacts["errors"][name] = traceback.format_exc(limit=2).strip().splitlines()[-1]

    step("context", lambda: build_context(project))
    step("oversight", lambda: audit_oversight(project))
    step("records", lambda: audit_records(project))
    step("resilience", lambda: check_resilience(project))
    if artefacts.get("context"):
        step("genai_monitoring",
             lambda: plan_genai(artefacts["context"], rules, project, inference_frequency))
        step("operational_monitoring",
             lambda: plan_operational(artefacts["context"], rules, artefacts.get("records"),
                                      inference_frequency))
    artefacts["rules"] = rules
    return artefacts


# --------------------------------------------------------------------- verdicts --
def has(section: dict | None, key: str) -> bool:
    return bool(section) and key in section


def verdict_for(rule: dict, a: dict) -> tuple[str, str]:
    """Return (status, why). `why` is what a reader needs to act, in one line."""
    rid = rule["id"]
    ctx = a.get("context") or {}
    classification = ctx.get("classification") or {}
    family = classification.get("family", "unknown")
    level = classification.get("agentic_level")
    oversight = a.get("oversight") or {}
    records = a.get("records") or {}
    genai = a.get("genai_monitoring") or {}
    ops = a.get("operational_monitoring") or {}
    resilience = a.get("resilience") or {}

    # --- architecture -------------------------------------------------------
    if rid == "BUILD-L1-DEFAULT":
        if level not in ("L2", "L3"):
            return NOT_APPLICABLE, "the system is not L2 or L3"
        return NEEDS_HUMAN, (f"the system is {level}; the necessity for that autonomy must be "
                             f"justified in the technical documentation")
    if rid in ("BUILD-STACK-L1", "BUILD-STACK-L2"):
        if not level:
            return NOT_APPLICABLE, "not an agentic system"
        found = classification.get("reference_framework")
        if not found:
            return NEEDS_HUMAN, "no orchestration framework recognised in the code"
        return MET, f"{found} is in use"
    if rid == "BUILD-OBSERVABILITY":
        if not level:
            return NOT_APPLICABLE, "not an agentic system"
        return (MET, "MLflow found") if has(ctx.get("observability"), "mlflow") else \
               (NOT_MET, "MLflow is the reference observability framework and was not found")
    if rid == "BUILD-EVALUATION":
        if not level:
            return NOT_APPLICABLE, "not an agentic system"
        return (MET, "DeepEval found") if has(ctx.get("evaluation"), "deepeval") else \
               (NOT_MET, "DeepEval is the reference evaluation framework and was not found")
    if rid == "BUILD-REDTEAM":
        if not level:
            return NOT_APPLICABLE, "not an agentic system"
        return (MET, "DeepTeam found") if has(ctx.get("security"), "deepteam") else \
               (NOT_MET, "no red-teaming framework found")

    # --- evaluation ---------------------------------------------------------
    if rid in ("EVAL-RAG-QUERIES", "EVAL-RAG-CORPUS", "EVAL-RAG-METRICS"):
        if family not in ("rag", "hybrid"):
            return NOT_APPLICABLE, "not a RAG system"
        return NEEDS_HUMAN, "dataset size and metric coverage are not visible in the code"
    if rid in ("EVAL-AGENTIC-QUERIES", "EVAL-AGENTIC-CATEGORIES"):
        if family not in ("agentic", "hybrid"):
            return NOT_APPLICABLE, "not an agentic system"
        return NEEDS_HUMAN, "evaluation set size and metric coverage are not visible in the code"

    # --- monitoring ---------------------------------------------------------
    if rid == "MON-TIMING":
        return NEEDS_HUMAN, "whether monitoring was in place before release is not in the code"
    if rid == "MON-FREQUENCY":
        schedule = (genai.get("schedule") or {}).get("monitoring_frequency")
        return (MET, f"{schedule} monitoring, derived from the inference frequency") if schedule \
            else (NOT_MET, "inference frequency unknown, so no schedule could be derived")
    if rid.startswith("MON-THRESHOLD-"):
        expected = {"prompt": "MON-THRESHOLD-PROMPT", "rag": "MON-THRESHOLD-RAG",
                    "agentic": "MON-THRESHOLD-AGENTIC", "hybrid": "MON-THRESHOLD-RAG"}
        if rid == "MON-THRESHOLD-ANALYTICS-LABELED":
            return NOT_APPLICABLE, "not an analytics model"
        if expected.get(family) != rid:
            return NOT_APPLICABLE, f"applies to another family than {family}"
        with_threshold = [m for m in genai.get("metrics", []) if m.get("alert_threshold")]
        return (MET, f"{len(with_threshold)} threshold(s) derived from the measured baseline") \
            if with_threshold else (NOT_MET, "no baseline, so no threshold could be derived")
    if rid == "MON-DRIFT-UNLABELED":
        return NOT_APPLICABLE, "applies to analytics and NLP models"
    if rid == "MON-DRIFT-TOOLSET":
        if not level:
            return NOT_APPLICABLE, "not an agentic system"
        return NEEDS_HUMAN, ("run detect_tool_drift.py between the documented version and HEAD; "
                             "whether it runs continuously is a process question")
    if rid == "MON-OPERATIONAL-MINIMUM":
        computable = [m for m in ops.get("metrics", []) if m.get("computable_today")]
        if computable:
            return MET, f"{len(computable)} metric(s) computable from existing records"
        return NOT_MET, "no metric from the guideline table can be computed today"
    if rid == "MON-GENAI-QUALITY-MINIMUM":
        if family == "unknown":
            return NOT_MET, "the system family is unknown, so no metric set applies"
        return (MET, "metric set selected for the family") if genai.get("metrics") \
            else (NOT_MET, "no quality metric selected")
    if rid == "MON-USER-FEEDBACK":
        if family not in ("rag", "agentic", "hybrid"):
            return NOT_APPLICABLE, "applies to RAG and agentic systems"
        return (MET, "a feedback path was found") if (oversight.get("controls") or {}).get("user_feedback") \
            else (NOT_MET, "no user feedback path found")

    # --- human oversight ----------------------------------------------------
    if rid == "OVERSIGHT-SCOPE":
        return NEEDS_HUMAN, "the VRM risk category decides whether these rules apply"
    if rid == "OVERSIGHT-CAPABILITIES":
        controls = oversight.get("controls") or {}
        if not oversight.get("tools") and not controls.get("stop_control"):
            return NEEDS_HUMAN, "no tools recognised; confirm how the system is interrupted"
        return (MET, "a stop or disable control was found") if controls.get("stop_control") \
            else (NOT_MET, "no stop or disable control found")
    if rid == "OVERSIGHT-EXPLAINABILITY":
        controls = oversight.get("controls") or {}
        return (MET, "source citation found in the outputs") if controls.get("source_citation") \
            else (NOT_MET, "no explainability measure found")
    if rid == "OVERSIGHT-INTERVENTION":
        counts = oversight.get("counts") or {}
        if not counts.get("irreversible"):
            return NOT_APPLICABLE, "no irreversible tool found"
        if counts.get("ungated"):
            return NOT_MET, (f"{counts['ungated']} irreversible tool(s) run with no human "
                             f"approval gate")
        return MET, "every irreversible tool is behind an approval gate"
    if rid == "OVERSIGHT-BIOMETRIC-4EYES":
        return NOT_APPLICABLE, "not a biometric identification system"

    # --- record keeping -----------------------------------------------------
    if rid == "REC-SCOPE":
        return NEEDS_HUMAN, "the VRM risk category decides whether these rules apply"
    if rid in ("REC-MODEL-MANDATORY", "REC-OPERATIONAL-MANDATORY", "REC-OVERSIGHT-MANDATORY"):
        missing = [k for k, v in (records.get("records") or {}).items()
                   if v.get("rule") == rid and not v.get("present")]
        if not records:
            return NEEDS_HUMAN, "record audit unavailable"
        return (NOT_MET, f"{len(missing)} mandatory record(s) with no mechanism: "
                         f"{', '.join(m.replace('_', ' ') for m in missing)}") if missing \
            else (MET, "every mandatory record of this group has a mechanism")
    if rid == "REC-FORMAT":
        if not records:
            return NEEDS_HUMAN, "record audit unavailable"
        if not (records.get("format") or {}).get("structured"):
            return NOT_MET, "logging is not structured"
        missing = [k for k, v in (records.get("fields") or {}).items() if not v.get("present")]
        return (NOT_MET, f"{len(missing)} required field(s) never logged") if missing \
            else (MET, "structured logging with every required field")
    if rid == "REC-RETENTION":
        if not records:
            return NEEDS_HUMAN, "record audit unavailable"
        problems = []
        if not (records.get("retention") or {}).get("configured"):
            problems.append("no retention policy")
        if not (records.get("immutability") or {}).get("configured"):
            problems.append("no tamper-evident storage")
        return (NOT_MET, " and ".join(problems)) if problems else \
            (MET, "retention and immutable storage configured")

    # --- documentation ------------------------------------------------------
    if rid in ("DOC-JOURNAL", "DOC-METHODOLOGY", "DOC-UPDATE-ON-CHANGE"):
        return NEEDS_HUMAN, "verified against the generated document, not against the code"

    return NEEDS_HUMAN, "no automated check defined for this rule"


def evaluate(artefacts: dict) -> dict:
    rules = artefacts["rules"]["rules"]
    verdicts = []
    for rule in rules:
        status, why = verdict_for(rule, artefacts)
        verdicts.append({
            "rule": rule["id"],
            "area": rule.get("area", "other"),
            "severity": rule.get("severity", "advisory"),
            "status": status,
            "why": why,
            "requirement": rule["requirement"][:220],
            "source": rule.get("source", ""),
        })

    by_area: dict[str, dict] = {}
    for verdict in verdicts:
        bucket = by_area.setdefault(verdict["area"], {MET: 0, NOT_MET: 0,
                                                      NEEDS_HUMAN: 0, NOT_APPLICABLE: 0})
        bucket[verdict["status"]] += 1

    checked = [v for v in verdicts if v["status"] in (MET, NOT_MET)]
    met = [v for v in checked if v["status"] == MET]
    return {
        "verdicts": verdicts,
        "by_area": by_area,
        "totals": {
            "rules": len(verdicts),
            "verifiable": len(checked),
            "met": len(met),
            "not_met": len(checked) - len(met),
            "needs_human": sum(1 for v in verdicts if v["status"] == NEEDS_HUMAN),
            "not_applicable": sum(1 for v in verdicts if v["status"] == NOT_APPLICABLE),
            "score_pct": round(len(met) * 100 / len(checked)) if checked else None,
        },
    }


def build(project: Path, inference_frequency: str | None) -> dict:
    artefacts = collect(project, inference_frequency)
    assessment = evaluate(artefacts)
    ctx = artefacts.get("context") or {}
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "project": {
            "path": str(project.resolve()),
            "name": (ctx.get("project") or {}).get("name", project.name),
            "classification": ctx.get("classification", {}),
        },
        "inference_frequency": inference_frequency,
        "assessment": assessment,
        "artefact_errors": artefacts["errors"],
        "artefacts": {
            "oversight": artefacts.get("oversight"),
            "records": artefacts.get("records"),
            "resilience": artefacts.get("resilience"),
            "genai_monitoring": artefacts.get("genai_monitoring"),
            "operational_monitoring": artefacts.get("operational_monitoring"),
        },
    }


def render(audit: dict) -> str:
    totals = audit["assessment"]["totals"]
    classification = audit["project"]["classification"] or {}
    level = f" / {classification.get('agentic_level')}" if classification.get("agentic_level") else ""

    lines = [
        f"AIDA audit - {audit['project']['name']}",
        f"Classification : {classification.get('family', 'unknown')}{level}"
        f"  (certainty: {classification.get('certainty', 'low')})",
        "",
        f"Requirements   : {totals['rules']}",
        f"  verifiable from the code : {totals['verifiable']}"
        f"   -> {totals['met']} met, {totals['not_met']} not met",
        f"  only the risk owner can answer : {totals['needs_human']}",
        f"  not applicable : {totals['not_applicable']}",
    ]
    if totals["score_pct"] is not None:
        lines.append(f"  score on what is verifiable : {totals['score_pct']}%")

    lines.append("")
    lines.append(f"{'AREA':<28} {'MET':<5} {'NOT MET':<9} {'HUMAN':<7} N/A")
    for area, counts in sorted(audit["assessment"]["by_area"].items()):
        label = AREA_LABELS.get(area, area)
        lines.append(f"{label[:27]:<28} {counts[MET]:<5} {counts[NOT_MET]:<9} "
                     f"{counts[NEEDS_HUMAN]:<7} {counts[NOT_APPLICABLE]}")

    failing = [v for v in audit["assessment"]["verdicts"] if v["status"] == NOT_MET]
    if failing:
        lines.append(f"\nNOT MET ({len(failing)})")
        for verdict in failing:
            lines.append(f"  [{verdict['rule']}] {verdict['why']}")

    if audit["artefact_errors"]:
        lines.append("\nANALYSES THAT DID NOT RUN")
        for name, error in audit["artefact_errors"].items():
            lines.append(f"  {name}: {error}")
        lines.append("  Their rules are counted as needing a human, not as met.")

    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the full AIDA audit of a project.")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--inference-frequency",
                        choices=["daily", "weekly", "monthly", "quarterly"])
    parser.add_argument("--out", default="aida/audit.json")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    project = Path(args.project).expanduser().resolve()
    if not project.is_dir():
        print(f"error: not a directory: {project}", file=sys.stderr)
        return 2

    audit = build(project, args.inference_frequency)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(audit, indent=2, ensure_ascii=False) if args.json else render(audit))
    print(f"\naudit written to {out}")
    return 1 if audit["assessment"]["totals"]["not_met"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
