#!/usr/bin/env python3
"""Turn the audit into a report a person will actually read.

    python render_report.py [--audit aida/audit.json] [--out aida/audit_report.md]

The audit JSON is complete and unreadable; this is the other half. It leads with what is
not met, because that is what someone opens the report to find, and it keeps the questions
for the risk owner in one block so they can be asked in a single conversation instead of
five.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

MET, NOT_MET, NEEDS_HUMAN, NOT_APPLICABLE = "met", "not_met", "needs_human", "n/a"

AREA_LABELS = {
    "architecture": "Architecture and autonomy",
    "observability": "Observability",
    "evaluation": "Evaluation",
    "security": "Security",
    "monitoring": "Model monitoring",
    "genai_monitoring": "GenAI quality monitoring",
    "operational_monitoring": "Operational monitoring",
    "human_oversight": "Human oversight",
    "record_keeping": "Record keeping",
    "documentation": "Documentation",
}
# Deliverable each area feeds, so a reader knows which document a gap lands in.
AREA_SECTION = {
    "record_keeping": "3.7 Record Keeping",
    "genai_monitoring": "3.8 AI Model Monitoring",
    "monitoring": "3.8 AI Model Monitoring",
    "operational_monitoring": "3.8 AI System Operational Monitoring",
    "human_oversight": "3.9 Human Oversight Measures",
    "architecture": "3.5 AI System Architecture",
    "evaluation": "3.3 Validation and Testing",
    "security": "3.10 Cybersecurity Measures",
    "observability": "3.7 Record Keeping",
    "documentation": "the document as a whole",
}



def yes_no(flag) -> str:
    """A missing safeguard is bold, so it stands out in the table."""
    return "yes" if flag else "**no**"

def light(counts: dict) -> str:
    """Red, amber or green for an area."""
    if counts[NOT_MET] == 0 and counts[MET] > 0:
        return "green"
    if counts[NOT_MET] == 0:
        return "amber"
    return "red" if counts[NOT_MET] > counts[MET] else "amber"


def header(audit: dict) -> list[str]:
    project = audit["project"]
    classification = project.get("classification") or {}
    level = classification.get("agentic_level")
    totals = audit["assessment"]["totals"]

    lines = [
        f"# AIDA compliance audit — {project['name']}",
        "",
        f"*Generated {audit['generated_at']} from the codebase at `{project['path']}`.*",
        "",
        "| | |",
        "|---|---|",
        f"| System family | {classification.get('family', 'unknown')}"
        f"{f' — {level}' if level else ''} |",
        f"| Classification certainty | {classification.get('certainty', 'low')} |",
        f"| Requirements assessed | {totals['rules']} |",
        f"| Verifiable from the code | {totals['verifiable']} "
        f"({totals['met']} met, {totals['not_met']} not met) |",
        f"| Only the risk owner can answer | {totals['needs_human']} |",
        f"| Not applicable to this system | {totals['not_applicable']} |",
    ]
    if totals["score_pct"] is not None:
        lines.append(f"| **Score on what is verifiable** | **{totals['score_pct']}%** |")
    lines += [
        "",
        "> The score covers only the requirements a codebase can answer. The "
        f"{totals['needs_human']} requirements that depend on people, process or another "
        "internal system are listed separately and are deliberately left out of it: "
        "scoring them would mean inventing a verdict.",
    ]
    return lines


def scorecard(audit: dict) -> list[str]:
    lines = ["", "## Scorecard", "",
             "| Area | Status | Met | Not met | Needs risk owner | Feeds |",
             "|---|---|---:|---:|---:|---|"]
    for area, counts in sorted(audit["assessment"]["by_area"].items(),
                               key=lambda item: (-item[1][NOT_MET], item[0])):
        lines.append(
            f"| {AREA_LABELS.get(area, area)} | {light(counts)} | {counts[MET]} | "
            f"{counts[NOT_MET]} | {counts[NEEDS_HUMAN]} | "
            f"{AREA_SECTION.get(area, '—')} |")
    return lines


def failures(audit: dict) -> list[str]:
    failing = [v for v in audit["assessment"]["verdicts"] if v["status"] == NOT_MET]
    if not failing:
        return ["", "## Not met", "", "Nothing. Every verifiable requirement is satisfied."]

    lines = ["", f"## Not met ({len(failing)})", ""]
    for verdict in sorted(failing, key=lambda v: (v["severity"] != "blocking", v["rule"])):
        lines += [
            f"### `{verdict['rule']}` — {AREA_LABELS.get(verdict['area'], verdict['area'])}",
            "",
            f"**Finding.** {verdict['why']}",
            "",
            f"**Requirement.** {verdict['requirement']}",
            "",
            f"*Source: {verdict['source']} · lands in {AREA_SECTION.get(verdict['area'], '—')}*",
            "",
        ]
    return lines


def questions(audit: dict) -> list[str]:
    pending = [v for v in audit["assessment"]["verdicts"] if v["status"] == NEEDS_HUMAN]
    if not pending:
        return []
    lines = ["", f"## For the risk owner ({len(pending)})", "",
             "These cannot be answered from the code. Ask them in one conversation.", "",
             "| Rule | What is needed |", "|---|---|"]
    for verdict in sorted(pending, key=lambda v: v["rule"]):
        lines.append(f"| `{verdict['rule']}` | {verdict['why']} |")
    return lines


def evidence(audit: dict) -> list[str]:
    lines = ["", "## Evidence"]
    artefacts = audit.get("artefacts") or {}

    oversight = artefacts.get("oversight")
    if oversight and oversight.get("tools"):
        counts = oversight["counts"]
        lines += ["", "### Tools the model can call", "",
                  f"{counts['tools']} tools, {counts['irreversible']} irreversible, "
                  f"{counts['gated']} behind a human approval gate.", "",
                  "| Tool | Severity | Gate | Where |", "|---|---|---|---|"]
        for tool in oversight["tools"]:
            gate = "yes" if tool["approval_gate"] else ("**no**" if tool["irreversible"] else "—")
            lines.append(f"| `{tool['name']}` | {tool['severity']} | {gate} | "
                         f"`{tool['file']}:{tool['line']}` |")

    records = artefacts.get("records")
    if records:
        counts = records["counts"]
        lines += ["", "### Records", "",
                  f"{counts['records_present']} of {counts['records_mandatory']} mandatory "
                  f"records have a mechanism; {counts['fields_present']} of "
                  f"{counts['fields_required']} required fields are logged."]

    resilience = artefacts.get("resilience")
    if resilience and resilience.get("calls"):
        counts = resilience["counts"]
        lines += ["", "### Outbound dependencies", "",
                  f"{counts['outbound']} calls — {counts['with_timeout']} with a timeout, "
                  f"{counts['with_retry']} with a retry, {counts['with_fallback']} with a "
                  f"fallback.", "",
                  "| Dependency | Call | Timeout | Retry | Fallback | Where |",
                  "|---|---|---|---|---|---|"]
        for call in resilience["calls"]:
            lines.append(f"| {call['dependency']} | `{call['call']}` | "
                         f"{yes_no(call['timeout'])} | {yes_no(call['retry'])} | "
                         f"{yes_no(call['fallback'])} | `{call['file']}:{call['line']}` |")

    genai = artefacts.get("genai_monitoring")
    if genai and genai.get("metrics"):
        lines += ["", "### Monitoring thresholds", "",
                  f"Baseline: `{genai.get('baseline_source') or 'none found'}` — "
                  f"threshold rule `{genai.get('threshold_rule')}` at "
                  f"{genai.get('relative_drop_pct')}% relative drop.", "",
                  "| Metric | Baseline | Alert below |", "|---|---:|---:|"]
        for metric in genai["metrics"]:
            baseline = metric["baseline"] if metric["baseline"] is not None else "—"
            threshold = metric["alert_threshold"] if metric["alert_threshold"] is not None else "—"
            lines.append(f"| {metric['metric']} | {baseline} | {threshold} |")

    errors = audit.get("artefact_errors") or {}
    if errors:
        lines += ["", "### Analyses that did not run", ""]
        for name, error in errors.items():
            lines.append(f"- **{name}**: {error}")
        lines.append("")
        lines.append("Their requirements are reported as needing a human, never as met.")

    return lines


def footer() -> list[str]:
    return [
        "", "---", "",
        "Produced by the `aida-compliance` plugin. Every finding above is derived from the "
        "code and cites where it was found; nothing in this report is inferred from intent "
        "or from documentation. A requirement the code cannot answer is reported as such "
        "rather than assumed satisfied.",
        "",
        "This report is input to the AIDA process, not a substitute for it.",
    ]


def render(audit: dict) -> str:
    return "\n".join(header(audit) + scorecard(audit) + failures(audit)
                     + questions(audit) + evidence(audit) + footer()) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Render the AIDA audit as a report.")
    parser.add_argument("--audit", default="aida/audit.json")
    parser.add_argument("--out", default="aida/audit_report.md")
    args = parser.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"error: audit not found: {audit_path}\n"
              f"       run run_audit.py first", file=sys.stderr)
        return 2

    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render(audit), encoding="utf-8")

    totals = audit["assessment"]["totals"]
    print(f"Report written to {out}")
    print(f"  {totals['met']} met, {totals['not_met']} not met, "
          f"{totals['needs_human']} for the risk owner")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
