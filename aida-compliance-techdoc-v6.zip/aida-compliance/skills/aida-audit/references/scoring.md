# How the audit rules on each requirement

Every rule in `aida_rules.json` gets exactly one of four verdicts. This file records how
each is decided, so a reader can challenge a verdict rather than having to trust it.

## Contents

- [The four verdicts](#the-four-verdicts)
- [What the score means](#what-the-score-means)
- [Verdict by area](#verdict-by-area)
- [What is deliberately not scored](#what-is-deliberately-not-scored)
- [When an analysis fails](#when-an-analysis-fails)

---

## The four verdicts

| Verdict | Decided when |
|---|---|
| `met` | an analysis produced evidence that the requirement holds |
| `not_met` | an analysis produced evidence that it does not |
| `needs_human` | no evidence in the code can settle it |
| `n/a` | the rule addresses a family, level or system type this project is not |

There is no `partially met`. A requirement that is half satisfied is not satisfied, and a
half-verdict would be the first place a reader stops trusting the report.

## What the score means

    score = met / (met + not_met)

Only requirements with a `met` or `not_met` verdict enter it. `needs_human` and `n/a` are
excluded, and the counts are always shown next to the percentage so the denominator is
visible.

A project can therefore score 100% and still be far from compliant: it means everything a
codebase can demonstrate is in place, and the organisational requirements remain. The
report says this in plain words rather than relying on the reader to infer it.

## Verdict by area

**Architecture.** The reference stack is checked against the detected autonomy level. The
L1-default rule is never `met` automatically: an L2 or L3 system always needs a written
justification, so it returns `needs_human`. Below L2 it is `n/a`.

**Observability, evaluation, security.** MLflow, DeepEval and DeepTeam are the reference
frameworks for agentic systems; present or absent is a fact the code shows. For a
non-agentic system these are `n/a`.

**Evaluation data.** Dataset sizes — 50 questions for RAG, 20 queries for agentic — are
`needs_human`. A dataset file in the repository is not proof that it is the evaluation set,
and counting its rows would be a guess dressed as a measurement.

**Monitoring.** The frequency rule is `met` once a schedule was derived from a stated
inference frequency. A threshold rule is `met` only when a threshold was derived from a
measured baseline; with no baseline it is `not_met`, because a threshold with nothing behind
it is not a threshold. Only the rule matching the system family is assessed; the others are
`n/a`.

**Operational monitoring.** `met` when at least one metric of the guideline table is
computable from records the project actually keeps. A metric selected without its feeding
record does not count — that is the whole reason the plan reads the record audit.

**Human oversight.** Decided per tool. Irreversible tools with no approval gate make
`OVERSIGHT-INTERVENTION` `not_met`; the count is in the finding. Where no tool is
recognised at all the verdict is `needs_human`, not `met`: absence of evidence is not
evidence of absence.

**Record keeping.** The three mandatory groups are `met` only when every record in the
group has a mechanism, and the finding names the missing ones. Format covers both structured
logging and field coverage. Retention covers both the policy and tamper-evident storage,
and fails if either is missing.

**Documentation.** All three rules are `needs_human`: they are verified against the
generated document and the AI System Journal, not against the code.

## What is deliberately not scored

- **Intended purpose, risk category, system owner, named overseers.** Only the risk owner
  knows them. Deriving them from a README would be the exact failure this plugin exists to
  prevent.
- **Whether records are actually written in production.** The code shows a mechanism; it
  cannot show that it runs, that its output is retained, or that anyone can reach it.
- **Training and awareness of overseers.** Organisational, and unknowable from a repository.
- **Bias and fairness.** The evaluation guideline places them in the risk and validation
  domain, outside its own scope. Assessing them here would be out of scope, not thorough.
- **Whether monitoring was in place before release.** A timing requirement about the past,
  which the current state of the code cannot establish.

## When an analysis fails

If a check raises, its result is `None`, the exception is recorded in `artefact_errors`,
and every rule that depended on it returns `needs_human` with the reason. It is never
counted as `met`.

This matters more than it looks: the most damaging failure mode for a compliance tool is
not being wrong, it is being empty and looking clean. A report that lists which analyses did
not run cannot be mistaken for a report on a project with nothing wrong.
