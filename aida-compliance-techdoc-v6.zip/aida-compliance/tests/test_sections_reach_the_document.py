"""The five deliverables must land in the official template, not stop at an audit.

This is the challenge requirement in one sentence: generate the AIDA deliverables from the
official templates. Four of the five are sections of that document, and each was producing
a rich analysis that never reached it - the sections were being filled by the generic
renderers instead, which see only the context and none of the audits.

The merge rule tested here is the one that keeps the whole thing honest: the placeholder
map decides where an answer may come from, never the skill that wants to write it.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKILLS = PLUGIN_ROOT / "skills"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
for name in ("aida-core", "aida-human-oversight", "aida-record-keeping",
             "aida-genai-monitoring", "aida-operational-monitoring"):
    sys.path.insert(0, str(SKILLS / name / "scripts"))

import audit_oversight  # noqa: E402
import audit_records  # noqa: E402
import check_resilience  # noqa: E402
import plan_monitoring  # noqa: E402
import plan_operational  # noqa: E402
from placeholder_map import DEFAULT_TEMPLATE, extract, resolve  # noqa: E402
from scan_codebase import build_context  # noqa: E402
from section_values import entry, merge  # noqa: E402
from validate_values import validate  # noqa: E402


def section_writer(skill: str):
    """Import the write_section of one skill under a unique module name."""
    import importlib.util
    path = SKILLS / skill / "scripts" / "write_section.py"
    spec = importlib.util.spec_from_file_location(f"ws_{skill.replace('-', '_')}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="session")
def rules():
    return json.loads((SKILLS / "aida-core" / "references" / "aida_rules.json")
                      .read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def project():
    return FIXTURES / "agentic_assistant"


@pytest.fixture(scope="session")
def context(project):
    return build_context(project)


@pytest.fixture(scope="session")
def routing(context):
    return {p["placeholder"]: p for p in resolve(extract(DEFAULT_TEMPLATE), context)}


@pytest.fixture
def map_file(tmp_path, routing):
    path = tmp_path / "placeholders.json"
    path.write_text(json.dumps({"placeholders": list(routing.values())}), encoding="utf-8")
    return path


@pytest.fixture(scope="session")
def entries(project, context, rules):
    """What each of the four section skills would write."""
    oversight = section_writer("aida-human-oversight").build(
        audit_oversight.audit(project), rules)
    records = section_writer("aida-record-keeping").build(audit_records.audit(project))
    genai = section_writer("aida-genai-monitoring").build(
        plan_monitoring.build_plan(context, rules, project, "daily"))
    operational = section_writer("aida-operational-monitoring").build(
        plan_operational.build_plan(context, rules, audit_records.audit(project), "daily"),
        check_resilience.check(project))
    return {"3.9": oversight, "3.7": records, "3.8a": genai, "3.8b": operational}


# ------------------------------------------------- the sections target real fields --
@pytest.mark.parametrize("section", ["3.7", "3.8a", "3.8b", "3.9"])
def test_every_field_written_is_a_real_template_placeholder(section, entries, routing):
    for placeholder in entries[section]:
        assert placeholder in routing, (
            f"{section} writes {placeholder!r}, which the official template does not have"
        )


def test_the_four_sections_do_not_overwrite_each_other(entries):
    seen: dict[str, str] = {}
    for section, payload in entries.items():
        for placeholder in payload:
            # "Procedures for identifying and addressing performance drops." is a single
            # placeholder shared by both halves of 3.8; nothing else may collide.
            if placeholder in seen:
                assert {seen[placeholder], section} == {"3.8a", "3.8b"}, (
                    f"{placeholder!r} written by both {seen[placeholder]} and {section}"
                )
            seen[placeholder] = section


def test_the_audits_reach_the_document_not_just_the_json(entries):
    """The per-tool table is the deliverable's substance - it must be in the text."""
    measures = next(v["value"] for k, v in entries["3.9"].items()
                    if "human oversight measure" in k.lower())
    assert "purge_workspace" in measures and "agent.py:" in measures
    assert "NO APPROVAL GATE" in measures


def test_thresholds_reach_the_document_with_their_rule(entries):
    drops = next(v["value"] for k, v in entries["3.8a"].items()
                 if "performance drops" in k.lower())
    assert "10%" in drops and "MON-THRESHOLD-AGENTIC" in drops


def test_record_gaps_are_named_in_the_document(entries):
    historization = next(v["value"] for k, v in entries["3.7"].items()
                         if "historization" in k.lower())
    assert "REC-MODEL-MANDATORY" in historization
    assert "gaps to close" in historization


def test_operational_section_carries_no_quality_metric(entries):
    """The two halves of 3.8 must not blur into each other."""
    text = " ".join(v["value"] for v in entries["3.8b"].values()).lower()
    for quality_metric in ("faithfulness", "task_completion", "hallucination"):
        assert quality_metric not in text


# --------------------------------------------------- the map decides, not the skill --
def test_a_human_field_is_never_written_by_a_script(tmp_path, map_file, entries):
    values = tmp_path / "values.json"
    result = merge(values, entries["3.9"], map_file)
    overseers = "Names of the human overseers."
    assert overseers in result["left_to_human"]
    assert overseers not in json.loads(values.read_text(encoding="utf-8"))


def test_a_code_routed_field_without_evidence_is_skipped(tmp_path, map_file):
    values = tmp_path / "values.json"
    target = "Detail the tools used for record keeping and link to the emplacement of the records (where applicable)"
    result = merge(values, {target: entry("something", source="rule")}, map_file)
    assert target in result["skipped_no_evidence"]


def test_the_map_overrides_the_source_the_skill_declared(tmp_path, map_file):
    """A skill calling its answer a rule does not make it one."""
    values = tmp_path / "values.json"
    target = "Details of the logging mechanisms for system actions and decisions."
    merge(values, {target: entry("x", source="rule", evidence=["agent.py:42"])}, map_file)
    written = json.loads(values.read_text(encoding="utf-8"))[target]
    assert written["source"] == "code", "the template routes this field to the codebase"


def test_a_confirmed_answer_survives_a_regeneration(tmp_path, map_file, entries):
    values = tmp_path / "values.json"
    target = "Detail the human oversight measure put in place for the AI system."
    values.write_text(json.dumps({target: {"value": "reviewed by the risk owner",
                                           "confirmed_by": "S. Owner, 2026-08-08"}}),
                      encoding="utf-8")
    result = merge(values, entries["3.9"], map_file)
    assert target in result["kept_confirmed"]
    assert json.loads(values.read_text(encoding="utf-8"))[target]["value"] == \
           "reviewed by the risk owner"


# ------------------------------------------------------------- the chain validates --
def test_all_five_deliverables_together_pass_the_validator(tmp_path, map_file, entries,
                                                           routing, context, rules):
    values = tmp_path / "values.json"
    for payload in entries.values():
        merge(values, payload, map_file)
    supplied = json.loads(values.read_text(encoding="utf-8"))
    report = validate(supplied, routing, context, rules)
    assert not report.errors, report.render()
