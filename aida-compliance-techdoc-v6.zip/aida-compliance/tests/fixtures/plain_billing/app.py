"""Invoice CRUD service. No model, no prompt, no agent - the negative control."""
import logging

from flask import Flask, request
from sqlalchemy import create_engine, text

logger = logging.getLogger(__name__)
app = Flask(__name__)
engine = create_engine("sqlite:///billing.db")


@app.route("/invoices")
def list_invoices():
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT id, amount FROM invoices")).fetchall()
    return {"invoices": [dict(r._mapping) for r in rows]}


@app.route("/invoices/new")
def create_invoice():
    amount = request.args.get("amount")
    with engine.connect() as conn:
        conn.execute(text("INSERT INTO invoices (amount) VALUES (:a)"), {"a": amount})
        conn.commit()
    logger.info("invoice created amount=%s", amount)
    return {"status": "created"}
