"""Operations assistant - the LLM decides which tool to call (ReAct)."""
import logging
import os
import shutil
import smtplib

import mlflow
import requests
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent

logger = logging.getLogger(__name__)
mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI", "http://localhost:5000"))
mlflow.langchain.autolog()


@tool
def lookup_ticket(ticket_id: str) -> str:
    """Read a ticket - safe, read only."""
    return requests.get(f"https://tickets.internal/{ticket_id}", timeout=10).text


@tool
def send_notification(address: str, body: str) -> str:
    """Send an email to a user."""
    with smtplib.SMTP("smtp.internal") as smtp:
        smtp.sendmail("bot@internal", address, body)
    return "sent"


@tool
def purge_workspace(path: str) -> str:
    """Delete a workspace directory."""
    shutil.rmtree(path)
    return "purged"


TOOLS = [lookup_ticket, send_notification, purge_workspace]
agent = create_react_agent("bedrock:anthropic.claude-haiku-4-5-20251001-v1:0", tools=TOOLS)


def run(objective: str, session_id: str):
    logger.info("agent run session=%s", session_id)
    return agent.invoke({"messages": [("user", objective)]})
