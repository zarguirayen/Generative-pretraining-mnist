"""Document Q&A service - retrieves from a knowledge base, then generates."""
import logging

from chromadb import PersistentClient
from fastapi import FastAPI
from langchain.prompts import ChatPromptTemplate

logger = logging.getLogger(__name__)
app = FastAPI()

MODEL_ID = "anthropic.claude-haiku-4-5-20251001-v1:0"
REGION = "eu-west-3"

store = PersistentClient(path="./kb")
collection = store.get_or_create_collection("policies")

SYSTEM_PROMPT = ChatPromptTemplate.from_template(
    "Answer using only the context below.\n{context}\nQuestion: {question}"
)


def retrieve(question: str, k: int = 4):
    return collection.query(query_texts=[question], n_results=k)


@app.post("/ask")
def ask(question: str, session_id: str):
    contexts = retrieve(question)
    logger.info("inference session=%s question=%s", session_id, question)
    answer = f"stub answer for {question}"
    return {"answer": answer, "sources": contexts, "session_id": session_id}


@app.get("/health")
def health():
    return {"status": "ok"}
