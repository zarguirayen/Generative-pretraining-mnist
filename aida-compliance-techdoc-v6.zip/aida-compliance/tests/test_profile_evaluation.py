"""Section 3.3: the evaluation data and the experiment runs are read, not asked for.

    python -m pytest tests/test_profile_evaluation.py -v
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"))

from profile_evaluation import (CHARACTERISTICS, EXPERIMENT_LOGS, find_datasets,  # noqa: E402
                                mlflow_runs, profile)

CASES = ([{"question": f"Close ticket {i} and notify the owner", "expected_tools": ["close"],
           "expected_output": "closed", "category": "multi-step"} for i in range(8)]
         + [{"question": f"Status of ticket {i}?", "expected_output": "open",
             "category": "simple"} for i in range(5)]
         + [{"question": "Status of ticket 0?", "category": "simple"}])


def build_project(tmp: Path) -> Path:
    project = tmp / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    (project / "eval").mkdir()
    (project / "eval" / "dataset.jsonl").write_text(
        "\n".join(json.dumps(c) for c in CASES) + "\n", encoding="utf-8")
    run = project / "eval" / "outputs" / "run1"
    run.mkdir(parents=True)
    (run / "summary.json").write_text(json.dumps(
        {"timestamp": "2026-09-01T10:00:00Z", "metrics": {"task_completion": 0.86}}),
        encoding="utf-8")
    mlrun = project / "mlruns" / "1" / "a1b2c3"
    (mlrun / "metrics").mkdir(parents=True)
    (mlrun / "meta.yaml").write_text("run_name: baseline-v1\nstart_time: 1756720800000\n"
                                     "status: 3\n", encoding="utf-8")
    (mlrun / "metrics" / "task_completion").write_text("1756720800000 0.84 0\n",
                                                       encoding="utf-8")
    return project


@pytest.fixture(scope="module")
def generated(tmp_path_factory) -> Path:
    project = build_project(tmp_path_factory.mktemp("profile"))
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    return project / "aida"


@pytest.fixture(scope="module")
def values(generated) -> dict:
    return json.loads((generated / "values.json").read_text(encoding="utf-8"))


def test_the_dataset_is_found_and_profiled(tmp_path):
    project = build_project(tmp_path)
    [(path, cases)] = find_datasets(project)
    result = profile(path, cases, project)
    assert result["cases"] == 14
    assert result["distribution"] == {"multi-step": 8, "simple": 6}
    assert result["with_reference_answer"] == 13
    assert result["duplicates"] == 1


def test_characteristics_are_written_with_their_evidence(values):
    answer = values[CHARACTERISTICS]
    assert answer["source"] == "code"
    assert answer["evidence"] == ["eval/dataset.jsonl:1"]
    text = answer["value"]
    assert "14 case(s)" in text and "multi-step 8 (57%)" in text
    assert "13/14 with a reference answer" in text and "1 duplicate question" in text


def test_the_guideline_minimum_and_categories_are_checked(values):
    text = values[CHARACTERISTICS]["value"]
    assert "is BELOW the guideline minimum of 20 (EVAL-AGENTIC-QUERIES)" in text
    assert "No case labelled edge" in text


def test_case_selection_stays_an_open_point(values):
    assert "[A CONFIRMER - how the cases were selected" in values[CHARACTERISTICS]["value"]


def test_experiment_runs_are_dated_with_their_metrics(values):
    text = values[EXPERIMENT_LOGS]["value"]
    assert "2 experiment run(s)" in text
    assert "2026-09-01T10:00:00Z: task_completion 0.86" in text
    assert "MLflow run 'baseline-v1', 2025-09-01" in text and "task_completion 0.84" in text
    assert "[A CONFIRMER - MLflow experiment URL and the sign-off" in text


def test_mlflow_metric_reads_the_last_logged_value(tmp_path):
    run = tmp_path / "mlruns" / "0" / "r"
    (run / "metrics").mkdir(parents=True)
    (run / "meta.yaml").write_text("run_name: r\n", encoding="utf-8")
    (run / "metrics" / "acc").write_text("1 0.5 0\n2 0.7 1\n", encoding="utf-8")
    assert mlflow_runs(tmp_path)[0]["metrics"] == {"acc": 0.7}


def test_section_3_3_reaches_the_document(generated):
    xml = zipfile.ZipFile(generated / "technical_documentation.docx").read(
        "word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", "", xml)
    assert "Evaluation data: 14 case(s)" in text
    assert "MLflow run 'baseline-v1'" in text


def test_the_introduction_mentions_the_validation_data(values):
    intro = next(v["value"] for k, v in values.items() if k.startswith("Provide an overview"))
    assert "14 evaluation case(s)" in intro


def test_no_dataset_means_an_open_point_not_a_guess(tmp_path):
    project = tmp_path / "rag_service"
    shutil.copytree(FIXTURES / "rag_service", project)
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    values = json.loads((project / "aida" / "values.json").read_text(encoding="utf-8"))
    assert CHARACTERISTICS not in values and EXPERIMENT_LOGS not in values
