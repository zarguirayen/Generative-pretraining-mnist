"""Projects that instrument or declare things *properly* must not be reported as empty.

A compliance tool that penalises the teams who followed a standard is worse than one that
is merely incomplete: it teaches people that doing it right scores badly.

Two such false negatives are pinned here. A service instrumented to the OpenTelemetry
GenAI semantic conventions writes span attributes, not log keywords, and was reported as
recording none of the twelve required fields. Tools exposed to a model as JSON schemas -
the most common form there is - were invisible to a decorator-based audit, so the tool
count read as zero on an agent with a money-transfer tool.
"""

from __future__ import annotations

import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-record-keeping" / "scripts"))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-human-oversight" / "scripts"))

from audit_oversight import audit as audit_oversight  # noqa: E402
from audit_records import REQUIRED_FIELDS, audit as audit_records  # noqa: E402

FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"


def write(project: Path, name: str, content: str) -> None:
    project.mkdir(parents=True, exist_ok=True)
    (project / name).write_text(textwrap.dedent(content), encoding="utf-8")


# ------------------------------------------- OpenTelemetry GenAI semantic conventions --
@pytest.fixture
def otel_service(tmp_path):
    project = tmp_path / "otel"
    write(project, "api.py", '''
        from opentelemetry import trace

        tracer = trace.get_tracer(__name__)

        def answer(question, session_id):
            with tracer.start_as_current_span("chat") as span:
                span.set_attribute("gen_ai.provider.name", "aws.bedrock")
                span.set_attribute("gen_ai.request.model", "anthropic.claude-haiku-4-5")
                span.set_attribute("gen_ai.conversation.id", session_id)
                span.set_attribute("gen_ai.response.id", "resp-1")
                span.set_attribute("gen_ai.usage.input_tokens", 120)
                span.set_attribute("gen_ai.usage.output_tokens", 44)
                span.set_attribute("gen_ai.tool.name", "lookup")
                span.set_attribute("error.type", "none")
                return "answer"
    ''')
    return project


def test_span_attributes_count_as_recorded_fields(otel_service):
    """A field set on a span is recorded just as much as one passed to a logger."""
    result = audit_records(otel_service)
    assert result["counts"]["fields_present"] >= 6


@pytest.mark.parametrize("field,attribute", [
    ("session_id", "gen_ai.conversation.id"),
    ("request_id", "gen_ai.response.id"),
    ("model_version", "gen_ai.request.model"),
    ("tokens", "gen_ai.usage.input_tokens"),
    ("tool_calls", "gen_ai.tool.name"),
    ("outcome", "error.type"),
])
def test_each_otel_attribute_maps_to_its_required_field(otel_service, field, attribute):
    assert attribute in REQUIRED_FIELDS[field], "the alias must be declared, not inferred"
    assert audit_records(otel_service)["fields"][field]["present"], (
        f"{attribute} is the standard name for {field}"
    )


def test_fields_the_otel_service_really_lacks_are_still_reported(otel_service):
    """Recognising the standard must not turn into crediting fields that are absent."""
    fields = audit_records(otel_service)["fields"]
    for missing in ("input", "output", "prompt_version", "latency"):
        assert not fields[missing]["present"]


def test_a_percent_formatted_logger_still_records_nothing():
    """The original finding must survive: interpolating into a message is not a field."""
    assert audit_records(FIXTURES / "rag_service")["counts"]["fields_present"] == 0


# ------------------------------------------------------ schema-declared tools --
@pytest.fixture
def schema_agent(tmp_path):
    project = tmp_path / "schema"
    write(project, "agent.py", '''
        TOOLS = [
            {"type": "function", "function": {
                "name": "wire_transfer",
                "description": "Send money to an account.",
                "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {
                "name": "read_balance",
                "description": "Read an account balance.",
                "parameters": {"type": "object", "properties": {}}}},
        ]

        def dispatch(name, args):
            return HANDLERS[name](**args)
    ''')
    return project


def test_schema_declared_tools_are_found(schema_agent):
    names = {t["name"] for t in audit_oversight(schema_agent)["declared_tools"]}
    assert names == {"wire_transfer", "read_balance"}


def test_their_irreversibility_is_left_open_not_guessed(schema_agent):
    """The body is dispatched by name and cannot be read, so no severity is invented."""
    finding = next(f for f in audit_oversight(schema_agent)["findings"]
                   if "declared as a schema" in f["summary"])
    assert finding["severity"] == "advisory"
    assert "cannot judge whether they are irreversible" in finding["detail"]


def test_the_report_no_longer_claims_there_are_no_tools(schema_agent):
    from audit_oversight import render
    report = render(audit_oversight(schema_agent))
    assert "No model-callable tool found" not in report
    assert "DECLARED AS A SCHEMA" in report


def test_a_decorated_tool_is_not_double_counted(tmp_path):
    """A project that both decorates and schema-declares the same tool lists it once."""
    project = tmp_path / "both"
    write(project, "agent.py", '''
        from langchain_core.tools import tool

        @tool
        def lookup(x: str) -> str:
            """Read something."""
            return x

        SCHEMA = {"name": "lookup", "description": "Read something.", "parameters": {}}
    ''')
    result = audit_oversight(project)
    assert [t["name"] for t in result["tools"]] == ["lookup"]
    assert result["declared_tools"] == [], "already covered by the decorated function"


def test_an_ordinary_dictionary_is_not_mistaken_for_a_tool(tmp_path):
    project = tmp_path / "plain"
    write(project, "config.py", '''
        SETTINGS = {"name": "billing-service", "region": "eu-west-3", "retries": 3}
        USER = {"name": "alice", "email": "a@b.c"}
    ''')
    assert audit_oversight(project)["declared_tools"] == []
