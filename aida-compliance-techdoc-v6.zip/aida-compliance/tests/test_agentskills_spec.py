"""Conformance to the Agent Skills open standard (agentskills.io).

GitHub's own documentation points at this spec as the formal definition of the SKILL.md
format, and `skills-ref` is its reference validator. Two of its rules caught real bugs
here: the strict YAML subset rejects flow-style lists (`[a, b]`), and `allowed-tools`
must be a space-separated string, not a YAML list.

One deviation is deliberate and pinned by the last test: the hub's own skill template
mandates top-level `version`, `domain`, `risk_tier`, `depends_on`, `status` and `tags`,
which the spec does not define. The house template wins - it is the convention this
repository's contributions are reviewed against - but the test asserts that this is the
ONLY spec violation we carry, so any new one fails loudly instead of hiding behind it.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

skills_ref = pytest.importorskip("skills_ref", reason="pip install skills-ref")

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKILL_DIRS = sorted(p.parent for p in (PLUGIN_ROOT / "skills").glob("*/SKILL.md"))
HOUSE_FIELDS = {"depends_on", "domain", "risk_tier", "status", "tags", "version"}


def frontmatter_of(skill: Path) -> str:
    raw = (skill / "SKILL.md").read_text(encoding="utf-8")
    return raw.split("\n---", 1)[0]


@pytest.mark.parametrize("skill", SKILL_DIRS, ids=lambda p: p.name)
def test_the_only_spec_deviation_is_the_house_template(skill):
    errors = skills_ref.validate(skill)
    unexpected = [e for e in errors if "Unexpected fields" in str(e)]
    others = [e for e in errors if "Unexpected fields" not in str(e)]
    assert not others, f"spec violations beyond the house fields: {others}"
    if unexpected:
        named = set(re.findall(r"[a-z_]+", str(unexpected[0]).split(":", 1)[1].split(".")[0]))
        assert named <= HOUSE_FIELDS, (
            f"{skill.name} carries non-spec fields the house template does not mandate: "
            f"{sorted(named - HOUSE_FIELDS)}"
        )


@pytest.mark.parametrize("skill", SKILL_DIRS, ids=lambda p: p.name)
def test_allowed_tools_is_a_space_separated_string(skill):
    """The spec defines allowed-tools as a string; a YAML list silently fails to parse
    in strict hosts, which turns the pre-approval into a prompt on every call."""
    block = frontmatter_of(skill)
    match = re.search(r"^allowed-tools:(.*)$", block, re.M)
    if match:
        assert match.group(1).strip(), "allowed-tools must be an inline string"
        following = block[match.end():].lstrip("\n")
        assert not following.startswith("  - "), "allowed-tools must not be a YAML list"


@pytest.mark.parametrize("skill", SKILL_DIRS, ids=lambda p: p.name)
def test_no_flow_style_lists_in_frontmatter(skill):
    """The spec's strict YAML subset rejects JSON-esque flow collections."""
    for line in frontmatter_of(skill).splitlines():
        stripped = line.split("#")[0].rstrip()
        assert not re.search(r":\s*\[", stripped), f"flow-style list in: {line!r}"


@pytest.mark.parametrize("skill", SKILL_DIRS, ids=lambda p: p.name)
def test_compatibility_declares_real_requirements_within_limit(skill):
    block = frontmatter_of(skill)
    match = re.search(r"^compatibility:\s*(.+)$", block, re.M)
    assert match, "our scripts need Python - the spec's compatibility field must say so"
    value = match.group(1).strip()
    assert 1 <= len(value) <= 500
    assert "Python" in value


def test_properties_are_readable_by_the_reference_parser():
    """read_properties is what a spec-conformant host uses to index skills."""
    for skill in SKILL_DIRS:
        properties = skills_ref.read_properties(skill)
        assert properties.name == skill.name
        assert properties.description and len(properties.description) <= 1024
