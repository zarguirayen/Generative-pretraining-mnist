"""Derivation and drift detection for the technical documentation skill.

The derivation tests exist to hold one line: a script may answer what the code proves and
what a guideline fixes, and nothing else. The drift tests hold the other: a document that
no longer matches the code must say so on its own.
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
CORE = PLUGIN_ROOT / "skills" / "aida-core" / "scripts"
TECHDOC = PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(CORE))
sys.path.insert(0, str(TECHDOC))

from build_values import DEFAULT_RULES, build  # noqa: E402
from check_freshness import compare, snapshot  # noqa: E402
from placeholder_map import DEFAULT_TEMPLATE, extract, resolve  # noqa: E402
from scan_codebase import build_context  # noqa: E402
from validate_values import validate  # noqa: E402

PURPOSE = "Clearly define the specific tasks or problems the AI system is designed to address"
DROP = "Procedures for identifying and addressing performance drops."


@pytest.fixture(scope="session")
def rules():
    return json.loads(DEFAULT_RULES.read_text(encoding="utf-8"))


def context_and_routing(fixture: str):
    ctx = build_context(FIXTURES / fixture)
    routing = {p["placeholder"]: p for p in resolve(extract(DEFAULT_TEMPLATE), ctx)}
    return ctx, routing


@pytest.fixture(scope="session")
def agentic(rules):
    ctx, routing = context_and_routing("agentic_assistant")
    values, stats = build(ctx, routing, rules)
    return {"ctx": ctx, "routing": routing, "values": values, "stats": stats}


@pytest.fixture(scope="session")
def rag(rules):
    ctx, routing = context_and_routing("rag_service")
    values, stats = build(ctx, routing, rules)
    return {"ctx": ctx, "routing": routing, "values": values, "stats": stats}


# ----------------------------------------------------------- what may be answered --
def test_no_human_field_is_ever_answered(agentic, rag):
    for case in (agentic, rag):
        for placeholder in case["values"]:
            assert case["routing"][placeholder]["source"] in ("code", "rule"), (
                f"{placeholder!r} is not a code or rule field and must be left to a human"
            )


def test_intended_purpose_is_never_produced(agentic):
    assert PURPOSE not in agentic["values"]


def test_every_code_answer_carries_evidence(agentic, rag):
    for case in (agentic, rag):
        for placeholder, entry in case["values"].items():
            if entry["source"] == "code":
                assert entry.get("evidence"), f"{placeholder!r} asserts a fact with no proof"


def test_derived_values_pass_their_own_validator(agentic, rules):
    report = validate(agentic["values"], agentic["routing"], agentic["ctx"], rules)
    assert not report.errors, report.render()


def test_every_rule_field_gets_an_answer(agentic):
    """A guideline-determined field left blank is a gap the tool could have closed."""
    missing = [p for p, route in agentic["routing"].items()
               if route["source"] == "rule" and p not in agentic["values"]]
    assert not missing, f"rule fields with no derivation: {missing}"


# ------------------------------------------------------------- guideline fidelity --
def test_threshold_follows_the_system_family(agentic, rag):
    assert "10%" in agentic["values"][DROP]["value"]
    assert "MON-THRESHOLD-AGENTIC" in agentic["values"][DROP]["value"]
    assert "10%" in rag["values"][DROP]["value"]
    assert "MON-THRESHOLD-RAG" in rag["values"][DROP]["value"]


def test_thresholds_are_stated_with_their_rule_id(agentic):
    """A number without its source cannot be checked by a risk challenger."""
    quoted = [entry["value"] for entry in agentic["values"].values()
              if entry["source"] == "rule"]
    assert any("MON-" in text or "REC-" in text or "EVAL-" in text or "OVERSIGHT-" in text
               for text in quoted)


def test_retention_periods_are_the_guideline_numbers(agentic):
    text = " ".join(e["value"] for e in agentic["values"].values())
    assert "10 years" in text and "1 year" in text


def test_missing_oversight_controls_are_reported_as_gaps(agentic):
    oversight = next(v["value"] for k, v in agentic["values"].items()
                     if "human oversight measure" in k.lower())
    assert "send_email" in oversight and "delete" in oversight
    assert "not optional" in oversight


def test_autonomy_justification_is_demanded_for_l2(agentic):
    """The guideline requires the justification to be IN the documentation, and no
    placeholder asks for it - so it is raised where the level is stated."""
    demanded = [v["value"] for v in agentic["values"].values()
                if "BUILD-L1-DEFAULT" in v["value"]]
    assert demanded, "an L2 system must be asked to justify its autonomy"
    text = demanded[0]
    assert "Level 1 is the guideline default" in text
    assert "[A CONFIRMER" in text, "the justification itself must stay an open point"


def test_no_autonomy_justification_demanded_for_a_non_agentic_system(rag):
    assert not [v for v in rag["values"].values() if "BUILD-L1-DEFAULT" in v["value"]]


# ------------------------------------------------------------------ drift detection --
@pytest.fixture
def project(tmp_path, rules):
    workspace = tmp_path / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", workspace)
    ctx = build_context(workspace)
    routing = {p["placeholder"]: p for p in resolve(extract(DEFAULT_TEMPLATE), ctx)}
    values, _ = build(ctx, routing, rules)
    return {"path": workspace, "values": values}


def test_unchanged_project_is_reported_as_up_to_date(project):
    before = snapshot(project["values"], project["path"])
    after = snapshot(project["values"], project["path"])
    result = compare(before, after)
    assert not result["stale"] and not result["vanished"]


def test_a_code_change_marks_the_dependent_fields_stale(project):
    before = snapshot(project["values"], project["path"])
    agent = project["path"] / "agent.py"
    agent.write_text(agent.read_text(encoding="utf-8") + "\n# a new tool was added here\n",
                     encoding="utf-8")
    result = compare(before, snapshot(project["values"], project["path"]))
    assert result["stale"], "changing a cited file must mark its fields stale"
    assert {item["file"] for item in result["stale"]} == {"agent.py"}


def test_drift_report_names_the_oversight_section(project):
    before = snapshot(project["values"], project["path"])
    agent = project["path"] / "agent.py"
    agent.write_text(agent.read_text(encoding="utf-8") + "\n# new irreversible tool\n",
                     encoding="utf-8")
    result = compare(before, snapshot(project["values"], project["path"]))
    stale = " ".join(item["placeholder"].lower() for item in result["stale"])
    assert "human oversight" in stale, (
        "a change to the agent's tools changes what human oversight must cover"
    )


def test_a_deleted_source_file_is_reported(project):
    before = snapshot(project["values"], project["path"])
    (project["path"] / "agent.py").unlink()
    result = compare(before, snapshot(project["values"], project["path"]))
    assert result["stale"] or result["vanished"]


def test_snapshot_only_tracks_files_that_were_actually_cited(project):
    state = snapshot(project["values"], project["path"])
    for field in state["fields"].values():
        for relative in field["files"]:
            assert not relative.startswith("aida/"), "generated output is not evidence"
