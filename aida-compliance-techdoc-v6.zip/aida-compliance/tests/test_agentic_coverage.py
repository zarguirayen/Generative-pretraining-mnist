"""Coverage of agent architectures the first version of the scanners could not see.

Reviewing a production agent framework surfaced four blind spots, each with a concrete
consequence for the documentation this plugin writes:

* a self-extending agent was classified L2, which selects the wrong mandatory metrics -
  the guideline adds plan quality and plan adherence at L3;
* tools reached through an MCP server were invisible, so the tool count read as a total
  when it is only a floor - and the monitoring guideline names those tools explicitly;
* a project gated by an allowlist policy instead of a decorator was reported as entirely
  ungoverned, a false positive that trains readers to ignore findings;
* isolated execution was ignored, so the risk statement was the same for a sandboxed
  agent and a bare one.
"""

from __future__ import annotations

import json
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-core" / "scripts"))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-human-oversight" / "scripts"))

from audit_oversight import audit  # noqa: E402
from scan_codebase import build_context  # noqa: E402


def write(project: Path, name: str, content: str) -> None:
    path = project / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(textwrap.dedent(content), encoding="utf-8")


@pytest.fixture
def self_extending(tmp_path):
    """An agent that authors its own skills at runtime, spawns sub-agents, and keeps
    long-horizon memory - a Deep Agent by the guideline's definition."""
    project = tmp_path / "deep"
    write(project, "agent.py", '''
        from langchain_core.tools import tool
        from pathlib import Path

        SKILLS_DIR = Path.home() / ".agent" / "skills"

        def create_skill(name: str, body: str) -> None:
            """The agent authors a new capability at runtime."""
            (SKILLS_DIR / f"{name}.md").write_text(body)

        @tool
        def delegate(objective: str) -> str:
            """Spawn a sub-agent for a sub-objective."""
            return spawn_agent(objective)

        @tool
        def purge(path: str) -> str:
            """Delete a workspace."""
            import shutil
            shutil.rmtree(path)
            return "ok"
    ''')
    return project


# ----------------------------------------------------------------- L3 classification --
def test_a_self_extending_agent_is_l3_not_l2(self_extending):
    """Its capability set is not fixed at design time, which is what L3 means. Reporting
    L2 would silently drop plan quality and plan adherence from the mandatory metrics."""
    classification = build_context(self_extending)["classification"]
    assert classification["agentic_level"] == "L3"
    assert "not fixed at design time" in classification["agentic_level_reason"]


def test_the_l3_verdict_cites_its_evidence(self_extending):
    classification = build_context(self_extending)["classification"]
    assert classification["agentic_level_evidence"]
    for item in classification["agentic_level_evidence"]:
        path, _, line = item.rpartition(":")
        assert path and line.isdigit()


def test_a_plain_react_agent_stays_l2(tmp_path):
    """The widened patterns must not promote every agent to L3."""
    project = tmp_path / "react"
    write(project, "agent.py", '''
        from langgraph.prebuilt import create_react_agent
        from langchain_core.tools import tool

        @tool
        def lookup(x: str) -> str:
            """Read something."""
            return x

        agent = create_react_agent("model", tools=[lookup])
    ''')
    assert build_context(project)["classification"]["agentic_level"] == "L2"


# ------------------------------------------------------------------- MCP visibility --
@pytest.fixture
def with_mcp(self_extending):
    write(self_extending, ".mcp.json", '''
        {"mcpServers": {"filesystem": {"command": "npx"},
                        "payments": {"command": "node"}}}
    ''')
    return self_extending


def test_mcp_servers_are_reported(with_mcp):
    result = audit(with_mcp)
    assert result["mcp"], "an MCP configuration must be surfaced"
    servers = {name for entry in result["mcp"] for name in entry["servers"]}
    assert servers == {"filesystem", "payments"}


def test_mcp_finding_says_the_tool_count_is_only_a_floor(with_mcp):
    finding = next(f for f in audit(with_mcp)["findings"]
                   if "MCP" in f["summary"])
    assert "floor, not a total" in finding["detail"]
    assert finding["severity"] == "advisory", (
        "the audit cannot judge tools it cannot see, so this is a gap to close with the "
        "server owner, not a verdict on the project"
    )


def test_no_mcp_config_means_no_mcp_finding(self_extending):
    assert not audit(self_extending)["mcp"]
    assert not [f for f in audit(self_extending)["findings"] if "MCP" in f["summary"]]


# -------------------------------------------------- policy and isolation as context --
@pytest.fixture
def governed(self_extending):
    write(self_extending, "config/policy.yaml", '''
        approved_commands:
          - ls
          - cat
        sandbox: docker
    ''')
    return self_extending


def test_an_approval_policy_in_configuration_is_found(governed):
    """Policies live in config, not in Python - a code-only pass reported a governed
    project as entirely ungoverned."""
    controls = audit(governed)["controls"]
    assert controls["approval_policy"]
    assert controls["approval_policy"][0].startswith("config/policy.yaml")


def test_the_ungated_finding_mentions_the_policy_without_excusing_the_gap(governed):
    finding = next(f for f in audit(governed)["findings"]
                   if f["rule"] == "OVERSIGHT-INTERVENTION" and "approval gate" in f["summary"])
    assert finding["severity"] == "blocking", "a policy does not close the per-tool gap"
    assert "confirm whether it covers these tools" in finding["detail"]


def test_isolation_is_reported_as_a_question_not_an_assertion(governed):
    """Claiming execution is isolated because the word docker appears somewhere would be
    the same soft claim this plugin refuses everywhere else."""
    finding = next(f for f in audit(governed)["findings"]
                   if f["rule"] == "OVERSIGHT-INTERVENTION" and "approval gate" in f["summary"])
    assert "confirm whether tool calls actually execute in isolation" in finding["detail"]
    assert "isolation never replaces the approval" in finding["detail"]


def test_findings_stay_serialisable(governed):
    json.dumps(audit(governed))
