"""The produced document must still be a document Word will open.

A compliance deliverable that corrupts the official template is worse than no tool at
all, so the round-trip is checked structurally: same parts, same namespace prefixes,
same XML declaration.
"""

from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = PLUGIN_ROOT / "skills" / "aida-core" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from fill_docx import DEFAULT_TEMPLATE, PARTS_TO_FILL, build_resolver, fill_part  # noqa: E402
from placeholder_map import extract, is_instruction  # noqa: E402


@pytest.fixture(scope="session")
def routing():
    return {p["placeholder"]: p for p in extract(DEFAULT_TEMPLATE)}


@pytest.fixture(scope="session")
def produced(tmp_path_factory, routing):
    """Fill the real template with two known values and repackage it."""
    values = {
        "Indication of the version of the AI system addressed in this documentation": {
            "value": "1.4.2", "evidence": ["git tag v1.4.2"],
        },
    }
    missing: list[dict] = []
    kept: list[str] = []
    resolver = build_resolver(values, routing, missing, kept)

    out = tmp_path_factory.mktemp("filled") / "technical_documentation.docx"
    with zipfile.ZipFile(DEFAULT_TEMPLATE) as src:
        parts = {n: src.read(n) for n in src.namelist()}
        rewritten = {}
        for name in PARTS_TO_FILL:
            if name in parts:
                rewritten[name], _ = fill_part(parts[name], resolver)
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
            for info in src.infolist():
                dst.writestr(info, rewritten.get(info.filename, parts[info.filename]))
    return {"path": out, "missing": missing, "kept": kept}


# ------------------------------------------------------------- package integrity --
def test_no_part_is_lost_or_added(produced):
    with zipfile.ZipFile(DEFAULT_TEMPLATE) as a, zipfile.ZipFile(produced["path"]) as b:
        assert set(a.namelist()) == set(b.namelist())


def test_archive_is_not_corrupt(produced):
    with zipfile.ZipFile(produced["path"]) as z:
        assert z.testzip() is None


def test_namespace_prefixes_survive_the_round_trip(produced):
    """ElementTree renames prefixes to ns0: unless they are registered - Word rejects that."""
    with zipfile.ZipFile(produced["path"]) as z:
        raw = z.read("word/document.xml")
    assert b"ns0:" not in raw
    assert b"<w:document" in raw and b"<w:body" in raw
    assert b"mc:Ignorable" in raw


def test_xml_declaration_keeps_standalone(produced):
    with zipfile.ZipFile(produced["path"]) as z:
        raw = z.read("word/document.xml")
    assert raw.startswith(b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')


# ----------------------------------------------------------------- fill behaviour --
def test_supplied_value_is_written_with_its_evidence(produced):
    with zipfile.ZipFile(produced["path"]) as z:
        text = z.read("word/document.xml").decode("utf-8", "ignore")
    assert "1.4.2" in text
    assert "git tag v1.4.2" in text, "a written fact must carry the evidence that proves it"


def test_unknown_fields_become_a_confirmer_never_invented(produced):
    with zipfile.ZipFile(produced["path"]) as z:
        text = z.read("word/document.xml").decode("utf-8", "ignore")
    assert "A CONFIRMER" in text
    assert produced["missing"], "open points must be reported, not silently dropped"


def test_template_guidance_is_kept_not_turned_into_a_question(produced):
    kept = produced["kept"]
    assert kept, "the NB: notes and the usage note are guidance, not fields"
    assert all(is_instruction(k) for k in kept)
    for note in produced["missing"]:
        assert not is_instruction(note["placeholder"])


def test_no_placeholder_braces_remain(produced):
    """Every {...} must have been resolved one way or another."""
    with zipfile.ZipFile(produced["path"]) as z:
        raw = z.read("word/document.xml").decode("utf-8", "ignore")
    import re
    leftovers = [m for m in re.findall(r"\{([^{}]{3,})\}", raw)]
    assert not leftovers, f"unresolved placeholders left in the document: {leftovers[:3]}"


def test_open_points_carry_a_reason(produced):
    for item in produced["missing"]:
        assert item["source"] in {"code", "rule", "external", "human"}
        assert item["note"], "an open point without a reason is not actionable"
    # the report is what the risk owner works from, so it must serialise
    json.dumps(produced["missing"])


# ------------------------------------------------------------ closing section --
from fill_docx import closing_section  # noqa: E402


@pytest.fixture(scope="session")
def closed(routing):
    """The template filled with no answers at all, then closed."""
    missing: list[dict] = []
    kept: list[str] = []
    resolver = build_resolver({}, routing, missing, kept)
    with zipfile.ZipFile(DEFAULT_TEMPLATE) as src:
        raw, count = fill_part(src.read("word/document.xml"), resolver)
    fields = count - len(kept)
    return {"xml": closing_section(raw, missing, fields, 0).decode("utf-8", "ignore"),
            "missing": missing}


def test_every_open_point_gets_a_unique_reference(closed):
    refs = [item["ref"] for item in closed["missing"]]
    assert refs == [f"#{n:02d}" for n in range(1, len(refs) + 1)]


def test_each_reference_appears_in_the_text_and_in_the_closing_list(closed):
    """A reader must be able to go from the list to the field, and back."""
    for item in closed["missing"][:10]:
        assert f"[A CONFIRMER {item['ref']} -" in closed["xml"]
        assert f"{item['ref']}  " in closed["xml"]


def test_closing_section_states_status_owners_and_follow_up(closed):
    xml = closed["xml"]
    assert "Document completion status" in xml
    assert "Open points by owner" in xml
    assert "Follow-up actions" in xml
    assert "not a substitute" in xml


def test_closing_section_sits_before_the_section_properties(closed):
    """Word requires sectPr to stay the last child of the body."""
    body = closed["xml"].split("<w:body>", 1)[1]
    assert body.rstrip().endswith("</w:body></w:document>")
    assert body.rfind("<w:sectPr") > body.rfind("Document completion status")


def test_an_open_point_inside_an_answer_is_numbered_too(routing):
    """The autonomy justification lives inside the model-logic answer; it must still reach
    the closing list."""
    key = next(k for k in routing if "general logic of the selected model" in k.lower())
    values = {key: {"value": "System family: agentic. Justification: "
                             "[A CONFIRMER - to be given by the risk owner].",
                    "evidence": ["agent.py:1"]}}
    missing: list[dict] = []
    text = build_resolver(values, routing, missing, [])(key)
    assert "[A CONFIRMER #01 - to be given by the risk owner]" in text
    assert missing[0]["source"] == "partial"
