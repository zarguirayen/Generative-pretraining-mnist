"""Record coverage, field extraction, and the tamper-evident journal.

The field tests pin the distinction the guideline actually cares about: a log line that
interpolates a session id into a message string records nothing structured, and must not
be counted as if it did. The chain tests do the thing a compliance claim usually cannot
do - they try to cheat, and check that it shows.
"""

from __future__ import annotations

import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKILL = PLUGIN_ROOT / "skills" / "aida-record-keeping"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(SKILL / "scripts"))

from audit_records import MANDATORY, REQUIRED_FIELDS, audit, logged_field_names  # noqa: E402
from generate_records import CALL_SITES, TEMPLATE  # noqa: E402
from verify_chain import verify  # noqa: E402


@pytest.fixture(scope="session")
def rag():
    return audit(FIXTURES / "rag_service")


@pytest.fixture
def journal(tmp_path):
    """A real chained journal, written by the generated module."""
    workspace = tmp_path / "app"
    workspace.mkdir()
    (workspace / "aida_records.py").write_text(TEMPLATE.read_text(encoding="utf-8"),
                                               encoding="utf-8")
    script = textwrap.dedent('''
        import aida_records as r
        r.inference(session_id="s1", request_id="r1", model_version="m-1",
                    input="q", output="a", latency_ms=12, actor="ut1")
        r.human_review(item_id="r1", reviewer="s.owner", verdict="overridden")
        r.deployment(from_version="1.3", to_version="1.4", reason="new model",
                     actor="ops")
        r.access(actor="ut1", access_type="API call", resource="/ask", status="success")
    ''')
    subprocess.run([sys.executable, "-c", script], cwd=workspace, check=True,
                   capture_output=True)
    return workspace / "logs" / "aida_records.jsonl"


def lines_of(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8").splitlines()


# ------------------------------------------------------------------- the nine records --
def test_all_nine_mandatory_records_are_checked(rag):
    assert sum(len(group) for group in MANDATORY.values()) == 9
    assert len(rag["records"]) == 9


def test_each_record_reports_its_rule(rag):
    rules = {record["rule"] for record in rag["records"].values()}
    assert rules == {"REC-MODEL-MANDATORY", "REC-OPERATIONAL-MANDATORY",
                     "REC-OVERSIGHT-MANDATORY"}


def test_a_found_record_carries_evidence(rag):
    for record_id, record in rag["records"].items():
        if record["present"]:
            assert record["evidence"], f"{record_id} claims a mechanism with no location"


def test_missing_records_become_blocking_findings(rag):
    missing = [r for r in rag["records"].values() if not r["present"]]
    assert missing
    blocking = [f for f in rag["findings"] if f["severity"] == "blocking"]
    assert blocking


# ------------------------------------------------------------------ field extraction --
def test_a_percent_formatted_log_records_no_fields(rag):
    """The RAG fixture logs `logger.info("inference session=%s ...", session_id, question)`.
    Counting that as a session_id field would report coverage the project does not have."""
    assert rag["counts"]["fields_present"] == 0


def test_keyword_arguments_are_counted_as_fields(tmp_path):
    project = tmp_path / "structured"
    project.mkdir()
    (project / "api.py").write_text(textwrap.dedent('''
        import logging
        logger = logging.getLogger(__name__)

        def handle(question, session_id, answer):
            logger.info("inference", extra={"session_id": session_id})
            logger.info("done", session_id=session_id, model_version="m-1",
                        latency_ms=12, output=answer)
    '''), encoding="utf-8")
    result = audit(project)
    assert result["fields"]["session_id"]["present"]
    assert result["fields"]["model_version"]["present"]
    assert result["fields"]["latency"]["present"]
    assert result["fields"]["output"]["present"]


def test_dict_keys_passed_to_a_log_call_are_counted(tmp_path):
    project = tmp_path / "dictlog"
    project.mkdir()
    (project / "api.py").write_text(textwrap.dedent('''
        import logging
        logger = logging.getLogger(__name__)

        def handle(rid):
            logger.info({"request_id": rid, "outcome": "success"})
    '''), encoding="utf-8")
    fields = logged_field_names(project)
    assert "request_id" in fields and "outcome" in fields


def test_the_twelve_required_fields_are_the_ones_monitoring_needs():
    assert set(REQUIRED_FIELDS) == {
        "timestamp", "session_id", "request_id", "actor", "input", "output",
        "model_version", "prompt_version", "latency", "tokens", "tool_calls", "outcome"}


# --------------------------------------------------------- format, retention, storage --
def test_format_retention_and_immutability_are_three_separate_findings(rag):
    summaries = " | ".join(f["summary"] for f in rag["findings"])
    assert "not structured" in summaries
    assert "retention" in summaries
    assert "tamper-evident" in summaries


def test_a_hash_chained_project_is_recognised_as_tamper_evident(tmp_path):
    project = tmp_path / "chained"
    project.mkdir()
    (project / "records.py").write_text(
        'ENTRY = {"prev_hash": None}  # append-only hash chain\n', encoding="utf-8")
    assert audit(project)["immutability"]["configured"]


# ------------------------------------------------------------------ the chain itself --
def test_a_fresh_journal_verifies(journal):
    report = verify(journal)
    assert report["intact"] and report["entries"] == 4


def test_altering_an_entry_is_detected(journal):
    """Turning an overridden review into an accepted one is the tampering that matters."""
    lines = lines_of(journal)
    entry = json.loads(lines[1])
    entry["payload"]["verdict"] = "accepted"
    lines[1] = json.dumps(entry, ensure_ascii=False)
    journal.write_text("\n".join(lines) + "\n", encoding="utf-8")

    report = verify(journal)
    assert not report["intact"]
    assert any("content altered" in p["problem"] for p in report["problems"])
    assert report["problems"][0]["seq"] == 2


def test_deleting_an_entry_is_detected(journal):
    lines = lines_of(journal)
    del lines[2]
    journal.write_text("\n".join(lines) + "\n", encoding="utf-8")

    report = verify(journal)
    assert not report["intact"]
    problems = " ".join(p["problem"] for p in report["problems"])
    assert "sequence break" in problems and "broken link" in problems


def test_reordering_entries_is_detected(journal):
    lines = lines_of(journal)
    lines[1], lines[2] = lines[2], lines[1]
    journal.write_text("\n".join(lines) + "\n", encoding="utf-8")
    assert not verify(journal)["intact"]


def test_credentials_are_redacted_before_they_reach_the_journal(tmp_path):
    workspace = tmp_path / "secret"
    workspace.mkdir()
    (workspace / "aida_records.py").write_text(TEMPLATE.read_text(encoding="utf-8"),
                                               encoding="utf-8")
    subprocess.run([sys.executable, "-c", textwrap.dedent('''
        import aida_records as r
        r.access(actor="u", access_type="login", resource="/", status="ok")
        r.record("debug", api_key="sk-abcdefghijklmnop", nested={"password": "hunter2"})
    ''')], cwd=workspace, check=True, capture_output=True)
    text = (workspace / "logs" / "aida_records.jsonl").read_text(encoding="utf-8")
    assert "sk-abcdefghijklmnop" not in text and "hunter2" not in text
    assert "[redacted]" in text


def test_inference_requires_a_model_version(tmp_path):
    """A score that cannot be attributed to a version cannot be compared to a baseline."""
    workspace = tmp_path / "novers"
    workspace.mkdir()
    (workspace / "aida_records.py").write_text(TEMPLATE.read_text(encoding="utf-8"),
                                               encoding="utf-8")
    result = subprocess.run([sys.executable, "-c", textwrap.dedent('''
        import aida_records as r
        try:
            r.inference(session_id="s", request_id="r", input="q", output="a")
            print("ACCEPTED")
        except TypeError:
            print("REQUIRED")
    ''')], cwd=workspace, capture_output=True, text=True)
    assert "REQUIRED" in result.stdout


def test_verify_chain_runs_standalone_on_the_file(journal):
    """An auditor gets the file and the script, nothing else."""
    result = subprocess.run(
        [sys.executable, str(SKILL / "scripts" / "verify_chain.py"), str(journal)],
        capture_output=True, text=True)
    assert result.returncode == 0
    assert "INTACT" in result.stdout


# ----------------------------------------------------------------------- generation --
def test_every_mandatory_record_has_a_documented_call_site():
    mandatory = {rid for group in MANDATORY.values() for rid in group}
    assert mandatory <= set(CALL_SITES), (
        f"no call site documented for: {sorted(mandatory - set(CALL_SITES))}"
    )
