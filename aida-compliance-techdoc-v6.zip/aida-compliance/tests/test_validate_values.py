"""The gate between planning the answers and writing them into the document.

Each test plants one defect that would otherwise reach a compliance document, and
asserts the validator refuses it. The unconfirmed-value and threshold cases are the
ones that matter: they are the two shapes a fabricated compliance statement takes.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = PLUGIN_ROOT / "skills" / "aida-core" / "scripts"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(SCRIPTS))

from placeholder_map import DEFAULT_TEMPLATE, extract, resolve  # noqa: E402
from scan_codebase import build_context  # noqa: E402
from validate_values import DEFAULT_RULES, validate  # noqa: E402

PURPOSE = "Clearly define the specific tasks or problems the AI system is designed to address"
DEPENDENCIES = "Specify the software dependencies of the AI system and their versions"
DROP = "Procedures for identifying and addressing performance drops."


@pytest.fixture(scope="session")
def rules():
    return json.loads(DEFAULT_RULES.read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def rag_context():
    return build_context(FIXTURES / "rag_service")


@pytest.fixture(scope="session")
def agentic_context():
    return build_context(FIXTURES / "agentic_assistant")


@pytest.fixture(scope="session")
def routing(rag_context):
    return {p["placeholder"]: p for p in resolve(extract(DEFAULT_TEMPLATE), rag_context)}


def checks(report) -> set[str]:
    return {e["check"] for e in report.errors}


# --------------------------------------------------------- fabrication defences --
def test_human_only_field_filled_without_a_confirmer_is_blocked(routing, rag_context, rules):
    report = validate({PURPOSE: "Automated credit pre-scoring."}, routing, rag_context, rules)
    assert "unconfirmed" in checks(report), (
        "an intended purpose invented by the agent is the canonical hallucination here"
    )


def test_human_only_field_passes_once_a_confirmer_is_recorded(routing, rag_context, rules):
    values = {PURPOSE: {"value": "Automated credit pre-scoring.",
                        "confirmed_by": "S. Owner (risk owner), 2026-08-08"}}
    report = validate(values, routing, rag_context, rules)
    assert "unconfirmed" not in checks(report)


def test_code_derived_value_without_evidence_is_blocked(routing, rag_context, rules):
    report = validate({DEPENDENCIES: "fastapi 0.115.0"}, routing, rag_context, rules)
    assert "no-evidence" in checks(report)


def test_code_derived_value_with_evidence_passes(routing, rag_context, rules):
    values = {DEPENDENCIES: {"value": "fastapi 0.115.0",
                             "evidence": ["requirements.txt:1"]}}
    report = validate(values, routing, rag_context, rules)
    assert "no-evidence" not in checks(report)


# ------------------------------------------------------------ guideline fidelity --
def test_loosened_threshold_is_blocked_for_a_rag_system(routing, rag_context, rules):
    values = {DROP: "Alert when relative performance drops by 20% versus the baseline."}
    report = validate(values, routing, rag_context, rules)
    assert "threshold" in checks(report)
    detail = next(e["detail"] for e in report.errors if e["check"] == "threshold")
    assert "10%" in detail and "MON-THRESHOLD-RAG" in detail


def test_correct_threshold_passes_for_a_rag_system(routing, rag_context, rules):
    values = {DROP: "Alert when relative performance drops by 10% versus the baseline."}
    report = validate(values, routing, rag_context, rules)
    assert "threshold" not in checks(report)


def test_the_expected_threshold_follows_the_system_family(routing, agentic_context, rules):
    """20% is right for a prompt system and wrong for an agentic one - the check is
    driven by the classification, not by a single hardcoded number."""
    values = {DROP: "Alert on a 20% relative performance drop."}
    report = validate(values, routing, agentic_context, rules)
    assert "threshold" in checks(report)


def test_operational_thresholds_in_the_same_field_are_not_read_as_a_drop(
        routing, rag_context, rules):
    """Found on a real project: the metrics field also lists the usage thresholds (a 30%
    fall in active users, a +200% request spike), and all three were blocked as a loosened
    model-quality threshold."""
    values = {DROP: "Model quality: alert on a 10% relative performance drop versus the "
                    "baseline; active_users_trend - alert continuous drop of 30% "
                    "month-over-month; request_spike - alert +200% user requests within "
                    "one hour."}
    report = validate(values, routing, rag_context, rules)
    assert "threshold" not in checks(report)


def test_a_stricter_threshold_is_allowed_but_flagged(routing, agentic_context, rules):
    values = {DROP: "Alert on a 5% relative performance drop."}
    report = validate(values, routing, agentic_context, rules)
    assert "threshold" not in checks(report)
    assert any(w["check"] == "threshold-stricter" for w in report.warnings)


def test_retention_below_the_guideline_minimum_is_blocked(routing, rag_context, rules):
    values = {DROP: "Monitoring records are retained 0 years before deletion."}
    report = validate(values, routing, rag_context, rules)
    assert "retention" in checks(report)


# ------------------------------------------------------------------- hygiene --
def test_credentials_never_reach_the_document(routing, rag_context, rules):
    values = {DEPENDENCIES: {"value": "auth via api_key: sk-abcdefghijklmnopqrstuvwx",
                             "evidence": ["app.py:3"]}}
    report = validate(values, routing, rag_context, rules)
    assert "secret" in checks(report)


def test_draft_text_is_blocked(routing, rag_context, rules):
    values = {DEPENDENCIES: {"value": "TODO confirm with the owner",
                             "evidence": ["app.py:3"]}}
    report = validate(values, routing, rag_context, rules)
    assert "draft-text" in checks(report)


def test_unresolved_placeholder_inside_a_value_is_blocked(routing, rag_context, rules):
    values = {DEPENDENCIES: {"value": "{list the dependencies here}",
                             "evidence": ["app.py:3"]}}
    report = validate(values, routing, rag_context, rules)
    assert "draft-text" in checks(report)


def test_empty_value_is_blocked(routing, rag_context, rules):
    report = validate({DEPENDENCIES: "   "}, routing, rag_context, rules)
    assert "empty-value" in checks(report)


def test_answer_to_a_field_that_does_not_exist_is_blocked(routing, rag_context, rules):
    report = validate({"a field the template never had": "x"}, routing, rag_context, rules)
    assert "unknown-field" in checks(report)


# ------------------------------------------------------------------- warnings --
def test_malformed_evidence_is_a_warning_not_a_block(routing, rag_context, rules):
    values = {DEPENDENCIES: {"value": "fastapi 0.115.0", "evidence": ["somewhere in the repo"]}}
    report = validate(values, routing, rag_context, rules)
    assert "no-evidence" not in checks(report)
    assert any(w["check"] == "evidence-format" for w in report.warnings)


def test_a_clean_plan_produces_no_blocking_finding(routing, rag_context, rules):
    values = {
        PURPOSE: {"value": "Automated credit pre-scoring for retail clients.",
                  "confirmed_by": "S. Owner (risk owner), 2026-08-08"},
        DEPENDENCIES: {"value": "fastapi 0.115.0, chromadb 0.5.15",
                       "evidence": ["requirements.txt:1", "requirements.txt:3"]},
        DROP: "Alert on a 10% relative performance drop versus the build baseline.",
    }
    report = validate(values, routing, rag_context, rules)
    assert not report.errors, report.render()
