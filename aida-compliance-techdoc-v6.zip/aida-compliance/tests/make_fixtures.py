#!/usr/bin/env python3
"""Generate the three throwaway projects the scanner is tested against.

    python tests/make_fixtures.py

They are deliberately tiny but carry real signals: a RAG service, a ReAct agent, and a
plain CRUD service with no AI at all. The third one matters most - it proves the scanner
degrades honestly instead of inventing an AI system where there is none.
"""

from pathlib import Path

FIXTURES = {
    # ---------------------------------------------------------------- RAG ----
    "rag_service/requirements.txt": """\
fastapi==0.115.0
langchain==0.3.7
chromadb==0.5.15
sentence-transformers==3.2.1
boto3==1.34.162
""",
    "rag_service/app.py": '''\
"""Document Q&A service - retrieves from a knowledge base, then generates."""
import logging

from chromadb import PersistentClient
from fastapi import FastAPI
from langchain.prompts import ChatPromptTemplate

logger = logging.getLogger(__name__)
app = FastAPI()

MODEL_ID = "anthropic.claude-haiku-4-5-20251001-v1:0"
REGION = "eu-west-3"

store = PersistentClient(path="./kb")
collection = store.get_or_create_collection("policies")

SYSTEM_PROMPT = ChatPromptTemplate.from_template(
    "Answer using only the context below.\\n{context}\\nQuestion: {question}"
)


def retrieve(question: str, k: int = 4):
    return collection.query(query_texts=[question], n_results=k)


@app.post("/ask")
def ask(question: str, session_id: str):
    contexts = retrieve(question)
    logger.info("inference session=%s question=%s", session_id, question)
    answer = f"stub answer for {question}"
    return {"answer": answer, "sources": contexts, "session_id": session_id}


@app.get("/health")
def health():
    return {"status": "ok"}
''',
    # ------------------------------------------------------------ AGENTIC ----
    "agentic_assistant/requirements.txt": """\
langgraph==0.2.45
langchain==0.3.7
mlflow==2.17.0
deepeval==1.5.5
""",
    "agentic_assistant/agent.py": '''\
"""Operations assistant - the LLM decides which tool to call (ReAct)."""
import logging
import os
import shutil
import smtplib

import mlflow
import requests
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent

logger = logging.getLogger(__name__)
mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI", "http://localhost:5000"))
mlflow.langchain.autolog()


@tool
def lookup_ticket(ticket_id: str) -> str:
    """Read a ticket - safe, read only."""
    return requests.get(f"https://tickets.internal/{ticket_id}", timeout=10).text


@tool
def send_notification(address: str, body: str) -> str:
    """Send an email to a user."""
    with smtplib.SMTP("smtp.internal") as smtp:
        smtp.sendmail("bot@internal", address, body)
    return "sent"


@tool
def purge_workspace(path: str) -> str:
    """Delete a workspace directory."""
    shutil.rmtree(path)
    return "purged"


TOOLS = [lookup_ticket, send_notification, purge_workspace]
agent = create_react_agent("bedrock:anthropic.claude-haiku-4-5-20251001-v1:0", tools=TOOLS)


def run(objective: str, session_id: str):
    logger.info("agent run session=%s", session_id)
    return agent.invoke({"messages": [("user", objective)]})
''',
    # -------------------------------------------------------------- NO AI ----
    "plain_billing/requirements.txt": """\
flask==3.0.3
sqlalchemy==2.0.35
""",
    "plain_billing/app.py": '''\
"""Invoice CRUD service. No model, no prompt, no agent - the negative control."""
import logging

from flask import Flask, request
from sqlalchemy import create_engine, text

logger = logging.getLogger(__name__)
app = Flask(__name__)
engine = create_engine("sqlite:///billing.db")


@app.route("/invoices")
def list_invoices():
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT id, amount FROM invoices")).fetchall()
    return {"invoices": [dict(r._mapping) for r in rows]}


@app.route("/invoices/new")
def create_invoice():
    amount = request.args.get("amount")
    with engine.connect() as conn:
        conn.execute(text("INSERT INTO invoices (amount) VALUES (:a)"), {"a": amount})
        conn.commit()
    logger.info("invoice created amount=%s", amount)
    return {"status": "created"}
''',
}


def main() -> None:
    root = Path(__file__).parent / "fixtures"
    for relative, content in FIXTURES.items():
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    print(f"{len(FIXTURES)} fixture files written under {root}")


if __name__ == "__main__":
    main()
