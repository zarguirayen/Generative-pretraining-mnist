"""Conformance to the GitHub Copilot plugin and Agent Skills specifications.

Rules encoded here come from the GitHub Copilot CLI plugin reference and the Copilot
agent-skills documentation:

* plugin.json lives at the ROOT of the plugin directory (not under .github/)
* plugin.json `name` is kebab-case, max 64 chars; `description` max 1024
* SKILL.md requires `name` (lowercase + hyphens) and `description`
* skills are discovered from `skills/` as declared by the manifest
* every marketplace entry needs `name` and `source`
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = PLUGIN_ROOT.parents[2]
KEBAB = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


@pytest.fixture(scope="session")
def manifest():
    path = PLUGIN_ROOT / "plugin.json"
    assert path.exists(), (
        "plugin.json must sit at the root of the plugin directory - Copilot does not "
        "look for it under .github/plugin/"
    )
    return json.loads(path.read_text(encoding="utf-8"))


def frontmatter(skill_md: Path) -> dict:
    raw = skill_md.read_text(encoding="utf-8").replace("\r\n", "\n")
    assert raw.startswith("---\n"), f"{skill_md.name} must open with YAML frontmatter"
    block = raw[4:].split("\n---", 1)[0]
    parsed: dict[str, str] = {}
    key = None
    for line in block.split("\n"):
        m = re.match(r"^([A-Za-z][A-Za-z0-9_-]*):\s*(.*)$", line)
        if m:
            key = m.group(1)
            parsed[key] = m.group(2).strip()
        elif key and line.startswith(("  ", "\t")):
            parsed[key] = (parsed[key] + " " + line.strip()).strip()
    return parsed


def skill_files() -> list[Path]:
    return sorted((PLUGIN_ROOT / "skills").glob("*/SKILL.md"))


# ------------------------------------------------------------------ plugin.json --
def test_manifest_name_is_kebab_case_and_matches_the_folder(manifest):
    assert KEBAB.match(manifest["name"]), "Copilot requires a kebab-case plugin name"
    assert len(manifest["name"]) <= 64
    assert manifest["name"] == PLUGIN_ROOT.name


def test_manifest_description_within_limit(manifest):
    assert 0 < len(manifest["description"]) <= 1024


def test_manifest_version_is_semver(manifest):
    assert re.fullmatch(r"\d+\.\d+\.\d+", manifest["version"])


def test_manifest_author_has_a_name(manifest):
    assert manifest["author"]["name"]


def test_declared_skills_path_exists(manifest):
    declared = manifest.get("skills", "skills/")
    for path in ([declared] if isinstance(declared, str) else declared):
        assert (PLUGIN_ROOT / path).is_dir()


def test_manifest_and_hub_yaml_agree_on_version(manifest):
    """The two manifests describe the same plugin; a version drift is a packaging bug."""
    yaml_text = (PLUGIN_ROOT / "plugin.yaml").read_text(encoding="utf-8")
    yaml_version = re.search(r"^version:\s*(\S+)", yaml_text, re.M).group(1)
    assert yaml_version == manifest["version"]


# --------------------------------------------------------------------- SKILL.md --
def test_at_least_one_skill_is_shipped():
    assert skill_files()


@pytest.mark.parametrize("skill_md", skill_files(), ids=lambda p: p.parent.name)
def test_skill_frontmatter_meets_copilot_requirements(skill_md):
    fm = frontmatter(skill_md)
    assert "name" in fm and "description" in fm, "name and description are both required"
    assert KEBAB.match(fm["name"]), "skill name must be lowercase with hyphens"
    assert fm["name"] == skill_md.parent.name, "skill name must match its directory"
    assert len(fm["name"]) <= 64
    assert fm["description"], "an empty description means the skill never triggers"
    assert len(fm["description"]) <= 1024


@pytest.mark.parametrize("skill_md", skill_files(), ids=lambda p: p.parent.name)
def test_description_states_when_to_use_the_skill(skill_md):
    """The description is a routing rule: it must carry trigger wording, not just a summary."""
    description = frontmatter(skill_md)["description"].lower()
    assert "use it when" in description or "use when" in description


@pytest.mark.parametrize("skill_md", skill_files(), ids=lambda p: p.parent.name)
def test_description_is_written_in_third_person(skill_md):
    description = frontmatter(skill_md)["description"]
    assert not re.search(r"\b(I |I'|you can|we )", description), (
        "the description is injected into the system prompt - first or second person "
        "degrades skill selection"
    )


@pytest.mark.parametrize("skill_md", skill_files(), ids=lambda p: p.parent.name)
def test_skill_body_stays_within_the_recommended_size(skill_md):
    lines = skill_md.read_text(encoding="utf-8").count("\n")
    assert lines <= 500, "split content into reference files past 500 lines"


@pytest.mark.parametrize("skill_md", skill_files(), ids=lambda p: p.parent.name)
def test_no_windows_paths_in_the_skill(skill_md):
    body = skill_md.read_text(encoding="utf-8")
    assert not re.search(r"(scripts|references|assets)\\\\?\w", body), (
        "use forward slashes - backslash paths break on Unix runners"
    )


@pytest.mark.parametrize("skill_md", skill_files(), ids=lambda p: p.parent.name)
def test_referenced_resources_exist(skill_md):
    """A broken link in SKILL.md sends the agent looking for a file that is not there."""
    body = skill_md.read_text(encoding="utf-8")
    for target in re.findall(r"\]\((((?:scripts|references|assets)/)[^)]+)\)", body):
        assert (skill_md.parent / target[0]).exists(), f"missing bundled resource: {target[0]}"


# ---------------------------------------------------------------- marketplace --
def test_plugin_is_registered_in_the_marketplace(manifest):
    marketplace_path = REPO_ROOT / ".github" / "plugin" / "marketplace.json"
    if not marketplace_path.exists():
        pytest.skip("requires the plugin-skill-hub repository (marketplace.json not found)")
    marketplace = json.loads(
        (REPO_ROOT / ".github" / "plugin" / "marketplace.json").read_text(encoding="utf-8")
    )
    entries = {p["name"]: p for p in marketplace["plugins"]}
    assert manifest["name"] in entries, "an unregistered plugin is invisible in the marketplace"
    entry = entries[manifest["name"]]
    assert entry["source"], "a marketplace entry requires name and source"
    assert (REPO_ROOT / "plugins" / entry["source"]).is_dir()
    assert entry["version"] == manifest["version"]
