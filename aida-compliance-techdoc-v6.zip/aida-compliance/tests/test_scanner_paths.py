"""Every scanner must analyse the project it was given, wherever that project lives.

All four scanners filter out directories like `build`, `env` and `tests`. Filtering on the
absolute path made them skip every file of a project that simply happened to live under a
directory with one of those names - the scan came back empty and looked like a project with
nothing in it, which is the most dangerous failure mode this plugin has.
"""

from __future__ import annotations

import shutil
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
for folder in ("aida-core", "aida-human-oversight", "aida-record-keeping",
               "aida-operational-monitoring"):
    sys.path.insert(0, str(PLUGIN_ROOT / "skills" / folder / "scripts"))

from audit_oversight import audit as audit_oversight  # noqa: E402
from audit_records import audit as audit_records  # noqa: E402
from check_resilience import check as check_resilience  # noqa: E402
from scan_codebase import build_context  # noqa: E402

# Directory names each scanner skips inside a project - and which must not disqualify the
# project itself when it is the root or an ancestor of it.
AWKWARD_PARENTS = ["build", "env", "tests", "dist"]


@pytest.fixture(params=AWKWARD_PARENTS)
def buried_project(request, tmp_path):
    """A real agent project, sitting under a directory the scanners skip."""
    target = tmp_path / request.param / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", target)
    return target


def test_scan_finds_the_code_of_a_buried_project(buried_project):
    ctx = build_context(buried_project)
    assert ctx["project"]["files_scanned"] > 0
    assert ctx["classification"]["family"] == "agentic"


def test_oversight_audit_finds_the_tools_of_a_buried_project(buried_project):
    result = audit_oversight(buried_project)
    assert {t["name"] for t in result["tools"]} == {
        "lookup_ticket", "send_notification", "purge_workspace"}


def test_record_audit_reads_a_buried_project(buried_project):
    """Same project, same verdict - burying it must change nothing."""
    buried = audit_records(buried_project)
    original = audit_records(FIXTURES / "agentic_assistant")
    assert {k: v["present"] for k, v in buried["records"].items()} == \
           {k: v["present"] for k, v in original["records"].items()}
    assert buried["counts"]["fields_present"] == original["counts"]["fields_present"]


def test_resilience_check_reads_a_buried_project(buried_project):
    result = check_resilience(buried_project)
    assert result["counts"]["outbound"] > 0


def test_skip_rules_still_apply_inside_the_project(tmp_path):
    """The filter must keep working for directories *within* the project."""
    project = tmp_path / "app"
    (project / "src").mkdir(parents=True)
    (project / "src" / "agent.py").write_text(textwrap.dedent('''
        from langchain_core.tools import tool

        @tool
        def real_tool(x: str) -> str:
            """A tool that ships."""
            return x
    '''), encoding="utf-8")
    (project / ".venv" / "lib").mkdir(parents=True)
    (project / ".venv" / "lib" / "vendored.py").write_text(textwrap.dedent('''
        from langchain_core.tools import tool

        @tool
        def vendored_tool(x: str) -> str:
            """A tool from a dependency, not ours."""
            return x
    '''), encoding="utf-8")

    tools = {t["name"] for t in audit_oversight(project)["tools"]}
    assert tools == {"real_tool"}, "a vendored dependency must not be audited as our code"
