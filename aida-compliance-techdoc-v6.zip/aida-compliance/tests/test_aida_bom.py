"""The ML-BOM must be valid CycloneDX 1.6 and must not assert anything unproven.

Rules checked against the published schema (CycloneDX/specification, schema/bom-1.6):
bomFormat and specVersion are required at the root, a component requires `type` and
`name`, `type` comes from a closed enum, and a service requires only `name`.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = PLUGIN_ROOT / "skills" / "aida-core" / "scripts"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(SCRIPTS))

from aida_bom import build_bom  # noqa: E402
from scan_codebase import build_context  # noqa: E402

COMPONENT_TYPES = {
    "application", "framework", "library", "container", "platform", "operating-system",
    "device", "device-driver", "firmware", "file", "machine-learning-model", "data",
    "cryptographic-asset",
}


@pytest.fixture(scope="session")
def rag_bom():
    return build_bom(build_context(FIXTURES / "rag_service"))


@pytest.fixture(scope="session")
def plain_bom():
    return build_bom(build_context(FIXTURES / "plain_billing"))


# ------------------------------------------------------------ schema conformance --
def test_root_required_fields(rag_bom):
    assert rag_bom["bomFormat"] == "CycloneDX"
    assert rag_bom["specVersion"] == "1.6"
    assert rag_bom["serialNumber"].startswith("urn:uuid:")


def test_every_component_has_type_and_name_from_the_enum(rag_bom):
    for component in rag_bom["components"]:
        assert component["type"] in COMPONENT_TYPES
        assert component["name"]


def test_services_only_declare_what_is_provable(rag_bom):
    for service in rag_bom.get("services", []):
        assert service["name"]
        # the scan cannot prove authentication, so the field must be absent, not false
        assert "authenticated" not in service


def test_dependency_graph_references_existing_components(rag_bom):
    refs = {c["bom-ref"] for c in rag_bom["components"]}
    root = rag_bom["metadata"]["component"]["bom-ref"]
    for edge in rag_bom["dependencies"]:
        assert edge["ref"] == root or edge["ref"] in refs
        for target in edge["dependsOn"]:
            assert target in refs


# ---------------------------------------------------------------- content rules --
def test_model_component_carries_a_model_card(rag_bom):
    models = [c for c in rag_bom["components"] if c["type"] == "machine-learning-model"]
    assert models, "a model id was found in the code, so a model component is expected"
    params = models[0]["modelCard"]["modelParameters"]
    assert params["task"] and params["architectureFamily"]
    assert params["datasets"], "a RAG system retrieves from a corpus - it must appear as a dataset"


def test_every_component_carries_its_evidence(rag_bom):
    for component in rag_bom["components"]:
        props = {p["name"]: p["value"] for p in component.get("properties", [])}
        assert "aida:evidence" in props, f"{component['name']} has no evidence"


def test_no_model_component_when_no_model_is_found(plain_bom):
    models = [c for c in plain_bom["components"] if c["type"] == "machine-learning-model"]
    assert not models, "inventing a model for a non-AI project would be a false record"
    assert plain_bom["metadata"]["component"]["properties"]


def test_library_versions_are_cleaned_for_purl(rag_bom):
    libs = {c["name"]: c for c in rag_bom["components"] if c["type"] == "library"}
    assert "fastapi" in libs
    assert libs["fastapi"]["version"] == "0.115.0", "the == operator must be stripped"
    assert libs["fastapi"]["purl"] == "pkg:generic/fastapi@0.115.0"


def test_bom_is_json_serialisable_and_stable(rag_bom):
    import json
    first = json.dumps(rag_bom, sort_keys=True)
    assert json.loads(first)["specVersion"] == "1.6"
