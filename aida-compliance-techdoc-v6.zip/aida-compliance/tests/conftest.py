"""Make sure the fixture projects exist before any test collects them.

The three throwaway projects under `tests/fixtures/` are committed, so a fresh clone has
them. This regenerates them anyway when they are missing - after a `git clean`, or if
someone deletes one - because the alternative is a wall of failures whose cause is not
obvious from the error messages.

It has to live here rather than in one test module: pytest collects modules
alphabetically, and `test_audit.py` needs the fixtures long before `test_scan_codebase.py`
would have created them.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

TESTS = Path(__file__).resolve().parent
FIXTURES = TESTS / "fixtures"
EXPECTED = ("rag_service", "agentic_assistant", "plain_billing")


@pytest.fixture(scope="session", autouse=True)
def fixture_projects() -> Path:
    missing = [name for name in EXPECTED if not (FIXTURES / name / "requirements.txt").exists()]
    if missing:
        subprocess.run([sys.executable, str(TESTS / "make_fixtures.py")],
                       check=True, capture_output=True)
    for name in EXPECTED:
        assert (FIXTURES / name).is_dir(), f"fixture project {name} could not be created"
    return FIXTURES
