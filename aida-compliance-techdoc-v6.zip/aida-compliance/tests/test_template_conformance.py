"""The plugin must mirror templates/plugin-template and templates/skill-template.

CONTRIBUTING.md says a contribution starts by copying those templates, so the structure
they define is the house contract. These tests read the templates from the repository
rather than hardcoding a copy, so the plugin follows along if the templates change.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = PLUGIN_ROOT.parents[2]
PLUGIN_TEMPLATE = REPO_ROOT / "templates" / "plugin-template"
SKILL_TEMPLATE = REPO_ROOT / "templates" / "skill-template"

# These tests compare the plugin against the hub's own templates, so they only mean
# something inside the hub. Extracted on its own - which is how the submission archive is
# reviewed - the templates are not there, and a skip with a reason is the honest result.
if not PLUGIN_TEMPLATE.is_dir() or not SKILL_TEMPLATE.is_dir():
    pytest.skip("requires the plugin-skill-hub repository (templates/ not found)",
                allow_module_level=True)
PLACEHOLDER = re.compile(r"__[A-Z_]+__|Describe (what|the task)|Replace this README|lorem", re.I)


def skill_dirs() -> list[Path]:
    return sorted(p.parent for p in (PLUGIN_ROOT / "skills").glob("*/SKILL.md"))


# ------------------------------------------------------------- plugin structure --
@pytest.mark.parametrize("asset_dir", ["agents", "instructions", "prompts", "skills"])
def test_plugin_provides_every_asset_kind_the_template_defines(asset_dir):
    assert (PLUGIN_TEMPLATE / asset_dir).is_dir(), "template changed - review this test"
    directory = PLUGIN_ROOT / asset_dir
    assert directory.is_dir(), f"the plugin template defines {asset_dir}/"
    assert any(directory.iterdir()), f"{asset_dir}/ must not be empty"


def test_plugin_has_the_files_contributing_requires():
    for name in ("plugin.yaml", "README.md", "CHANGELOG.md"):
        assert (PLUGIN_ROOT / name).exists(), f"CONTRIBUTING.md requires {name}"


def test_asset_file_names_follow_the_template_suffixes():
    assert list(PLUGIN_ROOT.glob("agents/*.agent.md")), "agents use the .agent.md suffix"
    assert list(PLUGIN_ROOT.glob("prompts/*.prompt.md")), "prompts use the .prompt.md suffix"
    assert list(PLUGIN_ROOT.glob("instructions/*.instructions.md")), (
        "instructions use the .instructions.md suffix"
    )


def test_plugin_yaml_declares_every_shipped_asset():
    declared = (PLUGIN_ROOT / "plugin.yaml").read_text(encoding="utf-8")
    for path in (list(PLUGIN_ROOT.glob("agents/*.md"))
                 + list(PLUGIN_ROOT.glob("prompts/*.md"))
                 + list(PLUGIN_ROOT.glob("instructions/*.md"))
                 + list(PLUGIN_ROOT.glob("skills/*/SKILL.md"))):
        relative = path.relative_to(PLUGIN_ROOT).as_posix()
        assert relative in declared, f"{relative} is shipped but not listed under provides:"


# -------------------------------------------------------------- asset contracts --
def test_agent_frontmatter_matches_the_template():
    for agent in PLUGIN_ROOT.glob("agents/*.agent.md"):
        head = agent.read_text(encoding="utf-8")
        for field in ("name:", "description:", "tools:"):
            assert field in head.split("---")[1], f"{agent.name} is missing {field}"


def test_instructions_declare_apply_to():
    for instructions in PLUGIN_ROOT.glob("instructions/*.instructions.md"):
        block = instructions.read_text(encoding="utf-8").split("---")[1]
        assert "applyTo:" in block and "description:" in block


def test_prompt_declares_a_description():
    for prompt in PLUGIN_ROOT.glob("prompts/*.prompt.md"):
        assert "description:" in prompt.read_text(encoding="utf-8").split("---")[1]


# --------------------------------------------------------------- skill contract --
@pytest.mark.parametrize("skill", skill_dirs(), ids=lambda p: p.name)
def test_skill_has_the_template_subfolders(skill):
    for sub in ("references", "scripts", "assets"):
        assert (SKILL_TEMPLATE / sub).is_dir(), "template changed - review this test"
        assert (skill / sub).is_dir(), f"the skill template defines {sub}/"


@pytest.mark.parametrize("skill", skill_dirs(), ids=lambda p: p.name)
def test_skill_frontmatter_carries_the_template_fields(skill):
    block = (skill / "SKILL.md").read_text(encoding="utf-8").split("---")[1]
    for field in ("name:", "version:", "domain:", "risk_tier:", "depends_on:",
                  "description:", "tags:"):
        assert field in block, f"the skill template defines {field}"
    # status is not in the template but the hub CI requires it - see CONTRIBUTING.md
    assert "status:" in block


@pytest.mark.parametrize("skill", skill_dirs(), ids=lambda p: p.name)
def test_skill_keeps_the_template_sections(skill):
    body = (skill / "SKILL.md").read_text(encoding="utf-8")
    for heading in ("## Absolute rules", "## Purpose", "## Workflow", "## Resources"):
        assert heading in body, f"the skill template defines the {heading!r} section"


@pytest.mark.parametrize("skill", skill_dirs(), ids=lambda p: p.name)
def test_skill_domain_matches_its_place_in_the_hub(skill):
    """CONTRIBUTING.md: domain must match the parent folder for standalone skills;
    for plugin-bundled skills it must stay consistent with the plugin's hub domain."""
    block = (skill / "SKILL.md").read_text(encoding="utf-8").split("---")[1]
    domain = re.search(r"^domain:\s*(\S+)", block, re.M).group(1)
    assert domain in PLUGIN_ROOT.parent.name, (
        f"domain {domain!r} should be consistent with {PLUGIN_ROOT.parent.name!r}"
    )


# ---------------------------------------------------------- no leftover template --
def test_no_placeholder_text_survives_anywhere():
    offenders = []
    for path in PLUGIN_ROOT.rglob("*.md"):
        if "fixtures" in path.parts:
            continue
        if PLACEHOLDER.search(path.read_text(encoding="utf-8")):
            offenders.append(path.relative_to(PLUGIN_ROOT).as_posix())
    assert not offenders, f"template placeholder text left in: {offenders}"
