"""Scanner behaviour on the three fixture projects.

    python -m pytest tests/ -v

The negative control (plain_billing) is the important one: a compliance generator that
invents an AI system where there is none is worse than useless.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SCAN = PLUGIN_ROOT / "skills" / "aida-core" / "scripts" / "scan_codebase.py"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"

sys.path.insert(0, str(SCAN.parent))
from scan_codebase import build_context  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def fixtures_exist():
    if not FIXTURES.exists():
        subprocess.run([sys.executable, str(PLUGIN_ROOT / "tests" / "make_fixtures.py")], check=True)


@pytest.fixture(scope="session")
def rag():
    return build_context(FIXTURES / "rag_service")


@pytest.fixture(scope="session")
def agentic():
    return build_context(FIXTURES / "agentic_assistant")


@pytest.fixture(scope="session")
def plain():
    return build_context(FIXTURES / "plain_billing")


# --------------------------------------------------------------- classification --
def test_rag_is_classified_as_rag(rag):
    assert rag["classification"]["family"] == "rag"
    assert rag["classification"]["agentic_level"] is None


def test_agentic_is_l2_by_escalation_rule(agentic):
    cls = agentic["classification"]
    assert cls["family"] == "agentic"
    assert cls["agentic_level"] == "L2"
    assert "escalation rule" in cls["agentic_level_reason"].lower()


def test_non_ai_project_is_not_invented_into_an_ai_system(plain):
    cls = plain["classification"]
    assert cls["family"] == "unknown"
    assert cls["agentic_level"] is None
    assert cls["certainty"] == "low"
    assert plain["models"] == {}
    assert cls["reference_framework"] is None


# ---------------------------------------------------------------- evidence rule --
@pytest.mark.parametrize("name", ["rag", "agentic"])
def test_every_classification_carries_file_line_evidence(name, request):
    cls = request.getfixturevalue(name)["classification"]
    assert cls["family_evidence"], "a classification without evidence must never be emitted"
    for item in cls["family_evidence"]:
        path, _, line = item.rpartition(":")
        assert path and line.isdigit(), f"evidence must be 'path:line', got {item!r}"


# --------------------------------------------------------------------- extraction --
def test_model_id_and_region_are_extracted(rag):
    assert any("claude" in m for m in rag["models"])
    assert "eu-west-3" in rag["regions"]


def test_reference_stack_matches_build_guideline(rag, agentic):
    assert rag["classification"]["reference_framework"] == "langchain"
    assert agentic["classification"]["reference_framework"] == "langgraph"


def test_endpoints_are_found_with_their_route(rag):
    routes = {e["route"] for e in rag["endpoints"]}
    assert "/ask" in routes
    assert "/health" in routes


def test_dependencies_are_read_with_versions(rag):
    deps = rag["dependencies"]
    assert "chromadb" in deps
    assert deps["fastapi"]["version"] == "==0.115.0"


# ------------------------------------------------------- record keeping signals --
def test_missing_structured_logging_is_reported(rag):
    # REC-FORMAT requires structured logs; plain logger calls do not satisfy it.
    assert rag["logging"]["structured"] is False
    assert rag["logging"]["calls"], "logger calls should still be inventoried"


def test_observability_gap_is_visible(rag, agentic):
    assert rag["observability"] == {}          # no MLflow -> BUILD-OBSERVABILITY advisory
    assert "mlflow" in agentic["observability"]


# ------------------------------------------------------------- human oversight --
def test_irreversible_side_effects_are_inventoried(agentic):
    side = agentic["side_effects"]
    assert "send_email" in side, "an agent that sends mail must be flagged for OVERSIGHT-INTERVENTION"
    assert "delete" in side


def test_no_human_approval_gate_detected_in_fixture(agentic):
    # The fixture agent deletes and mails with no approval: the gap the skill must report.
    assert "human_approval" not in agentic["oversight_signals"]
    assert "kill_switch" not in agentic["oversight_signals"]


# --------------------------------------------------------------------- contract --
@pytest.mark.parametrize("name", ["rag", "agentic", "plain"])
def test_context_contract_is_stable(name, request):
    ctx = request.getfixturevalue(name)
    for key in ("schema_version", "generated_at", "project", "git", "classification",
                "dependencies", "endpoints", "logging", "side_effects", "infrastructure"):
        assert key in ctx, f"downstream skills rely on ctx[{key!r}]"


# ------------------------------------------------------- official AIDA template --
from placeholder_map import DEFAULT_TEMPLATE, extract, resolve  # noqa: E402


@pytest.fixture(scope="session")
def placeholders():
    return extract(DEFAULT_TEMPLATE)


def test_official_template_is_bundled():
    assert DEFAULT_TEMPLATE.exists(), "the official AIDA template must ship with the skill"


def test_all_template_placeholders_are_found(placeholders):
    # Template version 04.12.2025 carries 108 {placeholders}. A change here means the
    # template was updated - re-check the routing table before bumping this number.
    assert len(placeholders) == 108


def test_every_placeholder_is_routed_to_a_known_source(placeholders):
    assert {p["source"] for p in placeholders} <= {"code", "rule", "external", "human", "instruction"}


def test_no_placeholder_falls_through_the_routing_table(placeholders):
    unrouted = [p["placeholder"] for p in placeholders
                if (p["note"] or "").startswith("no routing rule matched")]
    assert not unrouted, f"{len(unrouted)} placeholders have no route: {unrouted[:3]}"


def test_prize_sections_are_mostly_automatable(placeholders, agentic):
    resolved = resolve(placeholders, agentic)
    for section in ("Record Keeping", "Monitoring"):
        rows = [p for p in resolved if p["section"] == section]
        assert rows, f"section {section!r} not found in the template"
        assert sum(1 for p in rows if p["resolved"]) / len(rows) >= 0.8


def test_intended_purpose_is_never_auto_filled(placeholders):
    """The intended-purpose field itself is human-only. The introduction mentions the
    purpose too, but is a summary assembled from the other sections - and it leaves the
    purpose as an open point inside it (see test_figures_and_introduction.py)."""
    purpose = [p for p in placeholders
               if "tasks or problems the ai system is designed" in p["placeholder"].lower()]
    assert purpose, "the template must ask for the intended purpose"
    assert all(p["source"] == "human" for p in purpose), (
        "intended purpose cannot be derived from code - inventing it would be a compliance fault"
    )
