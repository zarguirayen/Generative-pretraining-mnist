"""Per-tool oversight audit, and the controls it generates.

The audit is done on the syntax tree rather than by text search, so these tests pin the
distinction that matters: a tool that *reaches* an irreversible call, versus a file that
merely mentions one. The generated module is exercised too - a gate that approves when no
human can answer would be worse than no gate at all.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKILL = PLUGIN_ROOT / "skills" / "aida-human-oversight"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(SKILL / "scripts"))

from audit_oversight import audit  # noqa: E402
from generate_controls import TEMPLATE, patch_for, subject_for  # noqa: E402


@pytest.fixture(scope="session")
def agentic():
    return audit(FIXTURES / "agentic_assistant")


@pytest.fixture(scope="session")
def rag():
    return audit(FIXTURES / "rag_service")


def tool_named(result: dict, name: str) -> dict:
    return next(t for t in result["tools"] if t["name"] == name)


# ------------------------------------------------------------------ tool inventory --
def test_every_model_callable_tool_is_found(agentic):
    assert {t["name"] for t in agentic["tools"]} == {
        "lookup_ticket", "send_notification", "purge_workspace"}


def test_irreversible_tools_are_ranked_high(agentic):
    assert tool_named(agentic, "send_notification")["severity"] == "high"
    assert tool_named(agentic, "purge_workspace")["severity"] == "high"


def test_a_read_only_tool_is_not_flagged(agentic):
    """lookup_ticket does an HTTP GET. Flagging it would train users to ignore findings."""
    tool = tool_named(agentic, "lookup_ticket")
    assert tool["severity"] == "none"
    assert tool["irreversible"] is False


def test_each_tool_reports_where_it_is(agentic):
    for tool in agentic["tools"]:
        assert tool["file"].endswith(".py") and tool["line"] > 0


def test_tool_parameters_are_recorded(agentic):
    assert tool_named(agentic, "send_notification")["parameters"] == ["address", "body"]


def test_counts_match_the_tool_list(agentic):
    counts = agentic["counts"]
    assert counts["tools"] == 3
    assert counts["irreversible"] == 2
    assert counts["gated"] == 0
    assert counts["ungated"] == 2


# ------------------------------------------------------------------- gate detection --
def test_a_gated_tool_is_recognised(tmp_path):
    project = tmp_path / "gated"
    project.mkdir()
    (project / "agent.py").write_text(textwrap.dedent('''
        from langchain_core.tools import tool
        from oversight_controls import requires_approval

        @tool
        @requires_approval("purge", severity="high")
        def purge(path: str) -> str:
            """Delete a directory."""
            import shutil
            shutil.rmtree(path)
            return "done"
    '''), encoding="utf-8")
    result = audit(project)
    assert tool_named(result, "purge")["approval_gate"] is True
    assert result["counts"]["ungated"] == 0


def test_a_mention_outside_a_tool_is_not_a_tool(tmp_path):
    """Text search would report this file as dangerous. It has no callable tool."""
    project = tmp_path / "helper"
    project.mkdir()
    (project / "cleanup.py").write_text(textwrap.dedent('''
        import shutil

        def nightly_cleanup(path):
            shutil.rmtree(path)
    '''), encoding="utf-8")
    result = audit(project)
    assert result["tools"] == []


def test_raw_sql_write_inside_a_tool_is_detected(tmp_path):
    project = tmp_path / "sql"
    project.mkdir()
    (project / "agent.py").write_text(textwrap.dedent('''
        from langchain_core.tools import tool

        @tool
        def close_account(account_id: str, conn=None) -> str:
            """Close an account."""
            conn.execute("UPDATE accounts SET status = 'closed' WHERE id = ?", account_id)
            return "closed"
    '''), encoding="utf-8")
    result = audit(project)
    assert "db_write" in tool_named(result, "close_account")["effects"]


# ----------------------------------------------------------------------- findings --
def test_ungated_tools_produce_a_blocking_finding(agentic):
    finding = next(f for f in agentic["findings"] if f["rule"] == "OVERSIGHT-INTERVENTION")
    assert finding["severity"] == "blocking"
    assert "send_notification" in finding["detail"] and "purge_workspace" in finding["detail"]


def test_missing_controls_are_reported_with_their_rule(agentic):
    rules = {f["rule"] for f in agentic["findings"]}
    assert {"OVERSIGHT-CAPABILITIES", "MON-USER-FEEDBACK", "OVERSIGHT-EXPLAINABILITY"} <= rules


def test_a_project_without_tools_still_reports_the_other_gaps(rag):
    assert rag["tools"] == []
    rules = {f["rule"] for f in rag["findings"]}
    assert "OVERSIGHT-EXPLAINABILITY" in rules
    assert "OVERSIGHT-INTERVENTION" not in rules, "no tools means no ungated tools"


# ------------------------------------------------------------ generated controls --
def test_patch_uses_a_real_parameter_name(agentic):
    """Deriving the quarantine key from the docstring produced subject_arg="user" for a
    function whose parameter is `address` - a patch that fails at runtime."""
    tool = tool_named(agentic, "send_notification")
    assert subject_for(tool) is None
    assert "subject_arg" not in patch_for(tool)


def test_patch_carries_the_tool_location_and_severity(agentic):
    patch = patch_for(tool_named(agentic, "purge_workspace"))
    assert "agent.py:" in patch and 'severity="high"' in patch


@pytest.fixture
def generated(tmp_path):
    project = tmp_path / "project"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    (project / "aida").mkdir()
    (project / "aida" / "oversight_audit.json").write_text(
        json.dumps(audit(project)), encoding="utf-8")
    subprocess.run(
        [sys.executable, str(SKILL / "scripts" / "generate_controls.py"),
         "--audit", "aida/oversight_audit.json", "--project", "."],
        cwd=project, check=True, capture_output=True)
    return project


def test_generated_module_is_written_and_imports(generated):
    module = generated / "aida" / "generated" / "oversight_controls.py"
    assert module.exists()
    assert module.read_text(encoding="utf-8") == TEMPLATE.read_text(encoding="utf-8")


def test_project_source_is_never_touched(generated):
    original = (FIXTURES / "agentic_assistant" / "agent.py").read_text(encoding="utf-8")
    assert (generated / "agent.py").read_text(encoding="utf-8") == original


def test_the_gate_refuses_when_no_human_can_answer(generated):
    """The whole point of the control: unreachable approver means refuse, and record it."""
    script = textwrap.dedent('''
        import sys, json, pathlib
        sys.path.insert(0, "aida/generated")
        import oversight_controls as oc

        @oc.requires_approval("wire_transfer", severity="high")
        def wire_transfer(iban=None, amount=0, password=None):
            return "sent"

        try:
            wire_transfer(iban="FR76", amount=1000, password="hunter2")
            print("APPROVED")
        except oc.OversightStop:
            print("REFUSED")
        entry = json.loads(pathlib.Path("logs/oversight_journal.jsonl").read_text().splitlines()[-1])
        print(entry["event"], entry["arguments"]["password"])
    ''')
    result = subprocess.run([sys.executable, "-c", script], cwd=generated,
                            capture_output=True, text=True, stdin=subprocess.DEVNULL)
    assert "REFUSED" in result.stdout, result.stdout + result.stderr
    assert "refused [redacted]" in result.stdout, "the refusal must be journalled, "\
                                                  "and the credential must not be"


def test_the_stop_control_blocks_a_gated_action(generated):
    script = textwrap.dedent('''
        import sys
        sys.path.insert(0, "aida/generated")
        import oversight_controls as oc

        oc.stop("incident 42", by="s.owner")

        @oc.requires_approval("send", severity="high")
        def send(to=None):
            return "sent"

        try:
            send(to="a@b.c")
            print("RAN")
        except oc.OversightStop as exc:
            print("STOPPED", "stopped" in str(exc))
    ''')
    result = subprocess.run([sys.executable, "-c", script], cwd=generated,
                            capture_output=True, text=True, stdin=subprocess.DEVNULL)
    assert "STOPPED True" in result.stdout, result.stdout + result.stderr


def test_feedback_requires_a_valid_reason_category(generated):
    script = textwrap.dedent('''
        import sys
        sys.path.insert(0, "aida/generated")
        import oversight_controls as oc
        oc.feedback("s1", False, about="retrieval")
        try:
            oc.feedback("s1", False, about="whatever")
            print("ACCEPTED")
        except ValueError:
            print("REJECTED")
    ''')
    result = subprocess.run([sys.executable, "-c", script], cwd=generated,
                            capture_output=True, text=True, stdin=subprocess.DEVNULL)
    assert "REJECTED" in result.stdout, (
        "the guideline asks the user to say whether generation or retrieval failed, "
        "so the category cannot be free text"
    )
