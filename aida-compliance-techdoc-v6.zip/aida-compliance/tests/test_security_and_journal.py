"""Section 3.10 (guardrails, red teaming) and the AI System Journal appendix (DOC-JOURNAL).

    python -m pytest tests/test_security_and_journal.py -v
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
TECHDOC = PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"
sys.path.insert(0, str(TECHDOC))

from audit_security import GUARDRAILS, assess, scan  # noqa: E402

FAKE_KEY = "sk-" + "a1b2c3d4e5f6g7h8i9j0"


def run_chain(project: Path) -> Path:
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    return project / "aida"


@pytest.fixture(scope="module")
def agentic(tmp_path_factory) -> Path:
    project = tmp_path_factory.mktemp("sec") / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    return run_chain(project)


@pytest.fixture(scope="module")
def hardened(tmp_path_factory) -> Path:
    """The same agent with a token budget, validated output, a red-team suite - and a key."""
    project = tmp_path_factory.mktemp("sec") / "hardened"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    (project / "guard.py").write_text(
        "llm = ChatBedrock(max_tokens=512)\n"
        "structured = llm.with_structured_output(Answer)\n"
        f"API_KEY = \"{FAKE_KEY}\"\n", encoding="utf-8")
    (project / "redteam").mkdir()
    (project / "redteam" / "run.py").write_text("from deepteam import red_team\n",
                                                encoding="utf-8")
    return project


# ------------------------------------------------------------------------- 3.10 --
def test_absent_controls_are_gaps_mapped_to_owasp(agentic):
    audit = json.loads((agentic / "security_audit.json").read_text(encoding="utf-8"))
    summaries = " ".join(f["summary"] for f in audit["findings"])
    assert "LLM01 prompt injection" in summaries and "LLM05" in summaries
    assert "LLM06 excessive agency" in summaries          # the ungated tools of 3.9
    assert "no red-teaming suite" in summaries             # agentic -> BUILD-REDTEAM


def test_access_control_is_only_expected_behind_an_api(agentic):
    audit = json.loads((agentic / "security_audit.json").read_text(encoding="utf-8"))
    assert not any("access control" in f["summary"] for f in audit["findings"])
    rag = assess({}, [], {"endpoints": [{"route": "/ask"}]}, {})
    assert any("access control" in f["summary"] for f in rag["findings"])


def test_found_controls_are_cited_and_mapped(hardened):
    found, _ = scan(hardened)
    assert found["token_budget"] == ["guard.py:1"]
    assert found["output_validation"] == ["guard.py:2"]
    assert "redteam/run.py:1" in found["red_teaming"]
    result = assess(found, [], {"classification": {"family": "agentic"}}, {})
    summaries = " ".join(f["summary"] for f in result["findings"])
    assert "LLM05" not in summaries and "LLM10" not in summaries
    assert "red-teaming" not in summaries


def test_a_hardcoded_secret_is_reported_without_its_value(hardened):
    found, secrets = scan(hardened)
    assert secrets == ["guard.py:3"]
    result = assess(found, secrets, {}, {})
    assert any(f["severity"] == "blocking" and "LLM02" in f["summary"]
               for f in result["findings"])
    assert FAKE_KEY not in json.dumps(result)


def test_section_3_10_is_written_with_evidence_and_an_open_point(agentic):
    values = json.loads((agentic / "values.json").read_text(encoding="utf-8"))
    answer = values[GUARDRAILS]
    assert answer["source"] == "code" and answer["evidence"]
    assert "OWASP Top 10 for LLM applications" in answer["value"]
    assert "[A CONFIRMER - guardrails configured on the platform" in answer["value"]


# ------------------------------------------------------------------ the journal --
def journal_text(aida: Path) -> str:
    xml = zipfile.ZipFile(aida / "technical_documentation.docx").read(
        "word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", "", re.sub(r"</w:p>", "\n", xml))
    # the appendix heading; the closing section after it repeats the journal's name
    return text[text.rfind("Appendix"):]


def test_journal_opens_with_the_generation_and_lists_each_blocking_gap(agentic):
    rows = json.loads((agentic / "journal.json").read_text(encoding="utf-8"))
    assert rows[0]["event"].endswith("Technical documentation generated")
    gaps = [r for r in rows if "Compliance gap" in r["event"]]
    assert any("OVERSIGHT-INTERVENTION" in r["event"] for r in gaps)
    assert any("REC-MODEL-MANDATORY" in r["event"] for r in gaps)
    assert all("[A CONFIRMER - owner and due date" in r["measures"] for r in gaps)


def test_a_gap_seen_by_two_audits_is_journaled_once(agentic):
    rows = json.loads((agentic / "journal.json").read_text(encoding="utf-8"))
    ungated = [r for r in rows if "irreversible tool" in r["description"]]
    assert len(ungated) == 1


def test_journal_reaches_the_appendix_table(agentic):
    text = journal_text(agentic)
    assert "Technical documentation generated" in text
    assert "Compliance gap (OVERSIGHT-INTERVENTION)" in text
    assert "(Example: monitoring alert)" not in text, "the template's example row is removed"
    xml = zipfile.ZipFile(agentic / "technical_documentation.docx").read("word/document.xml")
    ids = re.findall(rb'w14:paraId="([0-9A-F]+)"', xml)
    assert len(ids) == len(set(ids)), "copied rows must not duplicate paragraph ids"


def test_journal_open_points_are_numbered_and_listed(agentic):
    text = journal_text(agentic)
    refs = re.findall(r"\[A CONFIRMER (#\d+) - owner and due date", text)
    assert refs
    closing = text[text.rfind("Document completion status"):]
    assert all(ref in closing for ref in refs)


def test_rows_added_by_overseers_survive_a_regeneration(agentic):
    journal = agentic / "journal.json"
    rows = json.loads(journal.read_text(encoding="utf-8"))
    rows.append({"event": "2026-10-02 - Monitoring alert", "description": "faithfulness -12%",
                 "measures": "prompt rolled back", "origin": "manual"})
    journal.write_text(json.dumps(rows), encoding="utf-8")
    subprocess.run([sys.executable, str(TECHDOC / "write_journal.py"), "--context",
                    "aida/context.json", "--aida", "aida"], cwd=agentic.parent, check=True,
                   capture_output=True)
    rows = json.loads(journal.read_text(encoding="utf-8"))
    assert rows[-1]["event"] == "2026-10-02 - Monitoring alert"
