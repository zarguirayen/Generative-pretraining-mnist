"""What running the plugin on real projects taught, pinned so it cannot come back.

The chain was run on three projects from the Plugin-Skill-Hub written by other people: the
AgentGrade evaluation engine, the prompt-optimisation package and the skill installer. The
last one - a utility that downloads folders from GitLab, with no AI in it - came out as a
hybrid L3 agent. Four separate causes, each fixed and each tested here:

1. documentation was read as code - a SKILL.md describing LangGraph and `@tool` is not an
   agent;
2. the scanner read its own previous output in `aida/`, so a second run classified the
   project from the words in the first run's reports;
3. test files were read as the system - mocks and sample strings are not behaviour;
4. `encode(` counted as an embedding call, and it matches every `str.encode()` in Python.

And one thing the fixture only passed by accident: a RAG built directly on ChromaDB's own
API, without the LangChain vocabulary, was invisible.
"""

from __future__ import annotations

import json
import sys
import textwrap
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-core" / "scripts"))

from scan_codebase import build_context  # noqa: E402


def write(project: Path, name: str, content: str) -> None:
    path = project / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(textwrap.dedent(content), encoding="utf-8")


def family(project: Path) -> str:
    return build_context(project)["classification"]["family"]


def downloader(tmp_path: Path) -> Path:
    """A plain utility: fetches an archive over HTTP. No model, no agent."""
    project = tmp_path / "downloader"
    write(project, "fetch.py", '''
        import json
        import urllib.request

        def fetch(url: str) -> bytes:
            with urllib.request.urlopen(url, timeout=10) as response:
                return response.read()

        def save(path, payload: dict) -> None:
            path.write_bytes(json.dumps(payload).encode("utf-8"))
    ''')
    return project


# ----------------------------------------------------- 1. documentation is not code --
def test_a_skill_md_that_describes_agents_does_not_make_an_agent(tmp_path):
    project = downloader(tmp_path)
    write(project, "SKILL.md", '''
        # Integration guide
        Build a LangGraph ReAct agent with create_react_agent and expose tools:

            @tool
            def load_skill(name: str) -> str: ...

        Uses the Claude Agent SDK, a retriever and a vectorstore with similarity_search.
    ''')
    write(project, "README.md", "An orchestrator that spawns sub_agent workers.\n")
    assert family(project) == "unknown"
    assert build_context(project)["models"] == {}


# ------------------------------------------------------------- 2. idempotent scan --
def test_a_second_run_does_not_read_the_first_runs_output(tmp_path):
    project = downloader(tmp_path)
    first = build_context(project)["classification"]

    # What a previous run leaves behind: reports full of the plugin's own vocabulary.
    write(project, "aida/audit.json", json.dumps({
        "why": "MCP servers, ReAct loop, planner, create_react_agent, similarity_search",
        "tools": "@tool bind_tools tools=[x]"}))
    write(project, "aida/values.json", json.dumps({"x": "orchestrator trajectory spawn"}))

    second = build_context(project)["classification"]
    assert second["family"] == first["family"] == "unknown"
    assert second["agentic_level"] == first["agentic_level"]


# ------------------------------------------------------- 3. tests are not the system --
def test_signals_that_only_appear_in_tests_are_ignored(tmp_path):
    project = downloader(tmp_path)
    write(project, "test_fetch.py", '''
        from unittest import mock

        def test_retrieval():
            retriever = mock.Mock()
            retriever.similarity_search.return_value = []
            assert retriever.as_retriever() is not None
    ''')
    write(project, "tests/test_agent.py", '''
        from langgraph.prebuilt import create_react_agent
        agent = create_react_agent("model", tools=[])
    ''')
    assert family(project) == "unknown"


# ---------------------------------------------------- 4. str.encode is not embedding --
def test_string_encoding_is_not_an_embedding_call(tmp_path):
    project = tmp_path / "encoder"
    write(project, "codec.py", '''
        def pack(text):
            return text.encode("utf-8")

        def pack_all(items):
            return [item.encode() for item in items]
    ''')
    assert family(project) == "unknown"


# ------------------------------------------ the native API a real RAG actually uses --
def test_a_rag_built_on_chromadb_directly_is_recognised(tmp_path):
    """No LangChain word anywhere - only the vector store's own client."""
    project = tmp_path / "native_rag"
    write(project, "search.py", '''
        import chromadb

        client = chromadb.PersistentClient(path="./kb")
        collection = client.get_or_create_collection("policies")

        def retrieve(question: str, k: int = 4):
            return collection.query(query_texts=[question], n_results=k)
    ''')
    assert family(project) == "rag"


def test_the_classification_evidence_never_points_at_docs_tests_or_output(tmp_path):
    project = tmp_path / "mixed"
    write(project, "search.py", '''
        import chromadb
        collection = chromadb.PersistentClient(path="kb").get_or_create_collection("c")
        def retrieve(q):
            return collection.query(query_texts=[q], n_results=3)
    ''')
    write(project, "README.md", "similarity_search retriever vectorstore\n")
    write(project, "test_search.py", "retriever = None  # similarity_search\n")
    write(project, "aida/context.json", '{"x": "similarity_search retriever"}')

    evidence = build_context(project)["classification"]["family_evidence"]
    assert evidence
    for item in evidence:
        path = item.rpartition(":")[0]
        assert path == "search.py", f"evidence taken from {path}"
