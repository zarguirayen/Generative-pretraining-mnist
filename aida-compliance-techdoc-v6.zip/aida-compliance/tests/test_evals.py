"""The evaluation scenarios must stay runnable and honest.

These do not run an agent - they check the eval files are well formed, point at
workspaces that exist, and keep covering the behaviours that matter. An eval suite that
silently rots is worse than none, because it looks like coverage.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
EVAL_FILES = sorted((PLUGIN_ROOT / "tests" / "evals").glob("*.evals.json"))


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def all_evals() -> list[tuple[Path, dict]]:
    return [(path, item) for path in EVAL_FILES for item in load(path)["evals"]]


def test_every_shipped_skill_has_an_eval_file():
    skills = {p.parent.name for p in (PLUGIN_ROOT / "skills").glob("*/SKILL.md")}
    covered = {path.name.replace(".evals.json", "") for path in EVAL_FILES}
    assert skills <= covered, f"no evaluations for: {sorted(skills - covered)}"


@pytest.mark.parametrize("path", EVAL_FILES, ids=lambda p: p.name)
def test_at_least_three_scenarios_per_skill(path):
    # Anthropic's authoring guidance: build at least three evaluations before writing
    # extensive documentation, so the skill solves real gaps rather than imagined ones.
    assert len(load(path)["evals"]) >= 3


@pytest.mark.parametrize("path,item", all_evals(), ids=lambda x: x if isinstance(x, str) else "")
def test_scenario_is_well_formed(path, item):
    for field in ("id", "skills", "query", "workspace", "expected_behavior"):
        assert item.get(field), f"{path.name}: scenario missing {field!r}"
    assert isinstance(item["expected_behavior"], list)
    assert len(item["expected_behavior"]) >= 3, "a scenario with one expectation proves little"


@pytest.mark.parametrize("path,item", all_evals(), ids=lambda x: x if isinstance(x, str) else "")
def test_scenario_targets_a_shipped_skill(path, item):
    for skill in item["skills"]:
        assert (PLUGIN_ROOT / "skills" / skill / "SKILL.md").exists()


@pytest.mark.parametrize("path,item", all_evals(), ids=lambda x: x if isinstance(x, str) else "")
def test_scenario_workspace_exists(path, item):
    assert (PLUGIN_ROOT / item["workspace"]).is_dir(), (
        f"{item['id']}: workspace {item['workspace']} is missing - run tests/make_fixtures.py"
    )


def test_scenario_ids_are_unique():
    ids = [item["id"] for _, item in all_evals()]
    assert len(ids) == len(set(ids))


def test_the_negative_control_is_covered():
    """The non-AI project is the scenario that proves the tool degrades honestly."""
    scenarios = [item for _, item in all_evals() if "plain_billing" in item["workspace"]]
    assert scenarios, "no evaluation runs against a project with no AI in it"
    forbidden = " ".join(" ".join(s.get("must_not", [])) for s in scenarios).lower()
    assert "invent" in forbidden


def test_fabrication_is_explicitly_forbidden_somewhere():
    must_not = " ".join(" ".join(item.get("must_not", [])) for _, item in all_evals()).lower()
    assert "infer an intended purpose" in must_not
    assert "guess a risk category" in must_not
