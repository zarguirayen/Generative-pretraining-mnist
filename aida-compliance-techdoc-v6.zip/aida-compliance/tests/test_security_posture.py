"""The plugin's own security posture, as the challenge's grader assesses it.

Two findings from the first review are pinned here so they cannot come back:

* AST03 - `allowed-tools: shell` pre-approved every shell command. Each skill now names
  exactly the commands it runs, in the Copilot CLI permission syntax.
* AST02 - one dependency in the archive used a floating range. Every declared version must
  be pinned to an exact release, fixtures included: a fixture is still code a reviewer
  installs.

And the property the whole plugin relies on: no script reaches the network.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKILL_DIRS = sorted(p.parent for p in (PLUGIN_ROOT / "skills").glob("*/SKILL.md"))
SCRIPTS = sorted((PLUGIN_ROOT / "skills").glob("*/scripts/*.py"))
ALLOWED_COMMANDS = {"python", "python3", "git"}
NETWORK_MODULES = {"requests", "httpx", "urllib.request", "urllib3", "socket", "http.client",
                   "aiohttp", "ftplib", "smtplib", "paramiko"}


def allowed_tools(skill: Path) -> str:
    block = (skill / "SKILL.md").read_text(encoding="utf-8").split("\n---", 1)[0]
    match = re.search(r"^allowed-tools:\s*(.+)$", block, re.M)
    return match.group(1).strip() if match else ""


# ------------------------------------------------------------ AST03: least privilege --
@pytest.mark.parametrize("skill", SKILL_DIRS, ids=lambda p: p.name)
def test_allowed_tools_is_scoped_to_named_commands(skill):
    tools = allowed_tools(skill).split()
    assert tools, "a skill that runs scripts must declare what it runs"
    for tool in tools:
        match = re.fullmatch(r"shell\(([a-z0-9]+):\*\)", tool)
        assert match, f"{tool!r} is not scoped - pre-approve a named command, not the shell"
        assert match.group(1) in ALLOWED_COMMANDS, f"{tool!r} pre-approves an unneeded command"


@pytest.mark.parametrize("skill", SKILL_DIRS, ids=lambda p: p.name)
def test_git_is_only_granted_to_skills_that_read_git(skill):
    """Least privilege in both directions: granting git where it is unused widens the
    surface for nothing."""
    scripts = " ".join(p.read_text(encoding="utf-8") for p in (skill / "scripts").glob("*.py"))
    uses_git = '"git"' in scripts or "'git'" in scripts or "run_audit" in scripts
    if skill.name in ("aida-core", "aida-technical-documentation", "aida-audit"):
        uses_git = True  # these drive scan_codebase.py, which reads git metadata
    grants_git = "shell(git:*)" in allowed_tools(skill)
    assert grants_git == uses_git, (
        f"{skill.name}: git granted={grants_git} but used={uses_git}"
    )


# -------------------------------------------------------- AST02: pinned dependencies --
def dependency_files() -> list[Path]:
    return sorted(PLUGIN_ROOT.rglob("requirements*.txt")) + \
           sorted(PLUGIN_ROOT.rglob("pyproject.toml"))


def test_every_declared_dependency_is_pinned_to_an_exact_version():
    loose = []
    for path in dependency_files():
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            line = line.split("#")[0].strip()
            if not line or line.startswith(("-", "[")):
                continue
            if re.search(r"[<>~^]=?|!=", line) or ("==" not in line and "=" not in line):
                loose.append(f"{path.relative_to(PLUGIN_ROOT).as_posix()}:{number} {line}")
    assert not loose, f"unpinned dependencies: {loose}"


# ---------------------------------------------------------- no network, no execution --
@pytest.mark.parametrize("script", SCRIPTS, ids=lambda p: f"{p.parent.parent.name}/{p.name}")
def test_no_script_imports_a_network_module(script):
    """The plugin reads local files and git history, nothing else. Nothing leaves the
    machine - which is the answer to 'does it use external access?'."""
    tree = ast.parse(script.read_text(encoding="utf-8"))
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported |= {alias.name for alias in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module)
    assert not (imported & NETWORK_MODULES), f"network module imported: {imported & NETWORK_MODULES}"


@pytest.mark.parametrize("script", SCRIPTS, ids=lambda p: f"{p.parent.parent.name}/{p.name}")
def test_no_script_evaluates_or_unpickles_input(script):
    tree = ast.parse(script.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            # Only the builtins execute code. `re.compile` is an attribute call that
            # compiles a regex, and must not be mistaken for them.
            if isinstance(func, ast.Name):
                assert func.id not in {"eval", "exec", "compile"}, \
                    f"{func.id}() in {script.name}"
            if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
                assert not (func.value.id in {"pickle", "marshal"} and func.attr == "loads")
                assert not (func.value.id == "yaml" and func.attr == "load")


@pytest.mark.parametrize("script", SCRIPTS, ids=lambda p: f"{p.parent.parent.name}/{p.name}")
def test_subprocess_is_never_given_a_shell(script):
    """Every subprocess call passes an argument list; `shell=True` would let a crafted file
    name become a command."""
    tree = ast.parse(script.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for keyword in node.keywords:
                if keyword.arg == "shell":
                    assert isinstance(keyword.value, ast.Constant) and keyword.value.value is False
