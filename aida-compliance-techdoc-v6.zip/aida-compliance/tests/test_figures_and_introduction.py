"""The architecture diagram (3.5), the performance chart (3.4) and the introduction.

    python -m pytest tests/test_figures_and_introduction.py -v

The three are written last, from the analyses that ran before, so they are checked on
the finished document: a figure that is generated but never reaches the .docx, or an
introduction that states a purpose nobody gave, is the failure that matters.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
TECHDOC = PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"
sys.path.insert(0, str(TECHDOC))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-core" / "scripts"))

from render_figures import architecture, performance  # noqa: E402
from write_introduction import INTRODUCTION, build  # noqa: E402


def document_text(docx: Path) -> str:
    xml = zipfile.ZipFile(docx).read("word/document.xml").decode("utf-8")
    return re.sub(r"<[^>]+>", "", re.sub(r"</w:p>", "\n", xml))


@pytest.fixture(scope="module")
def evaluated(tmp_path_factory) -> Path:
    """The agentic fixture after a build-phase evaluation, through the whole chain."""
    project = tmp_path_factory.mktemp("figures") / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    run = project / "eval" / "outputs" / "run1"
    run.mkdir(parents=True)
    (run / "summary.json").write_text(json.dumps(
        {"metrics": {"task_completion": 0.86, "tool_correctness": {"score": 0.8}}}),
        encoding="utf-8")
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    return project / "aida"


@pytest.fixture(scope="module")
def unevaluated(tmp_path_factory) -> Path:
    project = tmp_path_factory.mktemp("figures") / "rag_service"
    shutil.copytree(FIXTURES / "rag_service", project)
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    return project / "aida"


# ------------------------------------------------------------ 3.5 architecture --
def test_architecture_is_a_mermaid_flowchart_of_what_the_code_shows(evaluated):
    diagram = (evaluated / "architecture.mmd").read_text(encoding="utf-8")
    assert diagram.startswith("flowchart LR")
    assert "langgraph" in diagram and "claude-haiku" in diagram
    assert "purge_workspace" in diagram


def test_ungated_irreversible_tools_are_marked_on_the_diagram(evaluated):
    diagram = (evaluated / "architecture.mmd").read_text(encoding="utf-8")
    ungated = re.search(r"class (\S+) ungated", diagram)
    assert ungated, "an irreversible tool with no gate must stand out on the diagram"
    marked = ungated.group(1).split(",")
    assert any(f'{node}["Tool: purge_workspace' in diagram for node in marked)
    assert "lookup_ticket" in diagram and not any(
        f'{node}["Tool: lookup_ticket' in diagram for node in marked)


def test_a_component_not_found_is_not_drawn():
    diagram, legend = architecture({"classification": {"family": "unknown"}}, None)
    for absent in ("model", "kb", "tool", "mcp", "obs", "api"):
        assert not re.search(rf"^\s+{absent}\d*[\[(]", diagram, re.M)
    assert legend == []


def test_mermaid_labels_cannot_be_broken_by_the_code():
    ctx = {"classification": {"family": "agentic"},
           "models": {'bad"]model{x}': ["a.py:1"]}}
    diagram, _ = architecture(ctx, None)
    node = next(line for line in diagram.splitlines() if "model1" in line and "[(" in line)
    assert node.count('"') == 2 and "{" not in node


# -------------------------------------------------------- 3.4 performance chart --
def test_chart_is_drawn_from_the_measured_baseline(evaluated):
    chart = (evaluated / "performance_chart.mmd").read_text(encoding="utf-8")
    assert chart.startswith("xychart-beta")
    assert "0.86" in chart and "0.8" in chart
    plan = json.loads((evaluated / "monitoring_plan.json").read_text(encoding="utf-8"))
    thresholds = [f"{m['alert_threshold']:g}" for m in plan["metrics"]
                  if m.get("baseline") is not None]
    assert thresholds and all(t in chart for t in thresholds)


def test_chart_svg_is_well_formed(evaluated):
    root = ET.parse(evaluated / "performance_chart.svg").getroot()
    assert root.tag.endswith("svg")
    assert len(root.findall("{http://www.w3.org/2000/svg}rect")) >= 3   # background + 2 bars


def test_no_baseline_means_no_chart_and_an_open_point(unevaluated):
    assert not (unevaluated / "performance_chart.mmd").exists()
    figures = json.loads((unevaluated / "figures.json").read_text(encoding="utf-8"))
    chart = next(f for f in figures if "Model Performance" in f["section"])
    assert chart["source"] is None and chart["caption"].startswith("[A CONFIRMER")
    assert performance({"metrics": [{"metric": "x", "baseline": None}]}) == (None, None, [])


# --------------------------------------------------------- figures in the .docx --
def test_both_figures_land_in_their_own_section(evaluated):
    text = document_text(evaluated / "technical_documentation.docx")
    heading = "Design Specifications and Model Performance"
    # first occurrence is the table of contents; the closing section repeats it later
    body = text[text.find(heading, text.find(heading) + 1):]
    perf, arch = body.find("xychart-beta"), body.find("flowchart LR")
    deployment = body.find("AI system deployment")
    architecture_heading = body.find("AI System Architecture")
    assert 0 < perf < architecture_heading < arch < deployment


def test_open_point_in_a_figure_is_numbered_and_listed(unevaluated):
    text = document_text(unevaluated / "technical_documentation.docx")
    ref = re.search(r"\[A CONFIRMER (#\d+) - no build-phase evaluation", text)
    assert ref, "the missing-chart caption must carry a reference number"
    closing = text[text.rfind("Document completion status"):]
    assert ref.group(1) in closing


def test_document_still_opens_after_insertion(evaluated):
    xml = zipfile.ZipFile(evaluated / "technical_documentation.docx").read("word/document.xml")
    root = ET.fromstring(xml)
    body = root.find("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}body")
    assert list(body)[-1].tag.endswith("sectPr"), "sectPr must stay the last body element"
    assert xml.startswith(b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')


# ----------------------------------------------------------------- introduction --
def test_introduction_is_assembled_from_the_other_sections(evaluated):
    values = json.loads((evaluated / "values.json").read_text(encoding="utf-8"))
    intro = values[INTRODUCTION]["value"]
    assert "autonomy level L2" in intro
    assert "task_completion 0.86" in intro                   # predictive performance
    assert "10% relative drop" in intro                      # continuous monitoring
    assert "irreversible tool(s) run with no human approval gate" in intro   # limitations
    assert "Internal validation" in intro


def test_introduction_never_states_the_intended_purpose():
    intro = build({"project": {"name": "x"}, "classification": {"family": "rag"}},
                  {})[INTRODUCTION]["value"]
    assert "Intended purpose: [A CONFIRMER" in intro


def test_introduction_reaches_the_document(evaluated):
    text = document_text(evaluated / "technical_documentation.docx")
    assert "This document describes agentic_assistant" in text
    assert "{Provide an overview" not in text
