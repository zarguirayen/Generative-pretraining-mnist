# aida-compliance

> Produces the AIDA compliance deliverables of an AI project from its codebase, using
> the official CACIB templates.

## Overview

Filling AIDA documentation by hand is slow, and the result goes stale the moment the
code moves. This plugin reads the repository instead: it classifies the system against
the AI Factory taxonomy, inventories what the project actually contains, and writes the
official Word template from that evidence.

The rule it is built around: **every written fact carries the `path:line` that proves
it, and anything the code cannot prove is reported as an open point rather than
invented.** A confident compliance document with nothing behind it is worse than an
incomplete one.

It covers the five AIDA deliverables — which are four sections of one document plus the
document itself — and adds a one-command audit across all of them.

## Skills

| Skill | Prize deliverable | What it does |
|---|---|---|
| `aida-core` | (foundation) | Scans the repo into an evidence base: classification RAG / Prompt / Agentic L1-L2-L3, models, dependencies, endpoints, logging, side effects — plus the 108-field map of the official template and a CycloneDX 1.6 ML-BOM |
| `aida-technical-documentation` | Technical documentation | Derives every answer the code proves and the guidelines fix, profiles the §3.3 evaluation data, inventories §3.10 guardrails against the OWASP LLM Top 10, draws the §3.5 architecture diagram (Mermaid) and the §3.4 baseline-vs-threshold chart from evidence, opens the AI System Journal, writes the introduction last from the sections, validates, fills the official Word template, and detects when the document drifts from the code |
| `aida-record-keeping` | Record keeping (§3.7) | Audits the nine mandatory records and the twelve required fields on the syntax tree, then generates a hash-chained, tamper-evident journal an auditor can verify from the file alone |
| `aida-genai-monitoring` | GenAI monitoring (§3.8a) | Derives alert thresholds from the measured build-phase baseline (20% prompt / 10% RAG and agentic), plans drift per family, and detects tool-set drift between two git revisions |
| `aida-operational-monitoring` | Operational monitoring (§3.8b) | Selects only metrics the kept records can feed, emits machine-readable alert rules, and checks every outbound call for timeout, retry and fallback |
| `aida-human-oversight` | Human oversight (§3.9) | Ranks every model-callable tool by irreversibility, reports ungated ones, and generates the missing controls — approval gate that fails closed, stop, quarantine, journal |
| `aida-audit` | (bonus) | Runs everything in one pass and rules on the 36 guideline requirements — met / not met / needs the risk owner / n-a — with a scorecard and a gap report per AIDA section |

Also shipped: the `aida-reviewer` agent (reads a deliverable the way a risk challenger
would), the `aida-context` prompt, and always-on evidence instructions.

## Usage

Once the plugin is installed from the hub marketplace, ask Copilot in natural language:

- *"Scan this project for AIDA"* — builds the evidence base
- *"Generate the AIDA technical documentation"* — fills the official template
- *"Can a human supervise this agent?"* — the per-tool oversight audit
- *"How compliant is this project with AIDA?"* — the full audit and scorecard

Or run the scripts directly — standard library only, nothing to install:

```bash
python skills/aida-core/scripts/scan_codebase.py /path/to/project --out aida/context.json
python skills/aida-audit/scripts/run_audit.py /path/to/project --inference-frequency daily
python skills/aida-audit/scripts/render_report.py --audit aida/audit.json
```

The scan never modifies the project it reads. All output goes to `aida/`.

### Failing CI on a compliance regression

`run_audit.py` exits 1 when any verifiable requirement is not met, and
`check_freshness.py` exits 1 when the documentation no longer matches the code:

```yaml
aida-compliance:
  stage: validate
  script:
    - python skills/aida-audit/scripts/run_audit.py . --inference-frequency daily
    - python skills/aida-technical-documentation/scripts/check_freshness.py check --values aida/values.json --project .
```

A merge that adds an ungated irreversible tool, drops a mandatory record or loosens a
threshold turns the pipeline red — compliance drift stops being invisible.

## Conformance

- Hub CI: `scripts/ci/validate_manifests.ps1` passes.
- GitHub Copilot plugin reference: `plugin.json` at the plugin root, kebab-case names,
  description ≤ 1024 chars, semver.
- Agent Skills open standard: all seven skills pass the official `skills-ref` validator
  (strict YAML, string `allowed-tools`, `compatibility` declared), with one deliberate,
  test-pinned deviation — the top-level fields the hub's own skill template mandates.
- 594 tests, including three fixture projects (RAG, agentic L2, and a non-AI service as
  the negative control) and 35 behavioural evaluation scenarios under `tests/evals/`.
- Run end to end on three real projects of the Plugin-Skill-Hub (AgentGrade,
  prompt-optimization, hub-skill-installer); the faults this surfaced are fixed and
  pinned in `tests/test_real_project_lessons.py`.
- Security posture: `allowed-tools` scoped per skill, dependencies pinned, no network
  access, no `eval`/`exec`/`pickle`, no shell subprocess - all enforced by tests.

## What it will not do

- Answer for the risk owner. Intended purpose, AI Act risk category, system owner and
  named human overseers are asked for, never guessed.
- Replace validation. The plugin produces documentation and reports gaps; the AIDA
  governance process still validates the system.
- Assess bias or fairness. The evaluation guideline places those in the risk and
  validation domain, outside its own scope.

## Development

```bash
python -m pytest tests/ -q
```

Manifest validation, from the repository root:

```bash
powershell -ExecutionPolicy Bypass -File scripts/ci/validate_manifests.ps1
```

## Maintainers

ZARGUI Rayen — CACIB / DS Community.
Built for the AI Skills Summer Challenge, against the AI Factory guidelines:
Building Agentic AI Systems, Evaluation of GenAI Systems, Monitoring and Human
Oversight, and Record Keeping.
