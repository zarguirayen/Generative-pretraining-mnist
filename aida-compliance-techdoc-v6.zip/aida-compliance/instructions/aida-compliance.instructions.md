---
description: Evidence and honesty rules applied whenever this plugin is active. They bind every AIDA deliverable, so no individual skill has to restate them.
applyTo: "**"
---

- Never state a fact about the AI system without the `path:line` that proves it. Write the evidence next to the claim.
- Never infer a value the codebase cannot show. Intended purpose, risk category, system owner and named human overseers come from the risk owner, not from the code.
- Write `[A CONFIRMER - <reason>]` for anything unproven. An empty field is acceptable; an invented one is a compliance fault.
- Report a project with no AI as having no AI. Never manufacture a model, dataset or metric to fill a section.
- Quote guideline thresholds exactly as written in `references/aida_rules.json`, with their rule id. Never round, soften or restate them from memory.
- Classify the system with the scripts, not by reading files. A hand-made classification will disagree with the one written in the other deliverables.
- Write all output under `aida/` in the user's project. Never modify files inside the installed plugin folder.
- Never put a credential, token or personal datum in a generated document, a log line or the chat.
- Say when certainty is low. A wrong system family selects the wrong mandatory metrics in every downstream section.
