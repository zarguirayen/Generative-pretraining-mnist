#!/usr/bin/env python3
"""Export the AI System Journal from the record chain - documentation as a record.

    python export_ai_journal.py logs/aida_records.jsonl [--out aida/ai_system_journal.json]

The AI System Journal (DOC-JOURNAL) holds the major alerts, their investigations and
corrective measures, and every substantial overseer intervention. All of them are already
in the hash-chained journal; this checks the chain first, then lays them out in the
template's three columns - Event | Description | Justification / corrective measures:

- an alert, with the follow-ups recorded against it (action, justification, resolved or
  not) - or an open point when nobody has followed it up;
- incidents, security and toxicity events, changes and deployments, documentation versions;
- overseer interventions: an output overridden or escalated, an irreversible action taken
  without an approver, structured oversight feedback.

Writes the rows as JSON - the shape fill_docx.py takes for the appendix - and as Markdown.
Exit code 1 when the chain is broken: an export of a tampered journal is not a record.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))  # the sibling verify_chain.py, found from this file
from verify_chain import verify  # noqa: E402  (sibling script: the chain check)

OPEN = "[A CONFIRMER - investigation and corrective measures, with their owner and date]"


def read(path: Path) -> list[dict]:
    """Every entry of the journal, oldest first."""
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def followups(entries: list[dict]) -> dict[int, list[dict]]:
    """Alert sequence number -> the follow-ups recorded against it."""
    found: dict[int, list[dict]] = {}
    for entry in entries:
        if entry.get("event") == "alert_followup":
            found.setdefault(entry["payload"].get("alert_seq"), []).append(entry["payload"])
    return found


def measures(follow: list[dict]) -> str:
    """The follow-ups of one alert as the journal's third column, or an open point."""
    if not follow:
        return OPEN
    return "; ".join(f"{f.get('action')} - {f.get('justification')} "
                     f"({'resolved' if f.get('resolved') else 'still open'})" for f in follow)


def row(entry: dict, follow: dict[int, list[dict]]) -> list[str] | None:
    """(event, description, measures) for an entry the journal must hold, else None."""
    kind, p, day = entry.get("event"), entry.get("payload") or {}, str(entry.get("at", ""))[:10]
    if kind == "alert":
        title = p.get("kind") if p.get("kind") != "operational" else p.get("metric")
        return [f"{day} - alert: {title or p.get('metric')} ({p.get('severity')})",
                str(p.get("detail") or p.get("explanation") or ""), measures(follow.get(entry["seq"], []))]
    if kind in ("incident", "security_event"):
        return [f"{day} - {kind.replace('_', ' ')}: {p.get('kind')}", str(p.get("detail", "")), OPEN]
    if kind == "toxicity_detection":
        return [f"{day} - harmful output flagged: {p.get('category')}",
                f"score {p.get('score')} against {p.get('threshold')} ({p.get('detector')}), "
                f"request {p.get('request_id')}", f"action taken: {p.get('action')}"]
    if kind == "human_review" and p.get("verdict") in ("overridden", "escalated"):
        return [f"{day} - overseer intervention: output {p['verdict']}",
                f"item {p.get('item_id')}, by {entry.get('actor')}", str(p.get("comment") or OPEN)]
    if kind == "irreversible_action" and p.get("unapproved"):
        return [f"{day} - irreversible action without an approver: {p.get('tool')}",
                f"request {p.get('request_id')}", OPEN]
    if kind == "oversight_feedback":
        return [f"{day} - oversight feedback ({p.get('category')})", str(p.get("feedback", "")),
                f"improvement asked: {p.get('improvement')}"]
    if kind == "deployment":
        return [f"{day} - change deployed: {p.get('from_version')} -> {p.get('to_version')}",
                str(p.get("reason", "")), f"deployed by {entry.get('actor')} to {p.get('environment')}"]
    if kind == "documentation":
        return [f"{day} - documentation version: {p.get('kind')} {p.get('version')}",
                f"stored at {p.get('uri')}", f"kept {p.get('retention_years')} years"]
    return None


def build(path: Path) -> dict:
    """The journal's rows, after the chain check that makes them a record."""
    check = verify(path)
    entries = read(path)
    follow = followups(entries)
    rows = [{"cells": cells, "origin": "records", "seq": entry["seq"]}
            for entry in entries if (cells := row(entry, follow))]
    return {"source": str(path), "chain_intact": check["intact"], "entries": check["entries"],
            "rows": rows}


def markdown(journal: dict) -> str:
    """The journal as the template's three-column table."""
    lines = ["# AI System Journal", "",
             f"Exported from `{journal['source']}` ({journal['entries']} entries, chain "
             f"{'intact' if journal['chain_intact'] else 'BROKEN'}).", "",
             "| Event | Description | Justification / corrective measures |", "|---|---|---|"]
    lines += ["| " + " | ".join(cell.replace("|", "/") for cell in r["cells"]) + " |"
              for r in journal["rows"]]
    return "\n".join(lines) + "\n"


def main() -> int:
    """Command line: export the journal; exit 1 when the chain is broken."""
    parser = argparse.ArgumentParser(description="Export the AI System Journal from the records.")
    parser.add_argument("journal", nargs="?", default="logs/aida_records.jsonl")
    parser.add_argument("--out", default="aida/ai_system_journal.json")
    args = parser.parse_args()
    source = Path(args.journal)
    if not source.exists():
        print(f"error: journal not found: {source}", file=sys.stderr)
        return 2
    journal = build(source)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(journal, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    out.with_suffix(".md").write_text(markdown(journal), encoding="utf-8")
    print(f"{len(journal['rows'])} journal row(s) written to {out} and {out.with_suffix('.md')}"
          f" - chain {'intact' if journal['chain_intact'] else 'BROKEN'}")
    return 0 if journal["chain_intact"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
