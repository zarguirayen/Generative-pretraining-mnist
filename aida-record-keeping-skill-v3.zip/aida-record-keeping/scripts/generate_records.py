#!/usr/bin/env python3
"""Write the record keeping the audit found missing, and show where to call it.

    python generate_records.py --audit aida/records_audit.json --project .

The audit says which of the nine mandatory records have no mechanism and which fields the
inference log never carries. This writes a module that covers them, and prints the call
for each gap - at the endpoint, at deployment, at review time.

It never edits the project's own source: where those calls belong is a decision about the
application, not about compliance.

The record keeping is scaled to the rated risk (template §5): scale_records.py rates stakes,
complexity and exposure, and the decisions are written into the module's SCALED settings
and, with their reasons, into aida/records_scaling.json for section 3.7.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))  # the sibling scale_records.py, found from this file
import scale_records  # noqa: E402  (sibling script: the §5 risk scaling)

DEFAULT_SCALED = ('SCALED = {"anchor_every_seconds": 3600, "tool_steps": True, "source_address": True,\n'
                  '          "approver_on_irreversible": True}\n')
TEMPLATE = HERE.parent / "assets" / "aida_records.py.template"
STORAGE_TEMPLATE = HERE.parent / "assets" / "records_storage.tf.template"

# record id -> (where the call belongs, the call itself)
CALL_SITES: dict[str, tuple[str, str]] = {
    "inference_input_data": (
        "in the request handler, once the answer is produced",
        'records.inference(session_id=session_id, request_id=request_id,\n'
        '                  model_version=MODEL_ID, input=question, output=answer,\n'
        '                  latency_ms=elapsed_ms, tokens=usage, actor=caller)'),
    "inference_output_data": (
        "same call as the input - one record holds both",
        'records.inference(... output=answer ...)'),
    "observed_ground_truth_collection": (
        "in the feedback endpoint, when a user corrects an answer",
        'records.ground_truth(request_id=request_id, observed=correction, source="user")'),
    "model_training_data": (
        "wherever a dataset version is pinned for a model version",
        'records.model_dataset("training", uri=DATASET_URI, version=DATASET_VERSION)'),
    "model_validation_test_data": (
        "next to the training dataset record",
        'records.model_dataset("validation", uri=EVAL_URI, version=EVAL_VERSION)'),
    "model_training_performance_metrics": (
        "after the evaluation run, before a version goes to production",
        'records.model_performance(model_version=MODEL_ID, metrics=summary,\n'
        '                          deployed_at=deploy_date)'),
    "change_deployment_record": (
        "in the deployment pipeline, or at application startup",
        'records.deployment(from_version=previous, to_version=current,\n'
        '                   reason=release_note, actor=deployer)'),
    "system_access_log": (
        "in the authentication middleware",
        'records.access(actor=caller, access_type="API call", resource=path,\n'
        '               status=outcome)'),
    "human_review_record": (
        "wherever a person accepts, overrides or escalates an output",
        'records.human_review(item_id=request_id, reviewer=reviewer,\n'
        '                     verdict="overridden", comment=note)'),
}




def storage_files(journal: str) -> dict[str, str]:
    """The storage REC-RETENTION asks for, built: the policy, the infrastructure that
    enforces it (Terraform for S3), and the daily verified backup."""
    policy = {
        "rule": "REC-RETENTION",
        "retention_years": {"automatic_logs": 1, "documentation": 10},
        "immutability": "write once: S3 Object Lock in COMPLIANCE mode, plus the hash chain "
                        "and anchors of the journal itself",
        "enforcement": "lifecycle rules: logs to archive at 90 days, expired at 400; "
                       "documentation expired at 10 years; no deletion before (Object Lock)",
        "encryption": {"at_rest": "KMS key with rotation", "in_transit": "TLS only - the "
                       "bucket policy denies plain HTTP"},
        "backups": {"frequency": "daily", "how": "aida_records.backup() copies the journal "
                    "and anchors and verifies the copy", "schedule": "backup-crontab.txt"},
        "redundancy": "replication to a locked bucket in a second region",
        "clocks": "NTP-synchronised hosts, so timestamps compare across services",
        "journal": journal,
    }
    cron = ("# AIDA records - daily verified backup to a second location (REC-RETENTION).\n"
            "# exit code 1 = the copy did not verify: treat it as an incident.\n"
            "15 2 * * * cd /path/to/app && python -c \"import sys, aida_records as r; "
            "sys.exit(0 if r.backup('/mnt/aida-backup')['intact'] else 1)\"\n")
    return {"storage_policy.json": json.dumps(policy, indent=2) + "\n",
            "records_storage.tf": STORAGE_TEMPLATE.read_text(encoding="utf-8"), "backup-crontab.txt": cron}


def module_text(template: str, settings: dict) -> str:
    """The template with its SCALED settings replaced by the ones the risk decided."""
    if DEFAULT_SCALED not in template:
        raise SystemExit("error: the template's SCALED settings line has changed")
    return template.replace(DEFAULT_SCALED, f"SCALED = {settings!r}\n")


def scaling_lines(risk: dict, decisions: list[dict]) -> list[str]:
    """The ratings and each addition, applied or not, for the terminal."""
    lines = ["", "Scaled to the risk (template section 5):"]
    lines += [f"  {dimension:<11} {rated['rating']:<11} {rated['why']}" for dimension, rated in risk.items()]
    lines += [f"  {'+' if d['applied'] else '-'} {d['addition']}: {d['why']}" for d in decisions]
    return lines


def render_plan(audit: dict, target: Path, written: bool) -> str:
    """What was (or would be) written, and the call site of each missing record."""
    missing = [rid for rid, record in audit["records"].items() if not record["present"]]
    missing_fields = [name for name, field in audit["fields"].items() if not field["present"]]

    lines = [f"{'Wrote' if written else 'Would write'}: {target}", ""]
    lines.append("It provides one helper per mandatory record, and a hash-chained journal:")
    lines.append("  record()            append-only, credentials redacted, prev hash on every entry")
    lines.append("  verify()            walks the chain and reports where it stops holding")
    lines.append("  require_intact()    raises at startup if the journal was altered")
    lines.append("  nine record helpers covering REC-MODEL, REC-OPERATIONAL and REC-OVERSIGHT")

    if missing:
        lines.append("")
        lines.append(f"Add {len(missing)} missing record(s):")
        for record_id in missing:
            where, call = CALL_SITES.get(record_id, ("", ""))
            if not call:
                continue
            lines.append("")
            lines.append(f"# {record_id.replace('_', ' ')} - {where}")
            lines.append("import aida_records as records")
            lines.append(call)
    else:
        lines.append("\nEvery mandatory record already has a mechanism.")

    if missing_fields:
        lines.append("")
        lines.append(f"The inference record must also carry {len(missing_fields)} field(s) "
                     f"never logged today:")
        lines.append(f"  {', '.join(missing_fields)}")
        lines.append("  `model_version` is a required argument of records.inference() for "
                     "that reason: a score that cannot be attributed to a version cannot be "
                     "compared to a baseline.")

    lines.append("")
    lines.append("Still to decide, because code cannot decide it:")
    lines.append("  - the bucket names and regions of storage/records_storage.tf, and applying it")
    lines.append("  - the backup location in storage/backup-crontab.txt")
    lines.append("  - whether the actor must be anonymised or hashed for your data policy")
    lines.append("  - NTP synchronisation on the hosts, so timestamps are comparable")
    lines.append("")
    lines.append("Verify the journal at any time, with nothing but the file:")
    lines.append("  python verify_chain.py logs/aida_records.jsonl")
    return "\n".join(lines)


def main() -> int:
    """Command line: write the record module; the project's source is never edited."""
    parser = argparse.ArgumentParser(description="Generate the missing record keeping.")
    parser.add_argument("--audit", default="aida/records_audit.json")
    parser.add_argument("--project", default=".")
    parser.add_argument("--out", default="aida/generated/aida_records.py")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--context", default="aida/context.json",
                        help="scan of the project, to rate the risk (§5)")
    parser.add_argument("--risk-category", choices=["high", "limited", "minimal"],
                        help="AI Act risk category, from the risk owner (§5 stakes)")
    parser.add_argument("--users", choices=["internal", "external"],
                        help="who uses the system, from the risk owner (§5 exposure)")
    parser.add_argument("--inference-frequency", choices=["daily", "weekly", "monthly", "quarterly"])
    parser.add_argument("--scaling-out", default="aida/records_scaling.json")
    args = parser.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"error: audit not found: {audit_path}\n"
              f"       run audit_records.py first", file=sys.stderr)
        return 2
    if not TEMPLATE.exists():
        print(f"error: template missing: {TEMPLATE}", file=sys.stderr)
        return 2

    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    target = Path(args.project) / args.out
    context = Path(args.context)
    ctx = json.loads(context.read_text(encoding="utf-8")) if context.exists() else {}
    risk = scale_records.profile(ctx, args.inference_frequency, args.risk_category, args.users)
    decisions = scale_records.scale(risk)
    settings = scale_records.settings(decisions)

    written = False
    if not args.dry_run:
        if target.exists():
            print(f"{target} already exists - not overwriting. Delete it to regenerate.")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(module_text(TEMPLATE.read_text(encoding="utf-8"), settings),
                              encoding="utf-8")
            written = True
        storage = target.parent / "storage"
        storage.mkdir(parents=True, exist_ok=True)
        for name, content in storage_files("logs/aida_records.jsonl").items():
            (storage / name).write_text(content, encoding="utf-8")
        print(f"Storage built in {storage}: storage_policy.json, records_storage.tf "
              f"(Object Lock, KMS, TLS only, lifecycle, replication), backup-crontab.txt")
        scaling = Path(args.scaling_out)
        scaling.parent.mkdir(parents=True, exist_ok=True)
        scaling.write_text(json.dumps({"risk": risk, "adaptation": decisions, "settings": settings},
                                      indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(render_plan(audit, target, written))
    print("\n".join(scaling_lines(risk, decisions)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
