#!/usr/bin/env python3
"""Rate the risk of an AI system and scale its record keeping to it (template §5).

    python scale_records.py --context aida/context.json [--risk-category high]
                            [--users external] [--inference-frequency daily]

The record keeping is proportionate to the system. Three dimensions are rated, each from
the code's evidence or from the risk owner's answer - the same ratings, with the same
rules, as the two monitoring skills, so the whole of AIDA rests on one assessment (a test
keeps them identical):

- stakes - what a wrong output or action costs: the AI Act risk category, and the
  irreversible side effects the code can trigger;
- complexity - how much the system decides by itself: autonomy level and tools;
- exposure - who reaches it and how often: endpoints, inference frequency, users.

A dimension nobody has rated is "to confirm", never "low": its additions stay on until
the risk owner rates it low. Only additions are scaled; the nine mandatory records, their
fields, the format and the retention never are. generate_records.py writes the decisions
into the generated module's SCALED settings, so the additions run, not just read well.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HIGH, LOW, TO_CONFIRM = "high", "low", "to confirm"
IRREVERSIBLE = ("send_email", "delete", "http_write", "db_write")
HOURLY, DAILY = 3600, 86400

# Additions beyond the nine mandatory records, and the dimension that turns each one on.
SCALED_BY = {
    "approver on every irreversible action": "stakes",
    "hourly anchors": "stakes",
    "one record per tool step": "complexity",
    "source address on every access": "exposure",
}


def proofs(block: dict, limit: int = 4) -> list[str]:
    """The `path:line` proofs of a scan block `{name: {"evidence": [...]}}`, at most `limit`."""
    found = [item for entry in (block or {}).values() for item in entry.get("evidence") or []]
    return list(dict.fromkeys(found))[:limit]


def rating(level: str, why: str, evidence: list[str]) -> dict:
    """One rated dimension: its level, the reason, and the evidence behind it."""
    return {"rating": level, "why": why, "evidence": evidence}


def stakes(ctx: dict, risk_category: str | None) -> dict:
    """High for a high-risk category or an irreversible side effect; low only when the
    risk owner gave a lower category and the code can do nothing irreversible."""
    effects = {k: v for k, v in (ctx.get("side_effects") or {}).items() if k in IRREVERSIBLE}
    if risk_category == "high":
        return rating(HIGH, "high-risk AI Act category, per the risk owner", proofs(effects))
    if effects:
        kinds = ", ".join(k.replace("_", " ") for k in effects)
        return rating(HIGH, f"the code can take irreversible actions ({kinds})", proofs(effects))
    if risk_category in ("limited", "minimal"):
        return rating(LOW, f"{risk_category}-risk category per the risk owner, and no "
                           f"irreversible side effect in the code", [])
    return rating(TO_CONFIRM, "no irreversible side effect in the code; the risk category "
                              "is the risk owner's to give", [])


def complexity(ctx: dict) -> dict:
    """High for autonomy L2/L3 or several tools; low for a system that calls no tool."""
    cls = ctx.get("classification") or {}
    level = cls.get("agentic_level")
    tools = (cls.get("signal_counts") or {}).get("tools", 0)
    if level in ("L2", "L3") or tools > 1:
        return rating(HIGH, f"autonomy {level or 'L1'} with {tools} tool signal(s): the "
                            f"system chooses its own actions",
                      proofs(ctx.get("tool_definitions") or {}))
    if not tools and cls.get("family") in ("prompt", "rag"):
        return rating(LOW, f"a {cls['family']} system with no tool: it answers, it does not "
                           f"act", (cls.get("family_evidence") or [])[:2])
    return rating(TO_CONFIRM, "one tool at autonomy L1, or a family not established",
                  proofs(ctx.get("tool_definitions") or {}))


def exposure(ctx: dict, frequency: str | None, users: str | None) -> dict:
    """High for external users or an endpoint called daily; low for internal users."""
    endpoints = ctx.get("endpoints") or []
    evidence = [e["evidence"] for e in endpoints][:4]
    if users == "external":
        return rating(HIGH, "external users, per the risk owner", evidence)
    if endpoints and frequency == "daily":
        return rating(HIGH, f"{len(endpoints)} endpoint(s) in the code, called daily", evidence)
    if users == "internal":
        return rating(LOW, "internal users, per the risk owner, and no daily public "
                           "endpoint", evidence)
    return rating(TO_CONFIRM, "who uses the system is the risk owner's to say", evidence)


def profile(ctx: dict, frequency: str | None, risk_category: str | None,
            users: str | None) -> dict:
    """The three rated dimensions of §5."""
    return {"stakes": stakes(ctx, risk_category), "complexity": complexity(ctx),
            "exposure": exposure(ctx, frequency, users)}


def scale(risk: dict) -> list[dict]:
    """Every addition with its decision: applied unless its dimension is rated low."""
    decisions = []
    for addition, dimension in SCALED_BY.items():
        level = risk[dimension]["rating"]
        why = f"{dimension} {level}: {risk[dimension]['why']}"
        if level == TO_CONFIRM:
            why += " - applied until the risk owner rates it low"
        decisions.append({"addition": addition, "dimension": dimension,
                          "applied": level != LOW, "why": why})
    return decisions


def settings(decisions: list[dict]) -> dict:
    """The SCALED settings of the generated module, from the decisions."""
    on = {d["addition"]: d["applied"] for d in decisions}
    return {"anchor_every_seconds": HOURLY if on["hourly anchors"] else DAILY,
            "tool_steps": on["one record per tool step"],
            "source_address": on["source address on every access"],
            "approver_on_irreversible": on["approver on every irreversible action"]}


def main() -> int:
    """Command line: print the three ratings and what they add."""
    parser = argparse.ArgumentParser(description="Rate the risk and scale the record keeping (§5).")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--risk-category", choices=["high", "limited", "minimal"])
    parser.add_argument("--users", choices=["internal", "external"])
    parser.add_argument("--inference-frequency", choices=["daily", "weekly", "monthly", "quarterly"])
    args = parser.parse_args()
    context = Path(args.context)
    if not context.exists():
        print(f"error: context not found: {context}", file=sys.stderr)
        return 2
    risk = profile(json.loads(context.read_text(encoding="utf-8")), args.inference_frequency,
                   args.risk_category, args.users)
    for dimension, rated in risk.items():
        print(f"{dimension:<11} {rated['rating']:<11} {rated['why']}")
    for choice in scale(risk):
        print(f"  {'+' if choice['applied'] else '-'} {choice['addition']}: {choice['why']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
