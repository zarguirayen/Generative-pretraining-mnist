# Record keeping requirements

Source: AI Factory, *Record Keeping* guideline (version 04/12/2025) — EU AI Act
Article 12. Scope: **VRM risk categories 1 and 2**. Implementation must be complete
**before the end of the build phase**; records must be available on demand once the system
is in use.

## Contents

- [General requirements](#general-requirements)
- [Table 1 — model records](#table-1--model-records)
- [Table 2 — operational records](#table-2--operational-records)
- [Table 3 — human oversight records](#table-3--human-oversight-records)
- [Storage and retention](#storage-and-retention)
- [Documentation is itself a record](#documentation-is-itself-a-record)
- [Standard field names count](#standard-field-names-count)
- [Scaling to the risk (template §5)](#scaling-to-the-risk-template-5)
- [What the audit can and cannot check](#what-the-audit-can-and-cannot-check)

---

## General requirements

- **Timing** — in place before the end of the build phase.
- **Format** — structured, timestamped, standardised (JSON), so records can be parsed and
  traced.
- **Automatic** — embedded at the architectural level, with auto-logging, to minimise
  human error and to produce reliable input for monitoring.
- **Accessible** — available for review by authorised third parties on demand.
- **Updated** — record keeping is revisited on every significant change to the system.
- **Versioned and tamper-proof** — strict versioning of models and data, automated
  backups, tamper-proof audit trails.
- **Protected** — sensitive records encrypted, redundancy in place, retention and deletion
  automated.

Records marked **\*** are mandatory for internally developed systems. The others are
recommended, and a risk challenger may require them during review.

## Table 1 — model records

`REC-MODEL-MANDATORY`

| Record | Mandatory | What it holds | In the generated module |
|---|---|---|---|
| Model training data | **\*** | the dataset a model version was trained on | `model_dataset("training", ...)` |
| Model validation / test data | **\*** | the dataset it was validated on | `model_dataset("validation", ...)` |
| Model training performance metrics | **\*** | evaluation metrics of each version deployed to production | `model_performance()` |
| Inference input data | **\*** | prompts and requests, with timestamp and hashed user id | `inference()`, or `@logged_inference` on every call |
| Inference output data | **\*** | generated output, linked to its input | the same record as its input |
| Observed ground truth | **\*** | real-world outcomes, corrections, expected content | `ground_truth()`, joined by `request_id` |
| Model training experiment tracking | recommended | version, parameters, metrics, artifact, source commit | `experiment_run()` |
| User feedback | recommended | flagged outputs, alerts | `user_feedback()` |

For systems retrained often, only major dataset versions need keeping — those submitted to
validation, and those tied to a risk event.

## Table 2 — operational records

`REC-OPERATIONAL-MANDATORY`. Every record answers **what** (event), **when** (timestamp),
**who** (actor).

| Record | Mandatory | What it holds | In the generated module |
|---|---|---|---|
| Change / deployment record | **\*** | configuration changes, model updates, deployments | `deployment()` |
| System access log | **\*** | user or system access events, anonymised if required | `access()` |
| Inference request | recommended | request id, timestamp, size, status | `inference()`: `request_id`, `outcome` |
| Inference latency | recommended | duration per request — feeds the latency metric | `inference()`: `latency_ms` |
| System usage | recommended | session type, start and end — feeds usage duration | `usage_session()` |
| Data processing duration | recommended | pre- and post-processing time | `inference()`: `processing_ms` |
| System output size | recommended | output size per request | `inference()`: `output_chars`, output tokens |
| Timeout event | recommended | requests exceeding the limit — feeds timeout rate | `timeout_event()` |
| Error event | recommended | failed operations — feeds error rate | `error_event()` |
| Security event | recommended | unauthorised or suspicious access attempts | `security_event()` |
| Toxicity detection event | recommended | flagged harmful output, score and threshold | `toxicity_event()` |
| Incident event | recommended | critical incidents | `incident()` |
| System uptime | recommended | operational periods — feeds the uptime ratio | `uptime_probe()` |
| Resource utilisation | recommended | CPU, GPU, memory | `resource_usage()` |

The recommended ones are not optional in practice: each is the input of an operational
monitoring metric. Skipping the record makes the corresponding metric uncomputable.

## Table 3 — human oversight records

`REC-OVERSIGHT-MANDATORY`

| Record | Mandatory | What it holds | In the generated module |
|---|---|---|---|
| Human review record | **\*** | a human reviewed an output: reviewer, item, date, verdict | `human_review()` |
| Oversight feedback record | recommended | structured feedback feeding future improvements | `oversight_feedback()` |
| Alert trigger record | recommended | alert type, severity, time, who it went to | `alert()` |
| Alert follow-up record | recommended | action taken, justification, resolution | `alert_followup()` |

## Storage and retention

`REC-RETENTION`

- **Documentation records: 10 years.**
- **Automatic logs and records: at least 1 year.**
- Storage must be **secure and immutable**.
- Internal clocks **NTP-synchronised**, so timestamps are consistent across services.

A log file a developer can edit satisfies none of this. The generated module addresses it
by chaining each entry to the hash of the previous one: altering an entry changes its own
hash, removing one breaks the next link, and `verify_chain.py` reports where the chain
stops holding — using nothing but the file.

`generate_records.py` also builds the storage around the file, in
`aida/generated/storage/`:

- `records_storage.tf` — the bucket that enforces the rule: Object Lock in COMPLIANCE mode
  (nothing deleted or overwritten before a year), KMS encryption at rest, TLS only,
  versioning, no public access, a lifecycle that archives logs at 90 days and expires them
  at 400, documentation at 10 years, and replication to a locked bucket in a second region;
- `storage_policy.json` — the same decisions, platform-neutral, for another cloud or on
  premises;
- `backup-crontab.txt` — a daily `backup()`: the journal and its anchors copied to a second
  location and the copy verified, the backup itself recorded in the chain.

## Documentation is itself a record

The Technical Documentation is a mandatory record. It must describe the record keeping
methodology: which records were chosen, how they are structured, how they are maintained.
The **AI System Journal** inside it holds the major alerts, the investigations and the
corrective measures. `export_ai_journal.py` builds it from the chain, after checking the
chain is intact: each alert with its follow-ups — or an open point when nobody followed it
up — incidents, security and toxicity events, changes, overseer interventions, in the
template's three columns.

Project documents such as GAD and RPAD are part of the record set too, stored centrally
and kept current. The audit looks for them in the repository, and
`documentation_version(kind, version, uri)` records each version and where it is stored,
with its 10-year retention.

## Standard field names count

A project instrumented to the **OpenTelemetry GenAI semantic conventions** records its
fields as span attributes, not as log keywords. Those names are recognised, because a tool
that reported a properly instrumented service as recording nothing would penalise exactly
the teams who followed a standard:

| Required field | Standard attribute |
|---|---|
| session id | `gen_ai.conversation.id` |
| request id | `gen_ai.response.id` |
| model version | `gen_ai.request.model`, `gen_ai.response.model` |
| tokens | `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens` |
| tool calls | `gen_ai.tool.name`, `gen_ai.tool.call.id` |
| outcome | `error.type` |

Recognising the standard is not the same as crediting fields that are absent: a service
that sets those eight attributes and never records the input, the output or the latency is
still reported as missing them.

## Scaling to the risk (template §5)

The mandatory records hold for every system. What grows with the risk is how much more
is recorded, and how soon tampering would show:

| Addition | Turned on by | Why |
|---|---|---|
| an anchor every hour, not every day | stakes | the shorter the interval, the less of the tail can be cut off unseen |
| each irreversible action recorded with its approver | stakes | where an action cannot be undone, who allowed it is the record an auditor asks for first |
| one record per tool step | complexity | an agent's answer is only explainable from the sequence of tools it chose |
| the source address on every access | exposure | with external users, access has to be traceable to where it came from |

A dimension nobody rated keeps its additions. `scale_records.py` applies this table, and
`generate_records.py` writes the decisions into the generated module's `SCALED` settings.

## What the audit can and cannot check

| Requirement | Checkable from code | How |
|---|---|---|
| A mechanism exists for a mandatory record | yes, as a signal | pattern search, reported with `path:line` |
| Which fields an inference record carries | yes | keyword arguments and dict keys, on the syntax tree |
| Structured format | yes | structlog, JSON formatter, `.jsonl` output |
| Retention configured | partly | retention, TTL or lifecycle settings in config |
| Immutable storage | partly | append-only, object lock, hash chain markers |
| Records actually written in production | **no** | ask the risk owner |
| Records accessible to third parties on demand | **no** | organisational, ask the risk owner |
| Encryption of sensitive records at rest | **no** | infrastructure, ask the risk owner |

The bottom three rows are why the audit reports *mechanisms found*, never *compliance
achieved*.
