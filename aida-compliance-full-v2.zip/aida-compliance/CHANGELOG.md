# Changelog

All notable changes to `aida-compliance` are recorded here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the
project follows [SemVer](https://semver.org/).

## [Unreleased]

### Added

- `run_all.py --demo`: rebuilds the example ticket agent (21 evaluation cases, two dated
  runs, two tagged releases) and runs every skill on it, in one command.
- Technical documentation answers the bonus fields explicitly: the runtime and the
  operating system its container image fixes (2.3), how an update may affect performance
  (2.3), the limitations of the data from the evaluation profile (3.1), the
  post-processing of the predictions (3.2), and the re-evaluation of the AI Act risk
  category after a substantial change (4).
- Every SKILL.md lists its prerequisites file by file; `make_submission.py --skill`
  packages one skill and verifies it inside a copy of the plugin.

### Changed

- Every skill is granted `python` alone: the scripts read git themselves, with fixed
  read-only commands, and a test pins it.
- The audit rules through one check per area; long functions of the section writers and
  monitors split.

### Fixed

- `check_freshness.py` never reads a cited file outside the project.
- Section 3.8 said "alert below" for latency and tokens, which alert above.

## [0.1.0] - 2026-08-07

First working version. Builds the evidence base the AIDA deliverables are written from.

### Added

- `aida-core` skill: scans a repository into `aida/context.json`, where every recorded
  fact carries the `path:line` that proves it.
- System classification against the AI Factory taxonomy — RAG, Prompt, Agentic L1/L2/L3
  — including the escalation rule, with the reason and the evidence reported alongside.
- `references/aida_rules.json`: 36 machine-checkable rules extracted from the four AI
  Factory guidelines, each with its threshold, severity and source.
- Placeholder map of the official technical documentation template: 108 placeholders,
  of which 105 are fields and 3 are template guidance, each routed to `code`, `rule`,
  `external` or `human`.
- `fill_docx.py`: writes values into the official Word template while preserving its
  formatting, handling placeholders split across runs and keeping namespace prefixes
  intact. Unproven fields become `[A CONFIRMER - <reason>]` and are listed in a separate
  report.
- `aida_bom.py`: CycloneDX 1.6 ML-BOM of models, datasets and dependencies, which fills
  the dependency and third-party model fields and is itself a record under the record
  keeping guideline.
- `validate_values.py`: the gate between planning the answers and writing them. Blocks a
  human-only field filled without a recorded confirmer, a code-derived fact with no
  `path:line`, a guideline threshold that was loosened for the detected system family, a
  credential, leftover draft text, and answers to fields the template does not have.
- `aida-reviewer` agent, `aida-context` prompt, and always-on evidence instructions.
- Test suite of three fixture projects — RAG, agentic L2, and a non-AI service used as
  the negative control.
- Five behavioural evaluation scenarios covering classification, the escalation rule,
  honest degradation on a non-AI project, refusal to invent a human-only field, and
  holding a guideline threshold against a user asking to loosen it.

- `aida-technical-documentation` skill: derives the answers the codebase proves and the
  guidelines fix, collects the human answers with an attribution, validates, then writes
  the official Word template. Every guideline threshold is quoted with its rule id, and
  the alert threshold follows the detected system family.
- `check_freshness.py`: hashes every source file the document cites and reports the
  fields whose evidence has moved. Exits 1 on drift so a CI job can fail on stale
  documentation, which is what makes `DOC-UPDATE-ON-CHANGE` enforceable.
- `references/section_guide.md`: what each template section expects and which rule
  governs it.
- `aida-human-oversight` skill: per-tool irreversibility audit on the syntax tree,
  blocking findings for ungated tools, and generated controls whose approval gate fails
  closed and journals every refusal with credentials redacted.
- `aida-record-keeping` skill: coverage of the nine mandatory records and the twelve
  required inference fields, plus a hash-chained journal where editing, deleting or
  reordering an entry is detected by `verify_chain.py` from the file alone.
- `aida-genai-monitoring` skill: thresholds derived from the measured build-phase
  baseline, family-specific drift plans, and tool-set drift detection between two git
  revisions without touching the working tree.
- `aida-operational-monitoring` skill: metric selection constrained by which records
  exist, machine-readable alert rules, and per-call timeout / retry / fallback analysis.
- `aida-audit` skill: one pass over all 36 guideline requirements with four honest
  verdicts, a scorecard mapping each area to its AIDA section, and exit code 1 for CI.
- Conformance to the Agent Skills open standard, checked by the official `skills-ref`
  validator: strict YAML frontmatter, string `allowed-tools`, `compatibility` declared.
  The top-level house-template fields are the single, test-pinned deviation.

### Notes

- All five AIDA deliverables are covered — technical documentation, record keeping,
  GenAI monitoring, operational monitoring, human oversight — plus the aggregate audit.
- Everything runs on the Python standard library; `skills-ref` is an optional dev
  dependency used only by the conformance tests.
