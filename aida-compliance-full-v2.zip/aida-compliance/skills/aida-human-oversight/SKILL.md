---
name: aida-human-oversight
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: ready
compatibility: Requires Python 3.10+
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*)
description: >-
  Audits whether humans can actually oversee an AI system, and writes section 3.9 of
  the AIDA technical documentation. Inventories every tool the model can call, ranks
  each by how irreversible its effect is, reports which ones run with no human approval
  gate, checks the six oversight capabilities and the explainability requirement, then
  generates the missing controls - approval gate, stop control, quarantine, oversight
  journal, feedback and human review records. Use it when asked about human oversight,
  human-in-the-loop, approval gates, a kill switch or a stop button, when asked whether
  an agent can be supervised or interrupted, and when writing or reviewing the human
  oversight section of AIDA or EU AI Act Article 14 documentation.
tags:
  - aida
  - human-oversight
  - eu-ai-act
  - article-14
  - hitl
  - guardrails
  - agentic
---

# aida-human-oversight

Answers one question with evidence: if this agent does something wrong, can a person
stop it?

---

## Absolute rules

- **Never call a missing control acceptable.** An irreversible tool with no approval gate
  is a blocking finding, whatever the effort to close it.
- **Never edit the project's own source.** Generated controls go to
  `aida/generated/`; wiring them in is the developer's decision.
- **Never name a team as an overseer.** `OVERSIGHT-CAPABILITIES` needs natural persons;
  "the data science team" is not a name.
- **Never claim a control exists because a variable is called `confirm`.** The audit
  reports what it found and where; if the tools are declared in a way it does not
  recognise, say so instead of concluding there are none.
- **Never judge a tool whose body you could not read.** Tools declared as JSON
  schemas are dispatched by name; report them and ask the developer for their
  effect rather than assuming they are harmless.
- **Never present the tool count as complete when MCP servers are configured.** Their
  tools are declared outside the codebase; the count is a floor.
- **A policy or a sandbox is context, not a closed gap.** Report both, and keep the
  per-tool finding blocking.
- **An approval that cannot reach a person must refuse.** Fail closed, and record it.
- **Never write a credential into the oversight journal.**

---

## Purpose

Section 3.9 of the AIDA template asks for the human oversight measures in place, the
named overseers, and the record of alerts and actions. The guideline behind it requires
six capabilities, at least one explainability measure, and a set of intervention
mechanisms (`OVERSIGHT-CAPABILITIES`, `OVERSIGHT-EXPLAINABILITY`,
`OVERSIGHT-INTERVENTION`), for VRM risk categories 1 and 2.

Answering that from prose is guesswork. Answering it per tool is not: the audit parses
the syntax tree, finds the functions the model can call, and reports what each one
reaches — sending a message, deleting data, moving money, writing to an external system.
A tool that can do one of those and has no gate is the finding.

### When not to use

- The system calls no tool and takes no action - the audit will say so, but the §3.9
  answer is then mostly about user feedback and review, which the risk owner states.
- Logging of the decisions taken - use `aida-record-keeping`.

### Prerequisites

- Python 3.10+. Standard library only, in the generated controls too.
- The `aida-core` skill of the same plugin (`depends_on`), at `../aida-core/` from this
  folder. This skill uses exactly these files from it:

| `aida-core` file | Used by | For |
|---|---|---|
| `scripts/ast_utils.py` (`dotted`) | imported by `audit_oversight.py` | the dotted name of each call read on the syntax tree |
| `scripts/section_values.py` | imported by `write_section.py` | writing into `aida/values.json`: never a `human` field, never over a confirmed answer |
| `scripts/placeholder_map.py` → `aida/placeholders.json` | `write_section.py` (`--map`) | where each field's answer may come from |
| `references/aida_rules.json` | `write_section.py` (`--rules`) | the capabilities, explainability and intervention rules, with their ids |
| `scripts/validate_values.py`, `scripts/fill_docx.py` | Phase 5 | the blocking checks, then the Word document |

- The generated controls write the hash-chained journal format of `aida-record-keeping`,
  so its `verify_chain.py` checks every intervention with the same command.

---

## Workflow

Copy this checklist and tick items off as you go:

```
Human oversight:
- [ ] Phase 1: audit the tools and the controls
- [ ] Phase 2: report the findings
- [ ] Phase 3: generate the missing controls
- [ ] Phase 4: collect the named overseers
- [ ] Phase 5: write section 3.9
```

### Phase 1 — Audit

```bash
python scripts/audit_oversight.py . --out aida/oversight_audit.json
```

Exits 1 when there is a blocking finding. It reports, per tool: severity, what it
reaches, whether a gate is present, and `file:line`.

### Phase 2 — Report the findings

Lead with the number, not the theory:

```
3 tools callable by the model, 2 of them irreversible, 0 behind a human gate.

  purge_workspace    high    NO GATE   deletes data              agent.py:32
  send_notification  high    NO GATE   sends a message           agent.py:24
  lookup_ticket      -       -         read-only                 agent.py:18

Also missing: stop control, user feedback path, explainability measure.
```

Do not soften this. A risk challenger reads the same table.

### Phase 3 — Generate the missing controls

```bash
python scripts/generate_controls.py --audit aida/oversight_audit.json --project .
```

`--out` sets where the controls module is written (default
`aida/generated/oversight_controls.py`); `--dry-run` prints the plan and the patches
without writing anything.

Writes `aida/generated/oversight_controls.py` and `overseers.json`, and prints the exact
decorator patch for each ungated tool. The module covers the six intervention mechanisms of
`OVERSIGHT-INTERVENTION`:

| Mechanism | In the module |
|---|---|
| stop / override | `stop`, `resume`; `override` replaces or reverses an output |
| granular intervention | `quarantine` one output, session or user; `release` |
| user alert (PII, toxic, biased, copyright) | `flag_output` — journaled, quarantined, escalated |
| escalation with response timelines | `escalate`, `resolve`; `overdue()` lists the late ones |
| automatic routing to designated overseers | severities mapped to the people in `overseers.json` |
| logging of every alert, intervention, override | one hash-chained journal (`verify_chain.py`) |

Irreversible actions go through `requires_approval`; `four_eyes=True` requires two distinct
people, as `OVERSIGHT-BIOMETRIC-4EYES` does for biometric identification. It never
overwrites an existing file and never touches the project's source.

Tell the user what remains theirs to decide: the review channel the approver should call,
who the named overseers are, and where the journal lives with its retention.

### Phase 4 — Collect the named overseers

Ask in one block, and record the attribution:

```json
{ "Names of the human overseers.": {
    "value": "…", "confirmed_by": "<name> (risk owner), <date>" } }
```

Roles are not names. If the answer is a team, say that the guideline asks for natural
persons and ask again. Put the same names, and the response hours per severity, in
`aida/generated/overseers.json`: that file routes every escalation.

### Phase 5 — Write section 3.9

```bash
python scripts/write_section.py --audit aida/oversight_audit.json --values aida/values.json --map aida/placeholders.json
```

It writes this section's fields into the shared values file. The placeholder map decides
where each answer may come from: a field the template routes to a human is left as an open
point, and one routed to the codebase is skipped unless there is something to cite. Answers
carrying `confirmed_by` are never overwritten.

Then run the shared chain from `aida-core`:
`validate_values.py`, then `fill_docx.py`. The section must state the measures in place,
the ones missing, the named overseers, and where interventions are recorded — the AI
System Journal (`DOC-JOURNAL`).

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/write_section.py`](scripts/write_section.py) | Writes section 3.9 into `aida/values.json` |
| [`scripts/audit_oversight.py`](scripts/audit_oversight.py) | Per-tool irreversibility and gate audit, on the syntax tree |
| [`scripts/generate_controls.py`](scripts/generate_controls.py) | Writes the missing controls and the patch for each ungated tool |
| [`references/oversight_requirements.md`](references/oversight_requirements.md) | The six capabilities, the explainability options, the intervention mechanisms |
| [`assets/oversight_controls.py.template`](assets/oversight_controls.py.template) | The module that gets generated |

The `aida-core` files this skill relies on are listed under [Prerequisites](#prerequisites).

---

## Quality checklist

- [ ] Every model-callable tool is listed with its severity and `file:line`
- [ ] Every irreversible tool without a gate is reported as blocking
- [ ] The six capabilities were checked, not assumed
- [ ] At least one explainability measure is present or reported missing
- [ ] The named overseers are natural persons, recorded with a confirmer
- [ ] Generated controls went to `aida/generated/`, project source untouched
- [ ] The approval path fails closed when no person can be reached
