#!/usr/bin/env python3
"""Run every AIDA analysis on a project and rule on each requirement.

    python run_audit.py [project] [--inference-frequency daily] [--out aida/audit.json]

This orchestrates; it does not analyse. Each skill owns its own check, and re-implementing
any of them here would create a second opinion that could disagree with the first.

Every rule in `aida_rules.json` gets one of four verdicts:

    met          the evidence shows the requirement is satisfied
    not_met      the evidence shows it is not
    needs_human  code cannot answer it - only the risk owner can
    n/a          the rule does not apply to this system

The fourth status is what keeps the score honest. Roughly a third of the requirements are
organisational: whether records are truly kept in production, whether overseers were
trained, what the intended purpose is. A tool that scored those would be inventing a
verdict, so they are counted apart and never folded into the percentage.

Exit code 0 when nothing is `not_met`, 1 otherwise, 2 on a usage error.
Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILLS = HERE.parent.parent
RULES_PATH = SKILLS / "aida-core" / "references" / "aida_rules.json"

for skill in ("aida-core", "aida-human-oversight", "aida-record-keeping",
              "aida-genai-monitoring", "aida-operational-monitoring"):
    sys.path.insert(0, str(SKILLS / skill / "scripts"))

MET, NOT_MET, NEEDS_HUMAN, NOT_APPLICABLE = "met", "not_met", "needs_human", "n/a"

AREA_LABELS = {
    "architecture": "Architecture and autonomy",
    "observability": "Observability",
    "evaluation": "Evaluation",
    "security": "Security",
    "monitoring": "Model monitoring",
    "genai_monitoring": "GenAI quality monitoring",
    "operational_monitoring": "Operational monitoring",
    "human_oversight": "Human oversight",
    "record_keeping": "Record keeping",
    "documentation": "Documentation",
}


def collect(project: Path, inference_frequency: str | None) -> dict:
    """Run each skill's analysis. A failing analysis is reported, never silently skipped."""
    from audit_oversight import audit as audit_oversight
    from audit_records import audit as audit_records
    from check_resilience import check as check_resilience
    from plan_monitoring import build_plan as plan_genai
    from plan_operational import build_plan as plan_operational
    from scan_codebase import build_context

    rules = json.loads(RULES_PATH.read_text(encoding="utf-8"))
    artefacts: dict[str, dict] = {"errors": {}}

    def step(name: str, analysis, *args) -> None:
        """Run one analysis; a failure is recorded as a missing artefact, never hidden."""
        try:
            artefacts[name] = analysis(*args)
        except Exception:                              # noqa: BLE001 - reported, not hidden
            artefacts[name] = None
            artefacts["errors"][name] = traceback.format_exc(limit=2).strip().splitlines()[-1]

    step("context", build_context, project)
    step("oversight", audit_oversight, project)
    step("records", audit_records, project)
    step("resilience", check_resilience, project)
    if artefacts.get("context"):
        step("genai_monitoring", plan_genai,
             artefacts["context"], rules, project, inference_frequency)
        step("operational_monitoring", plan_operational,
             artefacts["context"], rules, artefacts.get("records"), inference_frequency)
    artefacts["rules"] = rules
    return artefacts


# --------------------------------------------------------------------- verdicts --
Verdict = tuple[str, str]

# Reference frameworks of the Building Agentic AI Systems guideline:
# rule -> (context key, name the scan reports, why when found, why when missing).
REFERENCE_TOOLS = {
    "BUILD-OBSERVABILITY": ("observability", "mlflow", "MLflow found",
                            "MLflow is the reference observability framework and was not found"),
    "BUILD-EVALUATION": ("evaluation", "deepeval", "DeepEval found",
                         "DeepEval is the reference evaluation framework and was not found"),
    "BUILD-REDTEAM": ("security", "deepteam", "DeepTeam found",
                      "no red-teaming framework found"),
}

THRESHOLD_RULE_BY_FAMILY = {"prompt": "MON-THRESHOLD-PROMPT", "rag": "MON-THRESHOLD-RAG",
                            "agentic": "MON-THRESHOLD-AGENTIC", "hybrid": "MON-THRESHOLD-RAG"}


@dataclass(frozen=True)
class Evidence:
    """What the analyses found, in the shape every area check reads."""
    ctx: dict
    family: str
    level: str | None
    oversight: dict
    records: dict
    genai: dict
    ops: dict

    @classmethod
    def of(cls, artefacts: dict) -> "Evidence":
        """Read the collected artefacts; a failed analysis reads as empty."""
        ctx = artefacts.get("context") or {}
        classification = ctx.get("classification") or {}
        return cls(ctx=ctx,
                   family=classification.get("family", "unknown"),
                   level=classification.get("agentic_level"),
                   oversight=artefacts.get("oversight") or {},
                   records=artefacts.get("records") or {},
                   genai=artefacts.get("genai_monitoring") or {},
                   ops=artefacts.get("operational_monitoring") or {})


def has(section: dict | None, key: str) -> bool:
    """True when the analysis produced `section` and it contains `key`."""
    return bool(section) and key in section


def architecture(rid: str, e: Evidence) -> Verdict | None:
    """BUILD-*: autonomy justification, reference stack and reference frameworks."""
    if rid == "BUILD-L1-DEFAULT":
        if e.level not in ("L2", "L3"):
            return NOT_APPLICABLE, "the system is not L2 or L3"
        return NEEDS_HUMAN, (f"the system is {e.level}; the necessity for that autonomy must "
                             f"be justified in the technical documentation")
    if rid in ("BUILD-STACK-L1", "BUILD-STACK-L2"):
        if not e.level:
            return NOT_APPLICABLE, "not an agentic system"
        found = (e.ctx.get("classification") or {}).get("reference_framework")
        if not found:
            return NEEDS_HUMAN, "no orchestration framework recognised in the code"
        return MET, f"{found} is in use"
    if rid in REFERENCE_TOOLS:
        if not e.level:
            return NOT_APPLICABLE, "not an agentic system"
        category, name, found, missing = REFERENCE_TOOLS[rid]
        return (MET, found) if has(e.ctx.get(category), name) else (NOT_MET, missing)
    return None


def evaluation(rid: str, e: Evidence) -> Verdict | None:
    """EVAL-*: dataset sizes and metric coverage, which the code does not show."""
    if rid in ("EVAL-RAG-QUERIES", "EVAL-RAG-CORPUS", "EVAL-RAG-METRICS"):
        if e.family not in ("rag", "hybrid"):
            return NOT_APPLICABLE, "not a RAG system"
        return NEEDS_HUMAN, "dataset size and metric coverage are not visible in the code"
    if rid in ("EVAL-AGENTIC-QUERIES", "EVAL-AGENTIC-CATEGORIES"):
        if e.family not in ("agentic", "hybrid"):
            return NOT_APPLICABLE, "not an agentic system"
        return NEEDS_HUMAN, "evaluation set size and metric coverage are not visible in the code"
    return None


def thresholds(rid: str, e: Evidence) -> Verdict:
    """MON-THRESHOLD-*: only the family's own rule applies, and it needs a baseline."""
    if rid == "MON-THRESHOLD-ANALYTICS-LABELED":
        return NOT_APPLICABLE, "not an analytics model"
    if THRESHOLD_RULE_BY_FAMILY.get(e.family) != rid:
        return NOT_APPLICABLE, f"applies to another family than {e.family}"
    derived = [m for m in e.genai.get("metrics", []) if m.get("alert_threshold")]
    if derived:
        return MET, f"{len(derived)} threshold(s) derived from the measured baseline"
    return NOT_MET, "no baseline, so no threshold could be derived"


def monitoring(rid: str, e: Evidence) -> Verdict | None:
    """MON-*: timing, frequency, thresholds and drift."""
    if rid == "MON-TIMING":
        return NEEDS_HUMAN, "whether monitoring was in place before release is not in the code"
    if rid == "MON-FREQUENCY":
        schedule = (e.genai.get("schedule") or {}).get("monitoring_frequency")
        if schedule:
            return MET, f"{schedule} monitoring, derived from the inference frequency"
        return NOT_MET, "inference frequency unknown, so no schedule could be derived"
    if rid.startswith("MON-THRESHOLD-"):
        return thresholds(rid, e)
    if rid == "MON-DRIFT-UNLABELED":
        return NOT_APPLICABLE, "applies to analytics and NLP models"
    if rid == "MON-DRIFT-TOOLSET":
        if not e.level:
            return NOT_APPLICABLE, "not an agentic system"
        return NEEDS_HUMAN, ("run detect_tool_drift.py between the documented version and HEAD; "
                             "whether it runs continuously is a process question")
    return None


def monitoring_coverage(rid: str, e: Evidence) -> Verdict | None:
    """MON-*: the operational and quality metric floors, and the user feedback path."""
    if rid == "MON-OPERATIONAL-MINIMUM":
        computable = [m for m in e.ops.get("metrics", []) if m.get("computable_today")]
        if computable:
            return MET, f"{len(computable)} metric(s) computable from existing records"
        return NOT_MET, "no metric from the guideline table can be computed today"
    if rid == "MON-GENAI-QUALITY-MINIMUM":
        if e.family == "unknown":
            return NOT_MET, "the system family is unknown, so no metric set applies"
        if e.genai.get("metrics"):
            return MET, "metric set selected for the family"
        return NOT_MET, "no quality metric selected"
    if rid == "MON-USER-FEEDBACK":
        if e.family not in ("rag", "agentic", "hybrid"):
            return NOT_APPLICABLE, "applies to RAG and agentic systems"
        if (e.oversight.get("controls") or {}).get("user_feedback"):
            return MET, "a feedback path was found"
        return NOT_MET, "no user feedback path found"
    return None


def human_oversight(rid: str, e: Evidence) -> Verdict | None:
    """OVERSIGHT-*: stop control, explainability, approval gates on irreversible tools."""
    controls = e.oversight.get("controls") or {}
    if rid == "OVERSIGHT-SCOPE":
        return NEEDS_HUMAN, "the VRM risk category decides whether these rules apply"
    if rid == "OVERSIGHT-CAPABILITIES":
        if not e.oversight.get("tools") and not controls.get("stop_control"):
            return NEEDS_HUMAN, "no tools recognised; confirm how the system is interrupted"
        if controls.get("stop_control"):
            return MET, "a stop or disable control was found"
        return NOT_MET, "no stop or disable control found"
    if rid == "OVERSIGHT-EXPLAINABILITY":
        if controls.get("source_citation"):
            return MET, "source citation found in the outputs"
        return NOT_MET, "no explainability measure found"
    if rid == "OVERSIGHT-INTERVENTION":
        counts = e.oversight.get("counts") or {}
        if not counts.get("irreversible"):
            return NOT_APPLICABLE, "no irreversible tool found"
        if counts.get("ungated"):
            return NOT_MET, (f"{counts['ungated']} irreversible tool(s) run with no human "
                             f"approval gate")
        return MET, "every irreversible tool is behind an approval gate"
    if rid == "OVERSIGHT-BIOMETRIC-4EYES":
        return NOT_APPLICABLE, "not a biometric identification system"
    return None


def record_keeping(rid: str, e: Evidence) -> Verdict | None:
    """REC-*: mandatory records, structured format with the required fields, retention."""
    if rid == "REC-SCOPE":
        return NEEDS_HUMAN, "the VRM risk category decides whether these rules apply"
    if not rid.startswith("REC-"):
        return None
    if not e.records:
        return NEEDS_HUMAN, "record audit unavailable"
    if rid in ("REC-MODEL-MANDATORY", "REC-OPERATIONAL-MANDATORY", "REC-OVERSIGHT-MANDATORY"):
        missing = [name for name, record in (e.records.get("records") or {}).items()
                   if record.get("rule") == rid and not record.get("present")]
        if missing:
            return NOT_MET, (f"{len(missing)} mandatory record(s) with no mechanism: "
                             f"{', '.join(m.replace('_', ' ') for m in missing)}")
        return MET, "every mandatory record of this group has a mechanism"
    if rid == "REC-FORMAT":
        if not (e.records.get("format") or {}).get("structured"):
            return NOT_MET, "logging is not structured"
        missing = [k for k, v in (e.records.get("fields") or {}).items() if not v.get("present")]
        if missing:
            return NOT_MET, f"{len(missing)} required field(s) never logged"
        return MET, "structured logging with every required field"
    if rid == "REC-RETENTION":
        problems = []
        if not (e.records.get("retention") or {}).get("configured"):
            problems.append("no retention policy")
        if not (e.records.get("immutability") or {}).get("configured"):
            problems.append("no tamper-evident storage")
        if problems:
            return NOT_MET, " and ".join(problems)
        return MET, "retention and immutable storage configured"
    return None


def documentation(rid: str, e: Evidence) -> Verdict | None:
    """DOC-*: checked against the generated document, never against the code."""
    if rid in ("DOC-JOURNAL", "DOC-METHODOLOGY", "DOC-UPDATE-ON-CHANGE"):
        return NEEDS_HUMAN, "verified against the generated document, not against the code"
    return None


# Each check answers the rules of its area and returns None for the others.
AREA_CHECKS = (architecture, evaluation, monitoring, monitoring_coverage, human_oversight,
               record_keeping, documentation)


def verdict_for(rule: dict, a: dict) -> Verdict:
    """Return (status, why). `why` is what a reader needs to act, in one line."""
    evidence = Evidence.of(a)
    for check in AREA_CHECKS:
        verdict = check(rule["id"], evidence)
        if verdict:
            return verdict
    return NEEDS_HUMAN, "no automated check defined for this rule"


def evaluate(artefacts: dict) -> dict:
    """One verdict per rule, with the totals per status and per area."""
    rules = artefacts["rules"]["rules"]
    verdicts = []
    for rule in rules:
        status, why = verdict_for(rule, artefacts)
        verdicts.append({
            "rule": rule["id"],
            "area": rule.get("area", "other"),
            "severity": rule.get("severity", "advisory"),
            "status": status,
            "why": why,
            "requirement": rule["requirement"][:220],
            "source": rule.get("source", ""),
        })

    by_area: dict[str, dict] = {}
    for verdict in verdicts:
        bucket = by_area.setdefault(verdict["area"], {MET: 0, NOT_MET: 0,
                                                      NEEDS_HUMAN: 0, NOT_APPLICABLE: 0})
        bucket[verdict["status"]] += 1

    checked = [v for v in verdicts if v["status"] in (MET, NOT_MET)]
    met = [v for v in checked if v["status"] == MET]
    return {
        "verdicts": verdicts,
        "by_area": by_area,
        "totals": {
            "rules": len(verdicts),
            "verifiable": len(checked),
            "met": len(met),
            "not_met": len(checked) - len(met),
            "needs_human": sum(1 for v in verdicts if v["status"] == NEEDS_HUMAN),
            "not_applicable": sum(1 for v in verdicts if v["status"] == NOT_APPLICABLE),
            "score_pct": round(len(met) * 100 / len(checked)) if checked else None,
        },
    }


def build(project: Path, inference_frequency: str | None) -> dict:
    """Run every analysis on the project and rule on the 36 requirements."""
    artefacts = collect(project, inference_frequency)
    assessment = evaluate(artefacts)
    ctx = artefacts.get("context") or {}
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "project": {
            "path": str(project.resolve()),
            "name": (ctx.get("project") or {}).get("name", project.name),
            "classification": ctx.get("classification", {}),
        },
        "inference_frequency": inference_frequency,
        "assessment": assessment,
        "artefact_errors": artefacts["errors"],
        "artefacts": {
            "oversight": artefacts.get("oversight"),
            "records": artefacts.get("records"),
            "resilience": artefacts.get("resilience"),
            "genai_monitoring": artefacts.get("genai_monitoring"),
            "operational_monitoring": artefacts.get("operational_monitoring"),
        },
    }


def render(audit: dict) -> str:
    """A terminal summary: score, verdict counts and what is not met."""
    totals = audit["assessment"]["totals"]
    classification = audit["project"]["classification"] or {}
    level = f" / {classification.get('agentic_level')}" if classification.get("agentic_level") else ""

    lines = [
        f"AIDA audit - {audit['project']['name']}",
        f"Classification : {classification.get('family', 'unknown')}{level}"
        f"  (certainty: {classification.get('certainty', 'low')})",
        "",
        f"Requirements   : {totals['rules']}",
        f"  verifiable from the code : {totals['verifiable']}"
        f"   -> {totals['met']} met, {totals['not_met']} not met",
        f"  only the risk owner can answer : {totals['needs_human']}",
        f"  not applicable : {totals['not_applicable']}",
    ]
    if totals["score_pct"] is not None:
        lines.append(f"  score on what is verifiable : {totals['score_pct']}%")

    lines.append("")
    lines.append(f"{'AREA':<28} {'MET':<5} {'NOT MET':<9} {'HUMAN':<7} N/A")
    for area, counts in sorted(audit["assessment"]["by_area"].items()):
        label = AREA_LABELS.get(area, area)
        lines.append(f"{label[:27]:<28} {counts[MET]:<5} {counts[NOT_MET]:<9} "
                     f"{counts[NEEDS_HUMAN]:<7} {counts[NOT_APPLICABLE]}")

    failing = [v for v in audit["assessment"]["verdicts"] if v["status"] == NOT_MET]
    if failing:
        lines.append(f"\nNOT MET ({len(failing)})")
        for verdict in failing:
            lines.append(f"  [{verdict['rule']}] {verdict['why']}")

    if audit["artefact_errors"]:
        lines.append("\nANALYSES THAT DID NOT RUN")
        for name, error in audit["artefact_errors"].items():
            lines.append(f"  {name}: {error}")
        lines.append("  Their rules are counted as needing a human, not as met.")

    return "\n".join(lines)


def main() -> int:
    """Command line: audit a project; exit 1 when a verifiable requirement is not met."""
    parser = argparse.ArgumentParser(description="Run the full AIDA audit of a project.")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--inference-frequency",
                        choices=["daily", "weekly", "monthly", "quarterly"])
    parser.add_argument("--out", default="aida/audit.json")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    project = Path(args.project).expanduser().resolve()
    if not project.is_dir():
        print(f"error: not a directory: {project}", file=sys.stderr)
        return 2

    audit = build(project, args.inference_frequency)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(audit, indent=2, ensure_ascii=False) if args.json else render(audit))
    print(f"\naudit written to {out}")
    return 1 if audit["assessment"]["totals"]["not_met"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
