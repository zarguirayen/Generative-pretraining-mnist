---
name: aida-audit
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
  - aida-human-oversight
  - aida-record-keeping
  - aida-genai-monitoring
  - aida-operational-monitoring
status: ready
compatibility: Requires Python 3.10+ and git
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*)
description: >-
  Runs every AIDA analysis on a project in one pass and rules on each of the 36
  guideline requirements, producing a scorecard by area and a report a risk challenger
  can read. Separates what the code proves from what only the risk owner can answer,
  and scores only the former. Use it when asked how compliant a project is, for an AIDA
  readiness check or gap analysis, to know what is missing before a validation review,
  to get one consolidated compliance report, or to fail a CI pipeline on a compliance
  regression.
tags:
  - aida
  - audit
  - compliance
  - gap-analysis
  - scorecard
  - eu-ai-act
  - governance
---

# aida-audit

One command, one verdict per requirement, one report. It orchestrates the other skills; it
never re-implements their checks.

---

## Absolute rules

- **Never score what the code cannot answer.** A requirement that depends on people,
  process or another internal system is reported as needing the risk owner, and stays out
  of the percentage.
- **Never let a failed analysis look like a pass.** If a check could not run, its
  requirements are reported as unanswered and the failure is named.
- **Never soften a finding to improve the score.** The score is a consequence, not a goal.
- **Never re-derive a verdict here.** Each skill owns its check; a second opinion in this
  skill would eventually contradict the first.
- **A score is not compliance.** This report is input to the AIDA process, not a
  substitute for it.

---

## Purpose

The five AIDA deliverables share one evidence base, so they can be assessed together. This
skill runs all of them, then rules on each requirement in
[`aida_rules.json`](../aida-core/references/aida_rules.json) with one of four verdicts:

| Verdict | Meaning |
|---|---|
| `met` | the evidence shows the requirement is satisfied |
| `not_met` | the evidence shows it is not |
| `needs_human` | code cannot answer it — only the risk owner can |
| `n/a` | the rule does not apply to this system |

That third verdict is the honest part. Roughly a third of the requirements are
organisational — whether records are truly kept in production, whether overseers were
trained, what the intended purpose is. They are counted separately and never folded into
the score.

### When not to use

- You need the Word deliverable itself - use `aida-technical-documentation`; the audit is
  the gap report, not the document.
- You need one section in depth - run that section's skill; the audit summarises.
- You need the gaps closed - the audit rules and reports; the section skills generate the
  missing controls, records and monitors.
- The project has no code yet - there is nothing to audit statically; audit the first
  working version.

### Prerequisites

- Python 3.10+ and git. Standard library only.
- The five skills it orchestrates, from the same plugin (`depends_on`), each at
  `../<skill>/` from this folder. `run_audit.py` imports exactly these:

| Skill | What `run_audit.py` uses | For |
|---|---|---|
| `aida-core` | `scan_codebase.build_context`, `references/aida_rules.json` | the evidence base and the 36 requirements |
| `aida-human-oversight` | `audit_oversight.audit` | tools, approval gates, the six capabilities |
| `aida-record-keeping` | `audit_records.audit` | the nine mandatory records, fields, retention |
| `aida-genai-monitoring` | `plan_monitoring.build_plan` | quality metrics, baseline, thresholds |
| `aida-operational-monitoring` | `plan_operational.build_plan`, `check_resilience.check` | Table 5 metrics, timeouts on outbound calls |

- An analysis that fails is reported as failed, and its requirements are never counted
  as met.

---

## Workflow

Copy this checklist and tick items off as you go:

```
AIDA audit:
- [ ] Phase 1: ask the inference frequency
- [ ] Phase 2: run the audit
- [ ] Phase 3: render the report
- [ ] Phase 4: brief the user
```

### Phase 1 — Ask the inference frequency

One question, because the monitoring schedule depends on it and the code cannot say:

> How often is the system called in production — daily, weekly, monthly or quarterly?

### Phase 2 — Run the audit

```bash
python scripts/run_audit.py . --inference-frequency daily --out aida/audit.json
```

Runs the scan, the oversight audit, the record audit, both monitoring plans and the
resilience check, then rules on all 36 requirements. Exits 1 when anything is `not_met`,
so a CI job can fail on a compliance regression.

### Phase 3 — Render the report

```bash
python scripts/render_report.py --audit aida/audit.json --out aida/audit_report.md
```

Leads with what is not met, then the questions for the risk owner in one block, then the
evidence — tools, records, dependencies, thresholds.

### Phase 4 — Brief the user

Three numbers, then the two worst areas, then the ask. Not the full table:

```
36 requirements. 18 verifiable from the code: 7 met, 11 not met.
10 need the risk owner. 8 do not apply.

Worst: record keeping (5 not met) and human oversight (3 not met) -
3 irreversible tools run with no approval gate, and nothing is recorded
in a form an auditor could verify.

I need three things from you: the VRM risk category, the intended purpose,
and the named human overseers.
```

Never present the percentage as a compliance level. It is the share of *verifiable*
requirements that are met, and it says nothing about the rest.

---

## Using it in CI

```bash
python scripts/run_audit.py . --inference-frequency daily || exit 1
```

The value is the regression: a merge that adds an ungated irreversible tool, removes a
record, or loosens a threshold turns a green area red on the next run. Compliance drift is
otherwise invisible until a review.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/run_audit.py`](scripts/run_audit.py) | Runs every analysis and rules on the 36 requirements |
| [`scripts/render_report.py`](scripts/render_report.py) | Renders the audit as a report for a human reader |
| [`references/scoring.md`](references/scoring.md) | How each verdict is decided, and what is deliberately not scored |

The skills it orchestrates are listed under [Prerequisites](#prerequisites). Their checks
are the source of truth; this skill only collects and rules.

---

## Quality checklist

- [ ] The classification was confirmed before the audit was presented
- [ ] Every `not_met` finding names its rule id and what to do
- [ ] `needs_human` requirements are listed as questions, in one block
- [ ] The score is presented as covering verifiable requirements only
- [ ] Any analysis that failed is named, and its rules are not counted as met
- [ ] The report was written and its path given to the user
