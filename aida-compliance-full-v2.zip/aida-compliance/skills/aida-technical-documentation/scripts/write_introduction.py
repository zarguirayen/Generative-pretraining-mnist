#!/usr/bin/env python3
"""Write the introduction of the AIDA technical documentation, last, from what is known.

    python write_introduction.py --values aida/values.json --map aida/placeholders.json

The template asks the introduction for an overview of the intended purpose, the model
conception, the predictive performance, the continuous monitoring, the limitations to
address in future versions, and the internal validation process. Every one of those except
the purpose is established by the analyses that ran before, so the introduction is
assembled from them - it is a summary of the document, written once the document exists.

The intended purpose stays an open point inside it. A summary that stated one would be the
single most visible invention in the whole document.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
# section_values lives in aida-core (depends_on); found from this file, not from the cwd
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

INTRODUCTION = ("Provide an overview about the AI systems’ intended purpose, model conception, "
                "predictive performance, continuous monitoring implementation, and limitations "
                "to be addressed in future versions. Provide an overview about the internal "
                "validation process of the system when available")

FAMILY = {"rag": "a retrieval-augmented generation (RAG) system",
          "prompt": "a prompt-based GenAI system",
          "agentic": "an agentic AI system",
          "hybrid": "a hybrid system - retrieval inside an agentic system",
          "unknown": "a system whose AI family could not be established from the code"}


def load(path: Path) -> dict | None:
    """A JSON file, or None when it does not exist."""
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def conception(ctx: dict) -> tuple[str, list[str]]:
    """Model conception: family, autonomy, models, framework."""
    cls = ctx.get("classification") or {}
    text = f"Model conception: {FAMILY.get(cls.get('family'), FAMILY['unknown'])}"
    if cls.get("agentic_level"):
        text += f", autonomy level {cls['agentic_level']}"
    text += f" (classification certainty: {cls.get('certainty', 'low')})."
    models = list(ctx.get("models") or {})
    if models:
        text += f" It relies on {', '.join(models[:3])}, used as-is without fine-tuning"
        if cls.get("reference_framework"):
            text += f", orchestrated with {cls['reference_framework']}"
        text += "."
    elif cls.get("family") not in (None, "unknown"):
        text += " The model identifier is not fixed in the code (configured at run time)."
    return text, (cls.get("family_evidence") or [])[:2]


def performance(plan: dict | None) -> str:
    """Predictive performance as measured by the build-phase evaluation."""
    if not plan:
        return ("Predictive performance: not assessed here - run the monitoring plan to "
                "read the build-phase evaluation.")
    measured = [m for m in plan.get("metrics", []) if m.get("baseline") is not None]
    if not measured:
        return ("Predictive performance: no build-phase evaluation was found in the project; "
                "it must be established before the end of the build phase, and it is the "
                "baseline every monitoring threshold depends on.")
    scores = ", ".join(f"{m['metric']} {m['baseline']}" for m in measured[:5])
    return (f"Predictive performance, as measured by the build-phase evaluation "
            f"({plan.get('baseline_source')}): {scores}.")


def monitoring(plan: dict | None, operational: dict | None) -> str:
    """Model and operational monitoring as planned."""
    parts = []
    if plan:
        schedule = (plan.get("schedule") or {}).get("monitoring_frequency")
        parts.append(f"model quality is monitored {schedule or 'at a frequency still to be set'} "
                     f"with an alert on a {plan.get('relative_drop_pct', 0):g}% relative drop "
                     f"({plan.get('threshold_rule')})")
    if operational:
        computable = [m["metric"] for m in operational.get("metrics", [])
                      if m.get("computable_today")]
        parts.append("operational monitoring covers "
                     + (", ".join(computable[:4]) if computable
                        else "no metric that the records kept today can feed"))
    if not parts:
        return "Continuous monitoring: to be defined."
    return "Continuous monitoring: " + "; ".join(parts) + "."


def limitations(oversight: dict | None, records: dict | None, resilience: dict | None,
                plan: dict | None) -> str:
    """The gaps the audits found, to address in future versions."""
    gaps = []
    if oversight:
        counts = oversight.get("counts", {})
        if counts.get("ungated"):
            gaps.append(f"{counts['ungated']} irreversible tool(s) run with no human approval "
                        f"gate")
        if not (oversight.get("controls") or {}).get("stop_control") and oversight.get("tools"):
            gaps.append("no stop control")
    if records:
        counts = records.get("counts", {})
        missing = counts.get("records_mandatory", 0) - counts.get("records_present", 0)
        if missing:
            gaps.append(f"{missing} of {counts.get('records_mandatory')} mandatory records "
                        f"have no mechanism")
        if not (records.get("format") or {}).get("structured"):
            gaps.append("logging is not structured")
    if resilience:
        unbounded = [c for c in resilience.get("calls", []) if not c.get("timeout")]
        if unbounded:
            gaps.append(f"{len(unbounded)} outbound call(s) have no timeout")
    if plan and not plan.get("baseline_source"):
        gaps.append("no evaluation baseline")
    if not gaps:
        return ("Limitations to address in future versions: none established from the code; "
                "see the open points at the end of this document.")
    return ("Limitations to address in future versions, established from the code: "
            + "; ".join(gaps) + ". Each is detailed in its section.")


def build(ctx: dict, audits: dict) -> dict[str, dict]:
    """The introduction, assembled from the context and the section audits."""
    project = ctx.get("project", {}).get("name", "the system")
    git = ctx.get("git") or {}
    version = git.get("tag") or ((git.get("commit") or "")[:12] and f"commit {git['commit'][:12]}")

    conception_text, evidence = conception(ctx)
    sentences = [
        f"This document describes {project}" + (f" ({version})" if version else "") + ".",
        "Intended purpose: [A CONFIRMER - to be stated by the risk owner; it is not derivable "
        "from the code and is never inferred].",
        conception_text,
        performance(audits.get("monitoring")),
        monitoring(audits.get("monitoring"), audits.get("operational")),
        limitations(audits.get("oversight"), audits.get("records"), audits.get("resilience"),
                    audits.get("monitoring")),
        "Internal validation: not yet performed. This document is an input to the AIDA "
        "validation process; its completion status and every open point are listed at the "
        "end of the document.",
    ]
    return {INTRODUCTION: entry(" ".join(sentences), source="rule", evidence=evidence)}


def main() -> int:
    """Command line: merge the introduction into aida/values.json, last."""
    parser = argparse.ArgumentParser(description="Write the introduction, last.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json")
    parser.add_argument("--aida", default="aida", help="folder holding the other analyses")
    args = parser.parse_args()

    ctx = load(Path(args.context))
    if ctx is None:
        print(f"error: context not found: {args.context}\n"
              f"       run the aida-core skill first", file=sys.stderr)
        return 2

    folder = Path(args.aida)
    audits = {
        "monitoring": load(folder / "monitoring_plan.json"),
        "operational": load(folder / "operational_plan.json"),
        "oversight": load(folder / "oversight_audit.json"),
        "records": load(folder / "records_audit.json"),
        "resilience": load(folder / "resilience.json"),
    }
    used = [name for name, value in audits.items() if value]
    result = merge(Path(args.values), build(ctx, audits), Path(args.routing))
    print(report(result, "1 Introduction", Path(args.values)))
    print(f"  assembled from: context{', ' + ', '.join(used) if used else ''}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
