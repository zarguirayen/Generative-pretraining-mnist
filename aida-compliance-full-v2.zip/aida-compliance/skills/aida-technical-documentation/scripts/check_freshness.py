#!/usr/bin/env python3
"""Tell whether the generated documentation still matches the code.

    python check_freshness.py record --values aida/values.json --project .
    python check_freshness.py check  --values aida/values.json --project .

Compliance documentation does not fail by being wrong on the day it is written. It fails
by staying on the shelf while the code moves underneath it, until the two describe
different systems and nobody noticed. The AIDA template asks for the documentation to be
updated on any substantial change (`DOC-UPDATE-ON-CHANGE`); this makes that check
mechanical.

`record` stores, for every answer, a hash of each source file it cites. `check` recomputes
those hashes and reports the fields whose evidence has moved. Exit code 1 when anything is
stale, so a CI job can fail on documentation drift.

Standard library only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

EVIDENCE_REF = re.compile(r"^(?P<path>.+?):(?P<line>\d+)$")
OUTSIDE = "outside the project - not read"


def inside(project: Path, relative: str) -> Path | None:
    """The cited file under the project, or None when the citation leaves the project.

    Citations come from aida/values.json, which people edit: an absolute path or a `..`
    must never make this script read a file outside the project it documents.
    """
    root = project.resolve()
    path = (root / relative).resolve()
    return path if path.is_relative_to(root) else None


def file_digest(path: Path) -> str | None:
    """The first 16 hex digits of a file's SHA-256, or None when unreadable."""
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()[:16]
    except OSError:
        return None


def cited_files(values: dict) -> dict[str, list[str]]:
    """placeholder -> the distinct source files its evidence points at."""
    out: dict[str, list[str]] = {}
    for placeholder, entry in values.items():
        if not isinstance(entry, dict):
            continue
        files: list[str] = []
        for item in entry.get("evidence") or []:
            match = EVIDENCE_REF.match(item.strip())
            if match and match.group("path") not in files:
                files.append(match.group("path"))
        if files:
            out[placeholder] = files
    return out


def snapshot(values: dict, project: Path) -> dict:
    """For every answer, the digest of each file it cites."""
    fields: dict[str, dict] = {}
    for placeholder, files in cited_files(values).items():
        digests = {}
        for relative in files:
            path = inside(project, relative)
            digests[relative] = file_digest(path) if path else OUTSIDE
        fields[placeholder] = {
            "files": digests,
            "value_digest": hashlib.sha256(
                json.dumps(values[placeholder], sort_keys=True).encode("utf-8")
            ).hexdigest()[:16],
        }
    return {
        "recorded_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "project": str(project.resolve()),
        "fields": fields,
    }


def compare(previous: dict, current: dict) -> dict:
    """Classify every recorded field against the current state of the project."""
    stale: list[dict] = []
    vanished: list[dict] = []
    added: list[str] = []

    for placeholder, before in previous.get("fields", {}).items():
        now = current["fields"].get(placeholder)
        if now is None:
            vanished.append({"placeholder": placeholder,
                             "detail": "no longer produced - the evidence behind it is gone"})
            continue
        for relative, digest in before["files"].items():
            new_digest = now["files"].get(relative)
            if new_digest is None:
                stale.append({"placeholder": placeholder, "file": relative,
                              "detail": "the cited file no longer backs this field"})
            elif new_digest != digest:
                stale.append({"placeholder": placeholder, "file": relative,
                              "detail": "the cited file changed since the document was written"})

    for placeholder in current["fields"]:
        if placeholder not in previous.get("fields", {}):
            added.append(placeholder)

    return {"stale": stale, "vanished": vanished, "added": added}


def render(result: dict, previous: dict) -> str:
    """What moved since the documentation was recorded."""
    stale, vanished, added = result["stale"], result["vanished"], result["added"]
    lines = [f"Documentation recorded on {previous.get('recorded_at', 'unknown date')}", ""]

    if not (stale or vanished or added):
        lines.append("Up to date - every cited file is unchanged.")
        return "\n".join(lines)

    if stale:
        by_field: dict[str, list[str]] = {}
        for item in stale:
            by_field.setdefault(item["placeholder"], []).append(item["file"])
        lines.append(f"STALE ({len(by_field)} field(s)) - regenerate these:")
        for placeholder, files in by_field.items():
            lines.append(f"  {placeholder[:70]}")
            lines.append(f"      evidence changed: {', '.join(sorted(set(files)))}")
    if vanished:
        lines.append(f"\nNO LONGER SUPPORTED ({len(vanished)}):")
        for item in vanished:
            lines.append(f"  {item['placeholder'][:70]}\n      {item['detail']}")
    if added:
        lines.append(f"\nNEW EVIDENCE AVAILABLE ({len(added)}) - fields the scan can now answer:")
        for placeholder in added[:10]:
            lines.append(f"  {placeholder[:70]}")
    return "\n".join(lines)


def load_values(path: Path) -> dict:
    """placeholder -> answer, from aida/values.json."""
    values = json.loads(path.read_text(encoding="utf-8"))
    return values.get("values", values) if isinstance(values, dict) else {}


def main() -> int:
    """Command line: record the state, or check it; exit 1 on drift."""
    parser = argparse.ArgumentParser(description="Detect documentation drift against the code.")
    parser.add_argument("action", choices=["record", "check"])
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--project", default=".")
    parser.add_argument("--state", default="aida/doc_state.json")
    args = parser.parse_args()

    values_path, project, state_path = Path(args.values), Path(args.project), Path(args.state)
    if not values_path.exists():
        print(f"error: values not found: {values_path}", file=sys.stderr)
        return 2

    current = snapshot(load_values(values_path), project)
    outside = sorted({cited for field in current["fields"].values()
                      for cited, digest in field["files"].items() if digest == OUTSIDE})
    if outside:
        print(f"not read, outside the project: {', '.join(outside)}", file=sys.stderr)

    if args.action == "record":
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state_path.write_text(json.dumps(current, indent=2, ensure_ascii=False) + "\n",
                              encoding="utf-8")
        print(f"Recorded {len(current['fields'])} field(s) and their source files.")
        print(f"state written to {state_path}")
        return 0

    if not state_path.exists():
        print(f"error: no recorded state at {state_path}\n"
              f"       run `check_freshness.py record` when the document is generated",
              file=sys.stderr)
        return 2

    previous = json.loads(state_path.read_text(encoding="utf-8"))
    result = compare(previous, current)
    print(render(result, previous))

    if result["stale"] or result["vanished"]:
        print("\nThe documentation no longer matches the code. Regenerate the affected "
              "sections and record the new state (DOC-UPDATE-ON-CHANGE).")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
