# Example output — see the result without running anything

`ticket_agent/` is what the plugin produces on a small LangGraph ticket agent (the
`tests/fixtures/agentic_assistant` project), released twice (`v1.0.0`, `v1.1.0`) and
evaluated twice (21 cases, two dated runs):

| File | What to look at |
|---|---|
| [`technical_documentation.docx`](ticket_agent/technical_documentation.docx) | The official AIDA template, filled: 50 of 106 fields answered from evidence, each with its `path:line` or rule id; §1 assembled last; §3.3 dataset profile and dated logs with SHA-256 digests; §3.4 chart; §3.5 diagram; the §5 validation table; the AI System Journal from the git history; 81 numbered open points listed by owner at the end |
| [`architecture.mmd`](ticket_agent/architecture.mmd) | §3.5 — the two irreversible tools without an approval gate are drawn in red |
| [`performance_chart.svg`](ticket_agent/performance_chart.svg) | §3.4 — the latest evaluation (2026-09-15) against the 10 % alert threshold of `MON-THRESHOLD-AGENTIC` |

The gaps the document reports — no approval gate on `purge_workspace`, no stop control, no
mandatory record kept — are the fixture's real gaps, left in on purpose.

Rebuild this example and regenerate its document in one command — `project/` holds its
evaluation cases and runs, added to `tests/fixtures/agentic_assistant`:

```bash
python run_all.py --demo
```

Or generate the document of any project:

```bash
python run_all.py /path/to/project --inference-frequency daily
```
