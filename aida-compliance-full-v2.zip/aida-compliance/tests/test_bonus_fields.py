"""The bonus bullets of sections 2.3, 3.1, 3.2 and 4, each answered explicitly.

A reviewer found them implicit once: the runtime behind "compatible operating systems",
the effect of an update on performance, the limitations of the data, the post-processing
of the predictions, and the re-evaluation of the risk category after a substantial change.

    python -m pytest tests/test_bonus_fields.py -v
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-core" / "scripts"))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"))

from build_values import (DEFAULT_RULES, r_continuous_compliance,  # noqa: E402
                          r_data_limitations, r_dependencies, r_post_processing,
                          r_update_effects)
from placeholder_map import DEFAULT_TEMPLATE, extract  # noqa: E402
from scan_codebase import build_context  # noqa: E402

RULES = json.loads(DEFAULT_RULES.read_text(encoding="utf-8"))
MODEL = 'MODEL = "anthropic.claude-haiku-4-5-20251001-v1:0"\n'


def scan(root: Path, family: str = "agentic") -> dict:
    """The context of a small project, its family set as the owner would confirm it."""
    ctx = build_context(root)
    ctx["classification"]["family"] = family
    return ctx


def test_the_runtime_names_python_and_the_image_that_fixes_the_os(tmp_path):
    (tmp_path / "app.py").write_text(MODEL, encoding="utf-8")
    (tmp_path / "requirements.txt").write_text("langchain==0.3.7\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text('[project]\nrequires-python = ">=3.10"\n',
                                             encoding="utf-8")
    (tmp_path / "Dockerfile").write_text("FROM python:3.12 AS build\nFROM python:3.12-slim\n",
                                         encoding="utf-8")
    value, evidence = r_dependencies(scan(tmp_path), RULES)
    assert "Python >=3.10" in value and "python:3.12-slim" in value and "operating system" in value
    assert "pyproject.toml:2" in evidence and "Dockerfile:2" in evidence


def test_no_declared_runtime_is_stated_rather_than_left_silent(tmp_path):
    (tmp_path / "requirements.txt").write_text("langchain==0.3.7\n", encoding="utf-8")
    value, _ = r_dependencies(scan(tmp_path), RULES)
    assert "No operating system or Python version is imposed" in value


def test_every_update_is_re_evaluated_against_the_family_threshold(tmp_path):
    (tmp_path / "requirements.txt").write_text("langchain==0.3.7\nboto3>=1.34\n", encoding="utf-8")
    value, _ = r_update_effects(scan(tmp_path, "agentic"), RULES)
    for expected in ("MON-THRESHOLD-AGENTIC", "MON-DRIFT-TOOLSET", "DOC-UPDATE-ON-CHANGE",
                     "1 of 2 declared dependencies are pinned"):
        assert expected in value


def test_post_processing_is_cited_where_the_code_parses_the_output(tmp_path):
    (tmp_path / "app.py").write_text(MODEL + "parser = PydanticOutputParser(pydantic_object=Answer)\n",
                                     encoding="utf-8")
    value, evidence = r_post_processing(scan(tmp_path), RULES)
    assert "parsed and validated" in value and evidence == ["app.py:2"]


def test_no_post_processing_found_leaves_the_field_open(tmp_path):
    (tmp_path / "app.py").write_text(MODEL, encoding="utf-8")
    assert r_post_processing(scan(tmp_path), RULES) is None


def test_data_limitations_come_from_the_profile_and_leave_their_handling_open(tmp_path):
    (tmp_path / "eval").mkdir()
    cases = [{"question": "q1", "expected": "a", "category": "simple"},
             {"question": "q1", "expected": "a", "category": "simple"},
             {"question": "q2", "category": "simple"},
             {"question": "q3", "expected": "c", "category": "edge"}]
    (tmp_path / "eval" / "cases.jsonl").write_text(
        "".join(json.dumps(c) + "\n" for c in cases), encoding="utf-8")
    value, evidence = r_data_limitations(scan(tmp_path, "agentic"), RULES)
    for expected in ("below the 20 queries of EVAL-AGENTIC-QUERIES", "without a reference answer",
                     "unbalanced categories", "1 duplicate question", "[A CONFIRMER"):
        assert expected in value
    assert evidence == ["eval/cases.jsonl:1"]


def test_a_substantial_change_sends_the_risk_category_back_to_the_owner():
    value, _ = r_continuous_compliance({}, RULES)
    assert "Change of usage procedure" in value and "AI Act risk category" in value


def test_the_bonus_fields_are_routed_to_their_answers():
    routes = {p["placeholder"]: p["source"] for p in extract(DEFAULT_TEMPLATE)}
    route = {start: next(v for k, v in routes.items() if k.startswith(start))
             for start in ("Describe how updates may affect", "Describe main limitations of the used",
                           "Complete the Change of usage")}
    assert route["Describe how updates may affect"] == "rule"
    assert route["Describe main limitations of the used"] == "code"
    assert route["Complete the Change of usage"] == "external"
