"""The aggregate audit, and the honesty of its arithmetic.

A scorecard is the easiest artefact in this plugin to make dishonest, in three ways: score
what cannot be verified, let a crashed analysis look like a clean one, or report an absence
of evidence as evidence of compliance. Each has a test here.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
AUDIT = PLUGIN_ROOT / "skills" / "aida-audit" / "scripts"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(AUDIT))

from render_report import render  # noqa: E402
from run_audit import (MET, NEEDS_HUMAN, NOT_APPLICABLE, NOT_MET,  # noqa: E402
                       RULES_PATH, build, evaluate)


@pytest.fixture(scope="session")
def agentic():
    return build(FIXTURES / "agentic_assistant", "daily")


@pytest.fixture(scope="session")
def plain():
    return build(FIXTURES / "plain_billing", "daily")


def verdict(audit: dict, rule_id: str) -> dict:
    return next(v for v in audit["assessment"]["verdicts"] if v["rule"] == rule_id)


# ------------------------------------------------------------------- completeness --
def test_each_rule_has_at_most_one_area_check():
    """One owner per rule: two checks answering the same rule would one day disagree."""
    from run_audit import AREA_CHECKS, Evidence
    rules = json.loads(RULES_PATH.read_text(encoding="utf-8"))["rules"]
    evidence = Evidence.of({})
    for rule in rules:
        owners = [check.__name__ for check in AREA_CHECKS if check(rule["id"], evidence)]
        assert len(owners) <= 1, f"{rule['id']} is answered by {owners}"


def test_every_rule_gets_exactly_one_verdict(agentic):
    rules = json.loads(RULES_PATH.read_text(encoding="utf-8"))["rules"]
    verdicts = agentic["assessment"]["verdicts"]
    assert len(verdicts) == len(rules)
    assert {v["rule"] for v in verdicts} == {r["id"] for r in rules}


def test_verdicts_come_from_the_closed_set(agentic):
    assert {v["status"] for v in agentic["assessment"]["verdicts"]} <= {
        MET, NOT_MET, NEEDS_HUMAN, NOT_APPLICABLE}


def test_every_verdict_explains_itself(agentic):
    for item in agentic["assessment"]["verdicts"]:
        assert item["why"], f"{item['rule']} has no reason attached"


# ------------------------------------------------------------------ honest scoring --
def test_score_denominator_excludes_what_cannot_be_verified(agentic):
    totals = agentic["assessment"]["totals"]
    assert totals["verifiable"] == totals["met"] + totals["not_met"]
    assert totals["verifiable"] + totals["needs_human"] + totals["not_applicable"] == \
           totals["rules"]
    assert totals["score_pct"] == round(totals["met"] * 100 / totals["verifiable"])


def test_organisational_requirements_are_never_scored(agentic):
    """Intended purpose, risk category and training belong to the risk owner."""
    for rule_id in ("OVERSIGHT-SCOPE", "REC-SCOPE", "MON-TIMING",
                    "DOC-JOURNAL", "DOC-METHODOLOGY", "DOC-UPDATE-ON-CHANGE"):
        assert verdict(agentic, rule_id)["status"] == NEEDS_HUMAN


def test_evaluation_dataset_size_is_not_guessed(agentic):
    assert verdict(agentic, "EVAL-AGENTIC-QUERIES")["status"] == NEEDS_HUMAN


# --------------------------------------------------------------- verdict accuracy --
def test_ungated_irreversible_tools_fail_the_intervention_rule(agentic):
    item = verdict(agentic, "OVERSIGHT-INTERVENTION")
    assert item["status"] == NOT_MET
    assert "approval gate" in item["why"]


def test_missing_mandatory_records_fail_and_name_what_is_missing(agentic):
    item = verdict(agentic, "REC-MODEL-MANDATORY")
    assert item["status"] == NOT_MET
    assert "mechanism" in item["why"]


def test_only_the_families_threshold_rule_is_assessed(agentic):
    assert verdict(agentic, "MON-THRESHOLD-AGENTIC")["status"] in (MET, NOT_MET)
    assert verdict(agentic, "MON-THRESHOLD-RAG")["status"] == NOT_APPLICABLE
    assert verdict(agentic, "MON-THRESHOLD-PROMPT")["status"] == NOT_APPLICABLE


def test_an_l2_system_is_asked_to_justify_its_autonomy(agentic):
    item = verdict(agentic, "BUILD-L1-DEFAULT")
    assert item["status"] == NEEDS_HUMAN
    assert "L2" in item["why"]


def test_monitoring_frequency_is_met_once_derived(agentic):
    item = verdict(agentic, "MON-FREQUENCY")
    assert item["status"] == MET
    assert "weekly" in item["why"]


def test_frequency_is_not_met_when_it_was_never_given():
    audit = build(FIXTURES / "agentic_assistant", None)
    assert verdict(audit, "MON-FREQUENCY")["status"] == NOT_MET


# ----------------------------------------------------- absence is not compliance --
def test_a_non_ai_project_does_not_score_well_by_default(plain):
    """Almost everything is n/a; that must not read as a compliant system."""
    totals = plain["assessment"]["totals"]
    assert totals["not_applicable"] > 0
    assert plain["project"]["classification"]["family"] == "unknown"
    assert verdict(plain, "MON-GENAI-QUALITY-MINIMUM")["status"] == NOT_MET


def test_no_recognised_tool_is_needs_human_not_met(plain):
    item = verdict(plain, "OVERSIGHT-CAPABILITIES")
    assert item["status"] in (NEEDS_HUMAN, NOT_MET)
    assert item["status"] != MET, "absence of evidence must never be recorded as met"


def test_a_failed_analysis_is_reported_and_never_counted_as_met(agentic, monkeypatch):
    broken = dict(agentic)
    broken["assessment"] = evaluate({
        "rules": json.loads(RULES_PATH.read_text(encoding="utf-8")),
        "context": None, "oversight": None, "records": None,
        "resilience": None, "genai_monitoring": None, "operational_monitoring": None,
        "errors": {"oversight": "ImportError: boom"},
    })
    statuses = {v["status"] for v in broken["assessment"]["verdicts"]}
    assert MET not in statuses, "with no artefacts, nothing can be met"


def test_artefact_errors_are_surfaced_in_the_payload(agentic):
    assert "artefact_errors" in agentic
    assert isinstance(agentic["artefact_errors"], dict)


# ---------------------------------------------------------------------- reporting --
def test_report_leads_with_what_is_not_met(agentic):
    report = render(agentic)
    assert report.index("## Not met") < report.index("## Evidence")


def test_report_states_what_the_score_covers(agentic):
    report = render(agentic)
    assert "only the requirements a codebase can answer" in report
    assert "inventing a verdict" in report


def test_report_maps_each_area_to_its_aida_section(agentic):
    report = render(agentic)
    for section in ("3.7 Record Keeping", "3.9 Human Oversight Measures",
                    "3.8 AI System Operational Monitoring"):
        assert section in report


def test_report_lists_the_risk_owner_questions_in_one_block(agentic):
    report = render(agentic)
    assert "## For the risk owner" in report
    assert report.count("## For the risk owner") == 1


def test_report_shows_tools_with_their_gate_and_location(agentic):
    report = render(agentic)
    assert "purge_workspace" in report and "agent.py:" in report


def test_report_disclaims_that_a_score_is_not_compliance(agentic):
    assert "not a substitute for it" in render(agentic)
