"""`run_all.py --demo`: the example project rebuilt, and its document written, in one command.

    python -m pytest tests/test_demo.py -v
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
RUN_ALL = PLUGIN_ROOT / "run_all.py"


def demo(target: Path) -> subprocess.CompletedProcess:
    """Run the demo into `target`."""
    return subprocess.run([sys.executable, str(RUN_ALL), "--demo", str(target)],
                          capture_output=True, text=True, timeout=600)


def test_the_demo_rebuilds_the_example_and_writes_its_document(tmp_path):
    result = demo(tmp_path)
    assert result.returncode == 0, result.stdout[-2000:]
    project = tmp_path / "ticket_agent"
    assert (project / "eval" / "cases.jsonl").exists()
    assert (project / "aida" / "technical_documentation.docx").exists()
    assert (project / "aida" / "performance_chart.svg").exists()
    if shutil.which("git"):
        tags = subprocess.run(["git", "-C", str(project), "tag"],
                              capture_output=True, text=True).stdout.split()
        assert tags == ["v1.0.0", "v1.1.0"]


def test_the_demo_never_deletes_a_folder_it_did_not_create(tmp_path):
    mine = tmp_path / "ticket_agent"
    mine.mkdir()
    (mine / "keep.txt").write_text("not the demo's\n", encoding="utf-8")
    assert demo(tmp_path).returncode != 0
    assert (mine / "keep.txt").exists()
