"""The two halves of section 3.8: model quality, and system health.

The tests that matter here are the ones about numbers. A monitoring section is only worth
something if its thresholds come from somewhere - the guideline for the drop percentage,
a measured evaluation for the baseline - and if the metrics selected can actually be
computed from what the system records.
"""

from __future__ import annotations

import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
GENAI = PLUGIN_ROOT / "skills" / "aida-genai-monitoring" / "scripts"
OPS = PLUGIN_ROOT / "skills" / "aida-operational-monitoring" / "scripts"
CORE = PLUGIN_ROOT / "skills" / "aida-core" / "scripts"
RECORDS = PLUGIN_ROOT / "skills" / "aida-record-keeping" / "scripts"
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
for folder in (CORE, RECORDS, GENAI, OPS):
    sys.path.insert(0, str(folder))

from audit_records import audit as audit_records  # noqa: E402
from check_resilience import check, kind_of  # noqa: E402
from detect_tool_drift import diff, tools_at  # noqa: E402
from plan_monitoring import DEFAULT_RULES, build_plan, find_baseline  # noqa: E402
from plan_operational import build_plan as build_operational  # noqa: E402
from scan_codebase import build_context  # noqa: E402


@pytest.fixture(scope="session")
def rules():
    return json.loads(DEFAULT_RULES.read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def agentic_ctx():
    return build_context(FIXTURES / "agentic_assistant")


@pytest.fixture(scope="session")
def rag_ctx():
    return build_context(FIXTURES / "rag_service")


@pytest.fixture
def with_baseline(tmp_path):
    """A project that has already run an evaluation."""
    project = tmp_path / "evaluated"
    (project / "eval" / "outputs" / "run1").mkdir(parents=True)
    (project / "eval" / "outputs" / "run1" / "summary.json").write_text(json.dumps(
        {"metrics": {"task_completion": 0.86, "stability": 0.90,
                     "tool_correctness": {"score": 0.80}}}), encoding="utf-8")
    return project


# ------------------------------------------------------------- thresholds and baseline --
def test_threshold_percentage_follows_the_family(agentic_ctx, rag_ctx, rules, tmp_path):
    agentic = build_plan(agentic_ctx, rules, tmp_path, "daily")
    assert agentic["relative_drop_pct"] == 10
    assert agentic["threshold_rule"] == "MON-THRESHOLD-AGENTIC"

    rag = build_plan(rag_ctx, rules, tmp_path, "daily")
    assert rag["threshold_rule"] == "MON-THRESHOLD-RAG"


def test_a_prompt_system_gets_twenty_percent(rules, tmp_path):
    ctx = {"classification": {"family": "prompt", "agentic_level": None}}
    assert build_plan(ctx, rules, tmp_path, "daily")["relative_drop_pct"] == 20


def test_threshold_is_derived_from_the_measured_score(agentic_ctx, rules, with_baseline):
    plan = build_plan(agentic_ctx, rules, with_baseline, "daily")
    by_name = {m["metric"]: m for m in plan["metrics"]}
    assert by_name["task_completion"]["baseline"] == 0.86
    assert by_name["task_completion"]["alert_threshold"] == pytest.approx(0.774)
    assert by_name["stability"]["alert_threshold"] == pytest.approx(0.81)


def test_a_nested_score_shape_is_read(with_baseline):
    scores, source = find_baseline(with_baseline)
    assert scores["tool_correctness"] == 0.80
    assert source.endswith("summary.json")


def test_a_metric_without_a_baseline_gets_no_threshold(agentic_ctx, rules, with_baseline):
    plan = build_plan(agentic_ctx, rules, with_baseline, "daily")
    orphan = next(m for m in plan["metrics"] if m["metric"] == "reasoning_quality")
    assert orphan["alert_threshold"] is None
    assert "establish it before the end of the build phase" in orphan["note"]


def test_no_baseline_at_all_is_a_blocking_finding(agentic_ctx, rules, tmp_path):
    plan = build_plan(agentic_ctx, rules, tmp_path, "daily")
    blocking = [f for f in plan["findings"] if f["severity"] == "blocking"]
    assert any("baseline" in f["summary"] for f in blocking)


# ------------------------------------------------------------------------ frequency --
@pytest.mark.parametrize("inference,expected", [
    ("daily", "weekly"), ("weekly", "monthly"),
    ("monthly", "quarterly"), ("quarterly", "yearly"),
])
def test_monitoring_frequency_follows_inference_frequency(agentic_ctx, rules, tmp_path,
                                                          inference, expected):
    plan = build_plan(agentic_ctx, rules, tmp_path, inference)
    assert plan["schedule"]["monitoring_frequency"] == expected


def test_unknown_inference_frequency_is_a_finding(agentic_ctx, rules, tmp_path):
    plan = build_plan(agentic_ctx, rules, tmp_path, None)
    assert any(f["rule"] == "MON-FREQUENCY" for f in plan["findings"])


# ------------------------------------------------------------------- metric selection --
def test_a_rag_system_gets_retrieval_metrics_too(rag_ctx, rules, tmp_path):
    names = {m["metric"] for m in build_plan(rag_ctx, rules, tmp_path, "daily")["metrics"]}
    assert {"faithfulness", "relevancy", "correctness"} <= names
    assert {"recall", "precision", "mrr", "ndcg"} <= names


def test_a_rag_system_gets_no_tool_metrics(rag_ctx, rules, tmp_path):
    names = {m["metric"] for m in build_plan(rag_ctx, rules, tmp_path, "daily")["metrics"]}
    assert "tool_correctness" not in names


def test_drift_plan_is_family_specific(agentic_ctx, rag_ctx, rules, tmp_path):
    agentic = {d["kind"] for d in build_plan(agentic_ctx, rules, tmp_path, "daily")["drift"]}
    assert "tool set drift" in agentic
    rag = {d["kind"] for d in build_plan(rag_ctx, rules, tmp_path, "daily")["drift"]}
    assert "knowledge base drift" in rag and "tool set drift" not in rag


# ------------------------------------------------------------------- tool set drift --
@pytest.fixture
def repo(tmp_path):
    project = tmp_path / "repo"
    project.mkdir()
    (project / "agent.py").write_text(textwrap.dedent('''
        from langchain_core.tools import tool

        @tool
        def lookup(ticket_id: str) -> str:
            """Read a ticket."""
            return ticket_id
    '''), encoding="utf-8")
    for args in (["init", "-q"], ["add", "-A"],
                 ["-c", "user.email=t@t", "-c", "user.name=t", "commit", "-q", "-m", "base"]):
        subprocess.run(["git", "-C", str(project), *args], check=True, capture_output=True)
    return project


def commit(project: Path, message: str) -> None:
    subprocess.run(["git", "-C", str(project), "add", "-A"], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(project), "-c", "user.email=t@t", "-c", "user.name=t",
                    "commit", "-q", "-m", message], check=True, capture_output=True)


def test_an_added_tool_is_a_critical_alert(repo):
    agent = repo / "agent.py"
    agent.write_text(agent.read_text(encoding="utf-8") + textwrap.dedent('''
        @tool
        def wire_transfer(iban: str, amount: float) -> str:
            """Send money."""
            return "sent"
    '''), encoding="utf-8")
    commit(repo, "add tool")

    result = diff(tools_at(repo, "HEAD~1"), tools_at(repo, "HEAD"))
    assert result["added"] == ["wire_transfer"]
    assert any(a["severity"] == "critical" and a["kind"] == "tool added"
               for a in result["alerts"])


def test_a_changed_parameter_is_a_critical_alert(repo):
    agent = repo / "agent.py"
    agent.write_text(agent.read_text(encoding="utf-8").replace(
        "def lookup(ticket_id: str)", "def lookup(ticket_id: str, verbose: bool = False)"),
        encoding="utf-8")
    commit(repo, "add parameter")

    result = diff(tools_at(repo, "HEAD~1"), tools_at(repo, "HEAD"))
    assert any(a["kind"] == "parameters changed" and a["severity"] == "critical"
               for a in result["alerts"])


def test_a_changed_description_is_a_warning_not_critical(repo):
    agent = repo / "agent.py"
    agent.write_text(agent.read_text(encoding="utf-8").replace(
        '"""Read a ticket."""', '"""Read a ticket and its full history."""'), encoding="utf-8")
    commit(repo, "reword")

    alerts = diff(tools_at(repo, "HEAD~1"), tools_at(repo, "HEAD"))["alerts"]
    assert alerts and all(a["severity"] == "warning" for a in alerts)


def test_an_unrelated_change_raises_nothing(repo):
    (repo / "README.md").write_text("docs\n", encoding="utf-8")
    commit(repo, "docs")
    assert diff(tools_at(repo, "HEAD~1"), tools_at(repo, "HEAD"))["alerts"] == []


def test_drift_detection_never_touches_the_working_tree(repo):
    before = (repo / "agent.py").read_text(encoding="utf-8")
    tools_at(repo, "HEAD")
    assert (repo / "agent.py").read_text(encoding="utf-8") == before


# ------------------------------------------------------- operational: computability --
def test_metrics_are_reported_with_the_record_that_feeds_them(agentic_ctx, rules):
    records = audit_records(FIXTURES / "agentic_assistant")
    plan = build_operational(agentic_ctx, rules, records, "daily")
    for metric in plan["metrics"]:
        assert metric["needs_record"], f"{metric['metric']} has no feeding record"
        assert metric["computable_today"] in (True, False)


def test_uncomputable_metrics_produce_a_blocking_finding(agentic_ctx, rules):
    records = audit_records(FIXTURES / "agentic_assistant")
    plan = build_operational(agentic_ctx, rules, records, "daily")
    assert any(f["severity"] == "blocking" and "computed" in f["summary"]
               for f in plan["findings"])


def test_without_a_record_audit_computability_is_unknown_not_assumed(agentic_ctx, rules):
    plan = build_operational(agentic_ctx, rules, None, "daily")
    assert all(m["computable_today"] is None for m in plan["metrics"])
    assert any("computability is unknown" in f["summary"] for f in plan["findings"])


def test_alert_rules_carry_their_condition_and_what_to_do(agentic_ctx, rules):
    plan = build_operational(agentic_ctx, rules, None, "daily")
    assert plan["alert_rules"]
    for alert in plan["alert_rules"]:
        assert alert["condition"] and alert["notify"] and alert["on_trigger"]
        assert "AI System Journal" in alert["on_trigger"]


def test_thresholds_are_the_guideline_numbers(agentic_ctx, rules):
    conditions = {m["metric"]: m["alert"]
                  for m in build_operational(agentic_ctx, rules, None, "daily")["metrics"]}
    assert conditions["average_inference_latency"] == ">= 3 s"
    assert conditions["uptime_pct"] == "< 99% per week"
    assert conditions["error_rate"] == ">= 2% per week"


def test_every_metric_of_the_guideline_table_is_planned_once(agentic_ctx, rules):
    table = next(r for r in rules["rules"] if r["id"] == "MON-OPERATIONAL-MINIMUM")
    planned = [m["metric"] for m in
               build_operational(agentic_ctx, rules, None, "daily")["metrics"]]
    assert planned == [m["name"] for m in table["metrics"]]
    assert len(planned) == 13


def test_the_plan_names_the_system_it_was_written_for(agentic_ctx, rules):
    system = build_operational(agentic_ctx, rules, None, "daily")["system"]
    assert system["family"] == agentic_ctx["classification"]["family"]
    assert system["agentic_level"] == agentic_ctx["classification"]["agentic_level"]


# ---------------------------------------------------------------------- resilience --
def test_a_call_without_a_timeout_is_blocking():
    result = check(FIXTURES / "agentic_assistant")
    assert any(f["severity"] == "blocking" and "timeout" in f["summary"]
               for f in result["findings"])


def test_a_timeout_at_the_call_site_is_recognised():
    result = check(FIXTURES / "rag_service")
    assert result["counts"]["outbound"] >= 0  # the RAG fixture has no outbound HTTP call


def test_environment_lookups_are_not_http_calls():
    """`os.environ.get` ends in `.get` like `requests.get`; matching on the last segment
    reported it as an outbound HTTP call."""
    assert kind_of("os.environ.get") is None
    assert kind_of("config.get") is None
    assert kind_of("requests.get") == "HTTP"
    assert kind_of("self.session.post") == "HTTP"


def test_a_call_inside_a_try_counts_as_having_a_fallback(tmp_path):
    project = tmp_path / "guarded"
    project.mkdir()
    (project / "client.py").write_text(textwrap.dedent('''
        import requests

        def fetch(url):
            try:
                return requests.get(url, timeout=5).text
            except Exception:
                return "unavailable"
    '''), encoding="utf-8")
    call = check(project)["calls"][0]
    assert call["timeout"] and call["fallback"]


def test_the_baseline_is_the_most_recent_evaluation(tmp_path):
    """Found on a project evaluated twice: the older run was taken as the baseline."""
    for run, when, score in (("2026-08-20", "2026-08-20T09:00:00Z", 0.84),
                             ("2026-09-15", "2026-09-15T09:00:00Z", 0.86)):
        folder = tmp_path / "eval" / "outputs" / run
        folder.mkdir(parents=True)
        (folder / "summary.json").write_text(json.dumps(
            {"timestamp": when, "metrics": {"task_completion": score}}), encoding="utf-8")
    scores, source = find_baseline(tmp_path)
    assert scores == {"task_completion": 0.86} and "2026-09-15" in source


def test_latency_degrades_upwards_even_without_a_baseline(agentic_ctx, rules, tmp_path):
    plan = build_plan(agentic_ctx, rules, tmp_path, "daily")
    direction = {m["metric"]: m["direction"] for m in plan["metrics"]}
    assert direction["latency"] == "lower" and direction["total_tokens"] == "lower"
    assert direction["task_completion"] == "higher"
