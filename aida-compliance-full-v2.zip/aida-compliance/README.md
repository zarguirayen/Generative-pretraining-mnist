# aida-compliance

> Produces the AIDA compliance deliverables of an AI project from its codebase, using
> the official CACIB templates.

## Overview

Filling AIDA documentation by hand is slow, and the result goes stale the moment the
code moves. This plugin reads the repository instead: it classifies the system against
the AI Factory taxonomy, inventories what the project actually contains, and writes the
official Word template from that evidence.

The rule it is built around: **every written fact carries the `path:line` that proves
it, and anything the code cannot prove is reported as an open point rather than
invented.** A confident compliance document with nothing behind it is worse than an
incomplete one.

It covers the five AIDA deliverables — which are four sections of one document plus the
document itself — and adds a one-command audit across all of them.

## Skills

| Skill | Prize deliverable | What it does |
|---|---|---|
| `aida-core` | (foundation) | Scans the repo into an evidence base: classification RAG / Prompt / Agentic L1-L2-L3, models, dependencies, endpoints, logging, side effects — plus the 108-field map of the official template and a CycloneDX 1.6 ML-BOM |
| `aida-technical-documentation` | Technical documentation | Derives every answer the code proves and the guidelines fix, profiles the §3.3 evaluation data and dated experiment logs, fills the §5 AIDA validation table, draws the §3.5 architecture diagram (Mermaid) and the §3.4 baseline-vs-threshold chart from evidence, writes the introduction last from the sections, validates, fills the official Word template, and detects when the document drifts from the code |
| `aida-record-keeping` | Record keeping (§3.7) | Audits the nine mandatory records from the calls that write them, then generates a hash-chained journal that records at the architecture level (a decorator, a logging handler), with anchors that expose a truncated tail and a standalone verifier |
| `aida-genai-monitoring` | GenAI monitoring (§3.8a) | Decides the scope with evidence, derives thresholds from the latest measured baseline (20% prompt / 10% RAG and agentic), and generates a runnable monitor: metrics from the records, judges pluggable, explained alerts into the journal, schedule |
| `aida-operational-monitoring` | Operational monitoring (§3.8b) | Ties each Table 5 metric to its record, checks every outbound call for timeout, retry and fallback, and generates a runnable monitor of the 13 metrics with its schedule |
| `aida-human-oversight` | Human oversight (§3.9) | Ranks every model-callable tool by irreversibility, and generates the six intervention mechanisms: approval gate (four-eyes available), stop, quarantine, user flags, escalation with deadlines to named overseers, override - all journaled |
| `aida-audit` | (bonus) | Runs everything in one pass and rules on the 36 guideline requirements — met / not met / needs the risk owner / n-a — with a scorecard and a gap report per AIDA section |

Also shipped: the `aida-reviewer` agent (reads a deliverable the way a risk challenger
would), the `aida-context` prompt, and always-on evidence instructions.

## Usage

### Try it in two minutes

Python 3.10+ is all it needs — standard library only, nothing to install:

```bash
python run_all.py --demo
```

It rebuilds the example project in `./aida-demo/ticket_agent` — a LangGraph ticket agent
with 21 evaluation cases, two dated runs and, when git is installed, two tagged releases —
then runs every skill on it. Open `aida-demo/ticket_agent/aida/technical_documentation.docx`:
the official template filled from evidence, with the §3.3 profile, the §3.4 chart, the
§3.5 diagram, the §5 table, the AI System Journal and the numbered open points.
`aida/audit_report.md` holds the 36-requirement scorecard, `aida/generated/` the record
journal and oversight controls, `aida/monitoring/` the two runnable monitors.
`python -m pytest tests/ -q` runs the test suite.

### In GitHub Copilot, or on your own project

To see the result before installing anything, open
[`examples/ticket_agent/technical_documentation.docx`](examples/ticket_agent/technical_documentation.docx):
the official template filled on a small LangGraph agent, released twice and evaluated
twice ([`examples/README.md`](examples/README.md) says what to look at).

Once the plugin is installed from the hub marketplace, ask Copilot in natural language:

- *"Scan this project for AIDA"* — builds the evidence base
- *"Generate the AIDA technical documentation"* — fills the official template
- *"Can a human supervise this agent?"* — the per-tool oversight audit
- *"How compliant is this project with AIDA?"* — the full audit and scorecard

Or run the scripts directly — standard library only, nothing to install:

```bash
python skills/aida-core/scripts/scan_codebase.py /path/to/project --out aida/context.json
python skills/aida-audit/scripts/run_audit.py /path/to/project --inference-frequency daily
python skills/aida-audit/scripts/render_report.py --audit aida/audit.json
```

The scan never modifies the project it reads. All output goes to `aida/`.

### Failing CI on a compliance regression

`run_audit.py` exits 1 when any verifiable requirement is not met, and
`check_freshness.py` exits 1 when the documentation no longer matches the code:

```yaml
aida-compliance:
  stage: validate
  script:
    - python skills/aida-audit/scripts/run_audit.py . --inference-frequency daily
    - python skills/aida-technical-documentation/scripts/check_freshness.py check --values aida/values.json --project .
```

A merge that adds an ungated irreversible tool, drops a mandatory record or loosens a
threshold turns the pipeline red — compliance drift stops being invisible.

## Conformance

- Hub CI: `scripts/ci/validate_manifests.ps1` passes.
- GitHub Copilot plugin reference: `plugin.json` at the plugin root, kebab-case names,
  description ≤ 1024 chars, semver.
- Agent Skills open standard: all seven skills pass the official `skills-ref` validator
  (strict YAML, string `allowed-tools`, `compatibility` declared), with one deliberate,
  test-pinned deviation — the top-level fields the hub's own skill template mandates.
- 653 tests, including three fixture projects (RAG, agentic L2, and a non-AI service as
  the negative control) and 35 behavioural evaluation scenarios under `tests/evals/`.
- Run end to end on three real projects of the Plugin-Skill-Hub (AgentGrade,
  prompt-optimization, hub-skill-installer); the faults this surfaced are fixed and
  pinned in `tests/test_real_project_lessons.py`.
- Security posture, each property enforced by a test that fails the build:

| Agent Skills risk | What holds | Enforced by |
|---|---|---|
| AST01 malicious behaviour, exfiltration | no network module in any script; reads the project, writes only under `aida/`; the audited source is never modified | `test_no_script_imports_a_network_module`, `test_project_source_is_never_touched`, `test_drift_detection_never_touches_the_working_tree` |
| AST02 supply chain | standard library only; every declared dependency pinned to an exact version | `test_every_declared_dependency_is_pinned_to_an_exact_version` |
| AST03 excessive permissions | `allowed-tools` limited to `python` per skill, `git` only for the skills that read history | `test_allowed_tools_is_scoped_to_named_commands`, `test_git_is_only_granted_to_skills_that_read_git` |
| AST04 metadata integrity | descriptions in third person, state when to use; every referenced resource exists | `test_description_is_written_in_third_person`, `test_referenced_resources_exist` |
| AST05 unsafe execution, deserialisation | no `eval` / `exec` / `compile` / `pickle`, JSON only; no subprocess with a shell | `test_no_script_evaluates_or_unpickles_input`, `test_subprocess_is_never_given_a_shell` |
| Credentials | redacted before the record journal; blocked before the document | `test_credentials_are_redacted_before_they_reach_the_journal`, `test_credentials_never_reach_the_document` |

## What it will not do

- Answer for the risk owner. Intended purpose, AI Act risk category, system owner and
  named human overseers are asked for, never guessed.
- Replace validation. The plugin produces documentation and reports gaps; the AIDA
  governance process still validates the system.
- Assess bias or fairness. The evaluation guideline places those in the risk and
  validation domain, outside its own scope.

## Development

```bash
python -m pytest tests/ -q
```

Manifest validation, from the repository root:

```bash
powershell -ExecutionPolicy Bypass -File scripts/ci/validate_manifests.ps1
```

## Maintainers

ZARGUI Rayen — CACIB / DS Community.
Built for the AI Skills Summer Challenge, against the AI Factory guidelines:
Building Agentic AI Systems, Evaluation of GenAI Systems, Monitoring and Human
Oversight, and Record Keeping.
