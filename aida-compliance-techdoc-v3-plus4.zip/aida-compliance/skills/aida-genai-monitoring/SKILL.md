---
name: aida-genai-monitoring
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: ready
compatibility: Requires Python 3.10+ and git (tool-set drift reads git objects)
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*) shell(git:*)
description: >-
  Builds the production quality-monitoring plan of a GenAI system and writes the AI
  Model Monitoring part of section 3.8 of the AIDA technical documentation. Selects the
  metrics the system's family requires, derives each alert threshold from the score the
  build-phase evaluation actually measured, sets the monitoring frequency from the
  inference frequency, and plans the drift the guideline asks for - including tool set
  drift, which it detects between two git revisions. Use it when asked about model
  monitoring, quality monitoring in production, drift, alert thresholds, hallucination
  or degradation monitoring of a RAG, prompt or agentic system, and when writing the
  model monitoring section of AIDA documentation.
tags:
  - aida
  - monitoring
  - genai
  - drift
  - thresholds
  - rag
  - agentic
  - eu-ai-act
---

# aida-genai-monitoring

Monitoring is the evaluation, continued. This turns the scores a project measured before
release into the thresholds that will alert after it.

---

## Absolute rules

- **A threshold with no baseline is guesswork.** If no evaluation was run, say the
  baseline must be established before the end of the build phase — do not invent a number.
- **The threshold follows the family.** 20% relative drop for a prompt system, 10% for RAG
  and agentic. Never state one without its rule id.
- **Stricter is allowed, looser is not.** And a stricter threshold still needs a
  justification.
- **Monitor the same metrics that were evaluated.** A production score is only
  interpretable against a baseline obtained the same way.
- **A tool added or removed is a critical alert**, not a changelog entry.
- **Never claim drift is monitored because a metric exists.** Drift is a separate
  mechanism with its own data.

---

## Purpose

Section 3.8 of the AIDA template has two distinct halves. This skill owns the first one,
**AI Model Monitoring**: which quality metrics run in production, against which baseline,
with which thresholds, at which frequency, and what drift is watched.

The metric set comes from the system family, which `aida-core` determined:

| Family | Metrics the guideline expects | Alert threshold |
|---|---|---|
| Prompt | faithfulness, relevancy, correctness | 20% relative drop (`MON-THRESHOLD-PROMPT`) |
| RAG | the above, plus recall, precision, contextual relevancy, MRR, NDCG | 10% (`MON-THRESHOLD-RAG`) |
| Agentic | task completion, step efficiency, stability, tool correctness, argument correctness, reasoning quality, latency, tokens | 10% (`MON-THRESHOLD-AGENTIC`) |

Safety signals — toxicity, PII leakage, copyright risk — need no baseline: any occurrence
is a signal.

### When not to use

- Latency, uptime, errors, usage - that is `aida-operational-monitoring`.
- Nothing has been evaluated yet - establish the build-phase baseline first; no threshold can be justified without it.

---

## Workflow

Copy this checklist and tick items off as you go:

```
GenAI monitoring:
- [ ] Phase 1: ask the inference frequency
- [ ] Phase 2: build the plan
- [ ] Phase 3: check tool set drift
- [ ] Phase 4: report
- [ ] Phase 5: write section 3.8, model monitoring
```

### Phase 1 — Ask the inference frequency

One question, because the code cannot answer it and the schedule depends on it:

> How often is the system called in production — daily, weekly, monthly or quarterly?

The mapping is fixed (`MON-FREQUENCY`): daily to weekly monitoring, weekly to monthly,
monthly to quarterly, quarterly to yearly.

### Phase 2 — Build the plan

```bash
python scripts/plan_monitoring.py --context aida/context.json --project . --inference-frequency daily
```

It looks for an evaluation summary the project already produced — the
`evaluation-pipeline` plugin writes one — and derives each threshold from the measured
score. Metrics with no baseline are reported as such, never given a default.

### Phase 3 — Check tool set drift

For an agentic system, between the last documented version and now:

```bash
python scripts/detect_tool_drift.py --from v1.4.0 --to HEAD --project .
```

Reads both revisions out of git objects, so nothing is checked out. Any tool or parameter
added or removed is a critical alert (`MON-DRIFT-TOOLSET`).

### Phase 4 — Report

Baseline first, then the table, then what is missing:

```
Family        : agentic / L2      threshold 10% (MON-THRESHOLD-AGENTIC)
Baseline      : eval/outputs/run1/summary.json
Frequency     : weekly (inference: daily)

task_completion    0.86  ->  alert below 0.774
stability          0.91  ->  alert below 0.819
step_efficiency      -       no baseline - to establish before end of build
```

### Phase 5 — Write the section

```bash
python scripts/write_section.py --plan aida/monitoring_plan.json --values aida/values.json --map aida/placeholders.json
```

It writes this section's fields into the shared values file. The placeholder map decides where each answer may come from: a field the template routes to a human is left as an open point, and one routed to the codebase is skipped unless there is something to cite. Answers carrying `confirmed_by` are never overwritten.

Then run the shared chain from `aida-core`:
`validate_values.py`, then `fill_docx.py`. The validator refuses a threshold that
contradicts the guideline for this family — which is the point.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/write_section.py`](scripts/write_section.py) | Writes section 3.8 model monitoring into `aida/values.json` |
| [`scripts/plan_monitoring.py`](scripts/plan_monitoring.py) | Metrics, baseline-derived thresholds, frequency, drift plan |
| [`scripts/detect_tool_drift.py`](scripts/detect_tool_drift.py) | Tool set drift between two git revisions |
| [`references/genai_monitoring.md`](references/genai_monitoring.md) | Metric tables per family, drift methodology, feedback requirements |

From `aida-core`: `scan_codebase.py`, `validate_values.py`, `fill_docx.py`,
`references/aida_rules.json`.

---

## Quality checklist

- [ ] The metric set matches the family `aida-core` determined
- [ ] Every threshold is derived from a measured baseline, or reported as missing one
- [ ] Every threshold carries its rule id
- [ ] Monitoring frequency follows the inference frequency, and both are stated
- [ ] Drift is planned per family, not mentioned generically
- [ ] Tool set drift was checked for an agentic system
- [ ] The user feedback path distinguishes generation from retrieval or tool path
