# Section guide — AIDA technical documentation

What each section of the official template expects, where its answer comes from, and
which rule governs it. Read the section you are working on; there is no need to read the
whole file.

## Contents

- [1. Introduction](#1-introduction)
- [2. General description](#2-general-description)
- [3.1 Data handling](#31-data-handling)
- [3.2 Development](#32-development)
- [3.3 Validation and testing](#33-validation-and-testing)
- [3.4 Design specifications and model performance](#34-design-specifications-and-model-performance)
- [3.5 Architecture](#35-architecture)
- [3.6 Deployment](#36-deployment)
- [3.7 Record keeping](#37-record-keeping)
- [3.8 Monitoring](#38-monitoring)
- [3.9 Human oversight](#39-human-oversight)
- [3.10 Cybersecurity](#310-cybersecurity)
- [4 to 7 and the appendix](#4-to-7-and-the-appendix)

---

## 1. Introduction

An overview of intended purpose, model conception, predictive performance, continuous
monitoring and known limitations. Written **last**, from the sections below — it is a
summary, not a place to introduce new claims. `write_introduction.py` assembles it from
the context and the section audits; the intended purpose stays an open point inside it.

## 2. General description

Intended purpose, target users, provider, version information, interactions,
compatibility and user interface.

Intended purpose, use cases and target users are **human** fields. They are the ones the
scan is most tempted to guess from a README or a project name — do not. Version
information and software dependencies are `code` fields. Hardware (2.4) is read from the
scan: accelerators referenced, or a managed model API and none — then say so plainly.

## 3.1 Data handling

Provenance, scope, acquisition, labelling, pre-treatment, feature engineering and the
limitations of the data used.

Almost entirely **human**. What the code shows is which vector store or corpus exists,
not where the data came from or how it was curated. The ML-BOM lists the datasets as
components; it does not document their provenance.

## 3.2 Development

Training, fine-tuning, evaluation and selection, post-processing, and third-party
models, tools and frameworks.

Third-party components are a `code` field and come straight from the scan and the
ML-BOM. State plainly when models are used as-is without fine-tuning — that is the
common case for a GenAI system and it is a meaningful fact, not an absence.

## 3.3 Validation and testing

Procedures, dataset characteristics, robustness metrics, experiment logs.

Dataset sizes are fixed by the guidelines: **at least 50 questions and 20 documents** for
RAG (`EVAL-RAG-QUERIES`, `EVAL-RAG-CORPUS`), **at least 20 queries** spanning simple,
complex and edge cases for agentic systems (`EVAL-AGENTIC-QUERIES`). If the project's
evaluation set is smaller, say so — it is a finding, not a detail.

`profile_evaluation.py` checks the codebase first: the dataset profile, each experiment log
dated with its metrics and a SHA-256 digest of the file, the latest results with the
robustness metrics run, and the tests to re-run on change. When nothing exists it says so
and how to produce signed logs (the record journal's `model_performance`, verified by
`verify_chain.py`). The MLflow URL and the sign-off remain the team's.

## 3.4 Design specifications and model performance

Model choice and assumptions, performance, explainability, robustness and fairness,
model artefacts.

The general logic of the model is the AI Factory classification: family, autonomy level,
and the reason. Measured performance is `external` — take it from the evaluation
pipeline output if the project has one, never from an estimate. Explainability must name
at least one measure (`OVERSIGHT-EXPLAINABILITY`); for GenAI the guideline's own option is
showing the retrieved sources behind an answer.

Fairness and bias sit in the risk and validation domain, explicitly outside the
evaluation guideline's scope. Do not manufacture an assessment here.

Figure: `render_figures.py` charts each metric's measured baseline against its alert
threshold (Mermaid `xychart-beta` + SVG). No baseline, no chart — an open point instead.

## 3.5 Architecture

GAD and RPAD documents, computational resources, feedback loops, how validation is
integrated.

GAD and RPAD are `external`: link them. If the system is L2 or L3, this is where the
autonomy justification required by `BUILD-L1-DEFAULT` belongs, and its absence is a
blocking gap.

Figure: `render_figures.py` draws the architecture as a Mermaid flowchart from the scan —
only components with evidence, ungated irreversible tools highlighted. It complements the
GAD/RPAD, it does not replace them.

## 3.6 Deployment

Installation, distribution forms, platforms, operational environment, CI/CD and
rollback.

`code` fields, from the infrastructure the scan detected. Rollback is rarely derivable
from a pipeline definition — leave it open rather than describing a procedure that may
not exist.

## 3.7 Record keeping

Input, output and ground-truth historisation, event logs, feedback capture, and the
tools used.

Governed by `REC-MODEL-MANDATORY`, `REC-OPERATIONAL-MANDATORY`, `REC-OVERSIGHT-MANDATORY`,
`REC-FORMAT` and `REC-RETENTION`. Six model records, two operational records and one
oversight record are mandatory for internally developed systems. Every record answers
**what, when and who**. Retention is **10 years for documentation and at least 1 year for
automatic logs**, in secure and immutable storage with NTP-synchronised timestamps.

Report missing records as gaps to close before the end of the build phase — that is the
guideline's own deadline, not an arbitrary one.

## 3.8 Monitoring

Two distinct subsections that must not be merged: **AI Model Monitoring** covers output
quality, **AI System Operational Monitoring** covers system health.

The alert threshold depends on the system family: **20%** relative drop for a prompt
system, **10%** for RAG and agentic (`MON-THRESHOLD-*`). Monitoring frequency follows
inference frequency — daily to weekly, weekly to monthly, monthly to quarterly, quarterly
to yearly (`MON-FREQUENCY`). At least one metric must be selected from the operational
table (`MON-OPERATIONAL-MINIMUM`), whose reference thresholds are latency ≥ 3 s, uptime
< 99% per week, timeout ≥ 5%, error rate ≥ 2%, one crash, resources ≥ 90%.

The baseline is the build-phase evaluation, which is what makes a production score
interpretable at all.

## 3.9 Human oversight

Measures in place, named overseers, and the record of alerts and actions.

Six capabilities are required (`OVERSIGHT-CAPABILITIES`), including **overriding a result
and interrupting the system**. At least one explainability measure and the intervention
mechanisms of `OVERSIGHT-INTERVENTION` — stop control, granular quarantine, user flag,
escalation paths, alert logging. The obligation applies to VRM risk categories 1 and 2.

The named overseers are a **human** field: a role name is not a person.

Where the scan found irreversible actions with no approval gate, say so here. It is the
most actionable finding the whole document contains.

## 3.10 Cybersecurity

Guardrails, red-teaming, and links to ISS opinion, MESARI and penetration test reports.

The reference red-teaming framework is DeepTeam, whose attack library follows the OWASP
LLM Top 10 (`BUILD-REDTEAM`). The three links are `external`.

## 4 to 7 and the appendix

Updates and changes, model validation, harmonised standards, declaration of conformity,
and the **AI System Journal**.

Section 5 ends with the AIDA validation table. `write_validation_table.py` fills one row
per version — version, changes since the previous tag, the opinion as an open point, the
validation status and the blocking gaps by rule — and keeps the rows of earlier versions.

Sections 6 and 7 apply to externally supplied systems only. The journal is not optional
paperwork: `DOC-JOURNAL` requires every substantial monitoring alert, its investigation
and its corrective measures to be recorded there, and so must every human overseer
intervention. It is what turns oversight from an assertion into an auditable fact.

`write_journal.py` opens it in the template's table: each released version from the git
history, the generation of the document, and one row per blocking gap with the corrective
measure and its owner as an open point. The template's example row stays; rows the overseers
add (`"origin": "manual"`) survive every regeneration.
