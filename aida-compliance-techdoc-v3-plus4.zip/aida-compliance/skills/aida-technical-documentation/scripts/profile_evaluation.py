#!/usr/bin/env python3
"""Section 3.3 from the evaluation files the project holds - or what is missing, plainly.

    python profile_evaluation.py . --context aida/context.json

Section 3.3 asks for the characteristics of the validation and testing data, dated and
signed experiment logs, the results of the tests, and the tests to re-run on future
changes. The first three exist as files in a project that has been evaluated, so they are
read, never asked for:

* the evaluation dataset (.jsonl / .json / .csv with a question column under eval/,
  evals/, golden/, benchmark/, datasets/...): size, fields, question length, distribution
  per category, reference-answer coverage, duplicates - checked against the size and
  categories the Evaluation guideline requires (EVAL-*-QUERIES, EVAL-AGENTIC-CATEGORIES,
  EVAL-RAG-CORPUS);
* the experiment logs: evaluation summaries (*/outputs/*/summary.json) and local MLflow
  runs (mlruns/), each dated, with its metrics and a SHA-256 digest of the file, so a
  reviewer can check the log has not changed since the document was generated;
* the results: the scores of the latest run, and which robustness metrics were run.

When a file does not exist, the answer says so and says how to produce it - a statement
a reviewer can act on, never a silent gap. What the files cannot say stays an open point:
how the cases were selected, the MLflow URL, and who signs the logs off.

build_values.py calls answers() for the four fields; the CLI prints the same profile.
Standard library only.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

CHARACTERISTICS = ("Provide information about the main characteristics of the validation "
                   "and testing data used (e.g. data distribution).")
EXPERIMENT_LOGS = ("Include dated and signed model experiments logs and reports (e.g. link "
                   "to ML flow experiment tracking).")
TEST_RESULTS = "Present clearly the results of the robustness and specification tests of the model"
FUTURE_TESTS = ("Document tests related to future expected changes to be operated to the AI "
                "system (where applicable).")

EVAL_DIRS = {"eval", "evals", "evaluation", "evaluations", "golden", "benchmark", "benchmarks",
             "testsets", "test_sets", "datasets"}
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "aida", "outputs",
             "mlruns", "site-packages"}
QUESTION_KEYS = ("question", "query", "input", "prompt", "user_input", "instruction")
ANSWER_KEYS = ("expected", "expected_answer", "ground_truth", "reference", "answer",
               "expected_output", "reference_answer")
CONTEXT_KEYS = ("context", "contexts", "reference_contexts", "sources", "documents",
                "expected_tools", "tools")
CATEGORY_KEYS = ("category", "type", "difficulty", "complexity", "tag", "kind", "scenario")
CORPUS_DIRS = {"corpus", "documents", "knowledge_base", "kb", "knowledge"}
AGENTIC_CATEGORIES = ("simple", "multi", "edge")
ROBUSTNESS_WORDS = ("robust", "adversarial", "perturb", "fairness", "bias", "stereotyp",
                    "toxicity", "injection", "jailbreak")


# ------------------------------------------------------------------- the data --
def read_cases(path: Path) -> list[dict]:
    """Rows of an evaluation file, or [] when it is not one."""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    rows: list = []
    if path.suffix == ".jsonl":
        for line in text.splitlines():
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    elif path.suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
        if isinstance(data, dict):
            data = next((v for v in data.values() if isinstance(v, list)), [])
        rows = data if isinstance(data, list) else []
    elif path.suffix == ".csv":
        rows = list(csv.DictReader(text.splitlines()))
    rows = [r for r in rows if isinstance(r, dict)]
    return rows if rows and question_key(rows[0]) else []


def question_key(row: dict) -> str | None:
    """The column that holds the question in an evaluation row, or None."""
    return next((k for k in QUESTION_KEYS if k in row), None)


def first_key(rows: list[dict], keys: tuple[str, ...]) -> str | None:
    """The first of `keys` present in any row, or None."""
    return next((k for k in keys if any(k in r for r in rows)), None)


def find_datasets(root: Path) -> list[tuple[Path, list[dict]]]:
    """Evaluation files under eval/, evals/, golden/... with their cases."""
    found = []
    for path in sorted(root.rglob("*")):
        parts = path.relative_to(root).parts
        if (not path.is_file() or path.suffix not in (".jsonl", ".json", ".csv")
                or any(p in SKIP_DIRS for p in parts)
                or not any(p.lower() in EVAL_DIRS for p in parts[:-1])):
            continue
        cases = read_cases(path)
        if cases:
            found.append((path, cases))
    return found


def profile(path: Path, cases: list[dict], root: Path) -> dict:
    """Size, fields, question length, distribution, coverage and duplicates of one file."""
    qkey = question_key(cases[0])
    questions = [str(c.get(qkey, "")) for c in cases]
    words = [len(q.split()) for q in questions]
    answer, context, category = (first_key(cases, keys)
                                 for keys in (ANSWER_KEYS, CONTEXT_KEYS, CATEGORY_KEYS))
    return {
        "file": path.relative_to(root).as_posix(), "cases": len(cases),
        "fields": sorted({k for c in cases for k in c}),
        "question_words": {"min": min(words), "median": statistics.median(words),
                           "max": max(words)},
        "reference_field": answer,
        "with_reference_answer": sum(1 for c in cases if answer and c.get(answer)),
        "context_field": context,
        "with_context": sum(1 for c in cases if context and c.get(context)),
        "category_field": category,
        "distribution": dict(Counter(str(c.get(category, "unlabelled")).lower()
                                     for c in cases).most_common(8)) if category else {},
        "duplicates": len(questions) - len({q.strip().lower() for q in questions}),
    }


def corpus_size(root: Path) -> tuple[int, str | None]:
    """Number of documents in the first corpus / knowledge-base folder, and its path."""
    for path in sorted(root.rglob("*")):
        if path.is_dir() and path.name.lower() in CORPUS_DIRS and not any(
                p in SKIP_DIRS for p in path.relative_to(root).parts):
            files = [f for f in path.rglob("*") if f.is_file()]
            if files:
                return len(files), path.relative_to(root).as_posix()
    return 0, None


# -------------------------------------------------------------------- the runs --
def digest(path: Path) -> str:
    """SHA-256 of the log file: lets a reviewer check it has not changed since."""
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def stamp(seconds: float) -> str:
    """A Unix time as a UTC date."""
    return datetime.fromtimestamp(seconds, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def evaluation_runs(root: Path) -> list[dict]:
    """Evaluation summaries, dated by their own timestamp, else by the file date."""
    runs = []
    for path in sorted(set(root.glob("**/outputs/*/summary.json")) | set(root.glob("eval/**/summary.json"))):
        if any(p in SKIP_DIRS - {"outputs"} for p in path.relative_to(root).parts):
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        metrics = data.get("metrics", data) if isinstance(data, dict) else {}
        scores = {k: (v.get("score") if isinstance(v, dict) else v) for k, v in metrics.items()
                  if isinstance(v, (int, float, dict)) and not isinstance(v, bool)}
        date = next((str(data[k]) for k in ("timestamp", "date", "created_at", "run_date")
                     if k in data), None) if isinstance(data, dict) else None
        runs.append({"run": path.parent.name, "kind": "evaluation summary",
                     "file": path.relative_to(root).as_posix(), "sha256": digest(path),
                     "date": date or f"{stamp(path.stat().st_mtime)} (file date)",
                     "metrics": {k: v for k, v in scores.items() if isinstance(v, (int, float))}})
    return runs


def mlflow_runs(root: Path) -> list[dict]:
    """Local MLflow file store: mlruns/<experiment>/<run>/meta.yaml and metrics/."""
    runs = []
    for meta in sorted(root.glob("**/mlruns/*/*/meta.yaml")):
        fields = {}
        for line in meta.read_text(encoding="utf-8", errors="ignore").splitlines():
            key, _, value = line.partition(":")
            fields[key.strip()] = value.strip().strip("'\"")
        metrics = {}
        for metric in sorted((meta.parent / "metrics").glob("*")):
            last = metric.read_text(encoding="utf-8", errors="ignore").split()
            if len(last) >= 3:                   # "<timestamp> <value> <step>" per line
                metrics[metric.name] = float(last[-2])
        start = fields.get("start_time", "")
        runs.append({"run": fields.get("run_name") or meta.parent.name, "kind": "MLflow run",
                     "file": meta.relative_to(root).as_posix(), "sha256": digest(meta),
                     "date": stamp(int(start) / 1000) if start.isdigit() else "undated",
                     "metrics": metrics})
    return runs


# ---------------------------------------------------------------- the answers --
def required(family: str | None, rules: dict) -> tuple[int | None, str | None, str]:
    """(minimum size, rule id, unit) the Evaluation guideline sets for the family."""
    rule_id = {"rag": "EVAL-RAG-QUERIES", "hybrid": "EVAL-RAG-QUERIES",
               "agentic": "EVAL-AGENTIC-QUERIES"}.get(family or "")
    if not rule_id:
        return None, None, "cases"
    threshold = next(r["threshold"] for r in rules["rules"] if r["id"] == rule_id)
    return next(iter(threshold.values())), rule_id, ("queries" if family == "agentic" else "questions")


def describe_data(profiles: list[dict], family: str | None, rules: dict,
                  corpus: tuple[int, str | None]) -> str:
    """Section 3.3 data characteristics: the profile against EVAL-*, or what is missing."""
    minimum, rule_id, unit = required(family, rules)
    if not profiles:
        text = ("No evaluation dataset was found in the repository (searched eval/, evals/, "
                "evaluation/, golden/, benchmark/ and datasets/ for .jsonl, .json and .csv "
                "files with a question column). ")
        if minimum:
            text += f"The guideline requires at least {minimum} {unit} ({rule_id})"
            text += (", spanning simple, multi-step and edge cases (EVAL-AGENTIC-CATEGORIES). "
                     if family == "agentic" else ". ")
        text += ("Once the dataset exists, this section states its size, the distribution per "
                 "category, the share of cases with a reference answer and the duplicates. ")
    else:
        total = sum(p["cases"] for p in profiles)
        text = f"Evaluation data: {total} case(s) in {len(profiles)} file(s). "
        for p in profiles:
            text += (f"{p['file']}: {p['cases']} cases; fields {', '.join(p['fields'][:8])}; "
                     f"question length {p['question_words']['min']}-{p['question_words']['max']} "
                     f"words (median {p['question_words']['median']:g})")
            if p["reference_field"]:
                text += f"; {p['with_reference_answer']}/{p['cases']} with a reference answer"
            if p["context_field"]:
                text += f"; {p['with_context']}/{p['cases']} with {p['context_field']}"
            if p["distribution"]:
                text += f"; distribution by {p['category_field']}: " + ", ".join(
                    f"{k} {v} ({v * 100 // p['cases']}%)" for k, v in p["distribution"].items())
            if p["duplicates"]:
                text += f"; {p['duplicates']} duplicate question(s)"
            text += ". "
        if minimum:
            text += (f"Size {'meets' if total >= minimum else 'is BELOW'} the guideline minimum "
                     f"of {minimum} {unit} ({rule_id}). ")
        if family == "agentic":
            labels = " ".join(k for p in profiles for k in p["distribution"])
            missing = [c for c in AGENTIC_CATEGORIES if c not in labels]
            text += ("Simple, multi-step and edge cases are all labelled (EVAL-AGENTIC-CATEGORIES). "
                     if not missing else f"No case labelled {', '.join(missing)} - "
                     f"EVAL-AGENTIC-CATEGORIES requires simple, multi-step and edge cases. ")
    if family in ("rag", "hybrid"):
        need = next(r["threshold"]["min_documents"] for r in rules["rules"]
                    if r["id"] == "EVAL-RAG-CORPUS")
        count, where = corpus
        text += (f"Knowledge-base corpus: {count} document(s) in {where} "
                 f"({'meets' if count >= need else 'BELOW'} the {need} of EVAL-RAG-CORPUS). "
                 if where else f"Corpus size not found; EVAL-RAG-CORPUS requires at least {need} "
                               f"documents. ")
    return text + "[A CONFIRMER - how the cases were selected and whether they represent real usage]"


def describe_logs(runs: list[dict]) -> str:
    """Section 3.3 logs: each run dated with its digest, or how to produce signed logs."""
    if not runs:
        return ("No dated experiment log was found in the repository (evaluation summaries "
                "under */outputs/*/summary.json, local MLflow runs under mlruns/). Before "
                "validation, produce one per evaluated version: run the evaluation, keep its "
                "dated summary, and record it with records.model_performance() from the "
                "aida-record-keeping journal - the hash chain makes the log tamper-evident and "
                "verify_chain.py checks it. [A CONFIRMER - MLflow experiment URL and the person "
                "who signs the logs off]")
    lines = [f"{len(runs)} dated experiment log(s) in the repository, each with the SHA-256 "
             f"digest of its file so a reviewer can check it is unchanged:"]
    for run in runs[:6]:
        metrics = ", ".join(f"{k} {v:g}" for k, v in list(run["metrics"].items())[:5])
        lines.append(f"{run['kind']} '{run['run']}', {run['date']}"
                     + (f": {metrics}" if metrics else "")
                     + f" ({run['file']}, sha256 {run['sha256']}).")
    lines.append("[A CONFIRMER - MLflow experiment URL and the sign-off of these logs: name, "
                 "role, date]")
    return " ".join(lines)


def describe_results(runs: list[dict]) -> str:
    # oldest first, undated ones before any dated run: "latest" means the most recent date
    """Section 3.4 results: the most recent run and the robustness metrics run."""
    scored = sorted((r for r in runs if r["metrics"]),
                    key=lambda r: r["date"][:16].replace("T", " ") if r["date"][:1].isdigit() else "")
    if not scored:
        return ("No test result was found in the repository. The results to present here are "
                "the scores of the build-phase evaluation and of the robustness metrics listed "
                "in section 3.3, produced by running the evaluation; this document picks them "
                "up from the evaluation summary when it exists. [A CONFIRMER - test report]")
    latest = scored[-1]
    robust = sorted({k for r in scored for k in r["metrics"]
                     if any(w in k.lower() for w in ROBUSTNESS_WORDS)})
    return (f"Results of the latest evaluation run, '{latest['run']}' ({latest['date']}, "
            f"{latest['file']}): "
            + "; ".join(f"{k} {v:g}" for k, v in latest["metrics"].items()) + ". "
            + (f"{len(scored) - 1} earlier run(s) are listed in the experiment logs. "
               if len(scored) > 1 else "")
            + (f"Robustness metrics run: {', '.join(robust)}."
               if robust else "No robustness-specific metric (bias, perturbation, adversarial "
                              "or injection tests) appears in these results: the robustness "
                              "metrics listed in section 3.3 are still to be run."))


def describe_future_tests(ctx: dict, rules: dict) -> str:
    """Section 3.3: the regression tests every change re-runs."""
    family = (ctx.get("classification") or {}).get("family")
    rule_id = {"prompt": "MON-THRESHOLD-PROMPT", "rag": "MON-THRESHOLD-RAG",
               "hybrid": "MON-THRESHOLD-RAG", "agentic": "MON-THRESHOLD-AGENTIC"}.get(family)
    drop = next((r["threshold"]["relative_drop_pct"] for r in rules["rules"]
                 if r["id"] == rule_id), None)
    text = ("Every change to the system - model, prompt, tool, knowledge base, dependency - "
            "re-runs the same tests before release: the build-phase evaluation set with the "
            "same metrics, compared with the recorded baseline"
            + (f", a relative decrease of {drop:g}% or more blocking the release ({rule_id})"
               if drop else "") + ". ")
    if family in ("agentic", "hybrid"):
        text += ("The tool set is compared between the released and the new revision, and any "
                 "tool or parameter added or removed is critical (MON-DRIFT-TOOLSET). ")
    text += ("The documentation freshness check fails when a file this document cites has "
             "changed, so the affected sections are regenerated (DOC-UPDATE-ON-CHANGE). "
             "[A CONFIRMER - the changes planned for the system]")
    return text


def answers(project: Path, ctx: dict, rules: dict) -> dict[str, tuple[str, list[str]]]:
    """placeholder -> (value, evidence) for the four evidence-backed fields of 3.3 / 3.4."""
    family = (ctx.get("classification") or {}).get("family")
    datasets = find_datasets(project) if project.is_dir() else []
    profiles = [profile(path, cases, project) for path, cases in datasets]
    runs = (evaluation_runs(project) + mlflow_runs(project)) if project.is_dir() else []
    corpus = corpus_size(project) if project.is_dir() else (0, None)
    run_refs = [f"{r['file']}:1" for r in runs][:4]
    return {
        CHARACTERISTICS: (describe_data(profiles, family, rules, corpus),
                          [f"{p['file']}:1" for p in profiles][:4]),
        EXPERIMENT_LOGS: (describe_logs(runs), run_refs),
        TEST_RESULTS: (describe_results(runs), run_refs[-1:]),
        FUTURE_TESTS: (describe_future_tests(ctx, rules), []),
    }


def main() -> int:
    """Command line: print the section 3.3 profile of a project."""
    parser = argparse.ArgumentParser(description="Profile the evaluation data and runs (3.3).")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--rules", default=str(Path(__file__).resolve().parent.parent.parent
                                               / "aida-core" / "references" / "aida_rules.json"))
    args = parser.parse_args()
    context = Path(args.context)
    ctx = json.loads(context.read_text(encoding="utf-8")) if context.exists() else {}
    rules = json.loads(Path(args.rules).read_text(encoding="utf-8"))
    for placeholder, (value, evidence) in answers(Path(args.project).resolve(), ctx, rules).items():
        print(f"== {placeholder[:70]}\n{value}\n   evidence: {', '.join(evidence) or '-'}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
