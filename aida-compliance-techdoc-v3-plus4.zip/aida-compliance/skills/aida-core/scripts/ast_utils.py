"""Syntax-tree helpers shared by the audits that read Python source.

Imported by audit_oversight.py, check_resilience.py and detect_tool_drift.py, so the three
agree on what a call target is called. Standard library only.
"""

from __future__ import annotations

import ast


def dotted(node: ast.AST) -> str:
    """Best-effort dotted name of a call target, lowercased: requests.post, shutil.rmtree.

    Anything that is not a plain name chain (a subscript, a call result) keeps only the
    attribute part, so `clients[0].post` gives `post`.
    """
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return ".".join(reversed(parts)).lower()


if __name__ == "__main__":
    raise SystemExit("ast_utils.py is a library, imported by the audits; nothing to run.")
