#!/usr/bin/env python3
"""Validate the answers before they are written into the official template.

    python validate_values.py --values aida/values.json --map aida/placeholders.json \
                              --context aida/context.json

This is the check between planning and writing. Producing the answers is open-ended and
therefore error-prone; writing them into a compliance document is irreversible in
practice, because whoever reads it afterwards assumes it is true. So the plan is
verified first, mechanically.

Exit code 0 when the plan is safe to write, 1 when it is not.

The checks that matter most:

* a field only the risk owner can answer must not be filled without saying who confirmed
  it - that is the exact shape a hallucination takes in a compliance document;
* a fact derived from the code must cite the code;
* a guideline threshold must be the guideline's own number, not a plausible one.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RULES = HERE.parent / "references" / "aida_rules.json"

# --- things that must never reach a document -------------------------------------
SECRET_PATTERNS = [
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AWS access key id"),
    (re.compile(r"\b(?:sk|pk)-[A-Za-z0-9]{20,}\b"), "API key"),
    (re.compile(r"(?i)\b(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*\S{8,}"), "credential"),
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"), "private key"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._\-]{20,}"), "bearer token"),
]
LEFTOVER = re.compile(r"(?i)\b(todo|tbd|fixme|lorem ipsum|xxx+|à compléter|a completer)\b|\{[^{}]{3,}\}")

# --- threshold wording we can check against the rules -----------------------------
DROP_CONTEXT = re.compile(
    r"(?i)(drop|decrease|degradation|dégradation|baisse|relative performance|below baseline)"
)
PERCENT = re.compile(r"(\d+(?:[.,]\d+)?)\s*%")
# The model-quality threshold is one clause among many: the same field also lists the
# operational thresholds (a 30% fall in active users, a +200% request spike), which come
# from other rules and must not be read as a performance drop.
CLAUSE = re.compile(r"[;\n]|\.\s+(?=[A-Z])")
OPERATIONAL_CONTEXT = re.compile(
    r"(?i)(users?|requests?|sessions?|latency|uptime|error[_ ]rate|timeouts?|crash|cpu|"
    r"memory|resource|month-over-month|per hour|spike|cost|tokens?)")
YEARS = re.compile(r"(?i)(\d+)\s*(?:years?|ans?|années?)")
RETENTION_CONTEXT = re.compile(r"(?i)(retention|rétention|retain|conserv|archiv)")

FAMILY_TO_DROP_RULE = {
    "prompt": "MON-THRESHOLD-PROMPT",
    "rag": "MON-THRESHOLD-RAG",
    "agentic": "MON-THRESHOLD-AGENTIC",
    "hybrid": "MON-THRESHOLD-RAG",
}


class Report:
    def __init__(self) -> None:
        self.errors: list[dict] = []
        self.warnings: list[dict] = []

    def error(self, check: str, placeholder: str, detail: str) -> None:
        """Record a blocking finding."""
        self.errors.append({"check": check, "placeholder": placeholder, "detail": detail})

    def warn(self, check: str, placeholder: str, detail: str) -> None:
        """Record a finding that does not block."""
        self.warnings.append({"check": check, "placeholder": placeholder, "detail": detail})

    def render(self) -> str:
        """The findings as text, blocking first."""
        lines = []
        if self.errors:
            lines.append(f"BLOCKING ({len(self.errors)})")
            for item in self.errors:
                lines.append(f"  [{item['check']}] {item['placeholder'][:64]}")
                lines.append(f"      {item['detail']}")
        if self.warnings:
            lines.append(f"\nWARNINGS ({len(self.warnings)})")
            for item in self.warnings:
                lines.append(f"  [{item['check']}] {item['placeholder'][:64]}")
                lines.append(f"      {item['detail']}")
        if not self.errors and not self.warnings:
            lines.append("No issues found.")
        return "\n".join(lines)


def normalise(entry) -> tuple[str, list[str], str | None]:
    """values.json accepts a bare string or {value, evidence, confirmed_by}."""
    if isinstance(entry, str):
        return entry, [], None
    if isinstance(entry, dict):
        return (str(entry.get("value") or ""),
                list(entry.get("evidence") or []),
                entry.get("confirmed_by"))
    return "", [], None


def expected_drop_pct(rules: dict, family: str) -> float | None:
    """The relative drop the family's MON-THRESHOLD rule sets, or None."""
    rule_id = FAMILY_TO_DROP_RULE.get(family)
    if not rule_id:
        return None
    for rule in rules["rules"]:
        if rule["id"] == rule_id:
            return float(rule["threshold"]["relative_drop_pct"])
    return None


def retention_rule(rules: dict) -> dict:
    """The REC-RETENTION thresholds."""
    for rule in rules["rules"]:
        if rule["id"] == "REC-RETENTION":
            return rule["threshold"]
    return {}


def validate(values: dict, routing: dict, context: dict, rules: dict) -> Report:
    """Check every answer; blocking errors and warnings are collected in a Report."""
    report = Report()
    family = (context.get("classification") or {}).get("family", "unknown")
    drop_pct = expected_drop_pct(rules, family)
    retention = retention_rule(rules)

    for key, raw in values.items():
        value, evidence, confirmed_by = normalise(raw)
        route = routing.get(key)

        if route is None:
            report.error("unknown-field", key,
                         "not a placeholder of the template - it will never be written. "
                         "Check the wording against aida/placeholders.json.")
            continue

        source = route.get("source", "human")

        if not value.strip():
            report.error("empty-value", key, "supplied but empty - remove it or fill it.")
            continue

        if LEFTOVER.search(value):
            report.error("draft-text", key,
                         f"still contains draft or placeholder text: {value[:80]!r}")

        for pattern, label in SECRET_PATTERNS:
            if pattern.search(value):
                report.error("secret", key,
                             f"looks like a {label} - never write a credential into a "
                             f"compliance document.")
                break

        if source == "human" and not confirmed_by:
            report.error("unconfirmed", key,
                         "only the risk owner can answer this field, but a value was "
                         "supplied with no `confirmed_by`. Either record who confirmed "
                         "it, or leave it as [A CONFIRMER].")

        if source == "code" and not evidence:
            report.error("no-evidence", key,
                         "derived from the codebase but cites no path:line. A fact "
                         "without its proof cannot go into the document.")

        for item in evidence:
            if not re.search(r".+:\d+$", item) and not item.startswith(("git ", "http")):
                report.warn("evidence-format", key,
                            f"evidence {item!r} is not a path:line reference.")

        # A stated performance-drop threshold must be the guideline's own number.
        clauses = [c for c in CLAUSE.split(value) if DROP_CONTEXT.search(c)
                   and not OPERATIONAL_CONTEXT.search(c)] if drop_pct is not None else []
        for clause in clauses:
            for found in PERCENT.findall(clause):
                stated = float(found.replace(",", "."))
                rule_id = FAMILY_TO_DROP_RULE[family]
                if stated > drop_pct + 0.01:
                    report.error(
                        "threshold", key,
                        f"states a {stated:g}% performance drop, but the guideline sets "
                        f"{drop_pct:g}% for a {family} system ({rule_id}). Thresholds may "
                        f"be stricter, never looser - and must be justified.")
                elif stated < drop_pct - 0.01:
                    report.warn(
                        "threshold-stricter", key,
                        f"states a {stated:g}% drop, stricter than the {drop_pct:g}% of "
                        f"{rule_id}: allowed, but the justification must be documented.")

        if RETENTION_CONTEXT.search(value) and retention:
            for found in YEARS.findall(value):
                years = int(found)
                if years < retention.get("automatic_logs_years_min", 1):
                    report.error("retention", key,
                                 f"states {years} year(s) of retention; the guideline "
                                 f"requires at least "
                                 f"{retention['automatic_logs_years_min']} year for "
                                 f"automatic logs and "
                                 f"{retention['documentation_years']} years for "
                                 f"documentation (REC-RETENTION).")

    # Fields the scan could answer but nobody filled.
    for key, route in routing.items():
        if route.get("source") == "code" and route.get("resolved") and key not in values:
            report.warn("missing-known-value", key,
                        "the scan can answer this field but no value was supplied.")

    return report


def load(path: Path, label: str):
    """Read a JSON input, or exit 2 naming the missing file."""
    if not path.exists():
        print(f"error: {label} not found: {path}", file=sys.stderr)
        raise SystemExit(2)
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    """Command line: validate the answers; exit 1 on any blocking finding."""
    parser = argparse.ArgumentParser(description="Validate answers before writing the template.")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--rules", default=str(DEFAULT_RULES))
    parser.add_argument("--out", default="aida/validation.json")
    args = parser.parse_args()

    values = load(Path(args.values), "values")
    if isinstance(values, dict) and "values" in values:
        values = values["values"]
    routing_raw = load(Path(args.routing), "placeholder map")
    routing = {p["placeholder"]: p for p in routing_raw.get("placeholders", [])}
    context = load(Path(args.context), "context")
    rules = load(Path(args.rules), "rules")

    report = validate(values, routing, context, rules)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"errors": report.errors, "warnings": report.warnings},
                              indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"Fields supplied : {len(values)}")
    print(report.render())
    print(f"\nreport written to {out}")

    if report.errors:
        print("\nFix the blocking findings before running fill_docx.py.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
