# How template fields are routed

`placeholder_map.py` decides, for each `{placeholder}` of the official template, where its
answer may legitimately come from. The decision is made once, in the `ROUTES` table, and
every script obeys it: `section_values.merge` refuses a script answer to a `human` field
and a `code` answer with nothing to cite.

## The five sources

| Source | Answered by | Written as |
|---|---|---|
| `code` | the scan, with evidence | the fact followed by its `path:line` |
| `rule` | a guideline | the guideline's wording and number, with its rule id |
| `external` | another internal system (GAD, RPAD, MESARI, NSU, MLflow) | an open point naming that system |
| `human` | the risk owner | an open point, until answered with `confirmed_by` |
| `instruction` | nobody: it is template guidance (an `NB:`) | kept as written, braces dropped |

## Why the order of the table matters

For each placeholder, the **first** row whose keyword is a substring of the lowercased
placeholder wins. A specific keyword must therefore come before any generic keyword the
same placeholder also contains. The four cases in the current table:

| Specific keyword, first | Generic keyword it would otherwise hit | Why |
|---|---|---|
| `provide an overview about the ai system` | `intended purpose` | the introduction mentions the purpose but is assembled from the sections |
| `describe validation and testing procedures` | `data set` | the procedures field mentions "data sets selection methods" |
| `results of the robustness` | `robustness` | results are read from the evaluation files; the metrics are a rule |
| `model training (tested` | a bare `model training` | the monitoring section says "...with model training metrics" |

## Adding or changing a route

1. Put the row in its template section's group, before any generic keyword it contains.
2. For a `code` route, add the renderer in `build_values.py` (or the section skill) and
   return evidence with the answer: without evidence nothing is written.
3. Run the tests. `test_no_placeholder_falls_through_the_routing_table` fails when a field
   is left unrouted; `test_every_placeholder_is_routed_to_a_known_source` checks the
   sources; `test_every_rule_field_gets_an_answer` fails when a `rule` field has no renderer.
