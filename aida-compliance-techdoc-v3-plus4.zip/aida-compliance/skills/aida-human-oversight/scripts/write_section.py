#!/usr/bin/env python3
"""Write section 3.9 of the AIDA technical documentation from the oversight audit.

    python write_section.py --audit aida/oversight_audit.json --values aida/values.json

The audit is not the deliverable; the section is. This turns the per-tool findings into
the four fields the official template asks for, keeping the file and line behind every
statement so a risk challenger can check it.

The named overseers are never written here: only the risk owner knows them, and the
field is left as an open point until someone confirms it.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

MEASURES = "Detail the human oversight measure put in place for the AI system."
OVERSEERS = "Names of the human overseers."
JOURNAL = ("Documentation of alerts or action put in place following the human oversight "
           "process.")


def describe_tools(audit: dict) -> tuple[str, list[str]]:
    """The tools, their irreversibility and gates, as text with evidence."""
    counts = audit["counts"]
    tools = audit["tools"]
    if not tools and not audit.get("declared_tools"):
        return ("No model-callable tool was found in the codebase. If the system exposes "
                "tools in a form this audit does not recognise, the inventory below is "
                "incomplete and must be completed by the development team."), []

    lines = [f"The model can call {counts['tools']} tool(s), of which "
             f"{counts['irreversible']} have an irreversible effect and "
             f"{counts['gated']} are behind a human approval gate."]
    for tool in tools:
        effects = ", ".join(tool["effects"]) or "read-only"
        gate = "approval gate present" if tool["approval_gate"] else (
            "NO APPROVAL GATE" if tool["irreversible"] else "no gate needed")
        lines.append(f"{tool['name']} ({tool['severity']}): {effects} - {gate} "
                     f"[{tool['file']}:{tool['line']}]")

    if audit.get("declared_tools"):
        names = ", ".join(t["name"] for t in audit["declared_tools"])
        lines.append(f"Additionally, {len(audit['declared_tools'])} tool(s) are declared as "
                     f"JSON schemas and dispatched by name ({names}); their effect must be "
                     f"confirmed by the development team.")
    if audit.get("mcp"):
        servers = ", ".join(sorted({s for e in audit["mcp"] for s in e["servers"]}))
        lines.append(f"Tools reached through MCP server(s) ({servers}) are declared outside "
                     f"this codebase; the count above is a floor, not a total.")

    evidence = [f"{t['file']}:{t['line']}" for t in tools[:4]]
    return " ".join(lines), evidence


def describe_controls(audit: dict, rules: dict) -> str:
    """The controls present and missing, each with its rule."""
    controls = audit.get("controls", {})
    present, missing = [], []
    for label, key in (("a stop or disable control", "stop_control"),
                       ("a user feedback or flag path", "user_feedback"),
                       ("source citation in the outputs", "source_citation")):
        (present if controls.get(key) else missing).append(label)

    parts = []
    parts.append(f"Present in the system: {', '.join(present)}." if present
                 else "None of the intervention or explainability controls were detected "
                      "in the codebase.")
    if missing:
        parts.append(f"Not detected and therefore to be implemented: {', '.join(missing)}.")
    if controls.get("approval_policy"):
        parts.append(f"A project-level approval policy exists at "
                     f"{controls['approval_policy'][0]}; its coverage of the tools above "
                     f"must be confirmed.")
    if controls.get("sandboxing"):
        parts.append(f"A containerisation marker was found at {controls['sandboxing'][0]}; "
                     f"whether tool calls execute in isolation must be confirmed. Isolation "
                     f"limits reach but does not replace approval.")

    capabilities = next((r for r in rules["rules"]
                         if r["id"] == "OVERSIGHT-CAPABILITIES"), {})
    parts.append("Required capabilities (OVERSIGHT-CAPABILITIES): "
                 + "; ".join(capabilities.get("capabilities", [])) + ".")
    return " ".join(parts)


def build(audit: dict, rules: dict) -> dict[str, dict]:
    """The fields of section 3.9, from the audit."""
    tools_text, evidence = describe_tools(audit)
    measures = f"{tools_text} {describe_controls(audit, rules)}"

    entries = {
        MEASURES: entry(measures, source="code" if evidence else "rule", evidence=evidence),
        OVERSEERS: entry("[A CONFIRMER - the guideline requires natural persons; a role or "
                         "a team name does not satisfy it]", source="rule"),
        JOURNAL: entry(
            "Human overseers record their interventions and the justification for each in "
            "the AI System Journal appended to this document (DOC-JOURNAL). Alerts, the "
            "investigation they triggered and the corrective measures taken are logged "
            "there, which is what makes the oversight auditable rather than asserted. "
            "The mandatory Human Review Record (REC-OVERSIGHT-MANDATORY) captures "
            "reviewer, item, date and verdict for every reviewed output.",
            source="rule"),
    }
    return entries


def main() -> int:
    """Command line: merge section 3.9 into aida/values.json."""
    parser = argparse.ArgumentParser(description="Write section 3.9 from the oversight audit.")
    parser.add_argument("--audit", default="aida/oversight_audit.json")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json",
                        help="placeholder map - the authority on where an answer may come from")
    parser.add_argument("--rules",
                        default=str(HERE.parent.parent / "aida-core" / "references" / "aida_rules.json"))
    args = parser.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"error: audit not found: {audit_path}\n"
              f"       run audit_oversight.py first", file=sys.stderr)
        return 2

    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    rules = json.loads(Path(args.rules).read_text(encoding="utf-8"))
    values_path = Path(args.values)

    result = merge(values_path, build(audit, rules), Path(args.routing))
    print(report(result, "3.9 Human Oversight Measures", values_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
