"""Section 5: the AIDA validation table - version, changes, opinion, additional information.

    python -m pytest tests/test_validation_table.py -v
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"))

from write_validation_table import OPINION, build  # noqa: E402


def git(project: Path, *args: str) -> None:
    subprocess.run(["git", "-C", str(project), "-c", "user.email=t@t", "-c", "user.name=t",
                    *args], check=True, capture_output=True)


@pytest.fixture
def tagged(tmp_path) -> dict:
    """A repository at v1.1.0, two commits after v1.0.0."""
    project = tmp_path / "repo"
    project.mkdir()
    (project / "agent.py").write_text("x = 1\n", encoding="utf-8")
    git(project, "init", "-q")
    git(project, "add", "-A")
    git(project, "commit", "-q", "-m", "first release")
    git(project, "tag", "v1.0.0")
    for message in ("add the lookup tool", "switch to the new model"):
        (project / "agent.py").write_text(message + "\n", encoding="utf-8")
        git(project, "commit", "-qam", message)
    git(project, "tag", "v1.1.0")
    return {"project": {"path": str(project)}, "git": {"tag": "v1.1.0", "commit": "abc"},
            "classification": {"family": "agentic", "agentic_level": "L2",
                               "family_evidence": ["agent.py:1"]}}


def test_a_tagged_version_lists_its_changes_since_the_previous_tag(tagged, tmp_path):
    [row] = build(tagged, tmp_path, [], "2026-09-24")
    version, changes, opinion, info = row["cells"]
    assert version == "v1.1.0 (git tag)"
    assert changes.startswith("Since v1.0.0: 2 commit(s)")
    assert "switch to the new model" in changes and "[git log v1.0.0..v1.1.0]" in changes
    assert "agentic system; autonomy L2" in changes


def test_the_opinion_is_never_written_by_the_tool(tagged, tmp_path):
    [row] = build(tagged, tmp_path, [], "2026-09-24")
    assert row["cells"][2] == OPINION and OPINION.startswith("[A CONFIRMER")


def test_blocking_gaps_are_named_by_rule(tagged, tmp_path):
    (tmp_path / "oversight_audit.json").write_text(json.dumps({"findings": [
        {"rule": "OVERSIGHT-INTERVENTION", "severity": "blocking"},
        {"rule": "OVERSIGHT-INTERVENTION", "severity": "advisory"}]}), encoding="utf-8")
    info = build(tagged, tmp_path, [], "2026-09-24")[0]["cells"][3]
    assert "Validation not yet performed" in info and "OVERSIGHT-INTERVENTION (1)" in info


def test_without_git_the_version_is_an_open_point(tmp_path):
    [row] = build({"project": {"path": str(tmp_path)}}, tmp_path, [], "2026-09-24")
    assert row["cells"][0].startswith("[A CONFIRMER - version identifier")
    assert row["cells"][1].startswith("First version documented for AIDA")


def test_earlier_versions_entered_by_the_team_are_kept(tagged, tmp_path):
    history = [{"cells": ["v1.0.0", "first release", "favourable, 2026-06-01", "-"],
                "origin": "manual"},
               {"cells": ["v1.1.0 (git tag)", "stale", "-", "-"], "origin": "generated"}]
    rows = build(tagged, tmp_path, history, "2026-09-24")
    assert [r["cells"][0] for r in rows] == ["v1.0.0", "v1.1.0 (git tag)"]
    assert rows[1]["cells"][1].startswith("Since v1.0.0")


def test_the_table_reaches_section_5_of_the_document(tmp_path):
    project = tmp_path / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    xml = zipfile.ZipFile(project / "aida" / "technical_documentation.docx").read(
        "word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", "", re.sub(r"</w:tr>", "\n", xml))
    table = text[text.find("AI System version"):text.find("Harmonized standards", text.find("AI System version"))]
    assert "First version documented for AIDA" in table and "Validation not yet performed" in table
    ref = re.search(r"\[A CONFIRMER (#\d+) - AIDA opinion", table).group(1)
    assert ref in text[text.rfind("Document completion status"):], "the opinion is listed as open"
    ids = re.findall(r'w14:paraId="([0-9A-F]+)"', xml)
    assert len(ids) == len(set(ids)), "copied rows must not duplicate paragraph ids"
    assert xml.rstrip().endswith("</w:sectPr></w:body></w:document>")
