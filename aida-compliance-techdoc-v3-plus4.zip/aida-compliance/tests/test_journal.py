"""Appendix - AI System Journal (DOC-JOURNAL): history, generation, gaps, overseers' rows.

    python -m pytest tests/test_journal.py -v
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
TECHDOC = PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"
sys.path.insert(0, str(TECHDOC))

from write_journal import build  # noqa: E402

TODAY = "2026-09-24"


def git(project: Path, *args: str) -> None:
    subprocess.run(["git", "-C", str(project), "-c", "user.email=t@t", "-c", "user.name=t",
                    *args], check=True, capture_output=True)


@pytest.fixture
def released(tmp_path) -> Path:
    """The agentic fixture under git, released as v1.0.0 then v1.1.0."""
    project = tmp_path / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    git(project, "init", "-q")
    git(project, "add", "-A")
    git(project, "commit", "-q", "-m", "first release")
    git(project, "tag", "v1.0.0")
    (project / "agent.py").write_text((project / "agent.py").read_text(encoding="utf-8")
                                      + "# purge tool\n", encoding="utf-8")
    git(project, "commit", "-qam", "add ticket purge tool")
    git(project, "tag", "v1.1.0")
    return project


def audits(folder: Path) -> Path:
    (folder / "oversight_audit.json").write_text(json.dumps({"findings": [
        {"rule": "OVERSIGHT-INTERVENTION", "severity": "blocking",
         "summary": "2 irreversible tool(s) run with no human approval gate",
         "detail": "purge_workspace (agent.py:32)"},
        {"rule": "OVERSIGHT-INTERVENTION", "severity": "advisory", "summary": "1 MCP server"}]}),
        encoding="utf-8")
    return folder


def test_each_released_version_is_an_event_from_the_git_history(released, tmp_path):
    rows = build({"project": {"path": str(released)}}, tmp_path, [], TODAY)
    events = [r["cells"][0] for r in rows if r["origin"] == "git"]
    assert [e.split(" - ")[1] for e in events] == ["Version v1.0.0 released",
                                                   "Version v1.1.0 released"]
    latest = next(r for r in rows if "v1.1.0 released" in r["cells"][0])
    assert "add ticket purge tool" in latest["cells"][1]
    assert "[git log v1.0.0..v1.1.0]" in latest["cells"][1]


def test_untagged_history_is_one_event_asking_for_a_tag(tmp_path):
    project = tmp_path / "repo"
    project.mkdir()
    (project / "a.py").write_text("x = 1\n", encoding="utf-8")
    git(project, "init", "-q")
    git(project, "add", "-A")
    git(project, "commit", "-q", "-m", "start")
    [history] = [r for r in build({"project": {"path": str(project)}}, tmp_path, [], TODAY)
                 if r["origin"] == "git"]
    assert "no released version" in history["cells"][0] and "tag the release" in history["cells"][2]


def test_without_git_the_journal_still_opens_with_the_generation(tmp_path):
    rows = build({"project": {"path": str(tmp_path)}}, tmp_path, [], TODAY)
    assert rows[0]["cells"][0] == f"{TODAY} - Technical documentation generated"


def test_each_blocking_gap_gets_its_corrective_measure_and_an_open_owner(tmp_path):
    rows = build({"project": {"path": str(tmp_path)}}, audits(tmp_path), [], TODAY)
    gap = next(r for r in rows if "Compliance gap (OVERSIGHT-INTERVENTION)" in r["cells"][0])
    assert "purge_workspace (agent.py:32)" in gap["cells"][1]
    assert "generate_controls.py" in gap["cells"][2]
    assert "[A CONFIRMER - owner and due date of the corrective measure]" in gap["cells"][2]
    assert any(r["origin"] == "advisories" for r in rows), "advisories are summarised, not dropped"


def test_rows_added_by_overseers_survive_a_regeneration(tmp_path):
    manual = {"cells": ["2026-10-02 - Monitoring alert", "faithfulness -12%", "prompt rolled back"],
              "origin": "manual"}
    rows = build({"project": {"path": str(tmp_path)}}, tmp_path, [manual], TODAY)
    assert rows[-1] == manual


def test_the_journal_fills_the_appendix_table_and_keeps_the_template_example(released):
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(released)],
                   check=True, capture_output=True)
    xml = zipfile.ZipFile(released / "aida" / "technical_documentation.docx").read(
        "word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", "", re.sub(r"</w:tr>", "\n", xml))
    # the first "Appendix" is the table of contents, the second the heading itself
    appendix = text[text.find("Appendix", text.find("Appendix") + 1):]
    assert "(Example: monitoring alert)" in appendix, "the template's guidance row is kept"
    assert "Version v1.1.0 released" in appendix
    assert "Compliance gap (OVERSIGHT-INTERVENTION)" in appendix
    refs = re.findall(r"\[A CONFIRMER (#\d+) - owner and due date", appendix)
    closing = text[text.rfind("Document completion status"):]
    assert refs and all(ref in closing for ref in refs)
    ids = re.findall(r'w14:paraId="([0-9A-F]+)"', xml)
    assert len(ids) == len(set(ids))
