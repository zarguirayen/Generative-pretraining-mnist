"""Section 3.1: what the code proves about the data is stated; the rest stays the owner's.

    python -m pytest tests/test_data_handling.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-core" / "scripts"))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"))

from build_values import (r_data_acquisition, r_feature_engineering, r_labeling,  # noqa: E402
                          r_pretreatment, r_used_data)
from placeholder_map import DEFAULT_TEMPLATE, extract  # noqa: E402
from scan_codebase import build_context  # noqa: E402

MODEL = 'MODEL = "anthropic.claude-haiku-4-5-20251001-v1:0"\n'


def project(tmp_path: Path, source: str) -> dict:
    (tmp_path / "app.py").write_text(source, encoding="utf-8")
    ctx = build_context(tmp_path)
    # a one-file project is too small to classify; the family is what the owner confirms
    if ctx["classification"].get("family") in (None, "unknown"):
        ctx["classification"]["family"] = "prompt"
    return ctx


def test_a_pre_trained_model_means_no_in_house_training_data(tmp_path):
    value, evidence = r_used_data(project(tmp_path, MODEL + "answer = llm(MODEL)\n"), {})
    assert value.startswith("No in-house training data") and evidence == ["app.py:1"]
    assert r_labeling(project(tmp_path, MODEL), {})[0].startswith("No labelling")


def test_training_code_leaves_the_data_fields_to_the_owner(tmp_path):
    ctx = project(tmp_path, MODEL + "model.fit(features, labels)\n")
    assert r_used_data(ctx, {}) is None and r_pretreatment(ctx, {}) is None


def test_a_system_not_established_as_genai_gets_no_data_statement(tmp_path):
    ctx = project(tmp_path, MODEL)
    ctx["classification"]["family"] = "unknown"
    assert r_used_data(ctx, {}) is None


def test_loaders_chunking_and_embeddings_are_cited(tmp_path):
    ctx = project(tmp_path, MODEL + "\n".join([
        "docs = PyPDFLoader(path).load()",
        "chunks = RecursiveCharacterTextSplitter(chunk_size=800).split_documents(docs)",
        "vectors = embeddings.embed_documents(chunks)"]) + "\n")
    acquisition, where = r_data_acquisition(ctx, {})
    assert "document loaders" in acquisition and where == ["app.py:2"]
    pretreatment, where = r_pretreatment(ctx, {})
    assert pretreatment.startswith("Knowledge-base documents are split into chunks") and where == ["app.py:3"]
    engineering, where = r_feature_engineering(ctx, {})
    assert "embedding vectors" in engineering and where == ["app.py:4"]


def test_validation_procedures_are_no_longer_shadowed_by_the_data_set_route():
    routes = {p["placeholder"]: p["source"] for p in extract(DEFAULT_TEMPLATE)}
    procedures = next(k for k in routes if k.startswith("Describe validation and testing procedures"))
    assert routes[procedures] == "rule"
    limitations = next(k for k in routes if k.startswith("Describe main limitations of the used data"))
    assert routes[limitations] == "human", "data limitations stay the owner's"
