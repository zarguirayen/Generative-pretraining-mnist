"""Section 3.3: the evaluation files are read, and their absence is stated with the fix.

    python -m pytest tests/test_evaluation_profile.py -v
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
RULES = json.loads((PLUGIN_ROOT / "skills" / "aida-core" / "references" / "aida_rules.json")
                   .read_text(encoding="utf-8"))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"))

from profile_evaluation import (CHARACTERISTICS, EXPERIMENT_LOGS, FUTURE_TESTS,  # noqa: E402
                                TEST_RESULTS, answers)

AGENTIC = {"classification": {"family": "agentic"}}
CASES = ([{"question": f"Close ticket {i} and notify the owner", "expected_output": "closed",
           "category": "multi-step"} for i in range(8)]
         + [{"question": f"Status of ticket {i}?", "expected_output": "open", "category": "simple"}
            for i in range(5)]
         + [{"question": "Status of ticket 0?", "category": "simple"}])


def evaluated(root: Path) -> Path:
    """A project with an evaluation dataset, one summary and one older MLflow run."""
    (root / "eval" / "outputs" / "run1").mkdir(parents=True)
    (root / "eval" / "dataset.jsonl").write_text(
        "\n".join(json.dumps(c) for c in CASES) + "\n", encoding="utf-8")
    (root / "eval" / "outputs" / "run1" / "summary.json").write_text(json.dumps(
        {"timestamp": "2026-09-01T10:00:00Z",
         "metrics": {"task_completion": 0.86, "prompt_injection_resistance": 0.93}}),
        encoding="utf-8")
    run = root / "mlruns" / "1" / "a1b2"
    (run / "metrics").mkdir(parents=True)
    (run / "meta.yaml").write_text("run_name: baseline-v1\nstart_time: 1756720800000\n",
                                   encoding="utf-8")
    (run / "metrics" / "task_completion").write_text("1 0.80 0\n2 0.84 1\n", encoding="utf-8")
    return root


@pytest.fixture
def with_files(tmp_path) -> dict:
    return answers(evaluated(tmp_path), AGENTIC, RULES)


@pytest.fixture
def without_files(tmp_path) -> dict:
    return answers(tmp_path, AGENTIC, RULES)


# ------------------------------------------------------------ files present --
def test_the_dataset_is_profiled_and_checked_against_the_guideline(with_files):
    text, evidence = with_files[CHARACTERISTICS]
    assert evidence == ["eval/dataset.jsonl:1"]
    assert "14 case(s)" in text and "multi-step 8 (57%)" in text
    assert "13/14 with a reference answer" in text and "1 duplicate question" in text
    assert "is BELOW the guideline minimum of 20 queries (EVAL-AGENTIC-QUERIES)" in text
    assert "No case labelled edge" in text
    assert "[A CONFIRMER - how the cases were selected" in text


def test_every_log_is_dated_with_a_digest_and_the_sign_off_stays_open(with_files, tmp_path):
    text, evidence = with_files[EXPERIMENT_LOGS]
    assert "2 dated experiment log(s)" in text
    assert "2026-09-01T10:00:00Z: task_completion 0.86" in text
    assert "MLflow run 'baseline-v1', 2025-09-01" in text and "task_completion 0.84" in text
    digests = re.findall(r"sha256 ([0-9a-f]{16})", text)
    assert len(digests) == 2
    assert "[A CONFIRMER - MLflow experiment URL and the sign-off" in text
    assert evidence == ["eval/outputs/run1/summary.json:1", "mlruns/1/a1b2/meta.yaml:1"]


def test_results_come_from_the_most_recent_run_and_name_robustness_metrics(with_files):
    text, _ = with_files[TEST_RESULTS]
    assert "'run1' (2026-09-01" in text, "the 2026 summary is more recent than the 2025 run"
    assert "Robustness metrics run: prompt_injection_resistance" in text


# ------------------------------------------------------------- files absent --
def test_absent_dataset_states_the_requirement_not_a_silent_gap(without_files):
    text, evidence = without_files[CHARACTERISTICS]
    assert evidence == []
    assert text.startswith("No evaluation dataset was found")
    assert "at least 20 queries (EVAL-AGENTIC-QUERIES)" in text


def test_absent_logs_say_how_to_produce_signed_logs(without_files):
    text, _ = without_files[EXPERIMENT_LOGS]
    assert "records.model_performance()" in text and "verify_chain.py" in text


def test_absent_results_are_stated_as_such(without_files):
    assert without_files[TEST_RESULTS][0].startswith("No test result was found")


def test_future_change_tests_follow_the_family(without_files):
    text, _ = without_files[FUTURE_TESTS]
    assert "10% or more blocking the release (MON-THRESHOLD-AGENTIC)" in text
    assert "MON-DRIFT-TOOLSET" in text and "DOC-UPDATE-ON-CHANGE" in text


# --------------------------------------------------------------- end to end --
def test_section_3_3_reaches_the_document_and_passes_the_validator(tmp_path):
    project = tmp_path / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    evaluated(project)
    done = subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                          capture_output=True, text=True)
    assert "Fix the blocking findings" not in done.stdout
    xml = zipfile.ZipFile(project / "aida" / "technical_documentation.docx").read(
        "word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", "", xml)
    assert "Evaluation data: 14 case(s)" in text
    assert "dated experiment log(s)" in text and "Robustness metrics run" in text
