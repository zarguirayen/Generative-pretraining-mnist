"""Section 2.4: hardware is stated from the scan - accelerators found, or none and why.

    python -m pytest tests/test_hardware.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-core" / "scripts"))
sys.path.insert(0, str(PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"))

from build_values import r_hardware  # noqa: E402
from scan_codebase import build_context  # noqa: E402


def test_a_managed_model_api_with_no_accelerator_is_stated_plainly(tmp_path):
    (tmp_path / "app.py").write_text(
        'MODEL = "anthropic.claude-haiku-4-5-20251001-v1:0"\n', encoding="utf-8")
    value, evidence = r_hardware(build_context(tmp_path), {})
    assert value.startswith("No dedicated hardware requirement")
    assert "managed API" in value and evidence == ["app.py:1"]
    assert "[A CONFIRMER - CPU and memory sizing" in value


def test_an_accelerator_in_the_code_is_cited(tmp_path):
    (tmp_path / "train.py").write_text("import torch\ndevice = torch.cuda.current_device()\n",
                                       encoding="utf-8")
    value, evidence = r_hardware(build_context(tmp_path), {})
    assert value.startswith("Dedicated hardware referenced") and evidence == ["train.py:2"]


def test_no_model_and_no_accelerator_says_nothing(tmp_path):
    (tmp_path / "billing.py").write_text("def total(items):\n    return sum(items)\n",
                                         encoding="utf-8")
    assert r_hardware(build_context(tmp_path), {}) is None
