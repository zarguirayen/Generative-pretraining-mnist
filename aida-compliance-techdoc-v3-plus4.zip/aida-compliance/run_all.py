#!/usr/bin/env python3
"""Run the whole aida-compliance chain on a project, end to end.

    python run_all.py <project_dir> [--inference-frequency daily]

A convenience wrapper for testing the plugin by hand: it calls the skills' scripts in
order and produces the filled Word document plus the audit report under <project>/aida/.
The skills themselves are what Copilot invokes; this just drives them without an agent so
you can see the result on a real project in one command.

Standard library only.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SKILLS = Path(__file__).resolve().parent / "skills"


def run(label: str, script: Path, *args: str, cwd: Path) -> bool:
    """Run one script of the chain in the project; findings (exit 1) do not stop it."""
    print(f"\n=== {label} ===")
    result = subprocess.run([sys.executable, str(script), *args], cwd=cwd)
    if result.returncode not in (0, 1):        # 1 = findings, still a success for us
        print(f"  (script exited {result.returncode})")
    return result.returncode in (0, 1)


def main() -> int:
    """Command line: run the whole chain on a project, end to end."""
    parser = argparse.ArgumentParser(description="Drive the full AIDA chain on a project.")
    parser.add_argument("project")
    parser.add_argument("--inference-frequency", default="daily",
                        choices=["daily", "weekly", "monthly", "quarterly"])
    args = parser.parse_args()

    project = Path(args.project).expanduser().resolve()
    if not project.is_dir():
        print(f"error: not a directory: {project}", file=sys.stderr)
        return 2

    core = SKILLS / "aida-core" / "scripts"
    techdoc = SKILLS / "aida-technical-documentation" / "scripts"
    oversight = SKILLS / "aida-human-oversight" / "scripts"
    records = SKILLS / "aida-record-keeping" / "scripts"
    genai = SKILLS / "aida-genai-monitoring" / "scripts"
    ops = SKILLS / "aida-operational-monitoring" / "scripts"
    freq = args.inference_frequency

    steps = [
        ("Scan the codebase", core / "scan_codebase.py",
         [".", "--out", "aida/context.json", "--quiet"]),
        ("Map the template fields", core / "placeholder_map.py",
         ["--context", "aida/context.json", "--out", "aida/placeholders.json"]),
        ("Emit the ML-BOM", core / "aida_bom.py",
         ["--context", "aida/context.json", "--out", "aida/ml-bom.json"]),
        ("Derive the code + rule answers", techdoc / "build_values.py",
         ["--context", "aida/context.json", "--map", "aida/placeholders.json",
          "--out", "aida/values.json"]),

        ("Audit human oversight", oversight / "audit_oversight.py",
         [".", "--out", "aida/oversight_audit.json"]),
        ("Write section 3.9", oversight / "write_section.py",
         ["--audit", "aida/oversight_audit.json", "--values", "aida/values.json",
          "--map", "aida/placeholders.json"]),

        ("Audit record keeping", records / "audit_records.py",
         [".", "--out", "aida/records_audit.json"]),
        ("Write section 3.7", records / "write_section.py",
         ["--audit", "aida/records_audit.json", "--values", "aida/values.json",
          "--map", "aida/placeholders.json"]),

        ("Plan GenAI monitoring", genai / "plan_monitoring.py",
         ["--context", "aida/context.json", "--project", ".",
          "--inference-frequency", freq, "--out", "aida/monitoring_plan.json"]),
        ("Write section 3.8 (model)", genai / "write_section.py",
         ["--plan", "aida/monitoring_plan.json", "--values", "aida/values.json",
          "--map", "aida/placeholders.json"]),

        ("Plan operational monitoring", ops / "plan_operational.py",
         ["--context", "aida/context.json", "--records", "aida/records_audit.json",
          "--inference-frequency", freq]),
        ("Check dependency resilience", ops / "check_resilience.py",
         [".", "--out", "aida/resilience.json"]),
        ("Write section 3.8 (operational)", ops / "write_section.py",
         ["--plan", "aida/operational_plan.json", "--resilience", "aida/resilience.json",
          "--values", "aida/values.json", "--map", "aida/placeholders.json"]),

        ("Draw the architecture + performance figures", techdoc / "render_figures.py",
         ["--context", "aida/context.json", "--aida", "aida"]),
        ("Write the introduction, last", techdoc / "write_introduction.py",
         ["--context", "aida/context.json", "--values", "aida/values.json",
          "--map", "aida/placeholders.json", "--aida", "aida"]),

        ("Write the section 5 validation table", techdoc / "write_validation_table.py",
         ["--context", "aida/context.json", "--aida", "aida", "--out", "aida/validation_table.json"]),

        ("Open the AI System Journal (appendix)", techdoc / "write_journal.py",
         ["--context", "aida/context.json", "--aida", "aida", "--out", "aida/journal.json"]),

        ("Validate every answer", core / "validate_values.py",
         ["--values", "aida/values.json", "--map", "aida/placeholders.json",
          "--context", "aida/context.json"]),
        ("Fill the official template", core / "fill_docx.py",
         ["--values", "aida/values.json", "--map", "aida/placeholders.json",
          "--figures", "aida/figures.json",
          "--validation-table", "aida/validation_table.json", "--journal", "aida/journal.json", "--out", "aida/technical_documentation.docx"]),

        ("Full audit + scorecard", SKILLS / "aida-audit" / "scripts" / "run_audit.py",
         [".", "--inference-frequency", freq, "--out", "aida/audit.json"]),
        ("Render the audit report", SKILLS / "aida-audit" / "scripts" / "render_report.py",
         ["--audit", "aida/audit.json", "--out", "aida/audit_report.md"]),
    ]

    for label, script, script_args in steps:
        if not run(label, script, *script_args, cwd=project):
            print(f"\nstopped at: {label}")
            return 1

    print("\n" + "=" * 60)
    print("Done. Look under", project / "aida")
    print("  technical_documentation.docx   the filled official template")
    print("  technical_documentation_a_confirmer.json   the open points")
    print("  audit_report.md                the scorecard and gap analysis")
    print("  ml-bom.json                    the CycloneDX inventory")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
