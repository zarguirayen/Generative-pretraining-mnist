#!/usr/bin/env python3
"""Inventory the {placeholders} of the AIDA technical documentation template.

    python placeholder_map.py [--template PATH] [--context aida/context.json]
                              [--out aida/placeholders.json] [--report]

Each placeholder is routed to where its answer can legitimately come from:

    code      the scan already proves it - fill it, cite file:line
    rule      a guideline rule determines it (frequency, thresholds, retention)
    external  lives in another internal system (GAD, RPAD, MESARI, NSU, MLflow)
    human     only the risk owner can answer - never guess it

The point of the split is the last line: anything routed to `human` or `external` is
written as [A CONFIRMER] rather than invented. Standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
PLACEHOLDER = re.compile(r"\{([^{}]{3,})\}")
HEADING = re.compile(r"(?:Heading|Titre|heading)(\d)")

DEFAULT_TEMPLATE = Path(__file__).resolve().parent.parent / "assets" / "templates" / "technical_documentation.docx"

# Ordered routing table: first keyword that matches a placeholder decides its source.
# `path` is a dotted lookup into context.json when the source is `code`.
ROUTES: list[tuple[str, str, str | None, str]] = [
    # keyword (lowercase, matched as substring)   source      context path                    note
    # The introduction is a summary of the sections below, assembled last by
    # write_introduction.py. It must come before "intended purpose", which it mentions:
    # the purpose inside it stays an open point, the rest is built from evidence.
    ("provide an overview about the ai system",   "rule",     None,  "assembled from the other sections"),
    # --- header block: identity, version, ownership --------------------------------
    ("unique ai system id",                       "human",    None,  "assigned by AI governance"),
    ("version of the ai system",                  "code",     "git.tag",  "fall back to git describe / VERSION file"),
    ("documentation version",                     "rule",     None,  "bump on every regeneration; date = today"),
    ("risk level under ai act",                   "human",    None,  "VRM risk category drives which obligations apply"),
    ("responsible person",                        "human",    None,  "system owner / risk owner"),
    ("persons that contributed",                  "human",    None,  "documentation authors"),
    ("last date of validation",                   "external", None,  "AI governance validation record"),

    # --- 2.1 system overview ---------------------------------------------------------
    ("intended purpose",                          "human",    None,  "the one thing code cannot state"),
    ("tasks or problems",                         "human",    None,  "intended purpose"),
    ("use cases and target users",                "human",    None,  "role, location, number of users"),
    ("limitations or constraints",                "human",    None,  "confirm with risk owner; seed from TODO/FIXME"),
    ("legal name",                                "human",    None,  "provider entity"),
    ("contact information",                       "human",    None,  None),
    ("versioning system",                         "code",     "git",  "SemVer if tags follow it"),
    ("current version improves",                  "code",     "git.last_commit_date",  "seed from CHANGELOG if present"),

    # --- 2.2 to 2.7 interaction, compatibility, hardware, interface ------------------
    # Hardware is read from the scan: accelerators referenced, or a managed model API and
    # none - which is a statement, not a gap. The sizing of the host stays open.
    ("hardware components",                       "code",     "hardware",  "accelerators, else managed API"),
    ("software dependencies",                     "code",     "dependencies",  "name + version + evidence"),
    ("other ai systems",                          "code",     "endpoints",  "outbound calls to model APIs"),
    ("compatible versions",                       "code",     "dependencies",  None),
    ("minimum hardware",                          "code",     "hardware",  "accelerators, else managed API"),
    ("update process",                            "code",     "infrastructure.ci",  None),
    ("user interface",                            "human",    None,  "screenshots"),
    ("photographs or illustrations",              "human",    None,  "not derivable"),
    ("instructions of use",                       "human",    None,  "external systems only"),

    # --- 3.1 data handling -----------------------------------------------------------
    # A pre-trained model with no in-house training: what the code shows about the data
    # (none trained on, the knowledge base, how it is loaded, chunked and embedded) is
    # stated with evidence. With training code in the project these stay the owner's.
    ("general description of the used data",      "code",     "data",  "pre-trained model, knowledge base"),
    ("data provenance",                           "code",     "data",  "provider of the model, source of the documents"),
    ("scope and main characteristics of the data set", "code", "data", "no training set; knowledge base and evaluation set"),
    ("data acquisition and selection",            "code",     "data",  "document loaders"),
    ("labeling procedures",                       "code",     "data",  "no labelling beyond the evaluation set"),
    ("pretreatment",                              "code",     "data",  "document chunking"),
    ("feature engineering",                       "code",     "data",  "embeddings"),
    # Must precede "data set": the procedures field mentions "data sets selection methods".
    ("describe validation and testing procedures", "rule",    None,  "EVAL-* dataset size rules"),
    ("used data",                                 "human",    None,  "dataset description"),
    ("data provenance",                           "human",    None,  None),
    ("data set",                                  "human",    None,  None),
    ("labeling procedures",                       "human",    None,  None),
    ("pretreatment",                              "human",    None,  "data preparation choices, not visible in code"),
    ("specialized hardware",                      "code",     "hardware",  "accelerators, else managed API"),
    ("feature engineering",                       "code",     None,  "transformation code if present"),

    # --- 3.2 development, 3.3 validation and testing --------------------------------
    # "model training (tested" is deliberately narrow: a bare "model training" also
    # matches "...with model training metrics" in the monitoring section and would
    # shadow the rule that belongs there.
    ("model training (tested",                    "code",     "evaluation",  "MLflow experiment if present"),
    ("fine-tuning",                               "code",     None,  None),
    ("evaluation metrics",                        "rule",     None,  "EVAL-RAG-METRICS / EVAL-AGENTIC-CATEGORIES"),
    ("third-party models",                        "code",     "model_providers",  None),
    ("validation and testing procedures",         "rule",     None,  "EVAL-* dataset size rules"),
    # The four 3.3 / 3.4 evidence fields are answered by profile_evaluation.py: what the
    # evaluation files show, or - when they do not exist - what the guideline requires and
    # how to produce it. Case selection, MLflow URL and sign-off stay open inside the answer.
    ("results of the robustness",                 "rule",     None,  "latest evaluation run, else how to produce it"),
    ("robustness",                                "rule",     None,  "guideline robustness metrics"),
    ("experiments logs",                          "rule",     None,  "dated runs with SHA-256 digest, else how to produce them"),
    ("mlflow",                                    "external", None,  "MLflow experiment link"),

    # --- 3.4 design specifications and model performance ----------------------------
    ("general logic of the selected model",       "code",     "classification",  None),
    ("rationale behind the choice of this model", "human",    None,  None),
    ("key assumptions",                           "human",    None,  None),
    ("trade-offs",                                "human",    None,  None),
    ("predictive performance",                    "external", None,  "evaluation-pipeline summary.json if present"),
    ("explainability",                            "rule",     None,  "OVERSIGHT-EXPLAINABILITY - at least one measure"),
    ("guardrails",                                "code",     "security",  None),
    ("model artefacts",                           "code",     "git.remote",  "versioned code + stored model"),

    # --- 3.5 architecture ------------------------------------------------------------
    ("gad documentation",                         "external", None,  "GAD - internal architecture document"),
    ("rpad documentation",                        "external", None,  "RPAD - internal architecture document"),
    ("computational resources",                   "code",     "infrastructure",  None),
    ("feedback loops",                            "code",     "oversight_signals",  None),

    # --- 3.6 deployment --------------------------------------------------------------
    ("installation and configuration",            "code",     "infrastructure",  "Dockerfile / env files"),
    ("form of distribution",                      "code",     "infrastructure.docker",  None),
    ("deployment platforms",                      "code",     "infrastructure",  None),
    ("operational environment",                   "code",     "infrastructure",  None),
    ("ci/cd",                                     "code",     "infrastructure.ci",  None),
    ("rollback",                                  "code",     "infrastructure.ci",  None),

    # --- 3.7 record keeping (written by aida-record-keeping) ------------------------
    ("historization",                             "rule",     None,  "REC-MODEL-MANDATORY - 6 mandatory records"),
    ("logs of the main events",                   "rule",     None,  "REC-OPERATIONAL-MANDATORY - what/when/who"),
    ("users feedback",                            "rule",     None,  "MON-USER-FEEDBACK - thumbs up/down + reason"),
    ("tools used for record keeping",             "code",     "observability",  None),

    # --- 3.8 monitoring (written by the two monitoring skills) ----------------------
    ("metrics used for model monitoring",         "rule",     None,  "MON-GENAI-QUALITY-MINIMUM"),
    ("alignment between the choice",              "rule",     None,  "baseline = build-phase evaluation metrics"),
    ("metrics used for the operational",          "rule",     None,  "MON-OPERATIONAL-MINIMUM - Table 5"),
    ("performance drops",                         "rule",     None,  "MON-THRESHOLD-* per family"),
    ("logging mechanisms",                        "code",     "logging",  None),
    ("monitoring schedule",                       "rule",     None,  "MON-FREQUENCY - derived from inference frequency"),
    ("baseline choice",                           "rule",     None,  "build-phase evaluation metrics"),
    ("alert mechanism",                           "rule",     None,  "MON-OPERATIONAL-MINIMUM thresholds"),
    ("addressing alerts",                         "rule",     None,  "investigate, justify, corrective measures"),

    # --- 3.9 human oversight (written by aida-human-oversight) ----------------------
    ("human oversight measure",                   "rule",     None,  "OVERSIGHT-CAPABILITIES + OVERSIGHT-INTERVENTION"),
    ("names of the human overseers",              "human",    None,  "named natural persons"),
    ("alerts or action put in place",             "rule",     None,  "logged in the AI System Journal"),

    # --- 3.10 cybersecurity ----------------------------------------------------------
    ("red teaming",                               "code",     "security",  "DeepTeam if present"),
    ("iss opinion",                               "external", None,  "NSU"),
    ("mesari",                                    "external", None,  "MESARI documentation"),
    ("penetration test",                          "external", None,  "CAGIP vulnerability reports"),

    # --- 4 updates and changes, 5 model validation, 6-7 external systems ------------
    ("substantial changes",                       "code",     "git.last_commit_date",  None),
    ("continuous compliance",                     "rule",     None,  "DOC-UPDATE-ON-CHANGE"),
    ("change of usage procedure",                 "external", None,  "AIDA governance"),
    ("risk management setup",                     "external", None,  "AIDA validation record"),
    ("validation documentation",                  "external", None,  "AIDA opinion"),
    ("harmonized standards",                      "external", None,  "external systems only"),
    ("declaration of conformity",                 "external", None,  "external systems only"),

    # --- second pass: placeholders the first pass left unrouted -----------------
    ("ai system name",                            "code",     "project.name",  None),
    ("nature of these interactions",              "human",    None,  None),
    ("purpose and method of these interactions",  "human",    None,  None),
    ("dependencies that must be updated",         "code",     "dependencies",  None),
    ("updates may affect system performance",     "human",    None,  None),
    ("hardware requirements",                     "code",     "hardware",  "accelerators, else managed API"),
    ("marking and branding",                      "human",    None,  "external systems only"),
    ("main features and controls",                "human",    None,  "user interface"),
    ("screenshots",                               "human",    None,  None),
    ("full instruction of use",                   "external", None,  "instructions-of-use document"),
    ("data acquisition and selection",            "human",    None,  None),
    ("prediction post processing",                "code",     None,  "post-processing code if present"),
    ("used as-is, fine-tuned",                    "human",    None,  None),
    ("rationale behind choosing these third-party", "human",  None,  None),
    ("characteristics of the validation and testing data", "rule", None, "evaluation dataset profile vs EVAL-*"),
    ("future expected changes",                   "rule",     None,  "regression tests re-run on every change"),
    ("validation and testing is integrated",      "human",    None,  None),
    ("tools and processes put in place",          "code",     "observability",  None),
    ("solutions adopted to meet the requirements", "external", None, "external systems only"),
]

# Text that sits between braces but is guidance for the author, not a field to answer.
# It is kept in the document with the braces stripped - never turned into [A CONFIRMER].
INSTRUCTION_PREFIXES = ("nb:",)
INSTRUCTION_EXACT = {"brackets"}


def is_instruction(text: str) -> bool:
    low = text.strip().lower()
    return low in INSTRUCTION_EXACT or low.startswith(INSTRUCTION_PREFIXES)


def para_text(p: ET.Element) -> str:
    return "".join(t.text or "" for t in p.iter(W + "t"))


def heading_level(p: ET.Element) -> int | None:
    pr = p.find(W + "pPr")
    if pr is None:
        return None
    style = pr.find(W + "pStyle")
    if style is None:
        return None
    m = HEADING.match(style.get(W + "val") or "")
    return int(m.group(1)) if m else None


def route(text: str) -> tuple[str, str | None, str | None]:
    if is_instruction(text):
        return "instruction", None, "template guidance, kept as-is"
    low = text.lower()
    for keyword, source, path, note in ROUTES:
        if keyword in low:
            return source, path, note
    return "human", None, "no routing rule matched - review this placeholder"


def extract(template: Path) -> list[dict]:
    with zipfile.ZipFile(template) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    body = root.find(W + "body")
    if body is None:
        return []

    found: list[dict] = []
    section = "front matter"
    for para in body.iter(W + "p"):
        text = para_text(para).strip()
        if not text:
            continue
        if heading_level(para) is not None:
            section = text
            continue
        for raw in PLACEHOLDER.findall(text):
            cleaned = " ".join(raw.split())
            source, path, note = route(cleaned)
            found.append({
                "section": section,
                "placeholder": cleaned,
                "source": source,
                "context_path": path,
                "note": note,
            })
    return found


def lookup(ctx: dict, dotted: str | None):
    if not dotted:
        return None
    node = ctx
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def resolve(entries: list[dict], ctx: dict | None) -> list[dict]:
    for entry in entries:
        if entry["source"] == "instruction":
            entry["resolved"] = None          # not a question, so not a gap either
        elif entry["source"] == "code":
            entry["resolved"] = bool(lookup(ctx, entry["context_path"])) if ctx else False
        else:
            entry["resolved"] = entry["source"] == "rule"
    return entries


def report(entries: list[dict]) -> str:
    fields = [e for e in entries if e["source"] != "instruction"]
    total = len(fields)
    by_source: dict[str, int] = {}
    for e in fields:
        by_source[e["source"]] = by_source.get(e["source"], 0) + 1
    auto = sum(1 for e in fields if e.get("resolved"))
    pct = (auto * 100 // total) if total else 0

    lines = [
        f"Placeholders in template : {len(entries)}"
        f"   ({len(entries) - total} are template guidance, not fields)",
        f"Fields to answer         : {total}",
        f"Auto-fillable now        : {auto}  ({pct}%)",
        f"To confirm with a human  : {total - auto}",
        "",
        "By source:",
    ]
    labels = {
        "code": "from the codebase scan",
        "rule": "determined by a guideline rule",
        "external": "lives in another internal system",
        "human": "only the risk owner can answer",
    }
    for source in ("code", "rule", "external", "human"):
        if source in by_source:
            lines.append(f"  {source:<9} {by_source[source]:>3}   {labels[source]}")

    sections: dict[str, list[int]] = {}
    for e in fields:
        bucket = sections.setdefault(e["section"], [0, 0])
        bucket[0] += 1
        bucket[1] += 1 if e.get("resolved") else 0
    lines += ["", "By section:"]
    for name, (count, done) in sections.items():
        short = name if len(name) <= 52 else name[:49] + "..."
        lines.append(f"  {short:<54} {done:>2}/{count:<3}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Inventory the AIDA template placeholders.")
    parser.add_argument("--template", default=str(DEFAULT_TEMPLATE))
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--out", default="aida/placeholders.json")
    parser.add_argument("--report", action="store_true", help="print the coverage report")
    args = parser.parse_args()

    template = Path(args.template)
    if not template.exists():
        print(f"error: template not found: {template}", file=sys.stderr)
        return 2

    ctx = None
    ctx_path = Path(args.context)
    if ctx_path.exists():
        ctx = json.loads(ctx_path.read_text(encoding="utf-8"))

    entries = resolve(extract(template), ctx)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"template": template.name, "placeholders": entries},
                              indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    if args.report or ctx is None:
        print(report(entries))
        if ctx is None:
            print("\n(no context.json - run scan_codebase.py first for real coverage)")
    print(f"\nplaceholder map written to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
