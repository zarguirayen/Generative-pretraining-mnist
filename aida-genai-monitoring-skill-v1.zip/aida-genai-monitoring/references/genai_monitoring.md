# GenAI model monitoring

Source: AI Factory, *Monitoring and Human Oversight* guideline, section 4.4 — EU AI Act
Article 72. Applies to all risk categories.

## Contents

- [The method, in one paragraph](#the-method-in-one-paragraph)
- [Frequency](#frequency)
- [Prompt systems](#prompt-systems)
- [RAG systems](#rag-systems)
- [Agentic systems](#agentic-systems)
- [Drift](#drift)
- [User feedback as ground truth](#user-feedback-as-ground-truth)
- [When an alert fires](#when-an-alert-fires)

---

## The method, in one paragraph

Set a baseline from the build-phase evaluation, compute the same metrics continuously in
production, alert on a relative drop past the threshold, investigate, justify whether
corrective measures are taken, and record all of it. The baseline is what makes a
production score mean anything: without it there is nothing to compare against, and the
threshold is arbitrary.

## Frequency

`MON-FREQUENCY`. Proportionate to inference frequency and to system risk:

| Inference | Monitoring |
|---|---|
| daily | weekly |
| weekly | monthly |
| monthly | quarterly |
| quarterly | yearly |

Risk owners may propose another frequency with a justification submitted to the validation
stakeholders. Cumulative batches may be used to smooth the metric over time.

## Prompt systems

Alert on a **20% or greater relative drop** (`MON-THRESHOLD-PROMPT`).

| Metric | How | Tier |
|---|---|---|
| Faithfulness | LLM as judge | hallucination against the context |
| Relevancy | LLM as judge | does the output address the input |
| Correctness | LLM as judge | factual, against ground truth |
| Answer correctness | human feedback | ratio from user judgements |
| Usefulness score | human feedback | Likert scale, compared to model judgement |

At least one must be monitored.

## RAG systems

Alert on a **10% or greater relative drop** (`MON-THRESHOLD-RAG`).

Evaluation must cover **both** retriever and generator, so monitoring does too.

- Generation: faithfulness, relevancy, correctness.
- Retrieval: recall, precision, contextual relevancy, MRR, NDCG.

Data prerequisites from the evaluation guideline carry over: at least **50 questions** and
a curated knowledge base of at least **20 documents**.

## Agentic systems

Alert on a **10% or greater relative drop** (`MON-THRESHOLD-AGENTIC`), with **at least one
metric from each category**:

| Category | Metrics |
|---|---|
| Task | success rate, pass@k, accuracy / F1, custom task metrics |
| Path | trajectory efficiency, consistency, stability, number of steps, trajectory similarity |
| Tools | tool call accuracy, argument correctness, tool efficiency, tool call correctness |
| Reasoning | reasoning quality |
| System | latency, total tokens |

The evaluation set needs at least **20 queries** spanning simple, complex and edge cases,
including some the agent should not or cannot answer.

## Drift

Tracking metrics over time is completed by drift analysis, and it becomes necessary for
high-risk systems or when ground truth is hard to collect continuously.

**Queries drift.** Group production queries into task types — expert categorisation, or
clustering on embeddings with an LLM labelling the clusters — then compare the distribution
against pre-production with a chi-square test, alerting below a p-value of 0.05.

**Knowledge base drift** (RAG). The corpus is updated in production; compare it against its
pre-production state, and document the decision to include or exclude the drifted data.

**Question test set drift** (RAG). User questions move too. Keep a separate set of edge
cases the system struggled with, to drive future development.

**Tool set drift** (agentic), `MON-DRIFT-TOOLSET`, and the one that is fully mechanical:

- a tool **added or removed** → alert, it is critical;
- a tool **parameter added or removed** → alert, it is critical;
- a tool **description changed** → monitor as NLP drift, because the description is what
  steers the model's choice.

`detect_tool_drift.py` implements exactly this between two git revisions.

**Tool response drift** (agentic). Responses from black-box tools — behind an MCP server,
for instance — vary over time. Monitor them the way a knowledge base is monitored.

## User feedback as ground truth

`MON-USER-FEEDBACK`. Ground truth is expensive, so the guideline leans on users: a thumbs
up / thumbs down control, and **on a negative signal the user must be able to say what went
wrong** — the generated answer, the retrieval (RAG), or the sequence of tools (agentic).

For a RAG system, a user who says retrieval failed should be able to point at the correct
passage, or at least the page. Overall satisfaction counts are monitored over time as a
metric in their own right.

## When an alert fires

1. **Investigate** — new topics, untrained users, a changed usage pattern, a prompt or
   model update.
2. **Justify** — whether corrective measures are taken, and if not, why.
3. **Correct** — user training, prompt or guardrail updates, dataset refresh, retraining.
4. **Record** — metrics over time in a database or MLflow, and the substantial alerts,
   investigations and measures in the AI System Journal (`DOC-JOURNAL`).

Risk owners may adopt stricter thresholds, never looser ones.
