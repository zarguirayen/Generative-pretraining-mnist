#!/usr/bin/env python3
"""Write the AI Model Monitoring half of section 3.8 from the monitoring plan.

    python write_section.py --plan aida/monitoring_plan.json --values aida/values.json

The plan holds the metric set for the system family, the thresholds derived from the
measured baseline, the schedule and the drift methodology. This puts them into the fields
the official template asks for, with every number carrying the rule that fixes it.

The two halves of 3.8 are written by different skills and must not be mixed: the
operational half belongs to `aida-operational-monitoring`.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

METRICS = "List and justification of the choice of the metrics used for model monitoring"
ALIGNMENT = ("Explanation of the alignment between the choice of these metrics with model "
             "training metrics and the risks to be monitored.")
DROPS = "Procedures for identifying and addressing performance drops."
SCHEDULE = "Monitoring schedule: frequency of monitoring metrics computation."
BASELINE = "Baseline choice: the choice of the baseline for alert triggering."


def implemented(monitor: dict | None) -> str:
    """What runs, when the monitor was generated - the mechanism, not the intention."""
    if not monitor:
        return (" [A CONFIRMER - the monitor is not generated yet: run generate_monitor.py, "
                "MON-TIMING requires monitoring in place before the end of the build phase]")
    window = monitor["window"]
    by_method: dict[str, list[str]] = {}
    for metric in monitor["metrics"]:
        by_method.setdefault(metric["method"], []).append(metric["metric"])
    return (f" Implemented by aida/monitoring/genai_monitor.py, scheduled {window['period']} "
            f"(aida/monitoring/schedule/): each run reads the period's inference, ground-truth "
            f"and feedback records from the record-keeping journal, computes "
            + "; ".join(f"{', '.join(names)} from {method.replace('_', ' ')}"
                        for method, names in sorted(by_method.items()))
            + f", alerts after {window['consecutive_breaches']} period(s) past the threshold "
              f"with at least {window['min_samples']} inferences, tests the query mix for "
              f"drift (chi-square, p < {monitor['drift']['p_value_below']}), flags personal "
              f"data in any answer, and appends each alert - value, baseline, threshold, "
              f"explanation, requests to review - to the same hash-chained journal. "
              f"Machine-readable rules: aida/monitoring/alert_rules_quality.json.")


def threshold_phrase(metric: dict) -> str:
    """'alert below 0.774', or 'alert above 3.6' for a metric that degrades upwards."""
    side = "above" if metric.get("direction") == "lower" else "below"
    return f"alert {side} {metric['alert_threshold']}"


def metrics_text(plan: dict) -> str:
    """Which metrics are monitored and why: the family, the scope, the baselines."""
    level = f" ({plan['agentic_level']})" if plan.get("agentic_level") else ""
    with_threshold = [m for m in plan["metrics"] if m["alert_threshold"] is not None]
    without = [m for m in plan["metrics"] if m["alert_threshold"] is None]
    scope = plan.get("scope") or {}
    ruled = "; ".join(f"{r['family']} ({r['evidence']})" for r in scope.get("ruled_out", []))
    return (
        f"System family: {plan['family']}{level}. "
        + (f"Monitoring variant: {scope['variant'].replace('_', ' ')} - "
           f"{scope['consequence']}. " if scope.get("variant") else "")
        + (f"Ruled out, with the evidence: {ruled}. " if ruled else "")
        + "The metrics monitored in production are the ones computed during the build-phase "
          "evaluation, which is what makes a production score interpretable at all. "
        + ("Metrics with a measured baseline: "
           + "; ".join(f"{m['metric']} (baseline {m['baseline']}, {threshold_phrase(m)})"
                       for m in with_threshold) + ". "
           if with_threshold else "No metric has a measured baseline yet. ")
        + (f"Metrics still to be baselined before the end of the build phase: "
           f"{', '.join(m['metric'] for m in without)}. " if without else "")
        + "Safety signals need no baseline - any occurrence is a signal: "
        + ", ".join(s["metric"].replace("_", " ") for s in plan["safety_signals"]) + ".")


def alignment_text(plan: dict) -> str:
    """Why these metrics fit the model: they are the evaluation's, computed the same way."""
    return (
        "The monitoring metrics are the evaluation metrics of the build phase, computed the "
        "same way, so production and evaluation remain comparable. "
        + (f"The baseline comes from {plan['baseline_source']}."
           if plan.get("baseline_source")
           else "No build-phase evaluation was found, so no baseline exists yet; the "
                "guideline requires it to be established before the end of the build phase.")
        + " The risks monitored are degradation of answer quality, hallucination, and - for "
          "a retrieval or agentic system - drift in the corpus, the query mix and the tool set.")


def drops_text(plan: dict, monitor: dict | None) -> str:
    """The alert threshold and what an alert sets in motion."""
    return (
        f"A relative performance decrease of {plan['relative_drop_pct']:g}% or more against "
        f"the build-phase baseline triggers an alert ({plan['threshold_rule']}). A stricter "
        f"threshold may be adopted and justified; a looser one may not. The alert opens an "
        f"investigation into the cause - new topics, untrained users, a changed usage "
        f"pattern, a prompt or model update - and the decision whether to take corrective "
        f"measures is documented either way, in the AI System Journal (DOC-JOURNAL). "
        f"Corrective measures range from user training and prompt or guardrail updates to "
        f"dataset refresh and retraining." + implemented(monitor))


def schedule_text(plan: dict) -> str:
    """The monitoring frequency, derived from the inference frequency."""
    schedule = plan["schedule"]
    return (
        f"Monitoring frequency follows inference frequency ({schedule['rule']}): daily "
        f"inference to weekly monitoring, weekly to monthly, monthly to quarterly, "
        f"quarterly to yearly. "
        + (f"This system is called {schedule['inference_frequency']}, so monitoring runs "
           f"{schedule['monitoring_frequency']}."
           if schedule.get("monitoring_frequency")
           else "The inference frequency is [A CONFIRMER - not observable from the code], "
                "so the schedule cannot be derived yet.")
        + " Cumulative batches may be used to smooth the metric over time.")


def baseline_text(plan: dict) -> str:
    """Where the baseline comes from, and the drift monitoring that completes it."""
    if plan.get("baseline_source"):
        text = ("The baseline is the set of metrics measured during the build-phase "
                f"evaluation, recorded in {plan['baseline_source']}.")
    else:
        text = ("The baseline must be the set of metrics measured during the build-phase "
                "evaluation. None was found in the project, so alert thresholds cannot be "
                "justified until it exists.")
    if plan["drift"]:
        text += (" Drift monitoring completes the metric baseline: "
                 + "; ".join(f"{d['kind']} - {d['how']}" for d in plan["drift"]) + ".")
    return text


def build(plan: dict, monitor: dict | None = None) -> dict[str, dict]:
    """The five model-monitoring fields of section 3.8, from the plan."""
    return {
        METRICS: entry(metrics_text(plan), source="rule"),
        ALIGNMENT: entry(alignment_text(plan), source="rule"),
        DROPS: entry(drops_text(plan, monitor), source="rule"),
        SCHEDULE: entry(schedule_text(plan), source="rule"),
        BASELINE: entry(baseline_text(plan), source="rule"),
    }


def main() -> int:
    """Command line: merge section 3.8 (model monitoring) into aida/values.json."""
    parser = argparse.ArgumentParser(
        description="Write the AI Model Monitoring half of section 3.8.")
    parser.add_argument("--plan", default="aida/monitoring_plan.json")
    parser.add_argument("--monitor", default="aida/monitoring/genai_monitor_config.json",
                        help="configuration written by generate_monitor.py, when it has run")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json",
                        help="placeholder map - the authority on where an answer may come from")
    args = parser.parse_args()

    plan_path = Path(args.plan)
    if not plan_path.exists():
        print(f"error: plan not found: {plan_path}\n"
              f"       run plan_monitoring.py first", file=sys.stderr)
        return 2

    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    values_path = Path(args.values)
    monitor_path = Path(args.monitor)
    monitor = (json.loads(monitor_path.read_text(encoding="utf-8"))
               if monitor_path.exists() else None)
    result = merge(values_path, build(plan, monitor), Path(args.routing))
    print(report(result, "3.8 AI Model Monitoring", values_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
