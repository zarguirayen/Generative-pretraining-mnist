#!/usr/bin/env python3
"""Section 5: the AIDA validation table, one row per documented version.

    python write_validation_table.py --context aida/context.json --aida aida

Section 5 of the template ends with a table - AI System version | Changes description |
AIDA Opinion | Additional Information - the formal record of what AIDA said about each
version. Three of the four cells are facts this plugin already holds:

* the version: the git tag, else the commit;
* the changes: the commits since the previous tag, else "first documented version", with
  the scope the scan proved (family, autonomy level, models, model-callable tools);
* the additional information: validation status, and the blocking gaps the audits found,
  which are what AIDA will check first.

The opinion itself is AIDA's: it stays a numbered open point, never a guess. Rows for
earlier versions, entered by the team (`"origin": "manual"` in aida/validation_table.json),
are kept, so the table carries the history the template asks for.

Writes aida/validation_table.json, which fill_docx.py writes into the section 5 table.
Standard library only.
"""

from __future__ import annotations

import argparse
import json
import subprocess
from collections import Counter
from datetime import date
from pathlib import Path

COLUMNS = ("AI System version", "Changes description", "AIDA Opinion", "Additional Information")
AUDITS = ("oversight_audit.json", "records_audit.json", "monitoring_plan.json",
          "operational_plan.json", "resilience.json")
OPINION = ("[A CONFIRMER - AIDA opinion on this version (favourable, favourable with "
           "reservations or unfavourable), its date and reference]")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def git(root: str, *args: str) -> str | None:
    try:
        done = subprocess.run(["git", "-C", root, *args], capture_output=True, text=True,
                              timeout=15)
    except (OSError, subprocess.SubprocessError):
        return None
    return done.stdout.strip() if done.returncode == 0 and done.stdout.strip() else None


def version_of(ctx: dict) -> str:
    repo = ctx.get("git") or {}
    if repo.get("tag"):
        return f"{repo['tag']} (git tag)"
    if repo.get("commit"):
        return f"untagged, commit {repo['commit'][:12]}"
    return "[A CONFIRMER - version identifier: no git tag or commit found]"


def scope_of(ctx: dict, oversight: dict | None) -> str:
    cls = ctx.get("classification") or {}
    parts = [f"{cls.get('family', 'unknown')} system"]
    if cls.get("agentic_level"):
        parts.append(f"autonomy {cls['agentic_level']}")
    if ctx.get("models"):
        parts.append("models " + ", ".join(list(ctx["models"])[:3]))
    tools = ((oversight or {}).get("counts") or {}).get("tools")
    if tools is not None:
        parts.append(f"{tools} model-callable tool(s)")
    evidence = ", ".join((cls.get("family_evidence") or [])[:2])
    return "; ".join(parts) + (f" [{evidence}]" if evidence else "")


def changes_of(ctx: dict, oversight: dict | None) -> str:
    root = (ctx.get("project") or {}).get("path", ".")
    tag = (ctx.get("git") or {}).get("tag")
    previous = git(root, "describe", "--tags", "--abbrev=0", f"{tag}^") if tag else None
    scope = scope_of(ctx, oversight)
    if previous:
        subjects = (git(root, "log", "--format=%s", f"{previous}..{tag}") or "").splitlines()
        listed = "; ".join(subjects[:6]) + (f" (+{len(subjects) - 6} more)" if len(subjects) > 6 else "")
        return (f"Since {previous}: {len(subjects)} commit(s) - {listed} [git log {previous}..{tag}]. "
                f"Scope at this version: {scope}.")
    return f"First version documented for AIDA. Scope: {scope}."


def blocking_gaps(folder: Path) -> Counter:
    gaps: Counter = Counter()
    for name in AUDITS:
        for finding in (load(folder / name) or {}).get("findings", []):
            if finding.get("severity") == "blocking":
                gaps[finding["rule"]] += 1
    return gaps


def additional_of(folder: Path, today: str) -> str:
    gaps = blocking_gaps(folder)
    text = (f"Validation not yet performed for this version; documentation generated on "
            f"{today}. ")
    text += ("Blocking gaps to close before validation, by rule: "
             + ", ".join(f"{rule} ({n})" for rule, n in sorted(gaps.items())) + ". "
             if gaps else "The audits found no blocking gap. ")
    return (text + "Every open point of this document is listed, with its owner, in the "
                   "completion status section. Validation documentation: [A CONFIRMER - link "
                   "to the AI system risk evaluation and the validation feedback]")


def build(ctx: dict, folder: Path, previous: list[dict], today: str) -> list[dict]:
    current = {"cells": [version_of(ctx), changes_of(ctx, load(folder / "oversight_audit.json")),
                         OPINION, additional_of(folder, today)],
               "origin": "generated"}
    history = [row for row in previous
               if row.get("origin") == "manual" and row["cells"][0] != current["cells"][0]]
    return history + [current]


def main() -> int:
    parser = argparse.ArgumentParser(description="Write the section 5 AIDA validation table.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--aida", default="aida", help="folder holding the audits")
    parser.add_argument("--out", default="aida/validation_table.json")
    args = parser.parse_args()

    ctx = load(Path(args.context)) or {}
    out = Path(args.out)
    rows = build(ctx, Path(args.aida), load(out) or [], date.today().isoformat())
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Section 5 validation table: {len(rows)} row(s) -> {out}")
    for row in rows:
        print(f"  {row['cells'][0]}  |  {row['cells'][1][:70]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
