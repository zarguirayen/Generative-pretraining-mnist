# aida-compliance — Technical Documentation

**Submission type:** Technical Documentation
**Author:** ZARGUI Rayen — rayen.zargui@ca-cib.com (solo)
**Archive:** `aida-compliance.zip` — a GitHub Copilot plugin, 7 skills, Python standard library only

---

## What it does

It reads a project's codebase and fills the **official AIDA Technical Documentation
template** — the real `.docx`, not a Markdown lookalike — keeping its styles, its
numbering and its table of contents intact.

One principle governs everything else:

> **Every written fact carries the `path:line` that proves it. Anything the code cannot
> prove is reported as an open point, never invented.**

A confident compliance document with nothing behind it is worse than an incomplete one.
It is the defect a risk challenger looks for first, and it is the one this plugin is
built to make impossible.

## Why it is not a one-shot generator

The template has 108 placeholders, of which 105 are real fields and 3 are the template's
own drafting notes (the `NB: …` lines), kept as guidance rather than turned into
questions. Every field is routed to where its answer may legitimately come from:

| Source | Meaning | Example |
|---|---|---|
| `code` | proven by the scan | software dependencies, deployment, model inventory |
| `rule` | fixed by a guideline, quoted with its rule id | monitoring frequency, thresholds, retention |
| `external` | lives in another internal system | GAD, RPAD, MESARI, NSU, the MLflow run |
| `human` | only the risk owner can answer | intended purpose, risk category, named overseers |

**A script never answers a `human` field.** That rule is enforced mechanically, not by
convention: the placeholder map is the authority, and a section writer that tries to fill
such a field is refused by the merge.

## The chain

```
scan_codebase.py        →  evidence, each fact with its file and line
placeholder_map.py      →  the 108 fields, each routed
build_values.py         →  the code and rule answers, derived
write_section.py  ×4    →  record keeping, monitoring ×2, human oversight
validate_values.py      →  the gate — exits 1 and refuses to write
fill_docx.py            →  the official template, formatting preserved
```

The validation step is the plan-validate-execute pattern, and it blocks five things:

- a human-only field filled without a recorded `confirmed_by`;
- a code-derived fact with no `path:line`;
- a guideline threshold that was **loosened** — it knows 20% applies to a prompt system
  and 10% to a RAG or agentic one, and refuses the wrong number for the detected family;
- a credential;
- leftover draft text, or an answer to a field the template does not have.

## What the document actually says

Section 3.9, produced from a real scan, not a paraphrase:

> The model can call 3 tool(s), of which 2 have an irreversible effect and 0 are behind a
> human approval gate. `purge_workspace` (high): delete — **NO APPROVAL GATE**
> `[agent.py:32]` · `send_notification` (high): message — **NO APPROVAL GATE**
> `[agent.py:24]` · `lookup_ticket` (none): read-only — no gate needed `[agent.py:18]`

Section 3.8, with thresholds derived from the project's own measured evaluation:

> Metrics with a measured baseline: `task_completion` (baseline 0.86, alert below 0.774);
> `stability` (baseline 0.91, alert below 0.819). Metrics still to be baselined before the
> end of the build phase: `step_efficiency`, `tool_correctness`…

The baseline is read from the project's evaluation output — the `evaluation-pipeline`
plugin writes one — so the alert threshold is arithmetic on a measured score, not a
plausible number. **With no baseline, no threshold is invented**; the field says the
baseline must be established before the end of the build phase, which is the guideline's
own deadline.

## Grounded in the four guidelines, by rule id

`references/aida_rules.json` holds **36 machine-checkable rules** extracted from
*Building Agentic AI Systems*, *Evaluation of GenAI Systems*, *Monitoring and Human
Oversight* and *Record Keeping* — each with its threshold, its severity and its source
section. Every number the document states carries the id of the rule that fixes it, so a
risk challenger can check it rather than trust it.

Two rules shape the whole document:

- **The escalation rule.** A ReAct agent inside a deterministic workflow makes the *whole*
  system L2. The classification decides the mandatory metrics of every downstream section,
  so getting it wrong is not cosmetic.
- **L1 is the default.** An L2 or L3 system must justify its autonomy *in the technical
  documentation*. No placeholder asks for it, so the justification is raised where the
  level is stated — and left as an open point for the risk owner.

## It also tells you when it has gone stale

Documentation fails by ageing, not by being wrong on day one.

```bash
python skills/aida-technical-documentation/scripts/check_freshness.py check --values aida/values.json --project .
```

It hashes every source file the document cites and names the fields whose evidence moved.
Exit code 1 on drift, so a CI job can fail on it — which is what turns
`DOC-UPDATE-ON-CHANGE` from an intention into something enforceable.

## Try it

Unzip, then from the plugin folder:

```bash
python -m pytest tests/ -q
```

Then run the whole chain on any project:

```bash
python run_all.py /path/to/project --inference-frequency daily
```

It writes into `<project>/aida/`: the filled `technical_documentation.docx`, the list of
open points, a compliance scorecard, and a CycloneDX 1.6 ML-BOM. **The scan never
modifies the project it reads.**

In Copilot, the skills trigger on natural language — *"generate the AIDA technical
documentation"*, *"is our AIDA documentation still valid?"*

## Evidence that it works on any project

- **447 tests.** Three fixture projects ship with the archive: a RAG service, a ReAct
  agent, and a plain CRUD service with no AI at all. The third is the important one — it
  proves the tool reports *no AI system* instead of inventing one. A test fails if it ever
  starts inventing.
- **35 behavioural evaluation scenarios** under `tests/evals/`, including the ones that
  matter most: refusing to infer an intended purpose, refusing to loosen a threshold on
  request, and refusing to bypass the validator.
- **Standards.** Conforms to the GitHub Copilot CLI plugin reference and passes the
  official `skills-ref` validator of the Agent Skills open standard, with a single
  deliberate deviation — the top-level fields the hub's own skill template mandates —
  which is itself pinned by a test.

## What it will not do

- Answer for the risk owner. Intended purpose, AI Act / VRM risk category, system owner
  and named human overseers are asked for, never guessed. A team name is refused where the
  guideline asks for natural persons.
- Replace validation. It produces documentation and reports gaps; the AIDA process still
  validates the system.
- Assess bias or fairness. The evaluation guideline places those in the risk and
  validation domain, outside its own scope — going there would be out of scope, not
  thorough.

## The rest of the archive

The same evidence base feeds four other deliverables, submitted separately: record
keeping (§3.7), GenAI model monitoring and operational system monitoring (§3.8), and human
oversight (§3.9). They share one scan, which is what makes it impossible for two generated
sections to contradict each other. A seventh skill, `aida-audit`, rules on all 36
requirements in one pass and produces a scorecard.

---

*Built against the AI Factory guidelines. The plugin follows `templates/plugin-template`
and `templates/skill-template` from the Plugin-Skill-Hub, and its manifests pass
`scripts/ci/validate_manifests.ps1`.*
