"""The generated operational monitor: Table 5 metrics from the record journal, alerts in it.

    python -m pytest tests/test_ops_monitor.py -v
"""

from __future__ import annotations

import hashlib
import importlib.machinery
import importlib.util
import json
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
OPS = PLUGIN_ROOT / "skills" / "aida-operational-monitoring"
VERIFY = PLUGIN_ROOT / "skills" / "aida-record-keeping" / "scripts" / "verify_chain.py"
END = datetime(2026, 9, 28, tzinfo=timezone.utc)
HASHED = ("seq", "at", "event", "actor", "payload", "prev")


def load(path: Path):
    """Import a module from a file, .template included."""
    loader = importlib.machinery.SourceFileLoader(f"m{abs(hash(path))}", str(path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def chained(path: Path, events: list[tuple[datetime, str, str, dict]]) -> Path:
    """Write (at, event, actor, payload) entries as a verifiable aida_records journal."""
    prev = "0" * 64
    with path.open("w", encoding="utf-8") as handle:
        for seq, (at, event, actor, payload) in enumerate(events, 1):
            entry = {"schema": 1, "seq": seq, "at": at.isoformat(), "event": event,
                     "actor": actor, "payload": payload, "prev": prev}
            canonical = json.dumps({k: entry[k] for k in HASHED}, sort_keys=True,
                                   ensure_ascii=False, separators=(",", ":"))
            entry["hash"] = prev = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            handle.write(json.dumps(entry) + "\n")
    return path


def inferences(n: int, *, errors: int = 0, timeouts: int = 0, latency: float = 900,
               start: datetime = END - timedelta(days=3), per_hour: int = 10) -> list:
    """n inference records, the first `errors` failed and the next `timeouts` timed out."""
    rows = []
    for i in range(n):
        outcome = "error" if i < errors else "timeout" if i < errors + timeouts else "success"
        rows.append((start + timedelta(minutes=60 * (i // per_hour) + i % per_hour), "inference",
                     f"user-{i % 4}", {"request_id": f"r{i}", "session_id": f"s{i % 4}",
                                       "latency_ms": latency, "outcome": outcome,
                                       "tokens": {"input": 200, "output": 150}}))
    return rows


@pytest.fixture
def monitor(tmp_path):
    """The generated monitor and its config, from a plan with a weekly frequency."""
    plan = {"rule": "MON-OPERATIONAL-MINIMUM", "selected": ["error_rate"],
            "schedule": {"monitoring_frequency": "weekly"},
            "metrics": [{"metric": m, "alert": a} for m, a in (("error_rate", ">= 2% per week"),
                                                               ("uptime_pct", "< 99% per week"))]}
    (tmp_path / "plan.json").write_text(json.dumps(plan), encoding="utf-8")
    subprocess.run([sys.executable, str(OPS / "scripts" / "generate_ops_monitor.py"), "--plan",
                    str(tmp_path / "plan.json"), "--out", str(tmp_path / "monitoring"),
                    "--token-quota", "100000"], check=True, capture_output=True)
    out = tmp_path / "monitoring"
    return load(out / "ops_monitor.py"), json.loads((out / "ops_monitor_config.json").read_text()), out


def values(result: dict) -> dict:
    return {m["metric"]: m["value"] for m in result["metrics"]}


def test_everything_the_monitor_needs_is_generated(monitor):
    _, config, out = monitor
    assert {r["metric"] for r in config["rules"]} >= {"average_inference_latency", "uptime_pct",
                                                     "error_rate", "system_crashes", "request_spike"}
    assert "0 6 * * 1" in (out / "schedule" / "ops-crontab.txt").read_text()
    assert "ops_monitor.py" in (out / "schedule" / "ops-gitlab-ci.yml").read_text()
    assert config["thresholds_validated_by"].startswith("[A CONFIRMER")


def test_a_healthy_period_raises_nothing(monitor, tmp_path):
    ops, config, out = monitor
    journal = chained(tmp_path / "j.jsonl", inferences(100) + [
        (END - timedelta(days=1), "uptime_probe", "monitoring", {"status": "up", "target": "/health"})])
    result = ops.run(config, journal, out / "h.jsonl", END, write=False)
    assert values(result)["error_rate"] == 0 and values(result)["uptime_pct"] == 100
    assert values(result)["average_inference_latency"] == 900
    assert result["alerts"] == []


def test_error_timeout_and_latency_breaches_are_alerted_and_journaled(monitor, tmp_path):
    ops, config, out = monitor
    journal = chained(tmp_path / "j.jsonl", inferences(100, errors=3, timeouts=6, latency=3500))
    result = ops.run(config, journal, out / "h.jsonl", END)
    alerted = {a["metric"]: a for a in result["alerts"]}
    assert set(alerted) >= {"error_rate", "timeout_rate", "average_inference_latency"}
    assert "3 % >= 2" in alerted["error_rate"]["explanation"]
    assert subprocess.run([sys.executable, str(VERIFY), str(journal)]).returncode == 0


def test_one_crash_in_24_hours_is_critical(monitor, tmp_path):
    ops, config, out = monitor
    journal = chained(tmp_path / "j.jsonl", inferences(30) + [
        (END - timedelta(hours=2), "incident", "system", {"kind": "crash", "detail": "OOM"})])
    crash = next(a for a in ops.run(config, journal, out / "h.jsonl", END, write=False)["alerts"]
                 if a["metric"] == "system_crashes")
    assert crash["severity"] == "critical"


def test_three_failed_logins_within_a_minute_is_an_alert(monitor, tmp_path):
    ops, config, out = monitor
    at = END - timedelta(days=1)
    logins = [(at + timedelta(seconds=10 * i), "access", "mallory",
               {"status": "failed", "resource": "/login"}) for i in range(3)]
    journal = chained(tmp_path / "j.jsonl", inferences(30) + logins)
    result = ops.run(config, journal, out / "h.jsonl", END, write=False)
    assert values(result)["unauthorized_access_pct"] == 3
    assert any(a["metric"] == "unauthorized_access_pct" for a in result["alerts"])


def test_a_request_spike_and_a_token_quota_breach(monitor, tmp_path):
    ops, config, out = monitor
    burst = inferences(60, per_hour=60, start=END - timedelta(hours=5))
    journal = chained(tmp_path / "j.jsonl", inferences(40, per_hour=5) + burst)
    quota = next(r for r in config["rules"] if r["metric"] == "token_usage")
    quota["limit"] = 20000                                  # 60 calls x 350 tokens in one day
    result = ops.run(config, journal, out / "h.jsonl", END, write=False)
    assert values(result)["request_spike"] >= 3
    assert {"request_spike", "token_usage"} <= {a["metric"] for a in result["alerts"]}


def test_a_metric_without_its_record_is_a_gap_not_a_pass(monitor, tmp_path):
    ops, config, out = monitor
    journal = chained(tmp_path / "j.jsonl", inferences(20))
    gaps = " ".join(ops.run(config, journal, out / "h.jsonl", END, write=False)["coverage_gaps"])
    assert "uptime_pct: no uptime_probe record" in gaps
    assert "resource_utilization" in gaps


def test_active_users_falling_30_percent_against_history(monitor, tmp_path):
    ops, config, out = monitor
    history = out / "h.jsonl"
    history.write_text(json.dumps({"period_end": "x", "values": {"active_users_trend": 10}}) + "\n")
    journal = chained(tmp_path / "j.jsonl", inferences(40))      # 4 distinct users
    result = ops.run(config, journal, history, END, write=False)
    assert any(a["metric"] == "active_users_trend" for a in result["alerts"])


def test_the_cli_exits_1_on_an_alert(monitor, tmp_path):
    _, _, out = monitor
    journal = chained(tmp_path / "j.jsonl", inferences(50, errors=5))
    done = subprocess.run([sys.executable, str(out / "ops_monitor.py"), "--config",
                           str(out / "ops_monitor_config.json"), "--journal", str(journal),
                           "--period-end", "2026-09-28"], capture_output=True, text=True)
    assert done.returncode == 1 and '"error_rate"' in done.stdout
