"""Record keeping embedded in the architecture (REC-FORMAT) and truncation made visible.

    python -m pytest tests/test_records_automation.py -v
"""

from __future__ import annotations

import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
SKILL = PLUGIN_ROOT / "skills" / "aida-record-keeping"
TEMPLATE = SKILL / "assets" / "aida_records.py.template"
VERIFY = SKILL / "scripts" / "verify_chain.py"


@pytest.fixture
def app(tmp_path) -> Path:
    """An application folder with the generated records module."""
    (tmp_path / "aida_records.py").write_text(TEMPLATE.read_text(encoding="utf-8"), encoding="utf-8")
    return tmp_path


def run(app: Path, body: str) -> str:
    done = subprocess.run([sys.executable, "-c", textwrap.dedent(body)], cwd=app,
                          capture_output=True, text=True)
    return done.stdout + done.stderr


def journal(app: Path) -> list[dict]:
    path = app / "logs" / "aida_records.jsonl"
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def test_every_inference_is_recorded_without_a_call_site(app):
    out = run(app, """
        import aida_records as r
        @r.logged_inference(model_version="haiku-4.5")
        def answer(question, session_id=None, user=None):
            if question == "boom":
                raise RuntimeError("model down")
            return {"text": "ok", "usage": {"input": 12, "output": 3}}
        answer("hello", session_id="s1", user="u1")
        try:
            answer("boom", session_id="s1", user="u1")
        except RuntimeError:
            print("RERAISED")
    """)
    assert "RERAISED" in out
    first, second = journal(app)
    assert first["event"] == "inference" and first["payload"]["outcome"] == "success"
    assert first["payload"]["model_version"] == "haiku-4.5" and first["actor"] == "u1"
    assert first["payload"]["tokens"] == {"input": 12, "output": 3}
    assert second["payload"]["outcome"] == "error", "a failure is recorded, not lost"


def test_application_logs_reach_the_chained_journal(app):
    run(app, """
        import logging, aida_records as r
        logging.getLogger().addHandler(r.RecordHandler(level=logging.WARNING))
        logging.getLogger("billing").warning("quota at %d%%", 91)
        logging.getLogger("billing").info("not kept at this level")
    """)
    [entry] = journal(app)
    assert entry["event"] == "log" and entry["payload"]["message"] == "quota at 91%"
    assert entry["actor"] == "billing" and entry["payload"]["level"] == "WARNING"


def test_recommended_operational_records_feed_the_monitor(app):
    run(app, """
        import aida_records as r
        r.error_event(component="retriever", detail="index unavailable")
        r.timeout_event(dependency="bedrock", waited_ms=30000)
        r.incident(kind="crash", detail="out of memory")
        r.uptime_probe(status="up", target="/health")
        r.resource_usage(cpu_pct=71, memory_pct=93)
    """)
    events = [e["event"] for e in journal(app)]
    assert events == ["error_event", "timeout_event", "incident", "uptime_probe", "resource_usage"]


def test_an_anchor_makes_a_truncated_journal_fail_verification(app):
    run(app, """
        import aida_records as r
        for i in range(5):
            r.access(actor="u", access_type="API call", resource="/ask", status="success")
        r.anchor()
    """)
    path = app / "logs" / "aida_records.jsonl"
    anchors = app / "logs" / "aida_anchors.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    path.write_text("\n".join(lines[:3]) + "\n", encoding="utf-8")        # cut the last two
    plain = subprocess.run([sys.executable, str(VERIFY), str(path)], capture_output=True)
    assert plain.returncode == 0, "the chain alone cannot see a cut tail"
    anchored = subprocess.run([sys.executable, str(VERIFY), str(path), "--anchors", str(anchors)],
                              capture_output=True, text=True)
    assert anchored.returncode == 1 and "truncated or rewritten" in anchored.stdout
    assert "False" in run(app, "import aida_records as r; print(r.verify_anchors()['intact'])")


def test_token_counts_are_kept_and_credentials_are_not(app):
    run(app, """
        import aida_records as r
        r.record("usage", tokens={"input": 5}, max_tokens=512, access_token="abc123secret",
                 api_key="sk-12345678901234", session_cookie="c")
    """)
    payload = journal(app)[0]["payload"]
    assert payload["tokens"] == {"input": 5} and payload["max_tokens"] == 512
    assert {payload[k] for k in ("access_token", "api_key", "session_cookie")} == {"[redacted]"}


def test_the_tool_calls_an_answer_reports_are_recorded(app):
    run(app, """
        import aida_records as r
        @r.logged_inference(model_version="m")
        def act(question, session_id=None, user=None):
            return {"text": "done", "tool_calls": [{"name": "close_ticket", "status": "ok"}]}
        act("close 4", session_id="s", user="u")
    """)
    assert journal(app)[0]["payload"]["tool_calls"] == [{"name": "close_ticket", "status": "ok"}]
