"""The generated runtime works as one system: records, oversight, both monitors, one journal.

    python -m pytest tests/test_runtime_integration.py -v

The chain generates four modules into <project>/aida/: the record journal, the oversight
controls, the GenAI monitor and the operational monitor. This runs them together the way
an application would, then checks that an auditor can verify the single journal they share.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
VERIFY = PLUGIN_ROOT / "skills" / "aida-record-keeping" / "scripts" / "verify_chain.py"


@pytest.fixture(scope="module")
def project(tmp_path_factory) -> Path:
    """The agentic fixture, evaluated, after the whole chain."""
    root = tmp_path_factory.mktemp("runtime") / "agent"
    shutil.copytree(FIXTURES / "agentic_assistant", root)
    run = root / "eval" / "outputs" / "run1"
    run.mkdir(parents=True)
    (run / "summary.json").write_text(json.dumps({"metrics": {"task_completion": 0.9}}),
                                      encoding="utf-8")
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(root)], check=True,
                   capture_output=True)
    return root


def test_the_chain_generates_the_four_runtime_modules(project):
    generated = project / "aida"
    for path in ("generated/aida_records.py", "generated/oversight_controls.py",
                 "monitoring/genai_monitor.py", "monitoring/ops_monitor.py"):
        assert (generated / path).exists(), path


def test_records_oversight_and_monitors_share_one_verifiable_journal(project):
    script = textwrap.dedent('''
        import os, sys, json, subprocess
        os.environ["OVERSIGHT_JOURNAL"] = "logs/aida_records.jsonl"   # one journal for all
        sys.path[:0] = ["aida/generated", "aida/monitoring"]
        import aida_records as records, oversight_controls as oc

        @records.logged_inference(model_version="haiku-4.5")
        def answer(question, session_id=None, user=None):
            if "fail" in question:
                raise RuntimeError("tool error")
            return {"text": "done", "usage": {"input": 300, "output": 80}}

        for i in range(30):
            try:
                answer(f"close ticket {i}" + (" fail" if i < 12 else ""),
                       session_id=f"s{i % 3}", user=f"u{i % 3}")
            except RuntimeError:
                pass
        oc.flag_output("r7", "pii", reported_by="u1", detail="shows an IBAN")
        oc.human_review("r7", reviewer="r.owner", verdict="overridden")
        records.anchor()

        for monitor, config in (("genai_monitor", "genai_monitor_config.json"),
                                ("ops_monitor", "ops_monitor_config.json")):
            done = subprocess.run([sys.executable, f"aida/monitoring/{monitor}.py", "--config",
                                   f"aida/monitoring/{config}", "--journal",
                                   "logs/aida_records.jsonl"], capture_output=True, text=True)
            result = json.loads(done.stdout)
            print(monitor, done.returncode, sorted({a["metric"] for a in result["alerts"]}))
    ''')
    done = subprocess.run([sys.executable, "-c", script], cwd=project, capture_output=True, text=True)
    out = done.stdout + done.stderr
    assert "genai_monitor 1 ['task_completion']" in out, out      # 18/30 success vs 0.9
    assert "ops_monitor 1" in out and "error_rate" in out, out     # 40% errors vs 2%
    events = [json.loads(l)["event"] for l in
              (project / "logs" / "aida_records.jsonl").read_text(encoding="utf-8").splitlines()]
    assert {"inference", "user_alert", "quarantined", "escalated", "human_review",
            "alert"} <= set(events)
    verify = subprocess.run([sys.executable, str(VERIFY), str(project / "logs" / "aida_records.jsonl"),
                             "--anchors", str(project / "logs" / "aida_anchors.jsonl")],
                            capture_output=True, text=True)
    assert verify.returncode == 0, verify.stdout
