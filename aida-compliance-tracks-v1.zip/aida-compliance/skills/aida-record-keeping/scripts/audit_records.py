#!/usr/bin/env python3
"""Report which mandatory records a project actually keeps, and which fields it logs.

    python audit_records.py [project] [--out aida/records_audit.json]

Record keeping is the obligation most often declared and least often verified: a project
says it logs its inferences, and the log turns out to hold a timestamp and a message.
This checks two things separately.

**Which records exist** - the nine records the guideline marks mandatory for internally
developed systems (six model, two operational, one oversight).

**Which fields those records carry** - an inference record without the model version
cannot support monitoring, because a score cannot be attributed to a version.

Field names are read from the syntax tree: keyword arguments and dictionary keys passed
to logging calls. A message string that happens to contain the word "session" is not a
field, and is not counted as one.

Standard library only.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "aida-core" / "scripts"))
from ast_utils import dotted  # noqa: E402  (shared with the other syntax-tree audits)

SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env", "dist", "build",
    ".mypy_cache", ".pytest_cache", "site-packages", "aida", ".tox",
}

LOG_CALLS = ("debug", "info", "warning", "warn", "error", "critical", "exception",
             "log", "record", "emit", "track", "audit")
LOG_OWNERS = ("logger", "log", "logging", "_log", "audit", "journal", "recorder")

# Mandatory records, and the signals that show a mechanism exists.
# rule -> record id -> (label, signal regexes)
# record id -> (label, what the recording call must mention). A record has a mechanism
# when a call that records - a logger, mlflow.log_*, a span attribute, a record helper, a
# database insert - mentions it in its own source; a README or a data file that mentions
# it records nothing. See recording_calls() and declared_mechanisms().
MANDATORY: dict[str, dict[str, tuple[str, tuple[str, ...]]]] = {
    "REC-MODEL-MANDATORY": {
        "model_training_data": ("training dataset kept",
                                (r"train(ing)?[_-]?(data|set|dataset|file|path)", r"log_dataset")),
        "model_validation_test_data": ("validation / test dataset kept",
                                       (r"(valid(ation)?|test|eval)[_-]?(data|set|dataset|file|path)",)),
        "model_training_performance_metrics": ("performance metrics of deployed versions",
                                               (r"log_metrics?\b", r"model_performance",
                                                r"\b(accuracy|auc|f1|faithfulness|scores?|metrics)\b")),
        "inference_input_data": ("inference inputs recorded",
                                 (r"\b(prompt|question|query|user_input|inputs?|request)\b",)),
        "inference_output_data": ("inference outputs recorded",
                                  (r"\b(answer|completion|response|outputs?|generation)\b",)),
        "observed_ground_truth_collection": ("observed ground truth collected",
                                             (r"ground[_-]?truth|expected_answer|correction",
                                              r"thumbs?[_-]?(up|down)|\bfeedback\b")),
    },
    "REC-OPERATIONAL-MANDATORY": {
        "change_deployment_record": ("deployments and configuration changes recorded",
                                     (r"\bdeploy(ment|ed)?\b", r"\brelease[ds]?\b", r"rollout")),
        "system_access_log": ("access events recorded",
                              (r"\b(auth\w*|log[_-]?in|log[_-]?out|access|user_id|principal)\b",)),
    },
    "REC-OVERSIGHT-MANDATORY": {
        "human_review_record": ("human reviews recorded",
                                (r"human[_-]?review", r"\breviewer\b", r"overrid(e|den)",
                                 r"escalat", r"\bapprov(ed|al)\b")),
    },
}

# The fields an inference record needs for monitoring to be possible at all.
#
# The `gen_ai.*` aliases are the OpenTelemetry GenAI semantic conventions. A project
# instrumented to that standard writes span attributes, not log keywords, and reporting
# it as recording nothing would be the worst kind of wrong: penalising the projects that
# did it properly.
REQUIRED_FIELDS: dict[str, tuple[str, ...]] = {
    "timestamp": ("timestamp", "time", "at", "ts", "datetime", "occurred_at"),
    "session_id": ("session_id", "session", "conversation_id", "thread_id",
                   "gen_ai.conversation.id"),
    "request_id": ("request_id", "id", "trace_id", "correlation_id", "run_id",
                   "gen_ai.response.id"),
    "actor": ("user_id", "actor", "caller", "principal", "user", "requested_by",
              "enduser.id"),
    "input": ("input", "prompt", "question", "query", "user_input", "messages",
              "gen_ai.input.messages"),
    "output": ("output", "answer", "response", "completion", "generation", "result",
               "gen_ai.output.messages"),
    "model_version": ("model", "model_id", "model_version", "engine", "deployment",
                      "gen_ai.request.model", "gen_ai.response.model"),
    "prompt_version": ("prompt_version", "template_version", "system_prompt_version",
                       "gen_ai.agent.version"),
    "latency": ("latency", "latency_ms", "duration", "duration_ms", "elapsed",
                "server.request.duration"),
    "tokens": ("tokens", "token_usage", "input_tokens", "output_tokens", "usage",
               "gen_ai.usage.input_tokens", "gen_ai.usage.output_tokens"),
    "tool_calls": ("tool_calls", "tools", "tool", "actions", "steps",
                   "gen_ai.tool.name", "gen_ai.tool.call.id"),
    "outcome": ("status", "outcome", "success", "error", "result_status", "error.type"),
}

# Span instrumentation records a field just as well as a log line does.
SPAN_ATTRIBUTE_CALLS = ("set_attribute", "set_attributes", "add_event", "set_tag",
                        "update_current_trace", "log_param", "set_span_attribute")

STRUCTURED_MARKERS = (r"\bstructlog\b", r"python[_-]json[_-]logger", r"JsonFormatter",
                      r"json\.dumps\(.*\)\s*\)?\s*$", r"\bjsonlogger\b", r"\.jsonl\b")
RETENTION_MARKERS = (r"retention", r"\bttl\b", r"expire", r"lifecycle", r"log_rotation",
                     r"backup_count", r"max_age")
IMMUTABLE_MARKERS = (r"append[_-]?only", r"immutab", r"worm\b", r"object[_-]?lock",
                     r"hash[_-]?chain", r"prev_hash", r"tamper")


def iter_files(root: Path, suffixes=(".py",)):
    """Files with these suffixes below the root, skipping SKIP_DIRS."""
    for path in root.rglob("*"):
        # Relative parts only - an absolute-path filter skips every file of a project
        # that lives under a directory called build, env or venv.
        if path.is_file() and path.suffix in suffixes and \
                not any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            yield path


def is_log_call(node: ast.Call) -> bool:
    """True for a logger call or a span attribute setter."""
    func = node.func
    if isinstance(func, ast.Attribute):
        attr = func.attr.lower()
        if attr in SPAN_ATTRIBUTE_CALLS:
            return True
        owner = func.value
        owner_name = owner.id.lower() if isinstance(owner, ast.Name) else ""
        return attr in LOG_CALLS and (
            not owner_name or any(marker in owner_name for marker in LOG_OWNERS))
    if isinstance(func, ast.Name):
        return func.id.lower() in ("record", "audit", "journal")
    return False


def is_span_attribute_call(node: ast.Call) -> bool:
    """True for an OpenTelemetry set_attribute(s) call."""
    func = node.func
    return isinstance(func, ast.Attribute) and func.attr.lower() in SPAN_ATTRIBUTE_CALLS


# Calls that record, beyond the logger calls and span setters of is_log_call.
RECORDING_NAMES = ("log_metric", "log_metrics", "log_artifact", "log_artifacts", "log_input",
                   "log_dataset", "log_dict", "log_table", "log_text", "insert_one",
                   "insert_many", "human_review", "ground_truth", "model_dataset",
                   "model_performance", "alert_followup", "user_feedback")
# Names that only record when called on a record module: `records.access(...)` writes an
# access record, `os.access(...)` checks a file permission.
AMBIGUOUS_NAMES = ("inference", "access", "deployment", "feedback")
RECORD_OWNERS = ("record", "journal", "audit")
TEST_FILE = re.compile(r"^(test_.*|.*_test|conftest)\.py$")
CI_FILES = (".gitlab-ci.yml", ".github/workflows/*.yml", ".github/workflows/*.yaml")


def is_recording_call(node: ast.Call) -> bool:
    """True for a call that writes a record: a logger, a span setter, mlflow.log_*, a
    record helper or a database insert."""
    if is_log_call(node):
        return True
    func = node.func
    name = (func.attr if isinstance(func, ast.Attribute) else getattr(func, "id", "")).lower()
    if name in RECORDING_NAMES:
        return True
    owner = dotted(func.value).lower() if isinstance(func, ast.Attribute) else ""
    return name in AMBIGUOUS_NAMES and any(marker in owner for marker in RECORD_OWNERS)


def recording_calls(root: Path) -> list[tuple[str, int, str]]:
    """(file, line, source) of every call in the Python code that records something."""
    calls = []
    for path in iter_files(root):
        if TEST_FILE.match(path.name) or {"tests", "test"} & set(path.relative_to(root).parts):
            continue                                     # tests exercise the system, not record it
        try:
            source = path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source)
        except (OSError, SyntaxError):
            continue
        relative = path.relative_to(root).as_posix()
        calls += [(relative, node.lineno, ast.get_source_segment(source, node) or "")
                  for node in ast.walk(tree) if isinstance(node, ast.Call) and is_recording_call(node)]
    return calls


def declared_mechanisms(root: Path) -> dict[str, list[str]]:
    """Records kept by the platform rather than by a call: dataset versions under DVC, and
    deployments tracked by a CI environment (who deployed what, and when)."""
    found: dict[str, list[str]] = {}
    dvc = [p for p in list(root.glob("dvc.yaml")) + list(root.glob("**/*.dvc"))
           if not any(part in SKIP_DIRS for part in p.relative_to(root).parts)]
    if dvc:
        refs = [f"{p.relative_to(root).as_posix()}:1" for p in dvc[:2]]
        found["model_training_data"] = found["model_validation_test_data"] = refs
    for pattern in CI_FILES:
        for ci in root.glob(pattern):
            for lineno, line in enumerate(ci.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if re.match(r"\s*environment\s*:", line):
                    found.setdefault("change_deployment_record", []).append(
                        f"{ci.relative_to(root).as_posix()}:{lineno}")
    return found


def logged_field_names(root: Path) -> dict[str, list[str]]:
    """field name -> where it is logged. Only real keywords and dict keys count."""
    found: dict[str, list[str]] = {}
    for path in iter_files(root):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
        except (OSError, SyntaxError):
            continue
        relative = path.relative_to(root).as_posix()
        for node in ast.walk(tree):
            if not (isinstance(node, ast.Call) and is_log_call(node)):
                continue
            names: list[str] = [kw.arg for kw in node.keywords if kw.arg]
            for argument in node.args:
                if isinstance(argument, ast.Dict):
                    names += [k.value for k in argument.keys
                              if isinstance(k, ast.Constant) and isinstance(k.value, str)]
            # `span.set_attribute("gen_ai.usage.input_tokens", n)` names its field in the
            # first positional argument, not in a keyword.
            if is_span_attribute_call(node) and node.args:
                first = node.args[0]
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    names.append(first.value)
            for name in names:
                found.setdefault(name.lower(), []).append(f"{relative}:{node.lineno}")
    return found


def search_signals(root: Path, patterns: tuple[str, ...], limit: int = 3) -> list[str]:
    """Up to `limit` path:line references matching any of the patterns."""
    compiled = [re.compile(p, re.I) for p in patterns]
    hits: list[str] = []
    # code and configuration only: documentation describes a mechanism, it is not one
    for path in iter_files(root, (".py", ".yaml", ".yml", ".json", ".toml", ".cfg",
                                  ".ini", ".tf")):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        relative = path.relative_to(root).as_posix()
        for lineno, line in enumerate(text.splitlines(), 1):
            if any(pattern.search(line) for pattern in compiled):
                hits.append(f"{relative}:{lineno}")
                if len(hits) >= limit:
                    return hits
    return hits


def audit(root: Path) -> dict:
    """The nine mandatory records, the twelve fields, format, retention, immutability."""
    logged = logged_field_names(root)

    calls = recording_calls(root)
    declared = declared_mechanisms(root)
    records: dict[str, dict] = {}
    for rule_id, group in MANDATORY.items():
        for record_id, (label, patterns) in group.items():
            compiled = [re.compile(pattern, re.I) for pattern in patterns]
            evidence = [f"{file}:{line}" for file, line, source in calls
                        if any(c.search(source) for c in compiled)][:3]
            evidence += declared.get(record_id, [])[:3 - len(evidence)]
            records[record_id] = {
                "rule": rule_id,
                "label": label,
                "present": bool(evidence),
                "evidence": evidence,
            }

    fields: dict[str, dict] = {}
    for canonical, aliases in REQUIRED_FIELDS.items():
        evidence: list[str] = []
        for alias in aliases:
            evidence.extend(logged.get(alias, [])[:2])
        fields[canonical] = {"present": bool(evidence), "evidence": evidence[:3]}

    structured = search_signals(root, STRUCTURED_MARKERS, 2)
    retention = search_signals(root, RETENTION_MARKERS, 2)
    immutable = search_signals(root, IMMUTABLE_MARKERS, 2)

    result = {
        "project": str(root.resolve()),
        "records": records,
        "fields": fields,
        "counts": {
            "records_mandatory": len(records),
            "records_present": sum(1 for r in records.values() if r["present"]),
            "fields_required": len(fields),
            "fields_present": sum(1 for f in fields.values() if f["present"]),
        },
        "format": {"structured": bool(structured), "evidence": structured},
        "retention": {"configured": bool(retention), "evidence": retention},
        "immutability": {"configured": bool(immutable), "evidence": immutable},
    }
    result["findings"] = build_findings(result)
    return result


def build_findings(result: dict) -> list[dict]:
    """One blocking finding per rule left unmet."""
    findings: list[dict] = []

    missing_by_rule: dict[str, list[str]] = {}
    for record_id, record in result["records"].items():
        if not record["present"]:
            missing_by_rule.setdefault(record["rule"], []).append(record_id)
    for rule_id, missing in missing_by_rule.items():
        findings.append({
            "rule": rule_id, "severity": "blocking",
            "summary": f"{len(missing)} mandatory record(s) with no mechanism found",
            "detail": ", ".join(m.replace("_", " ") for m in missing),
        })

    missing_fields = [name for name, field in result["fields"].items() if not field["present"]]
    if missing_fields:
        findings.append({
            "rule": "REC-FORMAT", "severity": "blocking",
            "summary": f"{len(missing_fields)} required field(s) never logged",
            "detail": ", ".join(missing_fields),
        })

    if not result["format"]["structured"]:
        findings.append({
            "rule": "REC-FORMAT", "severity": "blocking",
            "summary": "logging is not structured",
            "detail": "Records must be structured, timestamped and standardised - JSON - "
                      "so they can be parsed and traced.",
        })
    if not result["retention"]["configured"]:
        findings.append({
            "rule": "REC-RETENTION", "severity": "blocking",
            "summary": "no retention policy found",
            "detail": "Documentation is kept 10 years, automatic logs at least 1 year.",
        })
    if not result["immutability"]["configured"]:
        findings.append({
            "rule": "REC-RETENTION", "severity": "blocking",
            "summary": "no tamper-evident or immutable storage found",
            "detail": "Records must live in secure, immutable storage. A log a developer "
                      "can edit proves nothing to an auditor.",
        })
    return findings


def render(result: dict) -> str:
    """The audit as a terminal report."""
    counts = result["counts"]
    lines = [
        f"Mandatory records with a mechanism : {counts['records_present']}/{counts['records_mandatory']}",
        f"Required fields actually logged    : {counts['fields_present']}/{counts['fields_required']}",
        "",
        f"{'RECORD':<38} {'STATE':<12} RULE",
    ]
    for record_id, record in result["records"].items():
        state = "found" if record["present"] else "MISSING"
        lines.append(f"{record_id.replace('_', ' ')[:37]:<38} {state:<12} {record['rule']}")

    lines.append("\nINFERENCE RECORD FIELDS")
    present = [n for n, f in result["fields"].items() if f["present"]]
    missing = [n for n, f in result["fields"].items() if not f["present"]]
    lines.append(f"  logged : {', '.join(present) or 'none'}")
    lines.append(f"  MISSING: {', '.join(missing) or 'none'}")

    lines.append("")
    for label, key in (("structured format", "format"), ("retention policy", "retention"),
                       ("tamper-evident storage", "immutability")):
        block = result[key]
        state = "yes" if (block.get("structured") or block.get("configured")) else "NO"
        lines.append(f"  {label:<24} {state}")

    if result["findings"]:
        lines.append(f"\nFINDINGS ({len(result['findings'])})")
        for finding in result["findings"]:
            lines.append(f"  [{finding['rule']}] {finding['summary']}")
            lines.append(f"      {finding['detail']}")
    else:
        lines.append("\nNo blocking finding.")
    return "\n".join(lines)


def main() -> int:
    """Command line: write aida/records_audit.json; exit 1 on a blocking finding."""
    parser = argparse.ArgumentParser(description="Audit record keeping against the guideline.")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--out", default="aida/records_audit.json")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    root = Path(args.project).expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    result = audit(root)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(result, indent=2, ensure_ascii=False) if args.json else render(result))
    print(f"\naudit written to {out}")
    return 1 if any(f["severity"] == "blocking" for f in result["findings"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
