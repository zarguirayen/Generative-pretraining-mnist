#!/usr/bin/env python3
"""Verify an AIDA record journal, without needing the application.

    python verify_chain.py logs/aida_records.jsonl

An auditor should be able to check the records with nothing but the file and this script.
That is the whole point of the chain: the proof travels with the data.

Each entry carries the hash of the one before it. Altering an entry changes its own hash;
removing one breaks the link of the next. Both are reported with the sequence number where
the chain first stops holding.

Exit code 0 when the journal is intact, 1 when it is not, 2 on a usage error.
Standard library only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

GENESIS = "0" * 64
HASHED_KEYS = ("seq", "at", "event", "actor", "payload", "prev")


def digest(entry: dict) -> str:
    """SHA-256 of an entry's hashed fields, in canonical JSON."""
    canonical = json.dumps({k: entry.get(k) for k in HASHED_KEYS},
                           sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def verify(path: Path) -> dict:
    """Walk the chain: entries, period, and every break with its sequence number."""
    problems: list[dict] = []
    entries = 0
    seq, prev = 0, GENESIS
    first_at = last_at = None

    with path.open("r", encoding="utf-8") as handle:
        for lineno, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            entries += 1
            try:
                entry = json.loads(line)
            except json.JSONDecodeError as exc:
                problems.append({"line": lineno, "seq": "?",
                                 "problem": f"not valid JSON: {exc.msg}"})
                continue

            first_at = first_at or entry.get("at")
            last_at = entry.get("at") or last_at

            if entry.get("seq") != seq + 1:
                problems.append({"line": lineno, "seq": entry.get("seq", "?"),
                                 "problem": f"sequence break - expected {seq + 1}, "
                                            f"found {entry.get('seq')}"})
            if entry.get("prev") != prev:
                problems.append({"line": lineno, "seq": entry.get("seq", "?"),
                                 "problem": "broken link - previous hash does not match"})
            if entry.get("hash") != digest(entry):
                problems.append({"line": lineno, "seq": entry.get("seq", "?"),
                                 "problem": "content altered - entry does not hash to its "
                                            "recorded value"})

            seq = entry.get("seq", seq + 1)
            prev = entry.get("hash", prev)

    return {"file": str(path), "entries": entries, "intact": not problems,
            "problems": problems, "first_at": first_at, "last_at": last_at}


def check_anchors(journal: Path, anchors: Path) -> list[dict]:
    """Anchored entries missing or changed: the journal was truncated or rewritten.

    The chain alone cannot see its most recent entries being cut off; an anchor file kept
    elsewhere (write-once storage) records the head at intervals and can.
    """
    hashes = {}
    for line in journal.read_text(encoding="utf-8").splitlines():
        if line.strip():
            entry = json.loads(line)
            hashes[entry.get("seq")] = entry.get("hash")
    problems = []
    for lineno, line in enumerate(anchors.read_text(encoding="utf-8").splitlines(), 1):
        mark = json.loads(line) if line.strip() else {}
        if mark.get("seq") and hashes.get(mark["seq"]) != mark.get("hash"):
            problems.append({"line": f"anchor {lineno}", "seq": mark["seq"],
                             "problem": "anchored entry missing or changed - the journal was "
                                        "truncated or rewritten after the anchor"})
    return problems


def render(report: dict) -> str:
    """The verification as a terminal report."""
    lines = [
        f"Journal   : {report['file']}",
        f"Entries   : {report['entries']}",
        f"Period    : {report['first_at'] or '-'} to {report['last_at'] or '-'}",
    ]
    if report["intact"]:
        lines.append("Integrity : INTACT - every entry hashes to its recorded value and "
                     "links to the previous one")
    else:
        lines.append(f"Integrity : BROKEN - {len(report['problems'])} problem(s)")
        for problem in report["problems"][:10]:
            lines.append(f"  line {problem['line']}, entry {problem['seq']}: {problem['problem']}")
        lines.append("")
        lines.append("A break means the file was modified after the fact. Treat it as an "
                     "incident: the records can no longer be relied on from that point.")
    return "\n".join(lines)


def main() -> int:
    """Command line: verify a journal; exit 1 when the chain is broken."""
    parser = argparse.ArgumentParser(description="Verify an AIDA record journal.")
    parser.add_argument("journal", nargs="?", default="logs/aida_records.jsonl")
    parser.add_argument("--anchors", help="anchor file written by aida_records.anchor()")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    path = Path(args.journal)
    if not path.exists():
        print(f"error: journal not found: {path}", file=sys.stderr)
        return 2

    report = verify(path)
    if args.anchors:
        report["problems"] += check_anchors(path, Path(args.anchors))
        report["intact"] = not report["problems"]
    print(json.dumps(report, indent=2, ensure_ascii=False) if args.json else render(report))
    return 0 if report["intact"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
