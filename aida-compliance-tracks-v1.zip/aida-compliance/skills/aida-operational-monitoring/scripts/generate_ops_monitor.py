#!/usr/bin/env python3
"""Turn the operational plan into a monitor that runs: code, configuration, schedule.

    python generate_ops_monitor.py --plan aida/operational_plan.json --out aida/monitoring

The operational plan says which metrics of the guideline's Table 5 the records can feed.
This writes, under aida/monitoring/, what measures them (MON-TIMING: in place before the
end of the build phase):

  ops_monitor.py              reads the record journal, computes the Table 5 metrics,
                              compares them with the thresholds, journals each alert
  ops_monitor_config.json     one rule per metric: threshold, unit, feeding record, severity
  schedule/ops-crontab.txt    the run at the frequency MON-FREQUENCY sets
  schedule/ops-gitlab-ci.yml  the same, as a scheduled CI job that turns red on an alert

Thresholds are the guideline's defaults. The guideline asks for them to be tailored to the
system and validated before the end of the build phase: a tailored value is set in the
config with its justification, and the validation stays an open point. The daily token
quota has no default - without --token-quota, token usage is reported as a coverage gap.
Standard library only.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "assets" / "ops_monitor.py.template"

# metric -> (kind, default threshold, unit, feeding record, severity), from Table 5.
RULES: dict[str, tuple[str, float | None, str, str, str]] = {
    "average_inference_latency": ("above", 3000, "ms", "inference (latency_ms)", "high"),
    "data_processing_duration": ("above", 3000, "ms", "inference (processing_ms)", "medium"),
    "output_size": ("above", 2000, "tokens", "inference (tokens.output)", "medium"),
    "uptime_pct": ("below", 99.0, "%", "uptime_probe", "high"),
    "timeout_rate": ("above", 5.0, "%", "inference outcome or timeout_event", "high"),
    "error_rate": ("above", 2.0, "%", "inference outcome or error_event", "high"),
    "system_crashes": ("above", 1, "crash(es) in 24h", "incident (kind crash)", "critical"),
    "resource_utilization": ("above", 90.0, "% peak CPU / GPU / memory", "resource_usage", "high"),
    "unauthorized_access_pct": ("above", 3, "failed logins within 1 min", "access (status failed)", "critical"),
    "token_usage": ("above", None, "tokens per day", "inference (tokens)", "medium"),
    "request_spike": ("above", 3.0, "x the hourly mean", "inference", "medium"),
    "active_users_trend": ("versus_history", 30, "users", "inference (actor)", "medium"),
    "average_usage_duration_per_user": ("versus_history", None, "s", "inference (session_id)", "low"),
}
CRON = {"weekly": "0 6 * * 1", "monthly": "0 6 1 * *", "quarterly": "0 6 1 1,4,7,10 *",
        "yearly": "0 6 2 1 *"}
ALERT_PROCEDURE = [
    "Investigate: new usage pattern, dependency outage, deployment, capacity",
    "Justify whether corrective measures are taken, and if not, why",
    "Correct: scale, fix, roll back, tighten access",
    "Record the investigation and the measures in the AI System Journal (DOC-JOURNAL)",
]


def build_config(plan: dict, journal: str, token_quota: float | None) -> dict:
    """The plan made executable: one rule per Table 5 metric, the window, the procedure."""
    table = {m["metric"]: m for m in plan["metrics"]}
    rules = []
    for metric, (kind, limit, unit, feeds, severity) in RULES.items():
        if metric == "token_usage":
            limit = token_quota
        rules.append({
            "metric": metric, "kind": kind, "limit": limit, "unit": unit, "feeds": feeds,
            "severity": severity,
            "condition": table.get(metric, {}).get("alert", ""),
            "selected": metric in plan.get("selected", []),
            "note": ("no daily token quota defined - set it with --token-quota"
                     if metric == "token_usage" and limit is None else ""),
        })
    period = plan["schedule"].get("monitoring_frequency") or "weekly"
    return {
        "generated_from": "aida/operational_plan.json", "rule": plan["rule"],
        "window": {"period": period,
                   "period_days": {"weekly": 7, "monthly": 30, "quarterly": 91, "yearly": 365}[period]},
        "rules": rules, "journal": journal, "alert_procedure": ALERT_PROCEDURE,
        "assigned_to": "operations owner - name to be confirmed",
        "thresholds_validated_by": "[A CONFIRMER - thresholds tailored and validated before the "
                                   "end of the build phase (MON-OPERATIONAL-MINIMUM)]",
    }


def schedules(config: dict, out: Path) -> dict[str, str]:
    """The crontab line and the scheduled GitLab CI job, at the monitoring frequency."""
    period = config["window"]["period"]
    cron = CRON.get(period, CRON["weekly"])
    command = (f"python {out.as_posix()}/ops_monitor.py --config "
               f"{out.as_posix()}/ops_monitor_config.json")
    return {
        "cron": cron,
        "ops-crontab.txt": (f"# AIDA operational monitoring - {period}, MON-FREQUENCY\n"
                            f"# exit code 1 = an alert was raised and recorded in the journal\n"
                            f"{cron} cd /path/to/project && {command}\n"),
        "ops-gitlab-ci.yml": (f"# AIDA operational monitoring - add to .gitlab-ci.yml and create a\n"
                              f"# pipeline schedule with the cron \"{cron}\" ({period}, MON-FREQUENCY).\n"
                              f"aida-operational-monitoring:\n  stage: monitor\n  rules:\n"
                              f"    - if: '$CI_PIPELINE_SOURCE == \"schedule\"'\n"
                              f"  script:\n    - {command}\n"),
    }


def main() -> int:
    """Command line: write the operational monitor, its config and schedule."""
    parser = argparse.ArgumentParser(description="Generate the runnable operational monitor.")
    parser.add_argument("--plan", default="aida/operational_plan.json")
    parser.add_argument("--out", default="aida/monitoring")
    parser.add_argument("--journal", default="logs/aida_records.jsonl")
    parser.add_argument("--token-quota", type=float, help="daily token quota (finops)")
    args = parser.parse_args()

    plan_path = Path(args.plan)
    if not plan_path.exists():
        print(f"error: plan not found: {plan_path}\n       run plan_operational.py first",
              file=sys.stderr)
        return 2
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    out = Path(args.out)
    (out / "schedule").mkdir(parents=True, exist_ok=True)
    config = build_config(plan, args.journal, args.token_quota)
    shutil.copyfile(TEMPLATE, out / "ops_monitor.py")
    (out / "ops_monitor_config.json").write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    sched = schedules(config, out)
    for name in ("ops-crontab.txt", "ops-gitlab-ci.yml"):
        (out / "schedule" / name).write_text(sched[name], encoding="utf-8")

    print(f"Operational monitor written to {out}/")
    print(f"  window   : {config['window']['period']}, cron \"{sched['cron']}\"")
    print(f"  rules    : {len(config['rules'])} Table 5 metrics, "
          f"{sum(r['selected'] for r in config['rules'])} selected by the plan")
    for rule in config["rules"]:
        limit = "no default" if rule["limit"] is None else f"{rule['limit']:g} {rule['unit']}"
        print(f"  {rule['metric']:<32} {rule['kind']:<15} {limit:<32} <- {rule['feeds']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
