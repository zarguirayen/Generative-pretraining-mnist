#!/usr/bin/env python3
"""Write the oversight controls the audit found missing, and show where to wire them.

    python generate_controls.py --audit aida/oversight_audit.json --project .

Documenting a missing stop button does not create one. This emits a reviewed starting
point - approval gate, stop control, quarantine, oversight journal, feedback and human
review records - and prints the exact patch for each ungated tool the audit found.

It never edits the project's own source. The application code stays the developer's to
change; only the new module is written, and never over an existing file.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "assets" / "oversight_controls.py.template"

SUBJECT_HINTS = ("session_id", "user_id", "user", "account", "customer_id", "session")


def subject_for(tool: dict) -> str | None:
    """Pick the argument a quarantine would key on.

    Only the tool's real parameters are considered. Reading the docstring instead would
    produce `subject_arg="user"` for a function whose parameter is `address` - a patch
    that fails at runtime, which is worse than no patch.
    """
    parameters = [p.lower() for p in tool.get("parameters") or []]
    for hint in SUBJECT_HINTS:
        if hint in parameters:
            return hint
    return None


def patch_for(tool: dict) -> str:
    """The decorator to add to one ungated tool, with its location and severity."""
    subject = subject_for(tool)
    subject_kw = f', subject_arg="{subject}"' if subject else ""
    return (
        f"# {tool['file']}:{tool['line']}  -  {tool['name']}\n"
        f"from oversight_controls import requires_approval\n\n"
        f"@tool\n"
        f'@requires_approval("{tool["name"]}", severity="{tool["severity"]}"{subject_kw})\n'
        f"def {tool['name']}(...):\n"
        f"    ...\n"
    )


# Who oversees, and how fast an alert must be answered. The guideline requires named
# natural persons and escalation pathways with response timelines; the hours below are a
# starting point for the risk owner to set, not a guideline number.
OVERSEERS = {
    "note": "Named natural persons, not a team (OVERSIGHT-CAPABILITIES). Response hours are "
            "the project's to set; these defaults are a proposal to validate.",
    "overseers": [
        {"name": "[A CONFIRMER - named natural person]", "role": "risk owner",
         "contact": "", "severities": ["critical", "high"]},
        {"name": "[A CONFIRMER - named natural person]", "role": "system owner",
         "contact": "", "severities": ["high", "medium", "low"]},
    ],
    "response_hours": {"critical": 1, "high": 4, "medium": 24, "low": 72},
}


def render_plan(audit: dict, target: Path, written: bool) -> str:
    """What was (or would be) written, and the patch for each ungated tool."""
    ungated = [t for t in audit["tools"] if t["irreversible"] and not t["approval_gate"]]
    controls = audit.get("controls", {})

    lines = []
    lines.append(f"{'Wrote' if written else 'Would write'}: {target}")
    lines.append("")
    lines.append("It provides:")
    lines.append("  requires_approval   gate an irreversible action; four_eyes=True needs two people")
    lines.append("  stop / resume       halt the system, recorded with who did it")
    lines.append("  quarantine          pause one output, session or user without stopping the rest")
    lines.append("  override            a person replaces or reverses an output")
    lines.append("  flag_output         user report of PII, toxic, biased or copyrighted content")
    lines.append("  escalate / overdue  alerts routed to the overseers with a deadline, late ones listed")
    lines.append("  feedback            user signal, distinguishing generation / retrieval / tool path")
    lines.append("  human_review        the mandatory Human Review Record")
    lines.append("  record              hash-chained journal (verify_chain.py), credentials redacted")
    lines.append(f"and {target.with_name('overseers.json')}: who is alerted, how fast")

    if ungated:
        lines.append("")
        lines.append(f"Apply the gate to {len(ungated)} tool(s):")
        lines.append("")
        for tool in ungated:
            lines.append(patch_for(tool))
    else:
        lines.append("\nNo ungated irreversible tool - nothing to wire.")

    missing = [name for name, found in
               (("stop control", controls.get("stop_control")),
                ("user feedback", controls.get("user_feedback")),
                ("source citation", controls.get("source_citation"))) if not found]
    if missing:
        lines.append("Still to decide, because code cannot decide it:")
        lines.append(f"  - the review channel `default_approver` should call "
                     f"(it refuses when no person can be reached, which is the safe default)")
        lines.append(f"  - who the named human overseers are, for the documentation")
        lines.append(f"  - where the journal is stored, retained at least one year "
                     f"(REC-RETENTION)")
        lines.append(f"  - missing controls to expose in the interface: {', '.join(missing)}")
    return "\n".join(lines)


def main() -> int:
    """Command line: write the missing controls; the project's source is never edited."""
    parser = argparse.ArgumentParser(description="Generate the missing oversight controls.")
    parser.add_argument("--audit", default="aida/oversight_audit.json")
    parser.add_argument("--project", default=".")
    parser.add_argument("--out", default="aida/generated/oversight_controls.py")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"error: audit not found: {audit_path}\n"
              f"       run audit_oversight.py first", file=sys.stderr)
        return 2
    if not TEMPLATE.exists():
        print(f"error: template missing: {TEMPLATE}", file=sys.stderr)
        return 2

    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    target = Path(args.project) / args.out

    written = False
    if not args.dry_run:
        if target.exists():
            print(f"{target} already exists - not overwriting. Delete it to regenerate.")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(TEMPLATE.read_text(encoding="utf-8"), encoding="utf-8")
            roster = target.with_name("overseers.json")
            if not roster.exists():
                roster.write_text(json.dumps(OVERSEERS, indent=2) + "\n", encoding="utf-8")
            written = True

    print(render_plan(audit, target, written))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
