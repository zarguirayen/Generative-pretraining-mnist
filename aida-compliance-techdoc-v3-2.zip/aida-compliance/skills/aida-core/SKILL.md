---
name: aida-core
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
status: experimental
compatibility: Requires Python 3.10+; git improves version metadata but is optional
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*) shell(git:*)
description: >-
  Scans an AI project and builds the shared evidence base every AIDA compliance
  deliverable needs: system classification against the AI Factory taxonomy
  (RAG / Prompt / Agentic L1-L2-L3), model, dependency and endpoint inventory,
  logging and side-effect coverage, the placeholder map of the official technical
  documentation template, and a CycloneDX ML-BOM. Use it when asked to scan,
  inventory, classify or audit an AI system for AIDA, when asked what a project's
  compliance context is, and as the mandatory first step of any AIDA deliverable -
  technical documentation, record keeping, GenAI or operational monitoring, human
  oversight.
tags:
  - aida
  - compliance
  - codebase-scan
  - classification
  - ml-bom
  - cyclonedx
  - eu-ai-act
---

# aida-core

Turns a repository into evidence the AIDA deliverables can be written from.

---

## Absolute rules

- **Every fact carries its proof** — cite the `path:line` that supports it. A field with
  no evidence stays empty.
- **Never invent a fact about the system** — unknown fields become
  `[A CONFIRMER - <reason>]`. Inventing an intended purpose, a risk category or a metric
  is a compliance fault, not a rounding error.
- **The scripts decide, not the prose** — classification, field routing and document
  writing are deterministic. Do not re-derive them by reading files yourself.
- **Degrade honestly** — a project with no AI is reported as such. Never manufacture a
  model, a dataset or a monitoring metric to fill a section.
- **Never write inside the installed plugin folder** — all output goes to `aida/` in the
  user's project.
- **Never put a secret** in a document, a log line, or the chat.

---

## Purpose

The four AIDA deliverable skills all need the same answers about a project: what the
system is, what it runs on, what it logs, and what it can do irreversibly. This skill
answers those questions once, from the code, so the deliverables consume a single shared
evidence base instead of each re-exploring the repository — which is what makes it
impossible for two generated documents to contradict each other.

Invoke it when asked to scan, classify or audit a project for AIDA, and always before
any deliverable is written.

It produces three files under `aida/`:

| Output | Contains |
|---|---|
| `context.json` | classification, models, dependencies, endpoints, logging, side effects — each with evidence |
| `placeholders.json` | the 108 template placeholders, each routed to where its answer can come from |
| `ml-bom.json` | CycloneDX 1.6 inventory of models, datasets and dependencies |

---

## Workflow

Copy this checklist and tick items off as you go:

```
AIDA context:
- [ ] Phase 1: scan the codebase
- [ ] Phase 2: inventory the template fields
- [ ] Phase 3: emit the ML-BOM
- [ ] Phase 4: present one confirmation block
```

### Phase 1 — Scan the codebase

```bash
python scripts/scan_codebase.py . --out aida/context.json
```

Run from the project root. Read the printed summary; do not load the whole JSON into
context unless a later phase needs a specific field.

### Phase 2 — Inventory the template fields

```bash
python scripts/placeholder_map.py --context aida/context.json --out aida/placeholders.json --report
```

Every field of the official template is routed to where its answer can legitimately come
from:

| Source | Meaning |
|---|---|
| `code` | proven by the scan — fill it and cite the evidence |
| `rule` | determined by a guideline rule (frequency, threshold, retention) |
| `external` | lives in another internal system (GAD, RPAD, MESARI, NSU, MLflow) |
| `human` | only the risk owner can answer — never guess |
| `instruction` | template guidance, kept as-is, not a question |

### Phase 3 — Emit the ML-BOM

```bash
python scripts/aida_bom.py --context aida/context.json --out aida/ml-bom.json --summary
```

A machine-readable inventory of models, datasets and dependencies. It fills the
"software dependencies and their versions" and "third-party models, tools and
frameworks" fields, and is itself a record under the record keeping guideline.

### Phase 4 — Present one confirmation block

Ask once, not question by question:

```
I scanned <project> (<n> files).

Classification : <family> / <level>   (certainty: <level>)
  because      : <the reason the script gave, verbatim>
Models         : <ids found> [evidence]
Reference stack: <framework>  (guideline expects <expected> at this level)
Observability  : <mlflow / none>
Structured logs: <yes / no>
Side effects   : <kinds found>
Template fields: <auto>/<total> auto-fillable, <n> need you

I still need from you:
  - Intended purpose and target users
  - AI Act / VRM risk category
  - System owner and named human overseers

Confirm the classification, or tell me what I got wrong.
```

Wait for the reply before any deliverable skill writes a document.

---

## Reading the classification

Two rules from the guidelines matter more than the rest.

**Escalation.** Introducing a ReAct agent into a deterministic workflow makes the *whole*
system L2, because the overall decision path stops being deterministic.

**Self-extension means L3.** A system that creates or registers its own tools or skills
at runtime has a capability set that is not fixed at design time. That is the definition of
a Deep Agent, and it matters downstream: L3 adds plan quality and plan adherence to the
mandatory metrics.

**L1 is the default.** Adopting L2 or L3 must be justified by a demonstrated necessity
*and* documented in the technical documentation. If the scan reports L2 or L3 and no
justification exists, report it as a compliance gap (rule `BUILD-L1-DEFAULT`).

When certainty is `low`, say so and ask rather than proceeding. A wrong family selects
the wrong mandatory metrics in every downstream section.

If the user corrects the classification, do not hand-edit `aida/context.json`. Record it
in `aida/overrides.json`:

```json
{ "classification": { "family": "rag", "agentic_level": null,
                      "reason": "confirmed by the risk owner on <date>" } }
```

Deliverable skills read the override on top of the context, so a rescan never silently
reverts a human decision.

---

## Resources

| Resource | Purpose |
|---|---|
| [`references/aida_rules.json`](references/aida_rules.json) | 36 machine-checkable rules from the four AI Factory guidelines, with thresholds and sources |
| [`assets/templates/technical_documentation.docx`](assets/templates/technical_documentation.docx) | The official AIDA template (version 04.12.2025) |
| [`scripts/scan_codebase.py`](scripts/scan_codebase.py) | Repository scan → `aida/context.json` |
| [`scripts/placeholder_map.py`](scripts/placeholder_map.py) | Template field inventory → `aida/placeholders.json` |
| [`scripts/aida_bom.py`](scripts/aida_bom.py) | CycloneDX 1.6 ML-BOM → `aida/ml-bom.json` |
| [`scripts/validate_values.py`](scripts/validate_values.py) | Checks the answers before they are written — exits 1 on any blocking finding |
| [`scripts/fill_docx.py`](scripts/fill_docx.py) | Writes values into the template, preserving its formatting |

Scripts use the Python standard library only. Nothing to install.

### Writing a deliverable

Deliverable skills never write the document straight from their answers. They plan,
validate, then execute:

```bash
# 1. plan   - the skill writes aida/values.json
# 2. validate
python scripts/validate_values.py --values aida/values.json --map aida/placeholders.json --context aida/context.json
# 3. execute - only if the validator exited 0
python scripts/fill_docx.py --values aida/values.json --map aida/placeholders.json --out aida/technical_documentation.docx
```

The validator blocks a human-only field filled without a `confirmed_by`, a code-derived
fact with no `path:line`, a guideline threshold that was loosened, a credential, and
leftover draft text. **Fix the findings and re-run it — never write the document
around a blocking finding.**

---

## Quality checklist

- [ ] `aida/context.json` exists and its classification matches what the user confirmed
- [ ] Every classification claim carries `path:line` evidence
- [ ] `aida/placeholders.json` reports zero unrouted fields
- [ ] `aida/ml-bom.json` contains no model the scan did not find
- [ ] Nothing was written outside `aida/`
- [ ] No secret appears in any generated file
