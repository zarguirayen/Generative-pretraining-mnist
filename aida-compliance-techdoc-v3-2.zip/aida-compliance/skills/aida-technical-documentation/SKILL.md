---
name: aida-technical-documentation
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: experimental
compatibility: Requires Python 3.10+ and git (freshness check hashes cited files)
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*) shell(git:*)
description: >-
  Writes the AIDA technical documentation of an AI project into the official CACIB
  Word template, from the evidence the codebase provides and the numbers the AI
  Factory guidelines fix. Fills the sections a scan can answer, quotes each guideline
  threshold with its rule id, and leaves every field only the risk owner can answer
  marked as an open point instead of inventing it. Use it when asked to write,
  generate, produce, update or refresh the AIDA technical documentation, the AI Act
  technical documentation or the compliance documentation of a project, and when
  asked whether an existing document is still up to date with the code.
tags:
  - aida
  - technical-documentation
  - compliance
  - eu-ai-act
  - docx
  - governance
---

# aida-technical-documentation

Produces the AIDA technical documentation from evidence, and tells you when it has
stopped matching the code.

---

## Absolute rules

- **Never answer a `human` field.** Intended purpose, risk category, system owner and
  named overseers come from the risk owner. A script that fills them turns a compliance
  document into a fabrication.
- **Never write the document around a blocking finding.** `validate_values.py` exits 1
  for a reason. Fix the finding, re-run, then write.
- **Never loosen a guideline number.** Thresholds may be stricter, never looser, and a
  stricter one still has to be justified.
- **Never overwrite a confirmed answer.** Anything carrying `confirmed_by` survives a
  regeneration.
- **Cite or abstain** — every asserted fact carries its `path:line`, or it is not
  asserted.
- **Write only under `aida/`.** The scan must never modify the project it reads.

---

## Purpose

The AIDA technical documentation is one Word document of 105 fields, and four of its
sections — 3.7 Record Keeping, 3.8 Monitoring, 3.9 Human Oversight — are themselves
separate AIDA deliverables. This skill fills what can be filled from evidence, states
what the guidelines fix, and hands back a precise list of what only a human can answer.

The three kinds of answer are kept strictly apart:

| Kind | Where the answer comes from | What is written |
|---|---|---|
| `code` | proven by the scan | the fact, followed by its `path:line` |
| `rule` | fixed by a guideline | the guideline's own wording and number, with its rule id |
| `human` / `external` | the risk owner, or another internal system | `[A CONFIRMER - <reason>]` |

Invoke it after `aida-core` has built the context and the classification has been
confirmed.

---

## Workflow

Copy this checklist and tick items off as you go:

```
Technical documentation:
- [ ] Phase 1: context ready and classification confirmed
- [ ] Phase 2: derive the answers
- [ ] Phase 3: collect the human answers
- [ ] Phase 3b: draw the figures, write the introduction last
- [ ] Phase 4: validate  (must exit 0)
- [ ] Phase 5: write the document
- [ ] Phase 6: record the state and report
```

### Phase 1 — Context ready

`aida/context.json` must exist and the user must have confirmed the classification. If
either is missing, run the `aida-core` skill first. Do not proceed on an unconfirmed
classification: it selects the mandatory metrics of every downstream section.

### Phase 2 — Derive the answers

```bash
python scripts/build_values.py --context aida/context.json --map aida/placeholders.json --out aida/values.json
```

This answers the `code` and `rule` fields only, and reports the count of each. Answers
already carrying `confirmed_by` are preserved.

### Phase 3 — Collect the human answers

Read `aida/placeholders.json` for the fields routed to `human`, and ask for them **in
one block**. Record each answer with who confirmed it and when:

```json
{ "Clearly define the specific tasks or problems the AI system is designed to address": {
    "value": "…",
    "confirmed_by": "<name> (risk owner), <date>" } }
```

Do not ask for `external` fields — say which internal system holds them (GAD, RPAD,
MESARI, NSU, MLflow) and leave them as open points.

### Phase 3b — Figures and introduction, last

Run once the section skills (3.7, 3.8, 3.9) have written their audits under `aida/` —
both scripts read them, and are poorer without them.

```bash
python scripts/render_figures.py --context aida/context.json --aida aida
python scripts/write_introduction.py --context aida/context.json --values aida/values.json --map aida/placeholders.json --aida aida
```

- **§3.5 architecture diagram** — `aida/architecture.mmd`, a Mermaid flowchart of what the
  scan found: API, orchestration and autonomy level, models, knowledge base, tools (an
  irreversible tool with no approval gate is marked red), MCP servers, observability. Each
  component's `path:line` goes in the caption. Nothing absent from the code is drawn.
- **§3.4 performance chart** — `aida/performance_chart.mmd` and `.svg`: each metric's
  build-phase baseline beside its alert threshold. With no measured baseline there is no
  chart, and the section carries an open point saying so. Never draw invented numbers.
- **§1 introduction** — assembled from the sections: conception, measured performance,
  monitoring, limitations the audits found, validation status. The intended purpose stays
  `[A CONFIRMER]` inside it.

`fill_docx.py` inserts the figures listed in `aida/figures.json` into their sections.

### Phase 4 — Validate

```bash
python ../aida-core/scripts/validate_values.py --values aida/values.json --map aida/placeholders.json --context aida/context.json
```

It blocks a human-only field with no confirmer, a code-derived fact with no evidence, a
loosened threshold, a credential, draft text, and answers to fields the template does not
have. **Fix and re-run until it exits 0.** Report the findings to the user rather than
working around them.

### Phase 5 — Write the document

```bash
python ../aida-core/scripts/fill_docx.py --values aida/values.json --map aida/placeholders.json --figures aida/figures.json --out aida/technical_documentation.docx
```

Formatting, styles and the table of contents of the official template are preserved. Open
points are listed in `aida/technical_documentation_a_confirmer.json`.

### Phase 6 — Record the state and report

```bash
python scripts/check_freshness.py record --values aida/values.json --project .
```

Then report: fields filled and from what, the count of open points by kind, and the
compliance gaps the scan already showed — no structured logging, no observability,
irreversible actions with no approval gate, an L2 or L3 classification with no documented
justification for the autonomy.

---

## Keeping it current

Documentation fails by ageing, not by being wrong on day one. After any substantial
change:

```bash
python scripts/check_freshness.py check --values aida/values.json --project .
```

It hashes every source file the document cites and reports the fields whose evidence has
moved. Exit code 1 on drift, so a CI job can fail on it — which is what makes
`DOC-UPDATE-ON-CHANGE` enforceable instead of aspirational.

Regenerate only the affected sections: re-run Phase 2, keep the confirmed answers, then
Phases 4 to 6.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/build_values.py`](scripts/build_values.py) | Derives the `code` and `rule` answers, with evidence and rule ids |
| [`scripts/render_figures.py`](scripts/render_figures.py) | §3.5 Mermaid architecture diagram and §3.4 baseline-vs-threshold chart, from evidence |
| [`scripts/write_introduction.py`](scripts/write_introduction.py) | §1 introduction, assembled last from the other sections |
| [`scripts/check_freshness.py`](scripts/check_freshness.py) | Records and checks the document against the code |
| [`references/section_guide.md`](references/section_guide.md) | What each template section expects, and which rule governs it |

From the `aida-core` skill: `scan_codebase.py`, `placeholder_map.py`,
`validate_values.py`, `fill_docx.py`, `references/aida_rules.json`, and the official
template in `assets/templates/`.

---

## Quality checklist

- [ ] The classification was confirmed by the user before anything was written
- [ ] `validate_values.py` exits 0
- [ ] Every `human` field is either `confirmed_by` someone or left as `[A CONFIRMER]`
- [ ] Every guideline threshold in the document carries its rule id
- [ ] §3.5 holds the architecture diagram, §3.4 the chart or the open point explaining its absence
- [ ] The introduction was written after the sections, and states no intended purpose
- [ ] The document opens in Word with its styles and table of contents intact
- [ ] Open points are reported to the user, not buried in the file
- [ ] The freshness state was recorded
- [ ] Nothing was written outside `aida/`
