#!/usr/bin/env python3
"""Derive the answers the codebase and the guidelines can already give.

    python build_values.py --context aida/context.json --map aida/placeholders.json \
                           --out aida/values.json

Two kinds of field are answered here and nowhere else:

* `code`  - the scan proved it, so the answer is written with the `path:line` behind it;
* `rule`  - a guideline determines it, so the answer is the guideline's own wording and
            number, quoted with its rule id.

Everything else is left untouched: a `human` field answered by a script is exactly the
failure this whole plugin exists to prevent. Run validate_values.py on the result before
writing the document.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RULES = HERE.parent.parent / "aida-core" / "references" / "aida_rules.json"

FAMILY_LABEL = {
    "rag": "Retrieval-Augmented Generation (RAG)",
    "prompt": "Prompt / vanilla GenAI",
    "agentic": "Agentic AI",
    "hybrid": "Hybrid (RAG inside an agentic system)",
    "unknown": "not determined from the code",
}
LEVEL_LABEL = {
    "L1": "Level 1 - Agentic AI Workflow (tools on hardcoded paths)",
    "L2": "Level 2 - ReAct Agent (the model drives tool selection)",
    "L3": "Level 3 - Deep Agent (autonomous planning and sub-agent spawning)",
}
EXPECTED_STACK = {
    "L1": "Dataiku agent builder",
    "L2": "LangChain for a simple ReAct pattern, LangGraph as soon as there are loops, "
          "conditions, persistent state or multi-agent orchestration",
    "L3": "no reference framework defined yet",
}


# --------------------------------------------------------------------- helpers --
def rule(rules: dict, rule_id: str) -> dict:
    for item in rules["rules"]:
        if item["id"] == rule_id:
            return item
    return {}


def evidence_of(section: dict, limit: int = 4) -> list[str]:
    """Collect path:line proofs out of a `{name: {hits, evidence}}` block."""
    out: list[str] = []
    for entry in (section or {}).values():
        for item in (entry.get("evidence") or []):
            if item not in out:
                out.append(item)
            if len(out) >= limit:
                return out
    return out


def joined(names) -> str:
    names = list(names)
    if not names:
        return ""
    if len(names) == 1:
        return names[0]
    return ", ".join(names[:-1]) + " and " + names[-1]


def unresolved(reason: str) -> tuple[str, list[str]]:
    return f"[A CONFIRMER - {reason}]", []


# ------------------------------------------------------------------ renderers --
# Each takes (ctx, rules) and returns (value, evidence) or None when it cannot answer.

def r_system_name(ctx, rules):
    return ctx["project"]["name"], [f"project directory: {ctx['project']['name']}"]


def r_system_version(ctx, rules):
    git = ctx.get("git") or {}
    if git.get("tag"):
        return git["tag"], [f"git tag {git['tag']}"]
    if git.get("commit"):
        return f"untagged, commit {git['commit'][:12]}", [f"git commit {git['commit'][:12]}"]
    return None


def r_documentation_version(ctx, rules):
    return (f"1.0 - generated on {date.today().isoformat()} from the codebase state "
            f"recorded in aida/context.json"), []


def r_versioning_scheme(ctx, rules):
    git = ctx.get("git") or {}
    if git.get("tag"):
        return ("Semantic versioning (MAJOR.MINOR.PATCH), carried by git tags on the "
                f"source repository; current tag {git['tag']}."), [f"git tag {git['tag']}"]
    return None


def r_dependencies(ctx, rules):
    deps = ctx.get("dependencies") or {}
    if not deps:
        return None
    listed = sorted(deps.items())[:25]
    text = "; ".join(f"{name} {meta.get('version') or '(unpinned)'}" for name, meta in listed)
    more = f" (+{len(deps) - len(listed)} more, see aida/ml-bom.json)" if len(deps) > len(listed) else ""
    proof = [meta["evidence"] for _, meta in listed[:4] if meta.get("evidence")]
    return (f"{len(deps)} declared dependencies: {text}{more}. The complete, machine "
            f"readable inventory is the CycloneDX ML-BOM in aida/ml-bom.json."), proof


def r_third_party_models(ctx, rules):
    models = ctx.get("models") or {}
    frameworks = list((ctx.get("frameworks") or {}))
    providers = list((ctx.get("model_providers") or {}))
    if not (models or frameworks):
        return None
    parts = []
    if models:
        parts.append(f"models invoked as-is, without fine-tuning: {joined(models)}")
    if providers:
        parts.append(f"provider SDKs: {joined(providers)}")
    if frameworks:
        parts.append(f"orchestration frameworks: {joined(frameworks)}")
    proof = []
    for refs in models.values():
        proof.extend(refs[:2])
    proof.extend(evidence_of(ctx.get("frameworks"), 2))
    return ("; ".join(parts) + ".", proof[:4])


def r_model_logic(ctx, rules):
    cls = ctx.get("classification") or {}
    family = FAMILY_LABEL.get(cls.get("family"), "not determined")
    text = f"System family: {family}."
    level = cls.get("agentic_level")
    if level:
        text += (f" Autonomy: {LEVEL_LABEL[level]}. "
                 f"{cls.get('agentic_level_reason', '')}")
    text += f" Classification certainty from static analysis: {cls.get('certainty', 'low')}."
    # The autonomy justification has no placeholder of its own, and the guideline requires
    # it to be *in* the technical documentation. It belongs with the statement of the
    # level, which is here.
    if level in ("L2", "L3"):
        item = rule(rules, "BUILD-L1-DEFAULT")
        text += (f" Level 1 is the guideline default: adopting {level} must be justified by "
                 f"a demonstrated necessity - multiple or non-deterministic execution paths - "
                 f"and that justification must appear in this documentation ({item['id']}, "
                 f"{item['source']}). Justification: "
                 f"[A CONFIRMER - to be given by the risk owner].")
    proof = (cls.get("family_evidence") or []) + (cls.get("agentic_level_evidence") or [])
    return text, proof[:4]


def r_reference_stack(ctx, rules):
    cls = ctx.get("classification") or {}
    found = cls.get("reference_framework")
    level = cls.get("agentic_level")
    if not found:
        return None
    text = f"Orchestration framework in use: {found}."
    if level and level in EXPECTED_STACK:
        text += (f" The Building Agentic AI Systems guideline names, for {level}: "
                 f"{EXPECTED_STACK[level]}.")
    return text, evidence_of(ctx.get("frameworks"), 3)


def r_computational_resources(ctx, rules):
    infra = ctx.get("infrastructure") or {}
    parts = [f"{kind}: {joined(paths)}" for kind, paths in infra.items() if paths]
    if not parts:
        return None
    return ("Declared in the repository - " + "; ".join(parts) + "."), []


def r_deployment(ctx, rules):
    infra = ctx.get("infrastructure") or {}
    docker, k8s, iac = infra.get("docker"), infra.get("kubernetes"), infra.get("iac")
    if not (docker or k8s or iac):
        return None
    parts = []
    if docker:
        parts.append(f"container image built from {joined(docker)}")
    if k8s:
        parts.append(f"Kubernetes manifests: {joined(k8s)}")
    if iac:
        parts.append(f"infrastructure as code: {joined(iac)}")
    return ("Distribution: " + "; ".join(parts) + ".", [])


def r_cicd(ctx, rules):
    ci = (ctx.get("infrastructure") or {}).get("ci")
    if not ci:
        return None
    return (f"Automated pipeline defined in {joined(ci)}. Rollback procedure: "
            f"[A CONFIRMER - not derivable from the pipeline definition]."), []


def r_model_artefacts(ctx, rules):
    git = ctx.get("git") or {}
    if not git.get("remote"):
        return None
    ref = git.get("tag") or (git.get("commit") or "")[:12]
    return (f"Versioned source: {git['remote']} at {ref}. Machine readable component "
            f"inventory: aida/ml-bom.json (CycloneDX 1.6)."), [f"git remote {git['remote']}"]


def r_substantial_changes(ctx, rules):
    git = ctx.get("git") or {}
    if not git.get("last_commit_date"):
        return None
    return (f"Last substantial change to the codebase: {git['last_commit_date']}. "
            f"This documentation reflects that state."), [f"git log -1 {git.get('commit', '')[:12]}"]


# --- record keeping (section 3.7) -------------------------------------------------
def r_record_historization(ctx, rules):
    item = rule(rules, "REC-MODEL-MANDATORY")
    records = joined(r.replace("_", " ") for r in item["records"])
    obs = list(ctx.get("observability") or {})
    where = (f"Currently collected through {joined(obs)}." if obs else
             "No collection mechanism was found in the codebase - this is a gap to close "
             "before the end of the build phase.")
    return (f"Mandatory records under {item['source']} ({item['id']}): {records}. {where}"), []


def r_record_events(ctx, rules):
    item = rule(rules, "REC-OPERATIONAL-MANDATORY")
    mandatory = joined(r.replace("_", " ") for r in item["records"])
    logging = ctx.get("logging") or {}
    state = ("Structured logging is in place." if logging.get("structured") else
             "Logging is present but not structured; the guideline requires structured, "
             "timestamped, standardised records (REC-FORMAT).")
    corr = ("A correlation identifier is used." if logging.get("has_correlation_id")
            else "No correlation identifier was found, so events cannot be tied to a session.")
    return (f"Every record must answer what, when and who. Mandatory: {mandatory} "
            f"({item['id']}). {state} {corr}"), evidence_of(logging.get("calls"), 3)


def r_record_feedback(ctx, rules):
    item = rule(rules, "MON-USER-FEEDBACK")
    signals = ctx.get("oversight_signals") or {}
    if "feedback" in signals:
        return (f"A user feedback path exists in the code. {item['requirement']}"), \
               evidence_of({"feedback": signals["feedback"]}, 3)
    return (f"No user feedback mechanism was found. {item['requirement']} "
            f"Closing this gap is required ({item['id']})."), []


def r_record_tools(ctx, rules):
    obs = list(ctx.get("observability") or {})
    retention = rule(rules, "REC-RETENTION")["threshold"]
    if obs:
        return (f"Record keeping relies on {joined(obs)}. Retention: documentation "
                f"{retention['documentation_years']} years, automatic logs at least "
                f"{retention['automatic_logs_years_min']} year, in secure and immutable "
                f"storage with NTP-synchronised timestamps (REC-RETENTION)."), \
               evidence_of(ctx.get("observability"), 3)
    return (f"No record keeping tool was found in the codebase. The guideline expects a "
            f"centralised, secure log store, retention of "
            f"{retention['documentation_years']} years for documentation and at least "
            f"{retention['automatic_logs_years_min']} year for automatic logs "
            f"(REC-RETENTION)."), []


# --- monitoring (section 3.8) -----------------------------------------------------
def r_model_metrics(ctx, rules):
    family = (ctx.get("classification") or {}).get("family", "unknown")
    item = rule(rules, "MON-GENAI-QUALITY-MINIMUM")
    metrics = joined(m.replace("_", " ") for m in item["prompt_metrics"])
    specific = joined(m.replace("_", " ") for m in item["genai_specific"])
    return (f"For a {family} system the guideline requires at least one quality metric "
            f"to be monitored, chosen from: {metrics}. GenAI-specific signals: {specific}. "
            f"The metrics selected here are the ones computed during the build-phase "
            f"evaluation, so the two phases stay comparable ({item['id']})."), []


def r_metrics_alignment(ctx, rules):
    return ("The monitoring metrics are the evaluation metrics computed in the build "
            "phase. That is what makes the baseline meaningful: a production score is "
            "only interpretable against a score obtained the same way."), []


def r_operational_metrics(ctx, rules):
    item = rule(rules, "MON-OPERATIONAL-MINIMUM")
    reliability = [m for m in item["metrics"] if m["category"] == "operational reliability"]
    sample = "; ".join(f"{m['name'].replace('_', ' ')} (alert {m['alert']})"
                       for m in reliability[:5])
    return (f"At least one metric must be chosen from the guideline table ({item['id']}). "
            f"Reliability metrics and their reference thresholds: {sample}. "
            f"Token usage is tracked against a defined quota for FinOps."), []


def r_performance_drops(ctx, rules):
    family = (ctx.get("classification") or {}).get("family", "unknown")
    mapping = {"prompt": "MON-THRESHOLD-PROMPT", "rag": "MON-THRESHOLD-RAG",
               "agentic": "MON-THRESHOLD-AGENTIC", "hybrid": "MON-THRESHOLD-RAG"}
    if family not in mapping:
        return None
    item = rule(rules, mapping[family])
    pct = item["threshold"]["relative_drop_pct"]
    return (f"A relative performance decrease of {pct}% or more against the build-phase "
            f"baseline triggers an alert ({item['id']}). The alert opens an investigation "
            f"whose findings and corrective measures are documented in the AI System "
            f"Journal. A stricter threshold may be adopted; a looser one may not."), []


def r_monitoring_schedule(ctx, rules):
    item = rule(rules, "MON-FREQUENCY")
    mapping = "; ".join(f"{k} inference to {v} monitoring" for k, v in item["mapping"].items())
    return (f"Frequency is proportionate to inference frequency and system risk: {mapping} "
            f"({item['id']}). The applicable inference frequency is "
            f"[A CONFIRMER - not observable from the code]."), []


def r_baseline_choice(ctx, rules):
    evaluation = list(ctx.get("evaluation") or {})
    tail = (f" Evaluation tooling found in the project: {joined(evaluation)}." if evaluation
            else " No evaluation framework was found; the baseline must be established "
                 "before the end of the build phase.")
    return ("The baseline is the set of metrics computed during the build-phase "
            "evaluation." + tail), evidence_of(ctx.get("evaluation"), 2)


def r_alert_mechanism(ctx, rules):
    return ("Threshold crossings raise an automated alert (mail or system notification) "
            "to the named human overseers. Isolated events must not trigger a "
            "disproportionate reaction; a major alert is escalated to the governance "
            "bodies, which decide on suspension or on validating corrective measures."), []


def r_addressing_alerts(ctx, rules):
    return ("Investigate the cause, confront it with engineering or business judgement, "
            "and document whether corrective measures were taken - and why, if they were "
            "not. Corrective measures range from user training and prompt or guardrail "
            "updates to retraining. Every substantial alert, its investigation and its "
            "outcome are recorded in the AI System Journal (DOC-JOURNAL)."), []


def r_logging_mechanisms(ctx, rules):
    logging = ctx.get("logging") or {}
    obs = list(ctx.get("observability") or {})
    if not (logging.get("calls") or obs):
        return None
    parts = []
    if obs:
        parts.append(f"traces collected through {joined(obs)}")
    if logging.get("calls"):
        parts.append("application logging present in the code")
    if logging.get("uses_print"):
        parts.append("some output still goes through print statements, which are not "
                     "structured records")
    return ("; ".join(parts).capitalize() + ".", evidence_of(logging.get("calls"), 3))


# --- human oversight (section 3.9) ------------------------------------------------
def r_oversight_measures(ctx, rules):
    caps = rule(rules, "OVERSIGHT-CAPABILITIES")
    mech = rule(rules, "OVERSIGHT-INTERVENTION")
    signals = ctx.get("oversight_signals") or {}
    side = ctx.get("side_effects") or {}

    present, missing = [], []
    for label, key in (("a stop or kill switch", "kill_switch"),
                       ("a human approval gate before an action", "human_approval"),
                       ("a user feedback or flag control", "feedback"),
                       ("source citation in the outputs", "citation")):
        (present if key in signals else missing).append(label)

    text = (f"Required capabilities ({caps['id']}): "
            + "; ".join(caps["capabilities"]) + ". ")
    text += (f"Detected in the codebase: {joined(present)}. " if present
             else "None of the intervention mechanisms were detected in the codebase. ")
    if missing:
        text += f"Not detected, and therefore to be implemented: {joined(missing)}. "
    if side:
        text += (f"The system performs irreversible actions ({joined(side)}), so the "
                 f"override and stop controls required by {mech['id']} are not optional.")
    proof = evidence_of(signals, 3) + evidence_of(side, 2)
    return text, proof[:4]


def r_explainability(ctx, rules):
    item = rule(rules, "OVERSIGHT-EXPLAINABILITY")
    signals = ctx.get("oversight_signals") or {}
    family = (ctx.get("classification") or {}).get("family")
    options = "; ".join(item["options"])
    if "citation" in signals:
        return (f"At least one explainability measure is required ({item['id']}); the "
                f"system exposes reference links to the retrieved evidence supporting "
                f"each answer. Available options: {options}."), \
               evidence_of({"citation": signals["citation"]}, 2)
    hint = (" For a retrieval-based system, showing the retrieved sources is the option "
            "the guideline names for GenAI." if family in ("rag", "hybrid") else "")
    return (f"No explainability measure was detected. At least one is required "
            f"({item['id']}): {options}.{hint}"), []


def r_oversight_journal(ctx, rules):
    item = rule(rules, "DOC-JOURNAL")
    return ("Human overseers record their interventions and the justification for each in "
            f"the AI System Journal appended to this document ({item['id']}). Alerts, the "
            "investigation they triggered and the corrective measures taken are logged "
            "there as well, which is what makes the oversight auditable rather than "
            "merely asserted."), []


def r_continuous_compliance(ctx, rules):
    item = rule(rules, "DOC-UPDATE-ON-CHANGE")
    return ("This documentation is regenerated from the codebase, so a substantial change "
            "is detected by comparing the recorded evidence against the current code "
            f"(check_freshness.py). {item['requirement']}"), []


def r_guardrails(ctx, rules):
    security = ctx.get("security") or {}
    if not security:
        return ("No guardrail or red-teaming tooling was found in the codebase. The "
                "Building Agentic AI Systems guideline names DeepTeam, whose attack "
                "library follows the OWASP LLM Top 10 (BUILD-REDTEAM)."), []
    return (f"Security tooling present: {joined(security)}."), evidence_of(security, 3)


# --- evaluation (sections 3.3 / 3.4) ----------------------------------------------
def r_evaluation_metrics(ctx, rules):
    family = (ctx.get("classification") or {}).get("family")
    if family in ("rag", "hybrid"):
        item = rule(rules, "EVAL-RAG-METRICS")
        return (f"Evaluation must cover retrieval and generation ({item['id']}). "
                f"Generation: {joined(item['mandatory_generation'])}. "
                f"Retrieval: {joined(item['mandatory_retrieval'])}."), []
    if family == "agentic":
        item = rule(rules, "EVAL-AGENTIC-CATEGORIES")
        cats = "; ".join(
            f"{name.replace('_', ' ')} (tier {meta['tier']}, recommended: "
            f"{joined(meta['recommended'])})" for name, meta in item["categories"].items())
        return (f"At least one metric from each applicable category ({item['id']}): "
                f"{cats}. Categories marked * apply to every agentic system, ** adds at "
                f"L2, *** adds at L3."), []
    return None


def r_validation_procedures(ctx, rules):
    family = (ctx.get("classification") or {}).get("family")
    if family in ("rag", "hybrid"):
        queries = rule(rules, "EVAL-RAG-QUERIES")["threshold"]["min_questions"]
        corpus = rule(rules, "EVAL-RAG-CORPUS")["threshold"]["min_documents"]
        return (f"The evaluation dataset must hold at least {queries} questions "
                f"representative of real usage, against a curated knowledge base of at "
                f"least {corpus} documents (EVAL-RAG-QUERIES, EVAL-RAG-CORPUS). "
                f"Highlighted passages are optional but materially improve reliability."), []
    if family == "agentic":
        queries = rule(rules, "EVAL-AGENTIC-QUERIES")["threshold"]["min_queries"]
        return (f"The evaluation set must hold at least {queries} queries spanning simple "
                f"tasks, multi-step tasks and edge cases - ambiguous instructions, missing "
                f"information, error handling - including some the agent should not or "
                f"cannot answer (EVAL-AGENTIC-QUERIES). Evaluation runs in a sandbox where "
                f"tool calls have no real-world consequence."), []
    return None


def r_introduction(ctx, rules):
    """A first draft from the scan alone. write_introduction.py rewrites it last, once the
    section audits exist - this draft only guarantees the field is never left empty."""
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from write_introduction import INTRODUCTION, build as introduction
    entry = introduction(ctx, {})[INTRODUCTION]
    return entry["value"], entry.get("evidence", [])


# Ordered: first keyword contained in the placeholder wins.
RENDERERS: list[tuple[str, object]] = [
    ("provide an overview about the ai system", r_introduction),
    ("ai system name", r_system_name),
    ("version of the ai system", r_system_version),
    ("documentation version number", r_documentation_version),
    ("clear versioning system", r_versioning_scheme),
    ("software dependencies", r_dependencies),
    ("compatible versions", r_dependencies),
    ("dependencies that must be updated", r_dependencies),
    ("third-party models", r_third_party_models),
    ("general logic of the selected model", r_model_logic),
    ("interaction with other ai systems", r_reference_stack),
    ("computational resources", r_computational_resources),
    ("form of distribution", r_deployment),
    ("deployment platforms", r_deployment),
    ("operational environment", r_deployment),
    ("installation and configuration", r_deployment),
    ("distribution and deployment procedures", r_cicd),
    ("update process", r_cicd),
    ("model artefacts", r_model_artefacts),
    ("substantial changes", r_substantial_changes),

    ("historization", r_record_historization),
    ("logs of the main events", r_record_events),
    ("users feedback", r_record_feedback),
    ("tools used for record keeping", r_record_tools),

    ("metrics used for model monitoring", r_model_metrics),
    ("alignment between the choice", r_metrics_alignment),
    ("metrics used for the operational", r_operational_metrics),
    ("performance drops", r_performance_drops),
    ("monitoring schedule", r_monitoring_schedule),
    ("baseline choice", r_baseline_choice),
    ("alert mechanism", r_alert_mechanism),
    ("addressing alerts", r_addressing_alerts),
    ("logging mechanisms", r_logging_mechanisms),
    ("tools and processes put in place", r_logging_mechanisms),

    ("human oversight measure", r_oversight_measures),
    ("alerts or action put in place", r_oversight_journal),
    ("continuous compliance", r_continuous_compliance),
    ("explainability", r_explainability),
    ("guardrails", r_guardrails),
    ("red teaming", r_guardrails),

    ("metrics used to test the model robustness", r_evaluation_metrics),
    ("evaluation metrics", r_evaluation_metrics),
    ("validation and testing procedures", r_validation_procedures),
]


def build(ctx: dict, routing: dict, rules: dict) -> tuple[dict, dict]:
    """Return (values, stats). Only `code` and `rule` fields are ever answered."""
    values: dict[str, dict] = {}
    stats = {"code": 0, "rule": 0, "skipped_human": 0, "no_renderer": 0}

    for placeholder, route in routing.items():
        source = route.get("source")
        if source not in ("code", "rule"):
            if source == "human":
                stats["skipped_human"] += 1
            continue

        low = placeholder.lower()
        rendered = None
        for keyword, renderer in RENDERERS:
            if keyword in low:
                rendered = renderer(ctx, rules)
                break

        if rendered is None:
            stats["no_renderer"] += 1
            continue

        value, evidence = rendered
        entry: dict = {"value": value, "source": source}
        if evidence:
            entry["evidence"] = evidence
        elif source == "code":
            # A code field with nothing to cite must not be asserted.
            stats["no_renderer"] += 1
            continue
        values[placeholder] = entry
        stats[source] += 1

    return values, stats


def main() -> int:
    parser = argparse.ArgumentParser(description="Derive the answers code and guidelines give.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json")
    parser.add_argument("--rules", default=str(DEFAULT_RULES))
    parser.add_argument("--out", default="aida/values.json")
    args = parser.parse_args()

    for label, path in (("context", args.context), ("placeholder map", args.routing),
                        ("rules", args.rules)):
        if not Path(path).exists():
            print(f"error: {label} not found: {path}", file=sys.stderr)
            return 2

    ctx = json.loads(Path(args.context).read_text(encoding="utf-8"))
    routing_raw = json.loads(Path(args.routing).read_text(encoding="utf-8"))
    routing = {p["placeholder"]: p for p in routing_raw["placeholders"]}
    rules = json.loads(Path(args.rules).read_text(encoding="utf-8"))

    values, stats = build(ctx, routing, rules)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        existing = json.loads(out.read_text(encoding="utf-8"))
        # Never overwrite an answer a human confirmed.
        kept = {k: v for k, v in existing.items()
                if isinstance(v, dict) and v.get("confirmed_by")}
        values.update(kept)
        print(f"kept {len(kept)} human-confirmed answer(s) from the existing file")
    out.write_text(json.dumps(values, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"Answered from the codebase : {stats['code']}")
    print(f"Answered from a guideline  : {stats['rule']}")
    print(f"Left for the risk owner    : {stats['skipped_human']}")
    print(f"No derivation available    : {stats['no_renderer']}")
    print(f"\nvalues written to {out}")
    print("Next: validate_values.py, then fill_docx.py.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
