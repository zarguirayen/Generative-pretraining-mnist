---
name: aida-record-keeping
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: experimental
compatibility: Requires Python 3.10+
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*)
description: >-
  Audits what an AI project actually records against the nine records the AI Factory
  guideline makes mandatory, checks which fields the inference log really carries,
  and writes section 3.7 of the AIDA technical documentation. Generates the missing
  record keeping as a hash-chained, tamper-evident journal that an auditor can verify
  with nothing but the file. Use it when asked about record keeping, logging,
  traceability, audit trails, log retention or EU AI Act Article 12, when asked
  whether a system's logs would survive an audit, and when writing or reviewing the
  record keeping section of AIDA documentation.
tags:
  - aida
  - record-keeping
  - eu-ai-act
  - article-12
  - logging
  - audit-trail
  - traceability
---

# aida-record-keeping

Answers what a log file cannot answer on its own: are the mandatory records kept, do they
carry the fields that make them useful, and could anyone tell if they had been edited?

---

## Absolute rules

- **A span attribute is a field.** A project instrumented to the OpenTelemetry
  GenAI conventions records through `set_attribute`, not through log keywords;
  reporting it as recording nothing would penalise the teams who followed the
  standard.
- **A message string is not a field.** Only real keyword arguments and dictionary keys
  count as recorded fields; `logger.info("session=%s", sid)` records nothing structured.
- **Never call retention satisfied because logs exist.** The guideline sets ten years for
  documentation and at least one year for automatic logs, in immutable storage.
- **Never write a credential, a token or a personal datum into a record.** The generated
  module redacts by key name; that is a safety net, not a licence to pass secrets.
- **Never edit the project's own source.** The module goes to `aida/generated/`; where the
  calls belong is an application decision.
- **A broken chain is an incident, not a warning.** Report it as such.
- **Report what was found and where.** If records are kept in a way the audit does not
  recognise, say so rather than concluding there are none.

---

## Purpose

Section 3.7 of the AIDA template asks how inputs, outputs and ground truth are collected
and historised, how main events are logged, how user feedback is captured, and with what
tools. Behind it, the Record Keeping guideline (EU AI Act Article 12) marks **nine
records mandatory** for internally developed systems — six model records, two operational,
one oversight — and requires them structured, timestamped, automatic, and stored so they
cannot be altered unnoticed.

This skill checks all four things separately, because a project usually satisfies some and
not others:

| Question | Rule |
|---|---|
| Do the nine mandatory records have a mechanism? | `REC-MODEL-MANDATORY`, `REC-OPERATIONAL-MANDATORY`, `REC-OVERSIGHT-MANDATORY` |
| Do inference records carry the fields monitoring needs? | `REC-FORMAT` |
| Is the format structured? | `REC-FORMAT` |
| Is retention set, and is storage tamper-evident? | `REC-RETENTION` |

---

## Workflow

Copy this checklist and tick items off as you go:

```
Record keeping:
- [ ] Phase 1: audit the records and the fields
- [ ] Phase 2: report the coverage
- [ ] Phase 3: generate the missing record keeping
- [ ] Phase 4: verify the chain
- [ ] Phase 5: write section 3.7
```

### Phase 1 — Audit

```bash
python scripts/audit_records.py . --out aida/records_audit.json
```

Exits 1 on any blocking finding. Field names are read from the syntax tree, so the count
reflects what is really recorded.

### Phase 2 — Report the coverage

Two numbers first, then the detail:

```
Mandatory records with a mechanism : 2/9
Required fields actually logged    : 0/12
  MISSING: timestamp, session_id, request_id, actor, input, output,
           model_version, prompt_version, latency, tokens, tool_calls, outcome
  structured format        NO
  retention policy         NO
  tamper-evident storage   NO
```

If the field count is zero while logging clearly happens, explain why: `%`-style log
messages carry no fields, which is exactly the gap the guideline is aimed at.

### Phase 3 — Generate the missing record keeping

```bash
python scripts/generate_records.py --audit aida/records_audit.json --project .
```

Writes `aida/generated/aida_records.py` — one helper per mandatory record, over an
append-only journal where each entry carries the hash of the previous one — and prints the
call site for every missing record.

### Phase 4 — Verify the chain

```bash
python scripts/verify_chain.py logs/aida_records.jsonl
```

Editing an entry changes its own hash; removing one breaks the next link. Both are
reported with the entry number. Run it in CI, and at startup through
`records.require_intact()`.

### Phase 5 — Write section 3.7

```bash
python scripts/write_section.py --audit aida/records_audit.json --values aida/values.json --map aida/placeholders.json
```

It writes this section's fields into the shared values file. The placeholder map decides where each answer may come from: a field the template routes to a human is left as an open point, and one routed to the codebase is skipped unless there is something to cite. Answers carrying `confirmed_by` are never overwritten.

Then run the shared chain from `aida-core`:
`validate_values.py`, then `fill_docx.py`. The section must state which records are kept,
by what mechanism, with what retention, and which ones are still gaps to close **before
the end of the build phase** — the guideline's own deadline.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/write_section.py`](scripts/write_section.py) | Writes section 3.7 into `aida/values.json` |
| [`scripts/audit_records.py`](scripts/audit_records.py) | Coverage of the nine mandatory records and the twelve required fields |
| [`scripts/generate_records.py`](scripts/generate_records.py) | Writes the journal module and the call site for each gap |
| [`scripts/verify_chain.py`](scripts/verify_chain.py) | Standalone integrity check — needs only the file |
| [`references/record_requirements.md`](references/record_requirements.md) | The three record tables, retention, and what code can and cannot show |
| [`assets/aida_records.py.template`](assets/aida_records.py.template) | The module that gets generated |

From `aida-core`: `scan_codebase.py`, `validate_values.py`, `fill_docx.py`,
`references/aida_rules.json`.

---

## Quality checklist

- [ ] All nine mandatory records were checked, each reported present or missing
- [ ] Field coverage was read from the syntax tree, not from log message text
- [ ] Structured format, retention and immutability were checked separately
- [ ] The generated module went to `aida/generated/`, project source untouched
- [ ] `verify_chain.py` was run and its result reported
- [ ] Retention is stated in the guideline's numbers: 10 years and 1 year
- [ ] Remaining gaps are named as gaps, with the build-phase deadline
