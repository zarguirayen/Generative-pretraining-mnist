#!/usr/bin/env python3
"""Detect a change in the agent's tool set between two git revisions.

    python detect_tool_drift.py --from v1.4.0 --to HEAD [--project .]

The guideline treats this as critical and says so plainly: *any tool addition or removal,
and any tool parameter addition or removal, must raise an alert* (`MON-DRIFT-TOOLSET`).
The reason is that the tool set defines what the system can do — change it and the
evaluation, the human oversight analysis and the technical documentation all describe a
system that no longer exists.

Both revisions are read straight out of git objects, so the working tree is never touched
and no checkout is needed.

Exit code 0 when the tool set is unchanged, 1 when it drifted, 2 on a usage error.
Standard library only.
"""

from __future__ import annotations

import argparse
import ast
import json
import subprocess
import sys
from pathlib import Path

TOOL_DECORATORS = ("tool", "function_tool", "structuredtool", "kernel_function", "agent_tool")


def git(project: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(project), *args],
                            capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"git {' '.join(args)} failed")
    return result.stdout


def dotted(node: ast.AST) -> str:
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return ".".join(reversed(parts)).lower()


def is_tool(func: ast.AST) -> bool:
    for decorator in getattr(func, "decorator_list", []):
        target = decorator.func if isinstance(decorator, ast.Call) else decorator
        name = dotted(target)
        if any(marker in name for marker in TOOL_DECORATORS):
            return True
    return False


def tools_at(project: Path, ref: str) -> dict[str, dict]:
    """name -> {parameters, docstring, file} for every model-callable tool at `ref`."""
    listing = git(project, "ls-tree", "-r", "--name-only", ref)
    tools: dict[str, dict] = {}

    for relative in listing.splitlines():
        if not relative.endswith(".py"):
            continue
        try:
            source = git(project, "show", f"{ref}:{relative}")
            tree = ast.parse(source)
        except (RuntimeError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and is_tool(node):
                signature = node.args
                tools[node.name] = {
                    "parameters": [a.arg for a in (list(signature.posonlyargs)
                                                   + list(signature.args)
                                                   + list(signature.kwonlyargs))],
                    "docstring": (ast.get_docstring(node) or "").strip(),
                    "file": relative,
                }
    return tools


def diff(before: dict, after: dict) -> dict:
    added = sorted(set(after) - set(before))
    removed = sorted(set(before) - set(after))
    changed: list[dict] = []

    for name in sorted(set(before) & set(after)):
        old, new = before[name], after[name]
        entry: dict = {"tool": name}
        if old["parameters"] != new["parameters"]:
            entry["parameters"] = {"before": old["parameters"], "after": new["parameters"]}
        if old["docstring"] != new["docstring"]:
            entry["description_changed"] = True
        if len(entry) > 1:
            changed.append(entry)

    alerts: list[dict] = []
    for name in added:
        alerts.append({"severity": "critical", "kind": "tool added", "tool": name,
                       "detail": f"`{name}` is callable by the model and was not there "
                                 f"before ({after[name]['file']})"})
    for name in removed:
        alerts.append({"severity": "critical", "kind": "tool removed", "tool": name,
                       "detail": f"`{name}` is gone; anything documented about it is now "
                                 f"wrong ({before[name]['file']})"})
    for entry in changed:
        if "parameters" in entry:
            alerts.append({"severity": "critical", "kind": "parameters changed",
                           "tool": entry["tool"],
                           "detail": f"{entry['parameters']['before']} -> "
                                     f"{entry['parameters']['after']}"})
        if entry.get("description_changed"):
            alerts.append({"severity": "warning", "kind": "description changed",
                           "tool": entry["tool"],
                           "detail": "the description steers when the model calls the tool; "
                                     "monitor it as NLP drift"})
    return {"added": added, "removed": removed, "changed": changed, "alerts": alerts}


def render(result: dict, before_ref: str, after_ref: str, counts: tuple[int, int]) -> str:
    lines = [f"Tool set {before_ref} -> {after_ref}",
             f"  tools before : {counts[0]}",
             f"  tools after  : {counts[1]}", ""]
    if not result["alerts"]:
        lines.append("Unchanged - no alert.")
        return "\n".join(lines)

    critical = [a for a in result["alerts"] if a["severity"] == "critical"]
    lines.append(f"ALERTS ({len(result['alerts'])}, {len(critical)} critical) "
                 f"- MON-DRIFT-TOOLSET")
    for alert in result["alerts"]:
        marker = "CRITICAL" if alert["severity"] == "critical" else "warning"
        lines.append(f"  [{marker}] {alert['kind']}: {alert['tool']}")
        lines.append(f"      {alert['detail']}")
    lines.append("")
    lines.append("A critical alert here means three documents are now out of date: the "
                 "evaluation set, the human oversight analysis, and section 3.9 of the "
                 "technical documentation. Record the change in the AI System Journal.")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Detect tool set drift between two refs.")
    parser.add_argument("--from", dest="before", required=True, help="baseline ref")
    parser.add_argument("--to", dest="after", default="HEAD")
    parser.add_argument("--project", default=".")
    parser.add_argument("--out", default="aida/tool_drift.json")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    project = Path(args.project).resolve()
    try:
        before = tools_at(project, args.before)
        after = tools_at(project, args.after)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    result = diff(before, after)
    result["from"] = args.before
    result["to"] = args.after

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(result, indent=2, ensure_ascii=False) if args.json
          else render(result, args.before, args.after, (len(before), len(after))))
    print(f"\nwritten to {out}")
    return 1 if result["alerts"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
