/**
 * API applicative sur ECS Fargate + ALB, et tâches planifiées.
 *
 * Pourquoi Fargate et non Lambda : les runs SSE dépassent régulièrement les
 * 15 minutes de Lambda (une phase de spécification complète, c'est plusieurs
 * minutes d'inférence, et le streaming doit rester ouvert).
 */
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecsPatterns from 'aws-cdk-lib/aws-ecs-patterns';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';

export interface ApiStackProps extends cdk.StackProps {
  readonly envName: 'staging' | 'prod';
  readonly vpc: ec2.Vpc;
  readonly database: rds.DatabaseCluster;
  readonly artifactsBucket: s3.Bucket;
  readonly userPoolId: string;
  readonly userPoolClientId: string;
}

export class ApiStack extends cdk.Stack {
  public readonly serviceUrl: string;

  constructor(scope: Construct, id: string, props: ApiStackProps) {
    super(scope, id, props);
    const isProd = props.envName === 'prod';

    const cluster = new ecs.Cluster(this, 'Cluster', {
      vpc: props.vpc,
      containerInsights: isProd,
    });

    // Secrets applicatifs (Stripe, LangSmith) — créés hors CDK puis référencés,
    // pour ne jamais faire transiter une clé dans le code d'infrastructure.
    const appSecrets = secretsmanager.Secret.fromSecretNameV2(
      this,
      'AppSecrets',
      `cadrage/${props.envName}/app`,
    );

    const service = new ecsPatterns.ApplicationLoadBalancedFargateService(this, 'Api', {
      cluster,
      cpu: isProd ? 1024 : 512,
      memoryLimitMiB: isProd ? 2048 : 1024,
      desiredCount: isProd ? 2 : 1,
      taskSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      taskImageOptions: {
        image: ecs.ContainerImage.fromAsset('../backend'),
        containerPort: 8000,
        logDriver: ecs.LogDrivers.awsLogs({
          streamPrefix: 'api',
          logRetention: isProd ? logs.RetentionDays.THREE_MONTHS : logs.RetentionDays.ONE_WEEK,
        }),
        environment: {
          ENV: props.envName,
          AWS_REGION: this.region,
          S3_BUCKET: props.artifactsBucket.bucketName,
          COGNITO_USER_POOL_ID: props.userPoolId,
          COGNITO_CLIENT_ID: props.userPoolClientId,
          LANGSMITH_TRACING: 'true',
          LANGSMITH_PROJECT: `cadrage-${props.envName}`,
        },
        secrets: {
          DATABASE_URL: ecs.Secret.fromSecretsManager(appSecrets, 'database_url'),
          STRIPE_SECRET_KEY: ecs.Secret.fromSecretsManager(appSecrets, 'stripe_secret_key'),
          STRIPE_WEBHOOK_SECRET: ecs.Secret.fromSecretsManager(appSecrets, 'stripe_webhook_secret'),
          LANGSMITH_API_KEY: ecs.Secret.fromSecretsManager(appSecrets, 'langsmith_api_key'),
        },
      },
      publicLoadBalancer: true,
      healthCheckGracePeriod: cdk.Duration.seconds(90),
    });

    // SSE : l'ALB doit garder les connexions ouvertes plus longtemps que le défaut.
    service.targetGroup.setAttribute('deregistration_delay.timeout_seconds', '60');
    service.targetGroup.configureHealthCheck({
      path: '/healthz',
      interval: cdk.Duration.seconds(30),
      healthyThresholdCount: 2,
    });
    service.loadBalancer.setAttribute('idle_timeout.timeout_seconds', '900');

    // ── Permissions ───────────────────────────────────────────────
    const task = service.taskDefinition.taskRole;

    // Bedrock : uniquement les modèles utilisés, pas `*`.
    task.addToPrincipalPolicy(
      new iam.PolicyStatement({
        actions: ['bedrock:InvokeModel', 'bedrock:InvokeModelWithResponseStream'],
        resources: [
          `arn:aws:bedrock:${this.region}::foundation-model/anthropic.claude-*`,
          `arn:aws:bedrock:${this.region}:${this.account}:inference-profile/eu.anthropic.claude-*`,
        ],
      }),
    );

    // S3 : le préfixe `tenants/` uniquement — la barrière d'isolation est aussi
    // dans IAM, pas seulement dans le code applicatif.
    task.addToPrincipalPolicy(
      new iam.PolicyStatement({
        actions: ['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:ListBucket'],
        resources: [
          props.artifactsBucket.bucketArn,
          `${props.artifactsBucket.bucketArn}/tenants/*`,
        ],
      }),
    );
    props.artifactsBucket.encryptionKey?.grantEncryptDecrypt(task);
    props.database.connections.allowDefaultPortFrom(service.service, 'API vers Aurora');

    // ── Remontée d'usage vers Stripe (toutes les heures) ──────────
    const meteringTask = new ecs.FargateTaskDefinition(this, 'MeteringTask', {
      cpu: 256,
      memoryLimitMiB: 512,
      taskRole: task,
    });
    meteringTask.addContainer('metering', {
      image: ecs.ContainerImage.fromAsset('../backend'),
      command: ['python', '-m', 'app.jobs.report_usage'],
      logging: ecs.LogDrivers.awsLogs({ streamPrefix: 'metering' }),
      environment: { ENV: props.envName, AWS_REGION: this.region },
      secrets: {
        DATABASE_URL: ecs.Secret.fromSecretsManager(appSecrets, 'database_url'),
        STRIPE_SECRET_KEY: ecs.Secret.fromSecretsManager(appSecrets, 'stripe_secret_key'),
      },
    });

    new events.Rule(this, 'MeteringSchedule', {
      schedule: events.Schedule.rate(cdk.Duration.hours(1)),
      targets: [
        new targets.EcsTask({
          cluster,
          taskDefinition: meteringTask,
          subnetSelection: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
        }),
      ],
    });

    this.serviceUrl = `https://${service.loadBalancer.loadBalancerDnsName}`;
    new cdk.CfnOutput(this, 'ApiUrl', { value: this.serviceUrl });
  }
}
