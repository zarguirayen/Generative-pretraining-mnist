/**
 * Socle de données : VPC, Aurora Serverless v2, S3 des artefacts, Cognito.
 *
 * Choix : Aurora Serverless v2 avec `minCapacity: 0.5` — on paie très peu à vide,
 * et le checkpointer LangGraph exige un PostgreSQL transactionnel disponible en
 * permanence (Data API seule ne suffirait pas).
 */
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as kms from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';

export interface DataStackProps extends cdk.StackProps {
  readonly envName: 'staging' | 'prod';
}

export class DataStack extends cdk.Stack {
  public readonly vpc: ec2.Vpc;
  public readonly database: rds.DatabaseCluster;
  public readonly artifactsBucket: s3.Bucket;
  public readonly userPool: cognito.UserPool;
  public readonly userPoolClient: cognito.UserPoolClient;

  constructor(scope: Construct, id: string, props: DataStackProps) {
    super(scope, id, props);
    const isProd = props.envName === 'prod';

    // ── Réseau ────────────────────────────────────────────────────
    this.vpc = new ec2.Vpc(this, 'Vpc', {
      maxAzs: isProd ? 3 : 2,
      natGateways: isProd ? 2 : 1, // le NAT est le poste coûteux : 1 seul hors prod
      subnetConfiguration: [
        { name: 'public', subnetType: ec2.SubnetType.PUBLIC, cidrMask: 24 },
        { name: 'private', subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS, cidrMask: 24 },
        { name: 'isolated', subnetType: ec2.SubnetType.PRIVATE_ISOLATED, cidrMask: 24 },
      ],
    });

    // Bedrock via endpoint privé : le trafic d'inférence ne sort pas du VPC.
    this.vpc.addInterfaceEndpoint('BedrockRuntime', {
      service: ec2.InterfaceVpcEndpointAwsService.BEDROCK_RUNTIME,
    });
    this.vpc.addGatewayEndpoint('S3Endpoint', {
      service: ec2.GatewayVpcEndpointAwsService.S3,
    });

    // ── Chiffrement ───────────────────────────────────────────────
    const key = new kms.Key(this, 'DataKey', {
      enableKeyRotation: true,
      description: 'Chiffrement des artefacts et de la base Cadrage',
      removalPolicy: isProd ? cdk.RemovalPolicy.RETAIN : cdk.RemovalPolicy.DESTROY,
    });

    // ── Base de données ───────────────────────────────────────────
    this.database = new rds.DatabaseCluster(this, 'Database', {
      engine: rds.DatabaseClusterEngine.auroraPostgres({
        version: rds.AuroraPostgresEngineVersion.VER_16_4,
      }),
      vpc: this.vpc,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
      serverlessV2MinCapacity: isProd ? 1 : 0.5,
      serverlessV2MaxCapacity: isProd ? 16 : 4,
      writer: rds.ClusterInstance.serverlessV2('writer'),
      readers: isProd ? [rds.ClusterInstance.serverlessV2('reader', { scaleWithWriter: true })] : [],
      defaultDatabaseName: 'cadrage',
      credentials: rds.Credentials.fromGeneratedSecret('cadrage_admin'),
      storageEncryptionKey: key,
      backup: { retention: cdk.Duration.days(isProd ? 30 : 7) },
      deletionProtection: isProd,
      removalPolicy: isProd ? cdk.RemovalPolicy.RETAIN : cdk.RemovalPolicy.DESTROY,
    });

    // ── Artefacts ─────────────────────────────────────────────────
    this.artifactsBucket = new s3.Bucket(this, 'Artifacts', {
      encryption: s3.BucketEncryption.KMS,
      encryptionKey: key,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      enforceSSL: true,
      // Versioning : l'historique v0.1 → v1.1 des livrables est natif.
      versioned: true,
      lifecycleRules: [
        { noncurrentVersionExpiration: cdk.Duration.days(180) },
        { abortIncompleteMultipartUploadAfter: cdk.Duration.days(7) },
      ],
      removalPolicy: isProd ? cdk.RemovalPolicy.RETAIN : cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: !isProd,
    });

    // ── Identité ──────────────────────────────────────────────────
    this.userPool = new cognito.UserPool(this, 'Users', {
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      standardAttributes: {
        email: { required: true, mutable: false },
        fullname: { required: false, mutable: true },
      },
      passwordPolicy: {
        minLength: 12,
        requireDigits: true,
        requireLowercase: true,
        requireUppercase: true,
        requireSymbols: true,
      },
      accountRecovery: cognito.AccountRecovery.EMAIL_ONLY,
      mfa: isProd ? cognito.Mfa.OPTIONAL : cognito.Mfa.OFF,
      removalPolicy: isProd ? cdk.RemovalPolicy.RETAIN : cdk.RemovalPolicy.DESTROY,
    });

    this.userPoolClient = this.userPool.addClient('WebClient', {
      authFlows: { userSrp: true },
      accessTokenValidity: cdk.Duration.hours(1),
      refreshTokenValidity: cdk.Duration.days(30),
      preventUserExistenceErrors: true,
    });

    new cdk.CfnOutput(this, 'UserPoolId', { value: this.userPool.userPoolId });
    new cdk.CfnOutput(this, 'UserPoolClientId', { value: this.userPoolClient.userPoolClientId });
    new cdk.CfnOutput(this, 'ArtifactsBucket', { value: this.artifactsBucket.bucketName });
    new cdk.CfnOutput(this, 'DbSecretArn', { value: this.database.secret!.secretArn });
  }
}
