# Déploiement

## 0. Prérequis

- Node 20+, Python 3.12+, Docker, AWS CLI configuré (`aws configure --profile cadrage`)
- Un compte Stripe (mode test suffit pour valider le parcours complet)
- Une clé LangSmith (facultatif mais fortement recommandé : sans traces, le débogage
  d'un pipeline à 9 agents est pénible et le coût réel reste invisible)

## 1. Activer l'accès aux modèles Bedrock

**À faire en premier** : sans cette étape, tout appel échoue en `AccessDeniedException`.

Console AWS → Bedrock → *Model access* → activer les modèles Claude dans la région
choisie (`eu-west-3` par défaut ici). Vérifier ensuite :

```bash
aws bedrock list-foundation-models --region eu-west-3 --profile cadrage \
  --query "modelSummaries[?contains(modelId,'claude')].modelId"
```

Les identifiants commençant par `eu.` sont des *inference profiles* : ils sont
obligatoires pour les modèles récents et répartissent la charge entre régions UE.

## 2. Développement local

```bash
cp .env.example .env          # renseigner AWS_PROFILE, LangSmith, Stripe test
docker compose up -d postgres minio createbucket
cd backend
pip install -e ".[dev]"
alembic upgrade head
python -m app.seed             # crée un tenant de démonstration + un utilisateur
uvicorn app.main:app --reload
```

Dans un autre terminal :

```bash
cd frontend && npm install && npm run dev
```

Le premier run réel se fait ici : lancer un cadrage, vérifier dans LangSmith le
coût observé, puis **ajuster `PRICE_CENTS_PER_MTOK_*`** avant d'ouvrir les
inscriptions. Tant que ce calibrage n'est pas fait, la marge est théorique.

## 3. Secrets AWS

Créer le secret applicatif référencé par la stack API :

```bash
aws secretsmanager create-secret \
  --name cadrage/staging/app \
  --profile cadrage --region eu-west-3 \
  --secret-string '{
    "database_url": "postgresql+asyncpg://cadrage_admin:MOTDEPASSE@CLUSTER:5432/cadrage",
    "stripe_secret_key": "sk_test_xxx",
    "stripe_webhook_secret": "whsec_xxx",
    "langsmith_api_key": "lsv2_pt_xxx"
  }'
```

`database_url` se complète après le déploiement de la stack Data (l'endpoint du
cluster n'existe pas avant). Ordre pratique : déployer Data → récupérer l'endpoint
et le secret généré → créer/mettre à jour le secret applicatif → déployer Api.

## 4. Infrastructure

```bash
cd infra
npm install
npx cdk bootstrap --profile cadrage           # une seule fois par compte/région
npx cdk deploy Cadrage-staging-Data --profile cadrage
# … compléter le secret applicatif avec l'endpoint Aurora …
npx cdk deploy Cadrage-staging-Api  --profile cadrage
```

Sorties utiles : `UserPoolId`, `UserPoolClientId`, `ArtifactsBucket`, `ApiUrl`.
Les reporter dans l'environnement du frontend.

## 5. Migrations en environnement AWS

Aurora est dans un sous-réseau isolé : les migrations passent par une tâche ECS
ponctuelle (même image que l'API), ou par un tunnel SSM depuis un bastion.

```bash
aws ecs run-task --cluster <cluster> --task-definition <api-task> \
  --launch-type FARGATE --profile cadrage \
  --network-configuration 'awsvpcConfiguration={subnets=[subnet-xxx],assignPublicIp=DISABLED}' \
  --overrides '{"containerOverrides":[{"name":"web","command":["alembic","upgrade","head"]}]}'
```

## 6. Rôle applicatif PostgreSQL (à faire une fois)

La barrière RLS ne vaut que si l'application se connecte avec un rôle **sans**
`BYPASSRLS`. Se connecter en administrateur et exécuter :

```sql
CREATE ROLE cadrage_app LOGIN PASSWORD '<mot de passe>' NOBYPASSRLS;
GRANT USAGE ON SCHEMA public TO cadrage_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO cadrage_app;
REVOKE UPDATE, DELETE ON audit_logs FROM cadrage_app;
```

Puis pointer `database_url` sur `cadrage_app`, **pas** sur `cadrage_admin`.
Vérification : `pytest tests/test_tenant_isolation.py` doit passer contre cette base.

## 7. Stripe

1. Produits : `Pro` (abonnement mensuel) et `Enterprise`.
2. Un prix **metered** basé sur un compteur nommé `cadrage_tokens` (unité : millier de
   tokens pondérés).
3. Webhook vers `https://<ApiUrl>/api/v1/webhooks/stripe`, événements :
   `customer.subscription.created|updated|deleted`, `invoice.payment_failed`.
4. Reporter les identifiants de prix dans le secret applicatif.

En local : `stripe listen --forward-to localhost:8000/api/v1/webhooks/stripe`.

## 8. Frontend

```bash
cd frontend
npm run build
# hébergement : Amplify Hosting (le plus simple) ou S3 + CloudFront
```

Variables : `NEXT_PUBLIC_API_URL`, `NEXT_PUBLIC_COGNITO_USER_POOL_ID`,
`NEXT_PUBLIC_COGNITO_CLIENT_ID`.

## 9. Vérifications avant ouverture aux clients

- [ ] `pytest tests/test_tenant_isolation.py` vert **contre la base de production**
      (avec le rôle `cadrage_app`)
- [ ] Un run complet observé de bout en bout dans LangSmith, coût réel relevé
- [ ] Tarification calibrée sur ce coût réel, marge vérifiée
- [ ] Webhook Stripe testé (souscription, échec de paiement, résiliation)
- [ ] Sauvegardes Aurora vérifiées par une **restauration réelle**, pas seulement
      par la présence du snapshot
- [ ] Quotas du plan `free` éprouvés : un compte gratuit ne doit pas pouvoir
      déclencher une facture Bedrock significative
- [ ] Registre RGPD à jour : Bedrock, LangSmith et Stripe sont des sous-traitants
- [ ] Purge d'un tenant testée (`storage.delete_tenant_data` + suppression en base)

## Coût indicatif (environnement staging, faible trafic)

| Poste | Ordre de grandeur |
|---|---|
| Aurora Serverless v2 (0,5 ACU minimum) | ~45 €/mois |
| NAT Gateway (1) | ~35 €/mois |
| Fargate (1 tâche 0,5 vCPU) | ~18 €/mois |
| ALB | ~20 €/mois |
| S3 + CloudWatch | quelques euros |
| **Bedrock** | à l'usage — dominant dès les premiers clients |

Le NAT et l'ALB sont les postes fixes qu'on peut supprimer en environnement de test
(sous-réseaux publics + API exposée directement), pas en production.
