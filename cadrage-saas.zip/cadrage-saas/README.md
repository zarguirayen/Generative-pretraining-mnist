# Cadrage SaaS — plateforme de cadrage projet piloté par agents

Produit multi-tenant autonome qui industrialise le pipeline **Cadrage → Spécification →
Plan → Estimation → Revue**, sans dépendance à un IDE ni à un outil tiers.

La méthode (agents, sous-agents, skills, gabarits) vit en Markdown dans
[`backend/kit/`](backend/kit/README.md) et est chargée à l'exécution — jamais réécrite
en code. Le service embarque tout ce dont il a besoin.

- **Orchestration** : LangGraph (graphe d'états + `interrupt()` pour les gates de validation humaine)
- **Inférence** : Amazon Bedrock (Claude), via `langchain-aws`
- **Hébergement des agents** : Amazon Bedrock AgentCore Runtime (sessions isolées longues) — repli ECS Fargate
- **Observabilité** : LangSmith (traces, évaluations, coûts par run)
- **Multi-tenant** : PostgreSQL + Row-Level Security, isolation S3 par préfixe, sessions AgentCore par tenant
- **Facturation** : Stripe (abonnement + metering à l'usage réel des tokens)
- **UI** : Next.js 15 (App Router) + Tailwind + shadcn/ui
- **IaC** : AWS CDK (TypeScript)

## Démarrage rapide (poste de dev)

```bash
cp .env.example .env          # renseigner AWS, LangSmith, Stripe
docker compose up -d          # postgres + minio + backend + frontend
cd backend && alembic upgrade head && python -m app.seed
```

API : http://localhost:8000/docs · UI : http://localhost:3000

## Documentation

| Document | Contenu |
|---|---|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Vue d'ensemble, choix techniques, modèle multi-tenant, flux d'un run |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Déploiement AWS pas à pas (CDK, AgentCore, Cognito, Stripe) |
| [backend/README.md](backend/README.md) | Structure du backend, graphe d'agents, tests |

## Arborescence

```
cadrage-saas/
├── infra/            CDK : réseau, Aurora, S3, Cognito, ECS, EventBridge
├── backend/          FastAPI + LangGraph + SQLAlchemy
│   ├── kit/          LA MÉTHODE : agents, sous-agents, skills, gabarits (.md)
│   ├── app/agents/   moteur : loader du kit, graphe, nœuds, sous-agents
│   ├── app/api/      REST v1 (projets, runs, gates, artefacts, facturation)
│   ├── app/db/       modèles multi-tenant + RLS
│   └── app/services/ facturation, quotas, stockage, tenants
└── frontend/         Next.js — console d'exécution, livrables, historique, facturation
```

### Interface

| Écran | Contenu |
|---|---|
| Tableau de bord | projets, état du steering, jauge de consommation |
| Exécutions | liste des runs, bandeau « décision requise », lancement (cadrage / revue / bug) |
| **Console d'un run** | activité des agents en direct, sorties, panneau de validation, livrables |
| **Livrables** | lecture Markdown rendue, copie, téléchargement `.md`, **export ZIP du workspace** |
| Contexte projet | steering product/tech/structure, éditable, rempli aussi par les agents |
| Historique | chronologie des exécutions, toutes les versions de chaque livrable |
| Abonnement | consommation du mois, plans, portail Stripe |
```

Le backend est **autosuffisant** : `docker build ./backend` embarque le kit et produit
une image déployable en l'état.

## Statut

Base de code initiale complète et cohérente : modèle de données, graphe d'agents avec gates,
API, facturation, infrastructure et UI. Voir la section « Reste à faire » d'[ARCHITECTURE.md](ARCHITECTURE.md)
pour les points à compléter avant une mise en production.
