# Architecture

## 1. Principe directeur

La **méthode** de cadrage (agents, skills, gabarits) vit en Markdown dans
`backend/kit/`, et l'**exécution** est assurée par ce service. Le kit est versionné,
buildé et déployé avec le backend : **le service est autonome, il ne dépend d'aucun
dossier extérieur.**

> **Règle fondatrice : le kit est la source de vérité, il n'est jamais réécrit.**
> `app/agents/kit_loader.py` charge les 16 agents `.agent.md`, les 7 `SKILL.md`, les
> instructions et les gabarits tels quels : il retire le frontmatter YAML, assemble
> l'agent avec les skills qu'il référence, et ajoute un préambule d'adaptation au
> contexte web. Aucun texte de méthode n'est réécrit en Python — le condenser
> dégraderait la sortie et créerait deux sources de vérité divergentes.
> Faire évoluer la méthode = modifier les `.md` de `backend/kit/`.
>
> Corollaire appliqué partout : les **critères de sortie des gates** sont extraits des
> cases `- [ ]` des fichiers du kit (`gate_criteria()`), jamais recopiés dans le code.

Chargement à deux niveaux, conforme au standard Agent Skills :

| Niveau | Contenu | Coût |
|---|---|---|
| 1 — toujours | corps de l'agent + skills qu'il référence, **intégralement** | inclus |
| 2 — catalogue | nom + description des autres skills | ~30 tokens/skill |

Les skills sont chargés d'office plutôt que sur décision du modèle : on ne parie pas sur
le fait qu'il pense à les demander. Coût mesuré des prompts assemblés : cadrage ~7 600
tokens, spécification ~3 200, plan ~4 100, revue ~3 300 — négligeable face au coût de
génération des documents.

L'exécution devient un **graphe LangGraph**, et les gates de validation des **interruptions
persistées** que l'UI présente à l'utilisateur.

```
Navigateur (Next.js)
   │  REST + SSE
   ▼
API FastAPI ──── Cognito (JWT)
   │                 │
   │                 └── tenant_id → contexte RLS PostgreSQL
   │
   ├── PostgreSQL (Aurora Serverless v2) : tenants, projets, runs, gates, usage
   │      └── checkpointer LangGraph (état du graphe entre deux interruptions)
   ├── S3 : artefacts markdown (workspace du projet), versionnés
   ├── Stripe : abonnements + metering
   └── Invocation du graphe
          ├── local/dev : in-process
          └── prod : Bedrock AgentCore Runtime (session isolée par run)
                        └── Bedrock (Claude) + traces LangSmith
```

## 2. Le graphe d'agents (LangGraph)

Le pipeline est un `StateGraph` dont chaque nœud est un agent du kit. Les gates humains utilisent
`interrupt()` : le graphe **s'arrête**, son état est persisté par le checkpointer Postgres, et il
reprend exactement au même point quand l'utilisateur répond — même des jours plus tard, sans
consommer de ressources entre-temps.

```
        ┌──────────────┐
        │ orchestrateur│  détecte le scénario, amorce le workspace
        └──────┬───────┘
               ▼
        ┌──────────────┐   sous-agents (fan-out parallèle) :
        │   cadrage    │──▶ faisabilite · risques · elicitateur
        └──────┬───────┘
        ⏸ GATE cadrage_valide
               ▼
        ┌──────────────┐
        │ spec_writer  │──▶ elicitateur
        └──────┬───────┘
        ⏸ GATE spec_validee
               ▼
        ┌──────────────┐
        │   planner    │──▶ risques · elicitateur · verificateur (GO/NO-GO)
        └──────┬───────┘
        ⏸ GATE plan_valide
               ▼
        ┌──────────────┐
        │  estimateur  │  (branche optionnelle, hors pipeline)
        └──────────────┘

Deux parcours indépendants, atteints directement depuis l'orchestrateur :

  ┌──────────┐  4 revues en parallèle (conformité · correction · sécurité ·
  │ reviewer │  patterns) → contre-vérification → verdict GO/NO-GO
  └────┬─────┘
  ⏸ GATE revue → boucle tant que des constats bloquants subsistent

  ┌──────────┐  entonnoir de diagnostic (tolérant au « je ne sais pas »),
  │  bugfix  │  condition du bug formalisée, correction test-first
  └────┬─────┘
  ⏸ GATE bugfix → boucle tant que le diagnostic n'a pas convergé
```

Le reviewer et le bugfix travaillent **exclusivement sur le code soumis**
(`state.code_context`, alimenté par les fichiers joints au run) : ils n'inventent
jamais un code qu'ils n'ont pas lu. L'audit de sécurité se déclenche d'office dès que
le changement touche l'authentification, un paiement, un upload ou une zone admin.

**Règle des deux niveaux** (héritée du kit, validée par le retour d'expérience Onyx sur la
dégradation de l'information en cascade) : un nœud d'entrée peut invoquer des sous-agents, un
sous-agent n'invoque jamais rien. Les sous-agents indépendants sont exécutés en parallèle
(`asyncio.gather`).

## 3. Modèle multi-tenant

Trois barrières indépendantes, aucune ne suffit seule :

1. **Base** : chaque table porte `tenant_id`; une politique RLS PostgreSQL filtre sur
   `current_setting('app.tenant_id')`. La session applicative pose ce paramètre à chaque requête
   (`app/db/session.py`). Un bug d'oubli de filtre dans une requête ne fuit donc rien.
2. **Stockage** : préfixe S3 `tenants/{tenant_id}/projects/{project_id}/...` + politique IAM
   restreinte par session (credentials temporaires scopés au préfixe).
3. **Exécution** : une session AgentCore Runtime par run, jamais réutilisée entre tenants ;
   l'identifiant de session porte le `tenant_id`.

Le rôle applicatif Postgres n'est **pas** propriétaire des tables (`NO BYPASSRLS`) : c'est ce qui
rend la barrière 1 réellement contraignante.

## 4. Facturation

| Élément | Choix |
|---|---|
| Abonnement | Stripe Billing — plans `free`, `pro`, `enterprise` |
| Usage | Metering Stripe : unité = **1 000 tokens Bedrock** (entrée + sortie pondérée) |
| Capture | Callback LangChain (`app/core/observability.py`) → table `usage_events` → agrégation horaire → Stripe |
| Quotas | Vérifiés **avant** le lancement d'un run (`app/services/quota.py`) : runs/mois, tokens/mois, projets, sièges |
| Dépassement | `402 Payment Required` avec le détail du quota atteint, jamais d'interruption en cours de run |

Les `usage_events` sont écrits même si l'envoi à Stripe échoue : la table est la source de vérité,
l'envoi est rejouable (idempotent via `event_id`).

## 5. Choix techniques et alternatives écartées

| Décision | Raison | Écarté |
|---|---|---|
| LangGraph plutôt que Step Functions | Les gates et le fan-out vivent dans le même langage que les prompts ; itération rapide. Step Functions reste pertinent si l'orchestration doit être auditée hors application | Step Functions `waitForTaskToken` |
| Checkpointer Postgres | Une seule base à opérer ; transactionnel avec les données métier | Redis (volatilité), DynamoDB (jointures) |
| AgentCore Runtime en prod | Sessions isolées jusqu'à 8 h, facturation à l'usage, pas de serveur à dimensionner pour des runs longs | ECS permanent (coût à vide) |
| Bedrock plutôt qu'API directe | Données et facturation dans le périmètre AWS du client ; modèles Claude disponibles | API Anthropic directe |
| Cognito | Intégration IAM/AgentCore native, coût nul à petite échelle | Auth0/Clerk (meilleure DX, dépendance externe) |

## 6. Écarts assumés avec le kit Copilot

| Élément du kit | Statut dans le SaaS |
|---|---|
| Textes des 16 agents et 7 skills | ✅ **identiques** — chargés depuis `kit/`, jamais réécrits |
| Gabarit de cadrage, constitution | ✅ fournis tels quels aux agents |
| 5 agents câblés dans le graphe (orchestrateur, cadrage, spec, plan, estimation) | ✅ |
| 4 sous-agents câblés (faisabilité, risques, élicitateur, vérificateur) | ✅ fan-out parallèle garanti |
| Reversement au steering | ✅ automatique à chaque phase (`steering_patch`) |
| `reviewer` + 4 sous-agents de revue, `bugfix` | ✅ **câblés** — parcours indépendants, code soumis par l'utilisateur |
| `capture-contexte` | ⚠️ non câblé (nécessite un connecteur Git) |
| Hooks déterministes | ⚠️ remplacés par les checklists mécaniques des gates |
| Notes de passation entre phases | ⚠️ implicites (l'état du graphe transporte le contexte) |
| Mémoire organisationnelle (`knowledge`) | ❌ non portée |

Câbler `reviewer` et `bugfix` ne demande plus de réécrire quoi que ce soit — leurs prompts
sont déjà chargeables. Il manque l'accès au code du client (dépôt Git connecté, isolation
par tenant), qui est un chantier produit à part entière.

### Différence de forme assumée

Les sous-agents du kit restituent en Markdown (tableaux, verdicts). La plateforme a besoin
d'un signal exploitable pour piloter l'interface : on ajoute donc un bloc ```control``` en
fin de réponse (`kit_loader.control_suffix`). **La restitution Markdown reste intacte** —
c'est elle que l'agent d'entrée intègre ; le bloc de contrôle ne sert qu'à alimenter la
checklist du gate et à détecter les constats bloquants.

## 7. Reste à faire avant production

- [ ] Tests de charge sur le checkpointer (runs concurrents par tenant)
- [ ] Chiffrement applicatif des artefacts sensibles (KMS par tenant, au-delà du SSE-S3)
- [ ] Rétention et purge RGPD (droit à l'effacement sur artefacts S3 + traces LangSmith)
- [ ] Rejeu automatique des envois Stripe en échec (file SQS + DLQ)
- [ ] Politique de reprise sur échec LLM en milieu de nœud (idempotence des écritures S3)
- [ ] Audit trail immuable des validations de gates (qui a validé quoi, quand)
