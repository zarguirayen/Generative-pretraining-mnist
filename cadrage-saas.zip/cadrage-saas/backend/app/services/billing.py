"""Facturation Stripe : abonnement + metering à l'usage.

Source de vérité = table `usage_events`. Stripe n'en est qu'un miroir : si un envoi
échoue, l'événement reste en base avec `reported_to_stripe = false` et sera rejoué.
On ne perd jamais de chiffre d'affaires à cause d'un incident réseau.
"""
from __future__ import annotations

import hashlib
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import stripe
from sqlalchemy import select, update

from app.config import settings
from app.db.models import Plan, Tenant, UsageEvent
from app.db.session import system_session, tenant_session

logger = logging.getLogger(__name__)

if settings.stripe_secret_key:
    stripe.api_key = settings.stripe_secret_key

PLAN_PRICES: dict[Plan, str | None] = {
    Plan.free: None,
    Plan.pro: settings.stripe_price_pro,
    Plan.enterprise: settings.stripe_price_enterprise,
}


# ─────────────────────────────────────────────────────────────────────
# Enregistrement de la consommation
# ─────────────────────────────────────────────────────────────────────
async def record_usage(
    tenant_id: uuid.UUID, run_id: uuid.UUID, records: list[dict[str, Any]]
) -> None:
    """Persiste la consommation d'un nœud. Idempotent : rejouer un nœud après un
    incident ne double pas la facture (clé = tenant+run+agent+tokens)."""
    if not records:
        return
    async with tenant_session(tenant_id) as session:
        for record in records:
            raw = (
                f"{tenant_id}:{run_id}:{record['agent']}:"
                f"{record['input_tokens']}:{record['output_tokens']}"
            )
            key = hashlib.sha256(raw.encode()).hexdigest()[:64]
            exists = await session.scalar(
                select(UsageEvent.id).where(UsageEvent.idempotency_key == key)
            )
            if exists:
                continue
            session.add(
                UsageEvent(
                    tenant_id=tenant_id,
                    run_id=run_id,
                    agent=record["agent"],
                    model_id=record["model_id"],
                    input_tokens=record["input_tokens"],
                    output_tokens=record["output_tokens"],
                    cost_cents=record["cost_cents"],
                    idempotency_key=key,
                )
            )


# ─────────────────────────────────────────────────────────────────────
# Remontée vers Stripe (tâche périodique)
# ─────────────────────────────────────────────────────────────────────
async def report_usage_to_stripe(window_hours: int = 1) -> int:
    """Agrège les événements non remontés et les envoie à Stripe.

    Appelée par un scheduler (EventBridge → Lambda) toutes les heures.
    L'unité facturée est le millier de tokens pondérés (sortie ×5, alignée sur
    l'écart de coût entrée/sortie de Bedrock).
    """
    if not settings.stripe_secret_key:
        return 0

    since = datetime.now(timezone.utc) - timedelta(hours=window_hours * 24)
    sent = 0

    async with system_session() as session:
        tenants = (
            await session.execute(
                select(Tenant).where(
                    Tenant.stripe_subscription_id.is_not(None),
                    Tenant.plan != Plan.free,
                )
            )
        ).scalars().all()

    for tenant in tenants:
        async with tenant_session(tenant.id) as session:
            events = (
                await session.execute(
                    select(UsageEvent).where(
                        UsageEvent.reported_to_stripe.is_(False),
                        UsageEvent.occurred_at >= since,
                    )
                )
            ).scalars().all()
            if not events:
                continue

            weighted = sum(e.input_tokens + e.output_tokens * 5 for e in events)
            units = max(1, weighted // 1000)

            try:
                stripe.billing.MeterEvent.create(
                    event_name="cadrage_tokens",
                    payload={
                        "stripe_customer_id": tenant.stripe_customer_id,
                        "value": str(units),
                    },
                    identifier=f"{tenant.id}-{datetime.now(timezone.utc):%Y%m%d%H}",
                )
            except Exception:  # noqa: BLE001 — on garde les événements pour rejeu
                logger.exception("Envoi Stripe échoué pour le tenant %s", tenant.id)
                continue

            await session.execute(
                update(UsageEvent)
                .where(UsageEvent.id.in_([e.id for e in events]))
                .values(reported_to_stripe=True)
            )
            sent += len(events)

    return sent


# ─────────────────────────────────────────────────────────────────────
# Abonnements
# ─────────────────────────────────────────────────────────────────────
async def ensure_customer(tenant: Tenant, email: str) -> str:
    if tenant.stripe_customer_id:
        return tenant.stripe_customer_id
    customer = stripe.Customer.create(
        email=email,
        name=tenant.name,
        metadata={"tenant_id": str(tenant.id), "slug": tenant.slug},
    )
    async with system_session() as session:
        db_tenant = await session.get(Tenant, tenant.id)
        if db_tenant:
            db_tenant.stripe_customer_id = customer.id
    return customer.id


async def create_checkout_session(
    tenant: Tenant, email: str, plan: Plan, success_url: str, cancel_url: str
) -> str:
    """Session Stripe Checkout : abonnement fixe + ligne metered pour l'usage."""
    price = PLAN_PRICES.get(plan)
    if not price:
        raise ValueError(f"Aucun prix Stripe configuré pour le plan {plan}")

    customer_id = await ensure_customer(tenant, email)
    line_items: list[dict[str, Any]] = [{"price": price, "quantity": 1}]
    if settings.stripe_price_metered_tokens:
        line_items.append({"price": settings.stripe_price_metered_tokens})

    session = stripe.checkout.Session.create(
        mode="subscription",
        customer=customer_id,
        line_items=line_items,
        success_url=success_url,
        cancel_url=cancel_url,
        subscription_data={"metadata": {"tenant_id": str(tenant.id), "plan": plan.value}},
    )
    return session.url


async def create_portal_session(tenant: Tenant, return_url: str) -> str:
    """Portail client Stripe : moyens de paiement, factures, résiliation."""
    if not tenant.stripe_customer_id:
        raise ValueError("Tenant sans client Stripe")
    session = stripe.billing_portal.Session.create(
        customer=tenant.stripe_customer_id, return_url=return_url
    )
    return session.url


# ─────────────────────────────────────────────────────────────────────
# Webhooks
# ─────────────────────────────────────────────────────────────────────
async def handle_webhook(payload: bytes, signature: str) -> dict[str, Any]:
    """Traite un événement Stripe. La signature est vérifiée : sans elle, un tiers
    pourrait activer gratuitement un abonnement."""
    event = stripe.Webhook.construct_event(
        payload, signature, settings.stripe_webhook_secret
    )
    data = event["data"]["object"]
    kind = event["type"]

    if kind in {"customer.subscription.created", "customer.subscription.updated"}:
        tenant_id = (data.get("metadata") or {}).get("tenant_id")
        plan_name = (data.get("metadata") or {}).get("plan", "pro")
        if tenant_id:
            await _apply_subscription(
                uuid.UUID(tenant_id),
                subscription_id=data["id"],
                plan=Plan(plan_name),
                active=data["status"] in {"active", "trialing"},
            )

    elif kind == "customer.subscription.deleted":
        tenant_id = (data.get("metadata") or {}).get("tenant_id")
        if tenant_id:
            await _apply_subscription(
                uuid.UUID(tenant_id), subscription_id=None, plan=Plan.free, active=True
            )

    elif kind == "invoice.payment_failed":
        customer_id = data.get("customer")
        await _suspend_by_customer(customer_id)

    return {"received": True, "type": kind}


async def _apply_subscription(
    tenant_id: uuid.UUID, *, subscription_id: str | None, plan: Plan, active: bool
) -> None:
    async with system_session() as session:
        tenant = await session.get(Tenant, tenant_id)
        if tenant is None:
            return
        tenant.stripe_subscription_id = subscription_id
        tenant.plan = plan
        tenant.subscription_active = active
        logger.info("Tenant %s → plan %s (actif=%s)", tenant_id, plan, active)


async def _suspend_by_customer(customer_id: str | None) -> None:
    if not customer_id:
        return
    async with system_session() as session:
        tenant = (
            await session.execute(
                select(Tenant).where(Tenant.stripe_customer_id == customer_id)
            )
        ).scalar_one_or_none()
        if tenant:
            tenant.subscription_active = False
            logger.warning("Tenant %s suspendu (paiement en échec)", tenant.id)
