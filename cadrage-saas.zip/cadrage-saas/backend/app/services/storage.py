"""Stockage des artefacts sur S3.

Isolation : la clé porte toujours `tenants/{tenant_id}/` en préfixe. Combinée à une
politique IAM restreignant le rôle applicatif à ce motif, elle constitue la deuxième
barrière du modèle multi-tenant (la première étant RLS côté base).
"""
from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timezone

import aioboto3

from app.config import settings

_session = aioboto3.Session()


def _client():
    return _session.client(
        "s3",
        region_name=settings.aws_region,
        endpoint_url=settings.s3_endpoint_url,  # MinIO en local
    )


def tenant_prefix(tenant_id: uuid.UUID) -> str:
    return f"tenants/{tenant_id}"


def artifact_key(
    *, tenant_id: uuid.UUID, project_id: uuid.UUID, kind: str, version: str
) -> str:
    """Reproduit l'arborescence du workspace du kit, dans S3."""
    folder = {
        "cadrage": "docs/cadrage",
        "spec": "docs/specs",
        "plan": "docs/plans",
        "tasks": "docs/plans",
        "estimation": "docs/estimates",
        "estimation_csv": "docs/estimates",
        "revue": "docs/reviews",
        "steering": "steering",
    }.get(kind, "docs")
    ext = "csv" if kind.endswith("_csv") else "md"
    return f"{tenant_prefix(tenant_id)}/projects/{project_id}/{folder}/{kind}-{version}.{ext}"


async def put_text(key: str, content: str) -> str:
    """Écrit un objet et renvoie son SHA-256 (contrôle d'intégrité côté base)."""
    body = content.encode("utf-8")
    checksum = hashlib.sha256(body).hexdigest()
    async with _client() as s3:
        await s3.put_object(
            Bucket=settings.s3_bucket,
            Key=key,
            Body=body,
            ContentType="text/markdown; charset=utf-8",
            ServerSideEncryption="AES256",
            Metadata={
                "checksum": checksum,
                "written_at": datetime.now(timezone.utc).isoformat(),
            },
        )
    return checksum


async def get_text(key: str) -> str:
    async with _client() as s3:
        response = await s3.get_object(Bucket=settings.s3_bucket, Key=key)
        body = await response["Body"].read()
    return body.decode("utf-8")


async def presign_download(key: str, expires_in: int = 300) -> str:
    """URL temporaire pour le téléchargement direct depuis le navigateur."""
    async with _client() as s3:
        return await s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": settings.s3_bucket, "Key": key},
            ExpiresIn=expires_in,
        )


async def delete_tenant_data(tenant_id: uuid.UUID) -> int:
    """Suppression complète des données d'un tenant (RGPD, droit à l'effacement)."""
    prefix = tenant_prefix(tenant_id)
    deleted = 0
    async with _client() as s3:
        paginator = s3.get_paginator("list_objects_v2")
        async for page in paginator.paginate(Bucket=settings.s3_bucket, Prefix=prefix):
            objects = [{"Key": obj["Key"]} for obj in page.get("Contents", [])]
            if objects:
                await s3.delete_objects(
                    Bucket=settings.s3_bucket, Delete={"Objects": objects}
                )
                deleted += len(objects)
    return deleted
