"""Quotas par plan, vérifiés AVANT le lancement d'un run.

Principe : on refuse un run qui dépasserait le quota, on n'interrompt jamais un run
en cours. Un cadrage coupé au milieu produirait un document inutilisable et une
facturation sans contrepartie.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from sqlalchemy import func, select

from app.db.models import Plan, Project, Run, Tenant, UsageEvent
from app.db.session import tenant_session


@dataclass(frozen=True, slots=True)
class Limits:
    runs_per_month: int
    tokens_per_month: int
    projects: int
    seats: int
    elicitation_passes: int   # passes d'examen critique par run


PLAN_LIMITS: dict[Plan, Limits] = {
    Plan.free: Limits(
        runs_per_month=5, tokens_per_month=300_000, projects=1, seats=2, elicitation_passes=1
    ),
    Plan.pro: Limits(
        runs_per_month=100, tokens_per_month=10_000_000, projects=20, seats=15, elicitation_passes=3
    ),
    Plan.enterprise: Limits(
        runs_per_month=10_000, tokens_per_month=500_000_000, projects=1_000, seats=500,
        elicitation_passes=10,
    ),
}


class QuotaExceeded(Exception):
    def __init__(self, quota: str, used: int, limit: int) -> None:
        self.quota, self.used, self.limit = quota, used, limit
        super().__init__(f"Quota « {quota} » atteint : {used}/{limit}")


def limits_for(tenant: Tenant) -> Limits:
    """Limites du plan, surchargeables par tenant (négociation entreprise)."""
    base = PLAN_LIMITS[tenant.plan]
    overrides = tenant.quota_overrides or {}
    if not overrides:
        return base
    return Limits(
        runs_per_month=overrides.get("runs_per_month", base.runs_per_month),
        tokens_per_month=overrides.get("tokens_per_month", base.tokens_per_month),
        projects=overrides.get("projects", base.projects),
        seats=overrides.get("seats", base.seats),
        elicitation_passes=overrides.get("elicitation_passes", base.elicitation_passes),
    )


def _month_start() -> datetime:
    now = datetime.now(timezone.utc)
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


async def check_can_start_run(tenant: Tenant) -> None:
    """Lève `QuotaExceeded` si le tenant ne peut pas lancer un run de plus."""
    if not tenant.subscription_active:
        raise QuotaExceeded("abonnement inactif", 0, 0)

    limits = limits_for(tenant)
    start = _month_start()

    async with tenant_session(tenant.id) as session:
        runs = await session.scalar(
            select(func.count(Run.id)).where(Run.created_at >= start)
        ) or 0
        if runs >= limits.runs_per_month:
            raise QuotaExceeded("runs par mois", runs, limits.runs_per_month)

        tokens = await session.scalar(
            select(
                func.coalesce(
                    func.sum(UsageEvent.input_tokens + UsageEvent.output_tokens), 0
                )
            ).where(UsageEvent.occurred_at >= start)
        ) or 0
        if tokens >= limits.tokens_per_month:
            raise QuotaExceeded("tokens par mois", int(tokens), limits.tokens_per_month)


async def check_can_create_project(tenant: Tenant) -> None:
    limits = limits_for(tenant)
    async with tenant_session(tenant.id) as session:
        count = await session.scalar(
            select(func.count(Project.id)).where(Project.archived.is_(False))
        ) or 0
    if count >= limits.projects:
        raise QuotaExceeded("projets", count, limits.projects)


async def current_usage(tenant_id: uuid.UUID) -> dict[str, int]:
    """Consommation du mois en cours, pour l'affichage dans l'UI."""
    start = _month_start()
    async with tenant_session(tenant_id) as session:
        runs = await session.scalar(
            select(func.count(Run.id)).where(Run.created_at >= start)
        ) or 0
        row = (
            await session.execute(
                select(
                    func.coalesce(func.sum(UsageEvent.input_tokens), 0),
                    func.coalesce(func.sum(UsageEvent.output_tokens), 0),
                    func.coalesce(func.sum(UsageEvent.cost_cents), 0),
                ).where(UsageEvent.occurred_at >= start)
            )
        ).one()
        projects = await session.scalar(
            select(func.count(Project.id)).where(Project.archived.is_(False))
        ) or 0

    return {
        "runs": int(runs),
        "input_tokens": int(row[0]),
        "output_tokens": int(row[1]),
        "cost_cents": int(row[2]),
        "projects": int(projects),
    }
