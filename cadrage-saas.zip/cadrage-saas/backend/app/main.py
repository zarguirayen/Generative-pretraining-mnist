"""Point d'entrée FastAPI."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.agents.graph import get_compiled_graph
from app.agents.kit_loader import verify_kit
from app.api.v1 import billing, projects, runs, tenants
from app.config import settings
from app.core.observability import configure_tracing
from app.services.quota import QuotaExceeded

logging.basicConfig(
    level=logging.INFO if settings.is_local else logging.WARNING,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_tracing()

    # Contrôle d'intégrité du kit : sans ses fichiers Markdown, la plateforme
    # n'a plus de méthode. Mieux vaut refuser de démarrer que produire des
    # documents dégradés.
    kit = verify_kit()
    if not kit["ok"]:
        raise RuntimeError(f"Kit de cadrage incomplet ou introuvable : {kit}")
    logger.info(
        "Kit chargé depuis %s — %s agents, skills : %s",
        kit["kit_root"], kit["agents"], ", ".join(kit["skills"]),
    )

    # Compile le graphe au démarrage : le premier run ne paie pas l'initialisation
    # du checkpointer (création des tables incluse).
    await get_compiled_graph()
    logger.info("API prête (env=%s, region=%s)", settings.env, settings.aws_region)
    yield


app = FastAPI(
    title="Cadrage SaaS",
    version="1.0.0",
    description="Plateforme de cadrage projet pilotée par agents",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(QuotaExceeded)
async def quota_handler(_: Request, exc: QuotaExceeded) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_402_PAYMENT_REQUIRED,
        content={
            "detail": str(exc),
            "quota": exc.quota,
            "used": exc.used,
            "limit": exc.limit,
        },
    )


@app.get("/healthz", include_in_schema=False)
async def healthz() -> dict[str, str]:
    return {"status": "ok", "env": settings.env}


@app.get("/kit", tags=["kit"])
async def kit_status() -> dict[str, object]:
    """État du kit chargé : utile pour vérifier qu'un déploiement embarque bien
    la version attendue de la méthode."""
    return verify_kit()


for module in (tenants, projects, runs, billing):
    app.include_router(module.router, prefix=settings.api_prefix)
