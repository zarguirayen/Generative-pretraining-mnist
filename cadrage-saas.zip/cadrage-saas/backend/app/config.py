"""Configuration applicative — chargée depuis l'environnement (12-factor)."""
from functools import lru_cache
from typing import Literal

from pydantic import Field, PostgresDsn
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ── Application ────────────────────────────────────────────────
    env: Literal["local", "staging", "prod"] = "local"
    api_prefix: str = "/api/v1"
    cors_origins: list[str] = ["http://localhost:3000"]

    # ── Base de données ────────────────────────────────────────────
    database_url: PostgresDsn
    db_pool_size: int = 10
    db_max_overflow: int = 20

    # ── AWS / Bedrock ──────────────────────────────────────────────
    aws_region: str = "eu-west-3"
    bedrock_model_id: str = "eu.anthropic.claude-sonnet-4-5-20250929-v1:0"
    bedrock_model_id_fast: str = "eu.anthropic.claude-haiku-4-5-20251001-v1:0"
    bedrock_max_tokens: int = 16000

    # ── AgentCore Runtime (prod) ───────────────────────────────────
    agentcore_enabled: bool = False
    agentcore_runtime_arn: str | None = None

    # ── Stockage des artefacts ─────────────────────────────────────
    s3_bucket: str = "cadrage-artifacts-local"
    s3_endpoint_url: str | None = None  # MinIO en local

    # ── Authentification (Cognito) ─────────────────────────────────
    cognito_user_pool_id: str | None = None
    cognito_client_id: str | None = None
    jwt_secret_dev: str = "dev-only-not-for-production"

    # ── Observabilité (LangSmith) ──────────────────────────────────
    langsmith_api_key: str | None = None
    langsmith_project: str = "cadrage-saas"
    langsmith_tracing: bool = False

    # ── Facturation (Stripe) ───────────────────────────────────────
    stripe_secret_key: str | None = None
    stripe_webhook_secret: str | None = None
    stripe_price_pro: str | None = None
    stripe_price_enterprise: str | None = None
    stripe_price_metered_tokens: str | None = None

    # ── Tarification interne (marge sur coût Bedrock) ──────────────
    # Prix facturé au client par million de tokens, en centimes d'euro.
    price_cents_per_mtok_input: int = 400
    price_cents_per_mtok_output: int = 2000

    @property
    def is_local(self) -> bool:
        return self.env == "local"


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
