"""Sous-agents : ils analysent et restituent, ils ne décident ni n'écrivent jamais.

Règle des deux niveaux : un sous-agent n'invoque aucun autre agent. L'information
relayée en cascade se dégrade ; l'architecture reste plate par construction.
Les sous-agents indépendants sont lancés en parallèle par les nœuds appelants.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any

from app.agents import progress
from app.agents.kit_loader import build_system_prompt, control_suffix
from app.agents.llm import invoke_agent, usage_record
from app.agents.state import CadrageState, SubAgentReport

logger = logging.getLogger(__name__)


def _parse_control(raw: str) -> dict[str, Any]:
    """Extrait le bloc ```control de fin de réponse.

    La restitution Markdown du kit reste intacte et sert à l'humain ; ce bloc ne
    sert qu'à piloter l'interface (verdict, gravités, compteurs). Son absence
    n'est pas bloquante : la restitution reste exploitable telle quelle.
    """
    fences = re.findall(r"```(?:control|json)?\s*(\{.*?\})\s*```", raw, re.DOTALL)
    for candidate in reversed(fences):          # le bloc de contrôle est en dernier
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue
    logger.debug("Aucun bloc de contrôle exploitable dans la restitution")
    return {}


def _strip_control(raw: str) -> str:
    """Restitution destinée à l'humain, débarrassée du bloc technique."""
    return re.sub(r"```control\s*\{.*?\}\s*```", "", raw, flags=re.DOTALL).strip()


async def _run(
    agent: str,
    state: CadrageState,
    user_input: str,
    **prompt_kwargs: str,
) -> tuple[SubAgentReport, dict[str, Any]]:
    progress.subagent_start(agent, prompt_kwargs.get("method", ""))
    system = build_system_prompt(
        agent,
        steering=state.get("steering", {}),
        constitution=state.get("constitution", ""),
        locale=state.get("locale", "fr"),
        **prompt_kwargs,
    ) + control_suffix(agent)
    result = await invoke_agent(
        agent=agent,
        system_prompt=system,
        user_input=user_input,
        metadata={"run_id": state.get("run_id"), "phase": state.get("phase")},
    )
    payload = _parse_control(result.text)

    report = SubAgentReport(
        agent=agent,
        verdict=payload.get("verdict"),
        # Constats bloquants : ils ne peuvent pas être absorbés silencieusement
        # par l'agent appelant (règle du kit).
        findings=payload.get("bloquants")
        or payload.get("corrections_requises")
        or payload.get("a_traiter_en_priorite")
        or payload.get("obligations_reglementaires")
        or [],
        # La restitution Markdown complète du kit est ce que l'agent d'entrée
        # intègre : on ne la résume jamais.
        raw=_strip_control(result.text),
    )
    # On conserve le JSON complet : les nœuds appelants en ont besoin
    report["payload"] = payload  # type: ignore[typeddict-unknown-key]
    progress.subagent_done(agent, report["verdict"], len(report["findings"]))
    return report, usage_record(agent, result)


async def analyse_faisabilite(state: CadrageState) -> tuple[SubAgentReport, dict]:
    return await _run(
        "faisabilite",
        state,
        f"Demande initiale à analyser :\n\n{state['initial_prompt']}",
    )


async def analyse_risques(state: CadrageState, document: str) -> tuple[SubAgentReport, dict]:
    return await _run(
        "risques",
        state,
        f"Document à analyser :\n\n{document}",
    )


async def elicitation(
    state: CadrageState, document: str, method: str
) -> tuple[SubAgentReport, dict]:
    return await _run(
        "elicitateur",
        state,
        f"Document à ré-examiner :\n\n{document}",
        method=method,
    )


async def verification_transverse(
    state: CadrageState, artifacts: dict[str, str]
) -> tuple[SubAgentReport, dict]:
    corpus = "\n\n".join(
        f"===== {kind.upper()} =====\n{content}" for kind, content in artifacts.items()
    )
    return await _run("verificateur", state, f"Corpus à vérifier :\n\n{corpus}")


# ─────────────────────────────────────────────────────────────────────
# Sous-agents de revue de code
# ─────────────────────────────────────────────────────────────────────
def format_code(code: dict[str, str], limit: int = 60_000) -> str:
    """Met le code soumis en forme, avec numérotation pour citer `fichier:ligne`."""
    if not code:
        return "(aucun code fourni)"
    blocks: list[str] = []
    budget = limit
    for path, content in code.items():
        numbered = "\n".join(
            f"{index:4d} | {line}" for index, line in enumerate(content.splitlines(), 1)
        )
        block = f"===== {path} =====\n{numbered}"
        if len(block) > budget:
            block = block[:budget] + "\n[… tronqué …]"
        blocks.append(block)
        budget -= len(block)
        if budget <= 0:
            break
    return "\n\n".join(blocks)


async def revue_conformite(state: CadrageState) -> tuple[SubAgentReport, dict]:
    """Le code fait-il ce que la spec a promis ?"""
    artifacts = state.get("artifacts", {})
    return await _run(
        "revue_conformite",
        state,
        f"Spécification :\n\n{artifacts.get('spec', '(absente)')}\n\n"
        f"Plan :\n\n{artifacts.get('plan', '(absent)')}\n\n"
        f"Code à examiner :\n\n{format_code(state.get('code_context', {}))}",
    )


async def revue_correction(state: CadrageState) -> tuple[SubAgentReport, dict]:
    """Qu'est-ce qui casse ?"""
    return await _run(
        "revue_correction",
        state,
        f"Périmètre : {state.get('review_scope', 'diff')}\n\n"
        f"Code à examiner :\n\n{format_code(state.get('code_context', {}))}",
    )


async def revue_securite(state: CadrageState) -> tuple[SubAgentReport, dict]:
    """Qu'est-ce qui est attaquable, et réellement exploitable ?"""
    return await _run(
        "revue_securite",
        state,
        f"Code à auditer :\n\n{format_code(state.get('code_context', {}))}",
    )


async def gardien_patterns(state: CadrageState) -> tuple[SubAgentReport, dict]:
    """Le code est-il cohérent avec le projet et les règles écrites ?"""
    return await _run(
        "gardien_patterns",
        state,
        f"Code à examiner :\n\n{format_code(state.get('code_context', {}))}",
    )


async def fan_out(*coros) -> tuple[list[SubAgentReport], list[dict]]:
    """Exécute des sous-agents indépendants en parallèle.

    Un sous-agent en échec ne fait pas tomber la phase : son absence est signalée
    dans les rapports, l'agent d'entrée poursuit en le mentionnant.
    """
    outcomes = await asyncio.gather(*coros, return_exceptions=True)
    reports: list[SubAgentReport] = []
    usage: list[dict] = []
    for outcome in outcomes:
        if isinstance(outcome, BaseException):
            logger.exception("Sous-agent en échec", exc_info=outcome)
            reports.append(
                SubAgentReport(
                    agent="inconnu", verdict="ERREUR", findings=[], raw=str(outcome)
                )
            )
            continue
        report, use = outcome
        reports.append(report)
        usage.append(use)
    return reports, usage


def format_reports(reports: list[SubAgentReport]) -> str:
    """Met les restitutions en forme pour l'agent d'entrée qui va les intégrer."""
    if not reports:
        return "(aucune analyse de sous-agent disponible)"
    blocks = []
    for r in reports:
        header = f"### Restitution — {r['agent']}"
        if r.get("verdict"):
            header += f" (verdict : {r['verdict']})"
        blocks.append(f"{header}\n{r['raw']}")
    return "\n\n".join(blocks)
