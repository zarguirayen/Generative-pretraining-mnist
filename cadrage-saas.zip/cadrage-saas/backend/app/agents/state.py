"""État partagé du graphe de cadrage.

Cet état est sérialisé par le checkpointer Postgres à chaque transition : il doit
rester strictement JSON-sérialisable (pas d'objets SQLAlchemy, pas de datetime nu).
"""
from __future__ import annotations

import operator
from typing import Annotated, Any, Literal, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages

Phase = Literal["orchestration", "cadrage", "specification", "plan", "estimation", "revue"]


class GatePayload(TypedDict):
    """Ce qui est présenté à l'humain quand le graphe s'interrompt."""

    phase: Phase
    title: str
    summary: str
    checklist: list[dict[str, Any]]   # [{"label", "ok", "evidence"}]
    artifact_kind: str | None
    questions: list[dict[str, Any]]   # questions fermées avec option (Recommandé)


class GateResponse(TypedDict):
    """Ce que l'humain renvoie pour reprendre le graphe."""

    decision: Literal["approved", "changes_requested", "rejected"]
    feedback: str | None
    answers: dict[str, str]


class SubAgentReport(TypedDict):
    """Restitution d'un sous-agent : il propose, il ne décide jamais."""

    agent: str
    verdict: str | None
    findings: list[dict[str, Any]]
    raw: str


class CadrageState(TypedDict, total=False):
    # ── Identité et contexte ──────────────────────────────────────
    tenant_id: str
    project_id: str
    run_id: str
    locale: str

    # Steering du projet (product / tech / structure) + constitution
    steering: dict[str, str]
    constitution: str

    # ── Conversation ──────────────────────────────────────────────
    messages: Annotated[list[BaseMessage], add_messages]
    initial_prompt: str

    # ── Progression ───────────────────────────────────────────────
    phase: Phase
    scale_level: int          # 0-4, fixé au triage par l'orchestrateur
    scenario: str             # greenfield | feature | migration | bug

    # ── Code soumis (revue et correction de bug) ──────────────────
    # Fichiers ou diff fournis par l'utilisateur : { "chemin": "contenu" }.
    # Les agents de revue travaillent exclusivement sur ce contenu — ils ne
    # supposent jamais l'existence d'un code qu'ils n'ont pas lu.
    code_context: dict[str, str]
    review_scope: str         # diff | module | codebase

    # ── Livrables (markdown), clé = kind ──────────────────────────
    artifacts: Annotated[dict[str, str], operator.or_]

    # Reversement vers le steering permanent du projet (product/tech/structure) :
    # produit par les nœuds à la validation, appliqué par le runner.
    steering_patch: Annotated[dict[str, str], operator.or_]

    # ── Sorties des sous-agents pour la phase courante ────────────
    reports: Annotated[list[SubAgentReport], operator.add]

    # ── Gates ─────────────────────────────────────────────────────
    pending_gate: GatePayload | None
    gate_history: Annotated[list[dict[str, Any]], operator.add]

    # ── Comptabilité ──────────────────────────────────────────────
    usage: Annotated[list[dict[str, Any]], operator.add]
    error: str | None


def initial_state(
    *,
    tenant_id: str,
    project_id: str,
    run_id: str,
    prompt: str,
    steering: dict[str, str],
    constitution: str,
    locale: str = "fr",
    code_context: dict[str, str] | None = None,
    review_scope: str = "diff",
    artifacts: dict[str, str] | None = None,
) -> CadrageState:
    return CadrageState(
        tenant_id=tenant_id,
        project_id=project_id,
        run_id=run_id,
        locale=locale,
        steering=steering,
        constitution=constitution,
        messages=[],
        initial_prompt=prompt,
        phase="orchestration",
        scale_level=2,
        scenario="greenfield",
        code_context=code_context or {},
        review_scope=review_scope,
        # Livrables déjà produits par les runs précédents du projet : un run de
        # revue a besoin de la spec et du plan pour vérifier la conformité.
        artifacts=artifacts or {},
        reports=[],
        pending_gate=None,
        gate_history=[],
        usage=[],
        error=None,
    )
