"""Événements de progression — ce que l'utilisateur voit pendant qu'un nœud travaille.

Sans cela, l'interface reste figée pendant les 30 à 60 secondes que dure une phase :
l'utilisateur ne sait pas si le système réfléchit ou s'il est planté. Copilot et Kiro
affichent « Searched workspace », « Editing file… » ; on émet l'équivalent.

Mécanisme : `get_stream_writer()` de LangGraph permet à un nœud d'émettre des
événements arbitraires, récupérés côté API avec `stream_mode="custom"`.
"""
from __future__ import annotations

import logging
from typing import Any, Literal

from langgraph.config import get_stream_writer

logger = logging.getLogger(__name__)

Kind = Literal["step", "subagent", "thinking", "writing", "checking", "done_step"]

# Libellés lisibles : l'utilisateur ne doit pas voir des noms de fonctions.
LABELS: dict[str, str] = {
    "orchestrateur": "Analyse de la demande",
    "cadrage": "Rédaction du cadrage",
    "spec_writer": "Rédaction de la spécification",
    "planner": "Conception du plan technique",
    "estimateur": "Chiffrage de l'effort",
    "faisabilite": "Contrôle de faisabilité",
    "risques": "Analyse des risques",
    "elicitateur": "Examen critique",
    "verificateur": "Vérification transverse",
}


def emit(kind: Kind, agent: str, detail: str = "", **extra: Any) -> None:
    """Émet un événement de progression. Sans effet hors d'un nœud du graphe."""
    try:
        writer = get_stream_writer()
    except Exception:  # noqa: BLE001 — hors contexte graphe (tests, appels directs)
        return
    if writer is None:
        return
    writer(
        {
            "type": "progress",
            "kind": kind,
            "agent": agent,
            "label": LABELS.get(agent, agent),
            "detail": detail,
            **extra,
        }
    )


def step_start(agent: str, detail: str = "") -> None:
    emit("step", agent, detail)


def step_done(agent: str, detail: str = "") -> None:
    emit("done_step", agent, detail)


def subagent_start(agent: str, detail: str = "") -> None:
    emit("subagent", agent, detail or "analyse en cours")


def subagent_done(agent: str, verdict: str | None = None, count: int = 0) -> None:
    detail = verdict or (f"{count} constat(s)" if count else "terminé")
    emit("done_step", agent, detail, verdict=verdict, findings=count)


def writing(agent: str, what: str) -> None:
    """« Rédaction du document de cadrage… » — pendant l'appel au modèle."""
    emit("writing", agent, what)


def checking(agent: str, what: str) -> None:
    """« Vérification des critères de sortie… »"""
    emit("checking", agent, what)
