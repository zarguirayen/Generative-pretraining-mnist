"""Façade de compatibilité — la méthode vit dans `kit/`, pas ici.

Historiquement ce module contenait des prompts réécrits en Python. C'était une
erreur : condenser le kit dégrade la sortie, et créait deux sources de vérité
divergentes. Les prompts sont désormais chargés depuis les fichiers Markdown
d'origine (`kit/agents/*.agent.md`, `kit/skills/*/SKILL.md`) par `kit_loader`.

Pour faire évoluer la méthode : modifier les fichiers du kit, pas ce fichier.
Les surcharges par tenant passent par la table `agent_prompts`.
"""
from __future__ import annotations

from app.agents.kit_loader import (
    AGENT_FILES,
    all_skills,
    build_system_prompt,
    load_agent,
    load_skill,
    load_template,
    skills_for,
    verify_kit,
)

__all__ = [
    "AGENT_FILES",
    "all_skills",
    "build_system_prompt",
    "load_agent",
    "load_skill",
    "load_template",
    "skills_for",
    "verify_kit",
]
