"""Chargement du kit de cadrage depuis ses fichiers Markdown d'origine.

Principe : **le kit est la source de vérité, on ne le réécrit jamais.** Les fichiers
de `kit/` sont exactement ceux qui ont été éprouvés dans GitHub Copilot ; les
réécrire ou les condenser dégraderait la sortie. Ce module se contente de :

  1. lire le fichier de l'agent (`*.agent.md`) et d'en retirer le frontmatter YAML ;
  2. charger les skills que ce corps référence (`skill `interview-cadrage``) ;
  3. neutraliser les quelques éléments propres au harnais Copilot (chemins
     `.github/`, outil `agent`, boutons de handoff) via un préambule d'adaptation ;
  4. assembler le tout avec le steering et la constitution du projet.

Chargement en deux niveaux, conformément au standard Agent Skills :
  - les skills référencés par l'agent sont chargés **intégralement** (garantie de
    performance : on ne parie pas sur le fait que le modèle pense à les demander) ;
  - les autres skills n'apparaissent que par leur nom et leur description, pour que
    l'agent puisse en signaler le besoin sans en payer le coût en tokens.
"""
from __future__ import annotations

import functools
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Le kit vit DANS le backend (`backend/kit/`) : le service est autonome, il se
# build et se déploie sans dépendre d'aucun dossier extérieur.
KIT_ROOT = Path(
    os.getenv("CADRAGE_KIT_ROOT") or Path(__file__).resolve().parents[2] / "kit"
)

_FRONTMATTER = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
# Repère les mentions de skills dans le corps d'un agent :
#   « skill `interview-cadrage` », « le skill correction-bug », « (skill `x`) »
_SKILL_MENTION = re.compile(r"skill[s]?\s+[`']?([a-z][a-z0-9-]{3,})[`']?", re.IGNORECASE)

# Correspondance nom d'agent du SaaS → fichier du kit.
AGENT_FILES: dict[str, str] = {
    "orchestrateur": "agents/orchestrateur.agent.md",
    "cadrage": "agents/cadrage.agent.md",
    "spec_writer": "agents/spec-writer.agent.md",
    "planner": "agents/planner.agent.md",
    "estimateur": "agents/estimateur.agent.md",
    "reviewer": "agents/reviewer.agent.md",
    "bugfix": "agents/bugfix.agent.md",
    "faisabilite": "agents/auxiliary/analyste-faisabilite.agent.md",
    "risques": "agents/auxiliary/analyste-risques.agent.md",
    "elicitateur": "agents/auxiliary/elicitateur.agent.md",
    "verificateur": "agents/auxiliary/verificateur-transverse.agent.md",
    "capture_contexte": "agents/auxiliary/capture-contexte.agent.md",
    "revue_conformite": "agents/auxiliary/revue-conformite.agent.md",
    "revue_correction": "agents/auxiliary/revue-correction.agent.md",
    "revue_securite": "agents/auxiliary/revue-securite.agent.md",
    "gardien_patterns": "agents/auxiliary/gardien-patterns.agent.md",
}

# Skills à charger d'office pour un agent, en complément de ceux détectés dans son
# corps (filet de sécurité si une formulation change dans le kit).
FORCED_SKILLS: dict[str, tuple[str, ...]] = {
    "cadrage": ("interview-cadrage", "estimation-risques"),
    "spec_writer": ("redaction-spec",),
    "planner": ("estimation-risques", "validation-transverse"),
    "bugfix": ("correction-bug",),
    "reviewer": ("revue-code",),
    "risques": ("estimation-risques",),
    "elicitateur": ("elicitation-avancee",),
    "verificateur": ("validation-transverse",),
    "revue_conformite": ("revue-code",),
    "revue_correction": ("revue-code",),
    "revue_securite": ("revue-code", "estimation-risques"),
    "gardien_patterns": ("revue-code",),
}


@dataclass(slots=True)
class Document:
    """Un fichier du kit : métadonnées du frontmatter + corps markdown intact."""

    name: str
    description: str
    body: str
    meta: dict[str, str] = field(default_factory=dict)


class KitNotFound(Exception):
    pass


def _parse(path: Path) -> Document:
    """Sépare le frontmatter du corps. Le corps n'est jamais modifié."""
    if not path.exists():
        raise KitNotFound(str(path))

    raw = path.read_text(encoding="utf-8")
    meta: dict[str, str] = {}
    body = raw

    match = _FRONTMATTER.match(raw)
    if match:
        body = raw[match.end() :]
        for line in match.group(1).splitlines():
            if ":" in line and not line.lstrip().startswith(("-", "#")):
                key, _, value = line.partition(":")
                meta[key.strip()] = value.strip().strip("\"'")

    return Document(
        name=meta.get("name", path.stem),
        description=meta.get("description", ""),
        body=body.strip(),
        meta=meta,
    )


@functools.lru_cache(maxsize=64)
def load_agent(agent: str) -> Document:
    """Corps de l'agent, tel qu'écrit dans le kit."""
    relative = AGENT_FILES.get(agent)
    if relative is None:
        raise KitNotFound(f"Agent inconnu : {agent}")
    return _parse(KIT_ROOT / relative)


@functools.lru_cache(maxsize=32)
def load_skill(name: str) -> Document:
    return _parse(KIT_ROOT / "skills" / name / "SKILL.md")


@functools.lru_cache(maxsize=1)
def all_skills() -> dict[str, Document]:
    skills: dict[str, Document] = {}
    skills_dir = KIT_ROOT / "skills"
    if not skills_dir.exists():
        logger.warning("Répertoire de skills introuvable : %s", skills_dir)
        return skills
    for path in sorted(skills_dir.glob("*/SKILL.md")):
        doc = _parse(path)
        skills[path.parent.name] = doc
    return skills


@functools.lru_cache(maxsize=8)
def load_template(name: str) -> str:
    path = KIT_ROOT / "templates" / name
    return path.read_text(encoding="utf-8") if path.exists() else ""


# Instructions par type de livrable (`applyTo` du kit, sans les globs Copilot).
INSTRUCTION_FILES: dict[str, str] = {
    "cadrage": "docs.instructions.md",
    "spec": "specs.instructions.md",
    "plan": "specs.instructions.md",
    "tasks": "specs.instructions.md",
}


@functools.lru_cache(maxsize=8)
def load_instructions(kind: str) -> str:
    """Règles de rédaction propres à un type de document.

    Dans Copilot elles s'appliquent par glob de chemin ; ici on les injecte selon
    le livrable que l'agent produit. Ce sont elles qui imposent le format EARS, la
    numérotation stable, les objectifs mesurables…
    """
    filename = INSTRUCTION_FILES.get(kind)
    if not filename:
        return ""
    path = KIT_ROOT / "instructions" / filename
    if not path.exists():
        return ""
    return _parse(path).body


@functools.lru_cache(maxsize=1)
def steering_templates() -> dict[str, str]:
    """Gabarits vierges de steering, pour initialiser un nouveau projet."""
    out: dict[str, str] = {}
    directory = KIT_ROOT / "steering"
    for path in sorted(directory.glob("*.md")):
        out[path.stem] = path.read_text(encoding="utf-8")
    return out


@functools.lru_cache(maxsize=1)
def agents_context() -> str:
    """`AGENTS.md` : contexte transverse partagé par tous les agents du kit."""
    path = KIT_ROOT / "reference" / "AGENTS.md"
    return path.read_text(encoding="utf-8") if path.exists() else ""


_CHECKBOX = re.compile(r"^\s*-\s*\[[ xX]\]\s*(.+?)\s*;?\s*$", re.MULTILINE)


def _checkboxes(text: str, *markers: str) -> list[str]:
    """Cases à cocher d'un document, à partir d'un marqueur de section si fourni."""
    lowered = text.lower()
    positions = [lowered.find(m) for m in markers if lowered.find(m) != -1]
    section = text[min(positions) :] if positions else text
    return [m.group(1).strip() for m in _CHECKBOX.finditer(section)]


@functools.lru_cache(maxsize=32)
def gate_criteria(agent: str) -> tuple[str, ...]:
    """Critères de sortie d'un agent, extraits du kit.

    Le kit les écrit en cases à cocher, soit dans la section « Gates de sortie »
    de l'agent (cadrage, spec-writer), soit dans le skill qu'il applique — le
    planner, par exemple, délègue son verdict au skill `validation-transverse`.
    Les lire ici plutôt que de les recopier en Python garantit que la checklist
    affichée à l'utilisateur suit automatiquement l'évolution du kit.
    """
    criteria = _checkboxes(
        load_agent(agent).body,
        "gate de sortie", "gates de sortie", "critères de sortie",
    )
    if criteria:
        return tuple(criteria)

    for skill_name in skills_for(agent):
        found = _checkboxes(load_skill(skill_name).body, "checklist", "critères")
        if found:
            return tuple(found)
    return ()


def skills_for(agent: str) -> list[str]:
    """Skills à charger : ceux cités dans le corps + ceux imposés par la table."""
    doc = load_agent(agent)
    available = set(all_skills())
    detected = {
        match.group(1).lower()
        for match in _SKILL_MENTION.finditer(doc.body)
    } & available
    return sorted(detected | (set(FORCED_SKILLS.get(agent, ())) & available))


# ─────────────────────────────────────────────────────────────────────
# Adaptation du harnais : ce qui change entre Copilot et la plateforme
# ─────────────────────────────────────────────────────────────────────
ADAPTATION = """\
## Contexte d'exécution (plateforme, à lire avant les instructions ci-dessous)

Tu t'exécutes sur une plateforme web, non dans un IDE. Les instructions qui suivent
sont celles du kit d'origine : applique-les **intégralement**, en tenant compte des
seules adaptations suivantes.

- **Écriture des livrables** : tu ne manipules pas de fichiers. Ta réponse EST le
  document : produis-la en Markdown complet, sans préambule ni commentaire autour.
  La plateforme se charge de l'enregistrer, de le versionner et de l'afficher.
  Ignore donc toute consigne de chemin (`docs/cadrage/…`, `<racine>/…`,
  `.github/…`) : elle est gérée pour toi.
- **Sous-agents** : tu n'invoques rien toi-même. Les analyses des sous-agents
  (faisabilité, risques, examen critique, vérification transverse) te sont fournies
  dans le message utilisateur, sous « Restitutions des sous-agents ». Intègre-les
  comme le kit le demande — elles proposent, l'utilisateur et toi décidez.
- **Gates et handoffs** : ne propose pas de bouton ni de bascule d'agent. Termine
  ton document ; la plateforme présente la validation à l'utilisateur avec la
  checklist des critères de sortie, et enchaîne la phase suivante après sa décision.
- **Questions** : formule-les normalement (fermées, avec option (Recommandé)) ; la
  plateforme les affiche dans le panneau de validation.
- **Steering et constitution** : ils te sont donnés ci-dessous, déjà chargés.

Tout le reste du kit s'applique sans changement : méthode, format, niveau de détail,
gates, vocabulaire.
"""


def build_system_prompt(
    agent: str,
    *,
    steering: dict[str, str],
    constitution: str,
    locale: str = "fr",
    include_catalog: bool = True,
    **extra: str,
) -> str:
    """Assemble le prompt système d'un agent à partir des fichiers du kit.

    Ordre : adaptation → contexte projet → corps de l'agent (intact) → skills.
    """
    doc = load_agent(agent)

    steering_txt = "\n\n".join(
        f"### {key}\n{value}" for key, value in (steering or {}).items() if value
    ) or "(steering vide — poser les questions produit, ne rien déduire du reste)"

    parts: list[str] = [
        ADAPTATION,
        f"Langue de travail : {locale}. Ne mélange jamais deux langues.",
        # AGENTS.md du kit : règles transverses partagées par tous les agents
        # (flux documentaire, vocabulaire, séparation des rôles).
        "## Contexte transverse du kit\n\n" + agents_context(),
        "## Contexte permanent du projet (steering)\n\n" + steering_txt,
        "## Principes non négociables (constitution)\n\n"
        + (constitution or load_template("constitution.md")),
        "---",
        f"# Instructions de l'agent « {doc.name} »\n\n{doc.body}",
    ]

    # Skills référencés : chargés intégralement, dans leur rédaction d'origine.
    for skill_name in skills_for(agent):
        skill = load_skill(skill_name)
        parts.append(
            f"---\n\n# Skill « {skill.name} » (méthode à appliquer)\n\n{skill.body}"
        )

    # Catalogue des autres skills : nom + description seulement (progressive
    # disclosure) — l'agent peut signaler qu'il en aurait besoin.
    if include_catalog:
        loaded = set(skills_for(agent))
        others = [
            f"- **{name}** : {doc_.description}"
            for name, doc_ in all_skills().items()
            if name not in loaded
        ]
        if others:
            parts.append(
                "---\n\n## Autres méthodes disponibles (non chargées)\n\n"
                + "\n".join(others)
                + "\n\nSi l'une d'elles est nécessaire, dis-le explicitement plutôt "
                "que d'improviser la méthode."
            )

    if extra:
        details = "\n".join(f"- {key} : {value}" for key, value in extra.items())
        parts.append(f"---\n\n## Paramètres de cette invocation\n\n{details}")

    return "\n\n".join(parts)


# ─────────────────────────────────────────────────────────────────────
# Restitution lisible + bloc de contrôle machine
# ─────────────────────────────────────────────────────────────────────
CONTROL_BLOCK = """\
---

## Format de sortie attendu (plateforme)

Produis d'abord ta restitution **exactement dans le format demandé par le kit
ci-dessus** (tableaux Markdown, formulations, niveau de détail : rien ne change).

Puis, en toute fin de réponse, ajoute un bloc de contrôle destiné à la plateforme —
il ne remplace pas ta restitution, il la résume pour piloter l'interface :

```control
{schema}
```

Ce bloc doit être du JSON valide et être le dernier élément de ta réponse.
"""

_REVIEW_SCHEMA = (
    '{"constats": [{"severite": "bloquant | majeur | mineur", '
    '"statut": "CONFIRMÉ | PLAUSIBLE", "fichier": "chemin:ligne", '
    '"constat": "...", "scenario_echec": "...", "correctif": "..."}], '
    '"statistiques": {"candidats": <n>, "confirmes": <n>, "rejetes": <n>}}'
)

CONTROL_SCHEMAS: dict[str, str] = {
    "revue_conformite": _REVIEW_SCHEMA,
    "revue_correction": _REVIEW_SCHEMA,
    "revue_securite": _REVIEW_SCHEMA,
    "gardien_patterns": _REVIEW_SCHEMA,
    "reviewer": (
        '{"verdict": "GO | NO-GO", '
        '"bloquants": [{"fichier": "...", "constat": "...", "action": "..."}], '
        '"majeurs": <n>, "mineurs": <n>, '
        '"tests": {"executes": true, "resultat": "42/43"}, '
        '"statistiques": {"candidats": <n>, "confirmes": <n>, "requalifies": <n>, "rejetes": <n>}}'
    ),
    "bugfix": (
        '{"phase": "diagnostic | correctif | verification", '
        '"condition_bug": "<prédicat formel>", '
        '"cas_regression": ["..."], '
        '"questions_ouvertes": ["..."]}'
    ),
    "faisabilite": (
        '{"verdict": "FAISABLE | FAISABLE AVEC ARBITRAGES | INCOMPATIBLE EN L\'ÉTAT", '
        '"incompatibilites": <nombre>, "obligations_reglementaires": ["<domaine — obligation>"]}'
    ),
    "risques": (
        '{"risques": <nombre>, "hypotheses": <nombre>, '
        '"a_traiter_en_priorite": ["<id — libellé>"]}'
    ),
    "elicitateur": (
        '{"methode": "<nom>", "bloquants": [{"id": "...", "section": "...", '
        '"constat": "...", "modification": "..."}], "importants": <nombre>, '
        '"mineurs": <nombre>, "verdict": "<une phrase>"}'
    ),
    "verificateur": (
        '{"verdict": "GO | NO-GO", "items": [{"item": "...", "ok": true, "preuve": "..."}], '
        '"corrections_requises": [{"item": "...", "document": "...", "agent_responsable": "..."}]}'
    ),
    "orchestrateur": (
        '{"scenario": "greenfield | feature | migration | bug", "scale_level": <0-4>, '
        '"phase_entree": "cadrage | specification | plan | revue", "resume": "<2 phrases>", '
        '"questions_produit": ["..."]}'
    ),
}


def control_suffix(agent: str) -> str:
    """Bloc de contrôle à ajouter au prompt d'un agent qui pilote le graphe."""
    schema = CONTROL_SCHEMAS.get(agent)
    return CONTROL_BLOCK.format(schema=schema) if schema else ""


def verify_kit() -> dict[str, object]:
    """Contrôle d'intégrité du kit, appelé au démarrage de l'API.

    L'API refuse de démarrer si le kit est incomplet : mieux vaut un déploiement
    bloqué que des documents produits avec une méthode amputée.
    """
    missing_agents = [a for a in AGENT_FILES if not (KIT_ROOT / AGENT_FILES[a]).exists()]
    skills = all_skills()
    templates = {
        name: bool(load_template(name))
        for name in ("TEMPLATE-cadrage.md", "constitution.md")
    }
    return {
        "kit_root": str(KIT_ROOT),
        "agents": len(AGENT_FILES) - len(missing_agents),
        "missing_agents": missing_agents,
        "skills": sorted(skills),
        "instructions": sorted(
            p.name for p in (KIT_ROOT / "instructions").glob("*.md")
        ),
        "steering_templates": sorted(steering_templates()),
        "templates": templates,
        "agents_context": bool(agents_context()),
        "gate_criteria": {
            agent: len(gate_criteria(agent))
            for agent in ("cadrage", "spec_writer", "planner")
        },
        "ok": not missing_agents and bool(skills) and all(templates.values()),
    }
