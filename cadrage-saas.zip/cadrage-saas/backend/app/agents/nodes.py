"""Nœuds du graphe : un nœud = un agent d'entrée du kit.

Chaque nœud d'une phase suit le même contrat :
  1. lance ses sous-agents (en parallèle quand ils sont indépendants) ;
  2. rédige ou met à jour son livrable en intégrant leurs restitutions ;
  3. prépare le `pending_gate` que le nœud `human_gate` présentera à l'utilisateur.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from langchain_core.messages import AIMessage

from app.agents import progress, subagents
from app.agents.kit_loader import (
    build_system_prompt,
    control_suffix,
    gate_criteria,
    load_instructions,
    load_template,
)
from app.agents.llm import invoke_agent, usage_record
from app.agents.state import CadrageState, GatePayload

logger = logging.getLogger(__name__)

SPLIT_TASKS = "---SPLIT-TASKS---"
SPLIT_CSV = "---SPLIT-CSV---"


# Livrable produit par chaque agent — détermine les instructions de rédaction
# à injecter (équivalent des règles `applyTo` du kit dans Copilot).
AGENT_OUTPUT: dict[str, str] = {
    "cadrage": "cadrage",
    "spec_writer": "spec",
    "planner": "plan",
}


def _system(state: CadrageState, agent: str, **extra: str) -> str:
    prompt = build_system_prompt(
        agent,
        steering=state.get("steering", {}),
        constitution=state.get("constitution", ""),
        locale=state.get("locale", "fr"),
        **extra,
    )
    instructions = load_instructions(AGENT_OUTPUT.get(agent, ""))
    if instructions:
        prompt += (
            "\n\n---\n\n## Règles de rédaction applicables à ce livrable\n\n"
            + instructions
        )
    return prompt


def _meta(state: CadrageState) -> dict[str, Any]:
    return {"run_id": state.get("run_id"), "tenant_id": state.get("tenant_id")}


def _gate_answers(state: CadrageState) -> str:
    """Réponses de l'utilisateur au dernier gate, à réinjecter dans la rédaction."""
    history = state.get("gate_history") or []
    if not history:
        return ""
    last = history[-1]
    parts = []
    if last.get("feedback"):
        parts.append(f"Retour de l'utilisateur : {last['feedback']}")
    for question, answer in (last.get("answers") or {}).items():
        parts.append(f"- {question} → {answer}")
    return "\n".join(parts)


# ─────────────────────────────────────────────────────────────────────
# Orchestrateur — triage, niveau d'échelle, routage
# ─────────────────────────────────────────────────────────────────────
async def orchestrateur(state: CadrageState) -> dict[str, Any]:
    progress.step_start("orchestrateur", "triage et niveau d'échelle")
    result = await invoke_agent(
        agent="orchestrateur",
        system_prompt=_system(state, "orchestrateur") + control_suffix("orchestrateur"),
        user_input=state["initial_prompt"],
        fast=True,
        metadata=_meta(state),
    )
    payload = subagents._parse_control(result.text)

    resume = payload.get("resume", "")
    questions = payload.get("questions_produit") or []
    progress.step_done(
        "orchestrateur",
        f"scénario {payload.get('scenario', 'greenfield')} · niveau {payload.get('scale_level', 2)}",
    )
    message = f"Demande analysée : {resume}"
    if questions:
        message += "\n\nQuestions produit (le steering est incomplet) :\n" + "\n".join(
            f"- {q}" for q in questions
        )

    return {
        "scenario": payload.get("scenario", "greenfield"),
        "scale_level": int(payload.get("scale_level", 2)),
        "phase": payload.get("phase_entree", "cadrage"),
        "messages": [AIMessage(content=message, name="orchestrateur")],
        "usage": [usage_record("orchestrateur", result)],
    }


# ─────────────────────────────────────────────────────────────────────
# Cadrage — faisabilité + risques en parallèle, puis brouillon complet
# ─────────────────────────────────────────────────────────────────────
async def cadrage(state: CadrageState) -> dict[str, Any]:
    progress.step_start("cadrage")
    existing = state.get("artifacts", {}).get("cadrage")
    answers = _gate_answers(state)

    if existing and answers:
        # Itération après un gate « changes_requested » : on ne repart pas de zéro.
        user_input = (
            f"Document de cadrage actuel :\n\n{existing}\n\n"
            f"Intègre ces retours et renvoie le document COMPLET mis à jour "
            f"(incrémente la version) :\n{answers}"
        )
        reports, usage = [], []
    else:
        # Premier passage : faisabilité (étape -1) et risques, en parallèle.
        reports, usage = await subagents.fan_out(
            subagents.analyse_faisabilite(state),
            subagents.analyse_risques(state, state["initial_prompt"]),
        )
        # Le gabarit du kit est fourni tel quel : c'est lui qui garantit que la
        # structure du document produit est identique à celle de Copilot.
        user_input = (
            f"Demande initiale :\n\n{state['initial_prompt']}\n\n"
            f"Niveau d'échelle retenu : {state.get('scale_level', 2)} · "
            f"scénario : {state.get('scenario', 'greenfield')}\n\n"
            f"Restitutions des sous-agents à intégrer :\n\n"
            f"{subagents.format_reports(reports)}\n\n"
            f"---\n\nGabarit à suivre strictement (mêmes sections, même ordre) :\n\n"
            f"{load_template('TEMPLATE-cadrage.md')}"
        )

    progress.writing("cadrage", "rédaction du document complet")
    result = await invoke_agent(
        agent="cadrage",
        system_prompt=_system(state, "cadrage"),
        user_input=user_input,
        metadata=_meta(state),
    )
    usage.append(usage_record("cadrage", result))
    document = result.text
    progress.checking("cadrage", "contrôle des critères de sortie")

    # Le gate reprend les critères de sortie du kit.
    gate = GatePayload(
        phase="cadrage",
        title="Validation du cadrage",
        summary=_summarize(document),
        checklist=_checklist_from_kit("cadrage", document, reports),
        artifact_kind="cadrage",
        questions=_extract_open_hypotheses(document),
    )
    progress.step_done("cadrage", "document prêt pour validation")
    return {
        "artifacts": {"cadrage": document},
        "steering_patch": _steering_from_cadrage(document),
        "reports": reports,
        "usage": usage,
        "pending_gate": gate,
        "phase": "cadrage",
        "messages": [AIMessage(content=gate["summary"], name="cadrage")],
    }


# ─────────────────────────────────────────────────────────────────────
# Spécification — rédaction puis passe socratique
# ─────────────────────────────────────────────────────────────────────
async def spec_writer(state: CadrageState) -> dict[str, Any]:
    progress.step_start("spec_writer")
    artifacts = state.get("artifacts", {})
    answers = _gate_answers(state)
    existing = artifacts.get("spec")

    if existing and answers:
        user_input = (
            f"Spécification actuelle :\n\n{existing}\n\n"
            f"Intègre ces retours et renvoie le document COMPLET mis à jour :\n{answers}"
        )
    else:
        user_input = (
            f"Cadrage validé à spécifier :\n\n{artifacts.get('cadrage', '')}\n\n"
            "Rédige la spécification complète du périmètre Must."
        )

    result = await invoke_agent(
        agent="spec_writer",
        system_prompt=_system(state, "spec_writer"),
        user_input=user_input,
        metadata=_meta(state),
    )
    usage = [usage_record("spec_writer", result)]
    document = result.text

    # Examen critique : la méthode socratique est la plus révélatrice sur une spec.
    reports, sub_usage = await subagents.fan_out(
        subagents.elicitation(state, document, "socratique")
    )
    usage.extend(sub_usage)

    blocking = _blocking_findings(reports)
    if blocking:
        # Les constats bloquants sont intégrés avant de soumettre au gate :
        # ils ne peuvent pas être absorbés silencieusement.
        fix = await invoke_agent(
            agent="spec_writer",
            system_prompt=_system(state, "spec_writer"),
            user_input=(
                f"Spécification :\n\n{document}\n\n"
                f"Constats BLOQUANTS de la passe socratique à corriger "
                f"(renvoie le document complet corrigé) :\n{json.dumps(blocking, ensure_ascii=False, indent=2)}"
            ),
            metadata=_meta(state),
        )
        usage.append(usage_record("spec_writer", fix))
        document = fix.text

    gate = GatePayload(
        phase="specification",
        title="Validation de la spécification",
        summary=_summarize(document),
        checklist=_checklist_from_kit("spec_writer", document, reports),
        artifact_kind="spec",
        questions=_extract_clarifications(document),
    )
    return {
        "artifacts": {"spec": document},
        "reports": reports,
        "usage": usage,
        "pending_gate": gate,
        "phase": "specification",
        "messages": [AIMessage(content=gate["summary"], name="spec_writer")],
    }


# ─────────────────────────────────────────────────────────────────────
# Plan — rédaction, risques d'implémentation, puis vérification transverse
# ─────────────────────────────────────────────────────────────────────
async def planner(state: CadrageState) -> dict[str, Any]:
    progress.step_start("planner")
    artifacts = state.get("artifacts", {})
    answers = _gate_answers(state)

    user_input = (
        f"Cadrage :\n\n{artifacts.get('cadrage', '')}\n\n"
        f"Spécification validée :\n\n{artifacts.get('spec', '')}"
    )
    if answers:
        user_input += f"\n\nRetours à intégrer :\n{answers}"

    result = await invoke_agent(
        agent="planner",
        system_prompt=_system(state, "planner"),
        user_input=user_input,
        metadata=_meta(state),
    )
    usage = [usage_record("planner", result)]

    plan_doc, tasks_doc = _split(result.text, SPLIT_TASKS)

    # Red team sur le plan + risques d'implémentation, en parallèle.
    reports, sub_usage = await subagents.fan_out(
        subagents.elicitation(state, plan_doc, "red team"),
        subagents.analyse_risques(state, plan_doc),
    )
    usage.extend(sub_usage)

    # Gate de sortie du kit : la vérification transverse prononce GO / NO-GO.
    corpus = {
        "cadrage": artifacts.get("cadrage", ""),
        "spec": artifacts.get("spec", ""),
        "plan": plan_doc,
        "tasks": tasks_doc,
    }
    verif, verif_usage = await subagents.verification_transverse(state, corpus)
    usage.append(verif_usage)
    reports.append(verif)

    verdict = (verif.get("payload") or {}).get("verdict", "NO-GO")  # type: ignore[attr-defined]
    corrections = (verif.get("payload") or {}).get("corrections_requises", [])  # type: ignore[attr-defined]

    gate = GatePayload(
        phase="plan",
        title=f"Validation du plan — vérification transverse : {verdict}",
        summary=_summarize(plan_doc),
        checklist=[
            {
                "label": item.get("item", ""),
                "ok": bool(item.get("ok")),
                "evidence": item.get("preuve", ""),
            }
            for item in (verif.get("payload") or {}).get("items", [])  # type: ignore[attr-defined]
        ],
        artifact_kind="plan",
        questions=[
            {
                "question": f"Correction requise : {c.get('item')} ({c.get('document')})",
                "options": ["Corriger maintenant", "Accepter et tracer en arbitrage"],
                "recommended": "Corriger maintenant",
            }
            for c in corrections
        ],
    )
    progress.step_done("planner", f"vérification transverse : {verdict}")
    return {
        "artifacts": {"plan": plan_doc, "tasks": tasks_doc},
        "steering_patch": _steering_from_plan(plan_doc),
        "reports": reports,
        "usage": usage,
        "pending_gate": gate,
        "phase": "plan",
        "messages": [AIMessage(content=gate["summary"], name="planner")],
    }


# ─────────────────────────────────────────────────────────────────────
# Estimation — branche hors pipeline
# ─────────────────────────────────────────────────────────────────────
async def estimateur(state: CadrageState) -> dict[str, Any]:
    artifacts = state.get("artifacts", {})
    source = (
        f"Plan :\n{artifacts.get('plan', '')}\n\nTâches :\n{artifacts.get('tasks', '')}"
        if artifacts.get("plan")
        else f"Spécification :\n{artifacts.get('spec', '')}\n\nCadrage :\n{artifacts.get('cadrage', '')}"
    )
    result = await invoke_agent(
        agent="estimateur",
        system_prompt=_system(state, "estimateur"),
        user_input=source,
        metadata=_meta(state),
    )
    readme, csv = _split(result.text, SPLIT_CSV)
    return {
        "artifacts": {"estimation": readme, "estimation_csv": csv},
        "usage": [usage_record("estimateur", result)],
        "phase": "estimation",
        "pending_gate": None,
        "messages": [AIMessage(content=_summarize(readme), name="estimateur")],
    }


# ─────────────────────────────────────────────────────────────────────
# Revue de code — 4 revues spécialisées puis contre-vérification
# ─────────────────────────────────────────────────────────────────────
SENSITIVE = ("auth", "login", "password", "token", "payment", "upload", "admin", "secret")


async def reviewer(state: CadrageState) -> dict[str, Any]:
    progress.step_start("reviewer", f"périmètre : {state.get('review_scope', 'diff')}")
    code = state.get("code_context", {})

    if not code:
        # Règle du kit : ne jamais inventer le code qu'on n'a pas lu.
        message = (
            "Aucun code n'a été fourni pour cette revue. Joignez le diff ou les "
            "fichiers concernés : je n'examine que du code réellement soumis."
        )
        progress.step_done("reviewer", "aucun code soumis")
        return {
            "phase": "revue",
            "pending_gate": None,
            "messages": [AIMessage(content=message, name="reviewer")],
        }

    # L'audit de sécurité est systématique dès que le changement touche une zone
    # sensible, sans attendre que l'utilisateur y pense.
    haystack = " ".join(code).lower() + " ".join(code.values())[:20000].lower()
    security_needed = any(word in haystack for word in SENSITIVE)

    reviews = [
        subagents.revue_correction(state),
        subagents.gardien_patterns(state),
    ]
    if state.get("artifacts", {}).get("spec"):
        reviews.insert(0, subagents.revue_conformite(state))
    if security_needed:
        reviews.append(subagents.revue_securite(state))

    reports, usage = await subagents.fan_out(*reviews)

    # Contre-vérification : le consolidateur re-trace lui-même les constats
    # bloquants et majeurs avant de les retenir (anti-faux-positifs).
    progress.checking("reviewer", "contre-vérification des constats")
    findings = _collect_findings(reports)
    consolidation = await invoke_agent(
        agent="reviewer",
        system_prompt=_system(state, "reviewer") + control_suffix("reviewer"),
        user_input=(
            f"Périmètre : {state.get('review_scope', 'diff')}\n\n"
            f"Code examiné :\n\n{subagents.format_code(code)}\n\n"
            f"---\n\nRestitutions des revues spécialisées :\n\n"
            f"{subagents.format_reports(reports)}\n\n"
            f"---\n\nConsolide : re-trace chaque constat bloquant ou majeur dans le code "
            f"ci-dessus (CONFIRME / REQUALIFIE / REJETTE avec la preuve), fusionne les "
            f"doublons, et prononce le verdict."
        ),
        metadata=_meta(state),
    )
    usage.append(usage_record("reviewer", consolidation))
    document = subagents._strip_control(consolidation.text)
    control = subagents._parse_control(consolidation.text)

    verdict = control.get("verdict", "NO-GO")
    blocking = control.get("bloquants", [])
    progress.step_done("reviewer", f"{verdict} · {len(blocking)} bloquant(s)")

    gate = GatePayload(
        phase="revue",
        title=f"Revue de code — verdict : {verdict}",
        summary=_summarize(document),
        checklist=[
            {
                "label": f"{item.get('fichier', '?')} — {item.get('constat', '')}",
                "ok": False,
                "evidence": item.get("action", ""),
                "auto": True,
            }
            for item in blocking
        ]
        or [{"label": "Aucun constat bloquant confirmé", "ok": True, "evidence": "", "auto": True}],
        artifact_kind="revue",
        questions=[
            {
                "question": "Comment traiter les constats bloquants ?",
                "options": ["Corriger avant de fusionner", "Accepter et tracer en arbitrage"],
                "recommended": "Corriger avant de fusionner",
            }
        ]
        if blocking
        else [],
    )
    return {
        "artifacts": {"revue": document},
        "reports": reports,
        "usage": usage,
        "pending_gate": gate,
        "phase": "revue",
        "messages": [AIMessage(content=gate["summary"], name="reviewer")],
    }


# ─────────────────────────────────────────────────────────────────────
# Correction de bug — diagnostic en entonnoir puis correction test-first
# ─────────────────────────────────────────────────────────────────────
async def bugfix(state: CadrageState) -> dict[str, Any]:
    progress.step_start("bugfix", "diagnostic")
    answers = _gate_answers(state)
    existing = state.get("artifacts", {}).get("bugfix")
    code = state.get("code_context", {})

    if existing and answers:
        user_input = (
            f"Document de diagnostic actuel :\n\n{existing}\n\n"
            f"Réponses de l'utilisateur :\n{answers}\n\n"
            "Poursuis l'entonnoir ou passe à la correction test-first si le "
            "diagnostic est suffisant. Renvoie le document complet mis à jour."
        )
    else:
        user_input = (
            f"Signalement :\n\n{state['initial_prompt']}\n\n"
            f"Code disponible :\n\n{subagents.format_code(code) if code else '(aucun code fourni)'}"
        )

    result = await invoke_agent(
        agent="bugfix",
        system_prompt=_system(state, "bugfix") + control_suffix("bugfix"),
        user_input=user_input,
        metadata=_meta(state),
    )
    document = subagents._strip_control(result.text)
    control = subagents._parse_control(result.text)
    questions = control.get("questions_ouvertes", [])

    progress.step_done("bugfix", control.get("phase", "diagnostic"))

    gate = GatePayload(
        phase="revue",
        title="Diagnostic du bug — validation",
        summary=_summarize(document),
        checklist=[
            {
                "label": "Condition du bug formalisée",
                "ok": bool(control.get("condition_bug")),
                "evidence": control.get("condition_bug", ""),
                "auto": True,
            },
            {
                "label": "Cas de régression à protéger identifiés",
                "ok": bool(control.get("cas_regression")),
                "evidence": f"{len(control.get('cas_regression', []))} cas",
                "auto": True,
            },
            {"label": "Validation explicite de l'utilisateur", "ok": False,
             "evidence": "en attente de votre décision", "auto": True},
        ],
        artifact_kind="revue",
        questions=[
            {"question": q, "options": ["Répondre", "Je ne sais pas"], "recommended": None}
            for q in questions[:5]
        ],
    )
    return {
        "artifacts": {"bugfix": document},
        "usage": [usage_record("bugfix", result)],
        "pending_gate": gate,
        "phase": "revue",
        "messages": [AIMessage(content=gate["summary"], name="bugfix")],
    }


def _collect_findings(reports: list[dict]) -> list[dict]:
    """Constats de toutes les revues, dédoublonnés par fichier+constat."""
    seen: set[tuple[str, str]] = set()
    out: list[dict] = []
    for report in reports:
        for item in (report.get("payload") or {}).get("constats", []):
            key = (item.get("fichier", ""), item.get("constat", "")[:80])
            if key not in seen:
                seen.add(key)
                out.append(item)
    return out


# ─────────────────────────────────────────────────────────────────────
# Utilitaires de préparation des gates
# ─────────────────────────────────────────────────────────────────────
def _split(text: str, marker: str) -> tuple[str, str]:
    if marker in text:
        left, right = text.split(marker, 1)
        return left.strip(), right.strip()
    return text.strip(), ""


def _summarize(document: str, limit: int = 900) -> str:
    """Résumé bon marché : titres + premières lignes. Pas d'appel LLM pour ça."""
    lines = [ln for ln in document.splitlines() if ln.strip()]
    head = [ln for ln in lines[:60] if ln.startswith("#") or ln.startswith("|")][:14]
    text = "\n".join(head) if head else "\n".join(lines[:12])
    return text[:limit]


def _blocking_findings(reports: list[dict]) -> list[dict]:
    """Constats bloquants remontés par les sous-agents (bloc de contrôle)."""
    out: list[dict] = []
    for report in reports:
        payload = report.get("payload") or {}
        out.extend(payload.get("bloquants", []))
        # Compatibilité : certains sous-agents listent tout dans « constats »
        for finding in payload.get("constats", []):
            if finding.get("gravite") == "bloquant":
                out.append(finding)
    return out


# ─────────────────────────────────────────────────────────────────────
# Checklists des gates : les libellés viennent du kit, la vérification est
# mécanique. Un critère dont on ne sait pas prouver la satisfaction reste
# à `false` avec la mention « à vérifier » — jamais coché par optimisme.
# ─────────────────────────────────────────────────────────────────────
def _evaluate(label: str, doc: str, reports: list[dict]) -> tuple[bool | None, str]:
    """Tente de vérifier un critère du kit sur le document produit."""
    text, low = doc, doc.lower()
    key = label.lower()

    if "valid" in key and "utilisateur" in key:
        return False, "en attente de votre décision"

    if "hors périmètre" in key or "hors perimetre" in key:
        section = low.split("hors périmètre", 1)[-1][:2000] if "hors périmètre" in low else ""
        count = sum(1 for ln in section.splitlines() if ln.strip().startswith(("-", "*")))
        return count >= 3, f"{count} exclusion(s) explicite(s)"

    if "objectif" in key and ("métrique" in key or "metrique" in key or "cible" in key):
        objectives = len(re.findall(r"\|\s*O\d+\s*\|", text))
        dated = bool(re.search(r"(mois|semaine|trimestre|T[1-4]|\d{4})", text))
        return (objectives > 0 and dated), f"{objectives} objectif(s) numéroté(s)"

    if "risque" in key:
        risks = len(re.findall(r"\|\s*R\d+\s*\|", text))
        return risks > 0, f"{risks} risque(s) coté(s)"

    if "hypothèse" in key or "hypothese" in key:
        remaining = text.count("[défaut]")
        return remaining == 0, (
            "toutes confirmées" if remaining == 0 else f"{remaining} hypothèse(s) [défaut] en attente"
        )

    if "clarification" in key:
        remaining = text.count("BESOIN DE CLARIFICATION")
        return remaining == 0, "aucune" if remaining == 0 else f"{remaining} ouverte(s)"

    if "critères de succès" in key or "criteres de succes" in key:
        return "critères de succès" in low, ""

    if "numérotée" in key or "testable" in key or "tracée" in key:
        requirements = len(re.findall(r"EF-\d{3}", text))
        traced = len(re.findall(r"→\s*O\d", text))
        return (requirements > 0 and traced > 0), f"{requirements} EF, {traced} traçage(s)"

    if "non fonctionnelle" in key and "chiffrée" in key:
        nfr = len(re.findall(r"ENF-\d{3}", text))
        return nfr > 0, f"{nfr} ENF"

    if "implémentation" in key or "implementation" in key:
        leaked = any(w in low for w in ("postgresql", "react", "django", "framework", "kubernetes"))
        return not leaked, "aucun choix technique détecté" if not leaked else "vocabulaire technique présent"

    if "invariant" in key:
        invariants = len(re.findall(r"INV-\d{3}", text))
        return invariants > 0, f"{invariants} invariant(s)"

    if "bloquant" in key:
        blocking = _blocking_findings(reports)
        return not blocking, f"{len(blocking)} constat(s) bloquant(s)"

    return None, "à vérifier manuellement"


def _checklist_from_kit(agent: str, doc: str, reports: list[dict]) -> list[dict[str, Any]]:
    """Construit la checklist du gate à partir des critères écrits dans le kit."""
    items: list[dict[str, Any]] = []
    for label in gate_criteria(agent):
        ok, evidence = _evaluate(label, doc, reports)
        items.append(
            {
                "label": label,
                "ok": bool(ok),
                "evidence": evidence,
                "auto": ok is not None,   # false = contrôle humain requis
            }
        )
    return items


def _extract_open_hypotheses(doc: str) -> list[dict[str, Any]]:
    """Transforme les hypothèses [défaut] en questions fermées pour le gate."""
    questions: list[dict[str, Any]] = []
    for line in doc.splitlines():
        if "[défaut]" in line and line.strip().startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) >= 2 and cells[1]:
                questions.append(
                    {
                        "question": f"Hypothèse {cells[0]} — {cells[1]}",
                        "options": ["Confirmer", "Corriger (préciser)"],
                        "recommended": "Confirmer",
                    }
                )
    return questions[:8]


def _section(doc: str, *titles: str, limit: int = 2500) -> str:
    """Extrait une section markdown par son titre (insensible à la casse)."""
    lines = doc.splitlines()
    wanted = tuple(t.lower() for t in titles)
    out: list[str] = []
    capture = False
    for line in lines:
        if line.startswith("#"):
            heading = line.lstrip("# ").strip().lower()
            if capture:
                break
            capture = any(w in heading for w in wanted)
            if capture:
                continue
        if capture:
            out.append(line)
    return "\n".join(out).strip()[:limit]


def _steering_from_cadrage(doc: str) -> dict[str, str]:
    """Reverse le cadrage dans le steering produit.

    Sans cette boucle, le steering reste vide et les phases suivantes (et les
    projets futurs) repartent sans mémoire — c'est le défaut qu'on avait constaté
    en testant le kit dans Copilot.
    """
    parts = [
        ("## Problème adressé", _section(doc, "contexte")),
        ("## Utilisateurs et parties prenantes", _section(doc, "utilisateurs", "parties prenantes")),
        ("## Objectifs métier", _section(doc, "objectifs")),
        ("## Ce que le produit ne fera pas", _section(doc, "hors périmètre")),
    ]
    body = "\n\n".join(f"{title}\n\n{content}" for title, content in parts if content)
    return {"product": f"# Steering — Produit\n\n{body}"} if body else {}


def _steering_from_plan(doc: str) -> dict[str, str]:
    """Reverse la stack retenue et l'organisation du code dans le steering technique."""
    tech = _section(doc, "architecture", "stack")
    structure = _section(doc, "modèle de données", "organisation", "structure")
    patch: dict[str, str] = {}
    if tech:
        patch["tech"] = f"# Steering — Technique\n\n> Décision issue du plan validé.\n\n{tech}"
    if structure:
        patch["structure"] = f"# Steering — Structure\n\n{structure}"
    return patch


def _extract_clarifications(doc: str) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for line in doc.splitlines():
        if "BESOIN DE CLARIFICATION" in line:
            out.append(
                {
                    "question": line.split("BESOIN DE CLARIFICATION", 1)[-1].strip(" :]"),
                    "options": [],
                    "recommended": None,
                }
            )
    return out[:8]
