"""Graphe LangGraph du pipeline de cadrage.

Le point clé du produit : `interrupt()`. Quand un livrable atteint son gate, le
graphe s'arrête, son état est persisté par le checkpointer Postgres et l'exécution
rend la main. Aucune ressource n'est consommée pendant que l'utilisateur réfléchit —
des minutes ou des semaines. La reprise se fait avec `Command(resume=...)` sur le
même `thread_id`, et le graphe repart exactement où il s'était arrêté.
"""
from __future__ import annotations

import logging
from typing import Any, Literal

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

from app.agents import nodes
from app.agents.state import CadrageState, GateResponse
from app.config import settings

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# Gate humain — un seul nœud générique, réutilisé par toutes les phases
# ─────────────────────────────────────────────────────────────────────
async def human_gate(state: CadrageState) -> dict[str, Any]:
    """Suspend le graphe et attend la décision de l'utilisateur.

    `interrupt()` lève une exception spéciale interceptée par LangGraph : la valeur
    passée est ce que l'API renverra à l'UI, et la valeur de reprise (`Command.resume`)
    devient la valeur de retour de cet appel.
    """
    gate = state.get("pending_gate")
    if gate is None:  # pas de gate à cette étape : on passe
        return {}

    response: GateResponse = interrupt(
        {
            "type": "gate",
            "phase": gate["phase"],
            "title": gate["title"],
            "summary": gate["summary"],
            "checklist": gate["checklist"],
            "questions": gate["questions"],
            "artifact_kind": gate.get("artifact_kind"),
        }
    )

    return {
        "pending_gate": None,
        "gate_history": [
            {
                "phase": gate["phase"],
                "decision": response.get("decision", "approved"),
                "feedback": response.get("feedback"),
                "answers": response.get("answers", {}),
            }
        ],
    }


# ─────────────────────────────────────────────────────────────────────
# Aiguillages
# ─────────────────────────────────────────────────────────────────────
def _last_decision(state: CadrageState) -> str:
    history = state.get("gate_history") or []
    return history[-1]["decision"] if history else "approved"


def route_after_orchestration(
    state: CadrageState,
) -> Literal["cadrage", "spec_writer", "planner", "estimateur", "reviewer", "bugfix"]:
    """Le scénario et la phase d'entrée déterminent le point de départ.

    Un bug (niveau d'échelle 0) ne passe pas par le pipeline complet : il suit le
    parcours léger diagnostic → correction test-first.
    """
    if state.get("scenario") == "bug" or state.get("scale_level") == 0:
        return "bugfix"

    phase = state.get("phase", "cadrage")
    if phase == "specification":
        return "spec_writer"
    if phase == "plan":
        return "planner"
    if phase == "estimation":
        return "estimateur"
    if phase == "revue":
        return "reviewer"
    return "cadrage"


def route_after_cadrage_gate(state: CadrageState) -> Literal["cadrage", "spec_writer", "__end__"]:
    decision = _last_decision(state)
    if decision == "changes_requested":
        return "cadrage"        # boucle d'itération, l'état conserve le document
    if decision == "rejected":
        return "__end__"
    if state.get("scale_level", 2) == 0:
        return "__end__"        # niveau 0 (correctif) : pas de spécification
    return "spec_writer"


def route_after_spec_gate(state: CadrageState) -> Literal["spec_writer", "planner", "__end__"]:
    decision = _last_decision(state)
    if decision == "changes_requested":
        return "spec_writer"
    if decision == "rejected":
        return "__end__"
    return "planner"


def route_after_plan_gate(state: CadrageState) -> Literal["planner", "estimateur", "__end__"]:
    decision = _last_decision(state)
    if decision == "changes_requested":
        return "planner"
    if decision == "rejected":
        return "__end__"
    return "estimateur"


def route_after_revue_gate(state: CadrageState) -> Literal["reviewer", "__end__"]:
    """Après une revue : re-vérifier les corrections, ou clore."""
    return "reviewer" if _last_decision(state) == "changes_requested" else "__end__"


def route_after_bugfix_gate(state: CadrageState) -> Literal["bugfix", "__end__"]:
    """Le diagnostic boucle tant que l'entonnoir n'a pas convergé."""
    return "bugfix" if _last_decision(state) == "changes_requested" else "__end__"


# ─────────────────────────────────────────────────────────────────────
# Construction du graphe
# ─────────────────────────────────────────────────────────────────────
def build_graph() -> StateGraph:
    g = StateGraph(CadrageState)

    g.add_node("orchestrateur", nodes.orchestrateur)
    g.add_node("cadrage", nodes.cadrage)
    g.add_node("gate_cadrage", human_gate)
    g.add_node("spec_writer", nodes.spec_writer)
    g.add_node("gate_spec", human_gate)
    g.add_node("planner", nodes.planner)
    g.add_node("gate_plan", human_gate)
    g.add_node("estimateur", nodes.estimateur)
    g.add_node("reviewer", nodes.reviewer)
    g.add_node("gate_revue", human_gate)
    g.add_node("bugfix", nodes.bugfix)
    g.add_node("gate_bugfix", human_gate)

    g.add_edge(START, "orchestrateur")
    g.add_conditional_edges("orchestrateur", route_after_orchestration)

    g.add_edge("cadrage", "gate_cadrage")
    g.add_conditional_edges("gate_cadrage", route_after_cadrage_gate)

    g.add_edge("spec_writer", "gate_spec")
    g.add_conditional_edges("gate_spec", route_after_spec_gate)

    g.add_edge("planner", "gate_plan")
    g.add_conditional_edges("gate_plan", route_after_plan_gate)

    g.add_edge("estimateur", END)

    # Revue de code : boucle de correction jusqu'à levée des constats bloquants.
    g.add_edge("reviewer", "gate_revue")
    g.add_conditional_edges("gate_revue", route_after_revue_gate)

    # Correction de bug : entonnoir de diagnostic, puis correction test-first.
    g.add_edge("bugfix", "gate_bugfix")
    g.add_conditional_edges("gate_bugfix", route_after_bugfix_gate)
    return g


# ─────────────────────────────────────────────────────────────────────
# Compilation avec checkpointer
# ─────────────────────────────────────────────────────────────────────
_compiled = None


async def get_compiled_graph():
    """Graphe compilé, partagé par le processus. Le checkpointer Postgres porte la
    reprise entre deux interruptions — c'est lui qui rend les gates durables."""
    global _compiled
    if _compiled is not None:
        return _compiled

    saver = AsyncPostgresSaver.from_conn_string(str(settings.database_url))
    checkpointer = await saver.__aenter__()
    await checkpointer.setup()   # idempotent : crée les tables checkpoints si absentes

    _compiled = build_graph().compile(checkpointer=checkpointer)
    logger.info("Graphe de cadrage compilé (checkpointer Postgres actif)")
    return _compiled


def thread_id(tenant_id: str, run_id: str) -> str:
    """Le thread porte le tenant : une reprise croisée entre tenants est
    structurellement impossible, en plus de la vérification applicative."""
    return f"tenant:{tenant_id}:run:{run_id}"


def resume_command(response: GateResponse) -> Command:
    return Command(resume=response)
