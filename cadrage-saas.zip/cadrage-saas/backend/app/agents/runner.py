"""Exécution d'un run : pont entre le graphe LangGraph et la persistance métier.

Responsabilités :
  - streamer les événements du graphe vers l'API (SSE) ;
  - persister à chaque étape les livrables (S3 + table `artifacts`), les messages,
    les gates et la consommation de tokens ;
  - garantir qu'un run ne peut être repris que par son tenant propriétaire.
"""
from __future__ import annotations

import logging
import uuid
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select

from app.agents.graph import get_compiled_graph, resume_command, thread_id
from app.agents.state import CadrageState, GateResponse, initial_state
from app.config import settings
from app.db.models import (
    Artifact,
    ArtifactKind,
    Gate,
    GateDecision,
    Phase,
    Project,
    Run,
    RunMessage,
    RunStatus,
)
from app.db.session import tenant_session
from app.services import billing, storage

logger = logging.getLogger(__name__)

ARTIFACT_KINDS = {
    "cadrage": ArtifactKind.cadrage,
    "spec": ArtifactKind.spec,
    "plan": ArtifactKind.plan,
    "tasks": ArtifactKind.tasks,
    "estimation": ArtifactKind.estimation,
    "revue": ArtifactKind.revue,
}


class RunNotFound(Exception):
    pass


class RunNotResumable(Exception):
    pass


# ─────────────────────────────────────────────────────────────────────
# Lancement et reprise
# ─────────────────────────────────────────────────────────────────────
async def start_run(
    *,
    tenant_id: uuid.UUID,
    project_id: uuid.UUID,
    user_id: uuid.UUID,
    prompt: str,
    entry_phase: Phase = Phase.orchestration,
    code_context: dict[str, str] | None = None,
    review_scope: str = "diff",
) -> Run:
    """Crée le run en base. L'exécution effective est lancée par `stream_run`."""
    async with tenant_session(tenant_id) as session:
        project = await session.get(Project, project_id)
        if project is None:
            raise RunNotFound(str(project_id))

        run = Run(
            tenant_id=tenant_id,
            project_id=project_id,
            started_by=user_id,
            thread_id="",  # complété juste après pour disposer de l'id
            entry_phase=entry_phase,
            current_phase=entry_phase,
            status=RunStatus.pending,
            initial_prompt=prompt,
            code_context=code_context or {},
            review_scope=review_scope,
        )
        session.add(run)
        await session.flush()
        run.thread_id = thread_id(str(tenant_id), str(run.id))
        await session.flush()
        await session.refresh(run)
        return run


async def stream_run(
    *,
    tenant_id: uuid.UUID,
    run_id: uuid.UUID,
    resume: GateResponse | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """Exécute (ou reprend) le graphe et émet des événements pour l'UI.

    Événements : `{"type": "message"|"artifact"|"gate"|"done"|"error", ...}`
    """
    async with tenant_session(tenant_id) as session:
        run = await session.get(Run, run_id)
        if run is None or run.tenant_id != tenant_id:
            raise RunNotFound(str(run_id))
        if resume and run.status is not RunStatus.waiting_human:
            raise RunNotResumable(f"run in status {run.status}")

        project = await session.get(Project, run.project_id)
        run.status = RunStatus.running
        run.error = None

        # Livrables déjà validés sur ce projet : une revue a besoin de la spec et
        # du plan pour vérifier la conformité, un nouveau cadrage de l'existant.
        previous = await _load_project_artifacts(session, run.project_id)

        state_seed = initial_state(
            tenant_id=str(tenant_id),
            project_id=str(run.project_id),
            run_id=str(run.id),
            prompt=run.initial_prompt,
            steering=(project.steering if project else {}) or {},
            constitution=(project.tenant.settings or {}).get("constitution", "")
            if project and project.tenant
            else "",
            code_context=run.code_context or {},
            review_scope=run.review_scope or "diff",
            artifacts=previous,
        )
        config = {
            "configurable": {"thread_id": run.thread_id},
            "recursion_limit": 60,
            "metadata": {"tenant_id": str(tenant_id), "run_id": str(run.id)},
            "tags": [f"tenant:{tenant_id}", f"env:{settings.env}"],
        }

    graph = await get_compiled_graph()
    payload: Any = resume_command(resume) if resume else state_seed
    seq = await _next_seq(tenant_id, run_id)
    final_state: CadrageState | None = None

    try:
        # `updates` = résultats des nœuds ; `custom` = progression fine émise par
        # les agents et sous-agents (ce que l'utilisateur voit défiler en direct).
        async for mode, chunk in graph.astream(
            payload, config=config, stream_mode=["updates", "custom"]
        ):
            if mode == "custom":
                yield {"type": "progress", **chunk}
                continue

            for node_name, update in chunk.items():
                if node_name == "__interrupt__":
                    gate_payload = update[0].value if update else {}
                    await _persist_gate(tenant_id, run_id, gate_payload)
                    yield {"type": "gate", "data": gate_payload}
                    return

                if not isinstance(update, dict):
                    continue

                for message in update.get("messages", []) or []:
                    seq += 1
                    content = getattr(message, "content", str(message))
                    await _persist_message(
                        tenant_id, run_id, seq, "agent", node_name, str(content)
                    )
                    yield {"type": "message", "agent": node_name, "content": content}

                for kind, content in (update.get("artifacts") or {}).items():
                    await _persist_artifact(tenant_id, run_id, kind, content)
                    yield {"type": "artifact", "kind": kind, "size": len(content)}

                if update.get("steering_patch"):
                    await _apply_steering(tenant_id, run_id, update["steering_patch"])
                    yield {
                        "type": "steering",
                        "keys": list(update["steering_patch"].keys()),
                    }

                if update.get("usage"):
                    await billing.record_usage(tenant_id, run_id, update["usage"])

                if update.get("phase"):
                    await _update_phase(tenant_id, run_id, update["phase"])

        snapshot = await graph.aget_state(config)
        final_state = snapshot.values if snapshot else None
        await _finish(tenant_id, run_id, RunStatus.completed)
        yield {"type": "done", "phase": (final_state or {}).get("phase")}

    except Exception as exc:  # noqa: BLE001 — on veut tracer toute défaillance
        logger.exception("Run %s en échec", run_id)
        await _finish(tenant_id, run_id, RunStatus.failed, error=str(exc))
        yield {"type": "error", "message": str(exc)}


# ─────────────────────────────────────────────────────────────────────
# Persistance
# ─────────────────────────────────────────────────────────────────────
async def _load_project_artifacts(session, project_id: uuid.UUID) -> dict[str, str]:
    """Dernière version de chaque livrable du projet, chargée depuis S3."""
    rows = (
        await session.execute(
            select(Artifact)
            .where(Artifact.project_id == project_id)
            .order_by(Artifact.kind, Artifact.created_at.desc())
        )
    ).scalars().all()

    latest: dict[str, Artifact] = {}
    for artifact in rows:
        latest.setdefault(artifact.kind.value, artifact)

    out: dict[str, str] = {}
    for kind, artifact in latest.items():
        try:
            out[kind] = await storage.get_text(artifact.s3_key)
        except Exception:  # noqa: BLE001 — un objet manquant ne bloque pas le run
            logger.warning("Artefact illisible ignoré : %s", artifact.s3_key)
    return out


async def _next_seq(tenant_id: uuid.UUID, run_id: uuid.UUID) -> int:
    async with tenant_session(tenant_id) as session:
        rows = await session.execute(
            select(RunMessage.seq).where(RunMessage.run_id == run_id).order_by(RunMessage.seq.desc()).limit(1)
        )
        last = rows.scalar_one_or_none()
        return int(last or 0)


async def _persist_message(
    tenant_id: uuid.UUID, run_id: uuid.UUID, seq: int, role: str, agent: str, content: str
) -> None:
    async with tenant_session(tenant_id) as session:
        session.add(
            RunMessage(
                tenant_id=tenant_id, run_id=run_id, seq=seq,
                role=role, agent=agent, content=content,
            )
        )


async def _persist_artifact(
    tenant_id: uuid.UUID, run_id: uuid.UUID, kind: str, content: str
) -> None:
    """Écrit le livrable dans S3 et enregistre sa version.

    Le versionnage suit le kit : v0.1, v0.2… puis v1.0 à la validation du gate.
    """
    artifact_kind = ARTIFACT_KINDS.get(kind)
    if artifact_kind is None:      # ex. estimation_csv : stocké en pièce jointe
        artifact_kind = ArtifactKind.estimation

    async with tenant_session(tenant_id) as session:
        run = await session.get(Run, run_id)
        if run is None:
            return
        existing = (
            await session.execute(
                select(Artifact)
                .where(Artifact.project_id == run.project_id, Artifact.kind == artifact_kind)
                .order_by(Artifact.created_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()

        version = _next_version(existing.version if existing else None)
        key = storage.artifact_key(
            tenant_id=tenant_id, project_id=run.project_id, kind=kind, version=version
        )
        checksum = await storage.put_text(key, content)

        session.add(
            Artifact(
                tenant_id=tenant_id,
                project_id=run.project_id,
                run_id=run_id,
                kind=artifact_kind,
                title=f"{kind} {version}",
                version=version,
                status="brouillon",
                s3_key=key,
                checksum=checksum,
                size_bytes=len(content.encode()),
            )
        )


def _next_version(current: str | None) -> str:
    if not current:
        return "v0.1"
    try:
        major, minor = current.lstrip("v").split(".")
        return f"v{major}.{int(minor) + 1}"
    except ValueError:
        return "v0.1"


async def _persist_gate(
    tenant_id: uuid.UUID, run_id: uuid.UUID, payload: dict[str, Any]
) -> None:
    async with tenant_session(tenant_id) as session:
        run = await session.get(Run, run_id)
        if run is None:
            return
        run.status = RunStatus.waiting_human
        session.add(
            Gate(
                tenant_id=tenant_id,
                run_id=run_id,
                phase=Phase(payload.get("phase", "cadrage")),
                title=payload.get("title", "Validation"),
                checklist=payload.get("checklist", []),
                summary=payload.get("summary", ""),
                decision=GateDecision.pending,
            )
        )


async def _apply_steering(
    tenant_id: uuid.UUID, run_id: uuid.UUID, patch: dict[str, str]
) -> None:
    """Reverse les décisions dans la mémoire permanente du projet.

    Le steering alimente tous les runs suivants : sans ce reversement, chaque
    nouveau cadrage repart d'une page blanche.
    """
    async with tenant_session(tenant_id) as session:
        run = await session.get(Run, run_id)
        if run is None:
            return
        project = await session.get(Project, run.project_id)
        if project is None:
            return
        steering = dict(project.steering or {})
        steering.update({k: v for k, v in patch.items() if v})
        project.steering = steering
        # Miroir dans S3 pour que le workspace téléchargé soit complet.
        for key, content in patch.items():
            if content:
                await storage.put_text(
                    storage.artifact_key(
                        tenant_id=tenant_id,
                        project_id=run.project_id,
                        kind="steering",
                        version=key,
                    ),
                    content,
                )


async def _update_phase(tenant_id: uuid.UUID, run_id: uuid.UUID, phase: str) -> None:
    async with tenant_session(tenant_id) as session:
        run = await session.get(Run, run_id)
        if run is not None:
            run.current_phase = Phase(phase)


async def _finish(
    tenant_id: uuid.UUID, run_id: uuid.UUID, status: RunStatus, error: str | None = None
) -> None:
    async with tenant_session(tenant_id) as session:
        run = await session.get(Run, run_id)
        if run is None:
            return
        run.status = status
        run.error = error
        run.finished_at = datetime.now(timezone.utc)
