"""Accès à Bedrock + capture de l'usage facturable.

Toute inférence du produit passe par `invoke_agent()` : c'est le seul endroit où
les tokens sont comptés, ce qui garantit qu'aucun appel n'échappe à la facturation.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from langchain_aws import ChatBedrockConverse
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage

from app.config import settings

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class AgentResult:
    text: str
    input_tokens: int
    output_tokens: int
    model_id: str

    def cost_cents(self) -> int:
        """Prix **client** (marge incluse), pas le coût AWS."""
        cents = (
            self.input_tokens * settings.price_cents_per_mtok_input
            + self.output_tokens * settings.price_cents_per_mtok_output
        ) / 1_000_000
        return max(1, round(cents)) if (self.input_tokens or self.output_tokens) else 0


_clients: dict[str, ChatBedrockConverse] = {}


def get_client(model_id: str, temperature: float = 0.2) -> ChatBedrockConverse:
    key = f"{model_id}:{temperature}"
    if key not in _clients:
        _clients[key] = ChatBedrockConverse(
            model=model_id,
            region_name=settings.aws_region,
            temperature=temperature,
            max_tokens=settings.bedrock_max_tokens,
        )
    return _clients[key]


async def invoke_agent(
    *,
    agent: str,
    system_prompt: str,
    messages: list[BaseMessage] | None = None,
    user_input: str | None = None,
    fast: bool = False,
    temperature: float = 0.2,
    metadata: dict[str, Any] | None = None,
) -> AgentResult:
    """Invoque un agent et retourne son texte + sa consommation.

    `fast=True` bascule sur le modèle rapide (tri, extraction, reformulation) —
    les agents de rédaction et de revue utilisent toujours le modèle principal.
    """
    model_id = settings.bedrock_model_id_fast if fast else settings.bedrock_model_id
    client = get_client(model_id, temperature)

    payload: list[BaseMessage] = [SystemMessage(content=system_prompt)]
    if messages:
        payload.extend(messages)
    if user_input:
        payload.append(HumanMessage(content=user_input))

    # Les tags LangSmith permettent de filtrer les traces par tenant et par agent
    # sans jamais exposer le contenu métier dans le nom du run.
    config: dict[str, Any] = {
        "tags": [f"agent:{agent}", f"env:{settings.env}"],
        "metadata": {"agent": agent, **(metadata or {})},
        "run_name": f"agent.{agent}",
    }

    response: AIMessage = await client.ainvoke(payload, config=config)  # type: ignore[assignment]

    usage = response.usage_metadata or {}
    result = AgentResult(
        text=response.text() if hasattr(response, "text") else str(response.content),
        input_tokens=int(usage.get("input_tokens", 0)),
        output_tokens=int(usage.get("output_tokens", 0)),
        model_id=model_id,
    )
    logger.info(
        "agent=%s model=%s in=%d out=%d",
        agent, model_id, result.input_tokens, result.output_tokens,
    )
    return result


def usage_record(agent: str, result: AgentResult) -> dict[str, Any]:
    """Ligne d'usage à accumuler dans l'état du graphe (persistée en fin de nœud)."""
    return {
        "agent": agent,
        "model_id": result.model_id,
        "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
        "cost_cents": result.cost_cents(),
    }
