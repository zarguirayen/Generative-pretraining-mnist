"""Facturation : plans, usage, portail client, webhooks Stripe."""
from __future__ import annotations

from typing import Any

import stripe
from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel

from app.api.deps import Principal, current_principal, require_role
from app.db.models import MemberRole, Plan
from app.services import billing as billing_service
from app.services import quota

router = APIRouter(tags=["billing"])


class CheckoutRequest(BaseModel):
    plan: Plan
    success_url: str
    cancel_url: str


class UsageOut(BaseModel):
    plan: Plan
    subscription_active: bool
    usage: dict[str, int]
    limits: dict[str, int]


@router.get("/{tenant_slug}/billing/usage", response_model=UsageOut)
async def get_usage(principal: Principal = Depends(current_principal)) -> UsageOut:
    """Consommation du mois et limites du plan — alimente la jauge de l'UI."""
    limits = quota.limits_for(principal.tenant)
    return UsageOut(
        plan=principal.tenant.plan,
        subscription_active=principal.tenant.subscription_active,
        usage=await quota.current_usage(principal.tenant.id),
        limits={
            "runs_per_month": limits.runs_per_month,
            "tokens_per_month": limits.tokens_per_month,
            "projects": limits.projects,
            "seats": limits.seats,
        },
    )


@router.post("/{tenant_slug}/billing/checkout")
async def create_checkout(
    body: CheckoutRequest,
    principal: Principal = Depends(require_role(MemberRole.owner)),
) -> dict[str, str]:
    """Souscription ou changement de plan. Réservé au propriétaire du tenant."""
    try:
        url = await billing_service.create_checkout_session(
            principal.tenant,
            principal.user.email,
            body.plan,
            body.success_url,
            body.cancel_url,
        )
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    return {"url": url}


@router.post("/{tenant_slug}/billing/portal")
async def create_portal(
    return_url: str,
    principal: Principal = Depends(require_role(MemberRole.owner)),
) -> dict[str, str]:
    try:
        url = await billing_service.create_portal_session(principal.tenant, return_url)
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    return {"url": url}


@router.post("/webhooks/stripe", include_in_schema=False)
async def stripe_webhook(
    request: Request, stripe_signature: str = Header(alias="Stripe-Signature")
) -> dict[str, Any]:
    """Point d'entrée Stripe — hors espace tenant, authentifié par signature."""
    payload = await request.body()
    try:
        return await billing_service.handle_webhook(payload, stripe_signature)
    except stripe.SignatureVerificationError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Signature invalide") from exc
