"""Runs : lancement, streaming SSE, reprise après un gate."""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sse_starlette.sse import EventSourceResponse

from app.agents import runner
from app.api.deps import Principal, current_principal, require_role
from app.db.models import (
    Gate,
    GateDecision,
    MemberRole,
    Phase,
    Run,
    RunMessage,
    RunStatus,
)
from app.db.session import tenant_session
from app.services import quota

router = APIRouter(prefix="/{tenant_slug}/projects/{project_id}/runs", tags=["runs"])


# ─────────────────────────────────────────────────────────────────────
# Schémas
# ─────────────────────────────────────────────────────────────────────
class StartRunRequest(BaseModel):
    prompt: str = Field(min_length=10, max_length=8000)
    entry_phase: Phase = Phase.orchestration
    # Revue de code et correction de bug : fichiers ou diff soumis par
    # l'utilisateur, { "chemin": "contenu" }. Les agents ne travaillent que sur
    # ce contenu — ils n'inventent jamais le code qu'ils n'ont pas lu.
    code_context: dict[str, str] = Field(default_factory=dict)
    review_scope: Literal["diff", "module", "codebase"] = "diff"

    @field_validator("code_context")
    @classmethod
    def _limit_code(cls, value: dict[str, str]) -> dict[str, str]:
        if len(value) > 60:
            raise ValueError("60 fichiers maximum par revue")
        total = sum(len(v) for v in value.values())
        if total > 400_000:
            raise ValueError("400 000 caractères maximum de code par revue")
        return value


class GateDecisionRequest(BaseModel):
    decision: Literal["approved", "changes_requested", "rejected"]
    feedback: str | None = Field(default=None, max_length=4000)
    answers: dict[str, str] = Field(default_factory=dict)


class RunOut(BaseModel):
    id: uuid.UUID
    status: RunStatus
    current_phase: Phase
    initial_prompt: str        # ouvre le fil de conversation dans la console
    review_scope: str
    created_at: datetime
    finished_at: datetime | None
    error: str | None

    model_config = {"from_attributes": True}


class GateOut(BaseModel):
    id: uuid.UUID
    phase: Phase
    title: str
    summary: str
    checklist: list[dict[str, Any]]
    decision: GateDecision
    created_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────────────
@router.post("", response_model=RunOut, status_code=status.HTTP_201_CREATED)
async def start_run(
    project_id: uuid.UUID,
    body: StartRunRequest,
    principal: Principal = Depends(require_role(MemberRole.contributor)),
) -> RunOut:
    """Crée un run. Le quota est vérifié ici : on refuse avant de démarrer, jamais
    au milieu d'un cadrage."""
    try:
        await quota.check_can_start_run(principal.tenant)
    except quota.QuotaExceeded as exc:
        raise HTTPException(
            status.HTTP_402_PAYMENT_REQUIRED,
            detail={"quota": exc.quota, "used": exc.used, "limit": exc.limit},
        ) from exc

    run = await runner.start_run(
        tenant_id=principal.tenant.id,
        project_id=project_id,
        user_id=principal.user.id,
        prompt=body.prompt,
        entry_phase=body.entry_phase,
        code_context=body.code_context,
        review_scope=body.review_scope,
    )
    return RunOut.model_validate(run)


@router.get("/{run_id}/stream")
async def stream(
    project_id: uuid.UUID,
    run_id: uuid.UUID,
    principal: Principal = Depends(current_principal),
) -> EventSourceResponse:
    """Flux SSE de l'exécution : messages d'agents, livrables produits, gate atteint."""

    async def event_source():
        try:
            async for event in runner.stream_run(
                tenant_id=principal.tenant.id, run_id=run_id
            ):
                yield {"event": event["type"], "data": json.dumps(event, default=str)}
        except runner.RunNotFound:
            yield {"event": "error", "data": json.dumps({"message": "Run introuvable"})}

    return EventSourceResponse(event_source())


@router.post("/{run_id}/gates/{gate_id}", response_model=RunOut)
async def decide_gate(
    project_id: uuid.UUID,
    run_id: uuid.UUID,
    gate_id: uuid.UUID,
    body: GateDecisionRequest,
    principal: Principal = Depends(require_role(MemberRole.contributor)),
) -> RunOut:
    """Enregistre la décision humaine. La reprise effective du graphe est déclenchée
    par un appel à `/resume` (SSE) — ce découpage permet à l'UI d'afficher la
    décision immédiatement, puis de suivre la suite en streaming."""
    async with tenant_session(principal.tenant.id) as session:
        gate = await session.get(Gate, gate_id)
        if gate is None or gate.run_id != run_id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Gate introuvable")
        if gate.decision is not GateDecision.pending:
            raise HTTPException(status.HTTP_409_CONFLICT, "Gate déjà tranché")

        gate.decision = GateDecision(body.decision)
        gate.decided_by = principal.user.id
        gate.decided_at = datetime.now(tz=None)
        gate.feedback = body.feedback

        run = await session.get(Run, run_id)
        if run is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Run introuvable")
        await session.refresh(run)
        return RunOut.model_validate(run)


@router.get("/{run_id}/resume")
async def resume(
    project_id: uuid.UUID,
    run_id: uuid.UUID,
    principal: Principal = Depends(require_role(MemberRole.contributor)),
) -> EventSourceResponse:
    """Reprend le graphe après une décision de gate, en streaming."""
    async with tenant_session(principal.tenant.id) as session:
        gate = (
            await session.execute(
                select(Gate)
                .where(Gate.run_id == run_id, Gate.decision != GateDecision.pending)
                .order_by(Gate.decided_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()
        if gate is None:
            raise HTTPException(status.HTTP_409_CONFLICT, "Aucune décision à appliquer")
        payload = {
            "decision": gate.decision.value,
            "feedback": gate.feedback,
            "answers": {},
        }

    async def event_source():
        try:
            async for event in runner.stream_run(
                tenant_id=principal.tenant.id, run_id=run_id, resume=payload  # type: ignore[arg-type]
            ):
                yield {"event": event["type"], "data": json.dumps(event, default=str)}
        except runner.RunNotResumable as exc:
            yield {"event": "error", "data": json.dumps({"message": str(exc)})}

    return EventSourceResponse(event_source())


@router.get("", response_model=list[RunOut])
async def list_runs(
    project_id: uuid.UUID, principal: Principal = Depends(current_principal)
) -> list[RunOut]:
    async with tenant_session(principal.tenant.id) as session:
        rows = (
            await session.execute(
                select(Run)
                .where(Run.project_id == project_id)
                .order_by(Run.created_at.desc())
                .limit(100)
            )
        ).scalars().all()
    return [RunOut.model_validate(r) for r in rows]


@router.get("/{run_id}/messages")
async def list_messages(
    project_id: uuid.UUID,
    run_id: uuid.UUID,
    principal: Principal = Depends(current_principal),
) -> list[dict[str, Any]]:
    async with tenant_session(principal.tenant.id) as session:
        rows = (
            await session.execute(
                select(RunMessage).where(RunMessage.run_id == run_id).order_by(RunMessage.seq)
            )
        ).scalars().all()
    return [
        {"seq": m.seq, "role": m.role, "agent": m.agent, "content": m.content,
         "created_at": m.created_at}
        for m in rows
    ]


@router.get("/{run_id}/gates", response_model=list[GateOut])
async def list_gates(
    project_id: uuid.UUID,
    run_id: uuid.UUID,
    principal: Principal = Depends(current_principal),
) -> list[GateOut]:
    async with tenant_session(principal.tenant.id) as session:
        rows = (
            await session.execute(
                select(Gate).where(Gate.run_id == run_id).order_by(Gate.created_at)
            )
        ).scalars().all()
    return [GateOut.model_validate(g) for g in rows]
