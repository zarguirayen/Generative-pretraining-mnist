"""Projets et artefacts."""
from __future__ import annotations

import io
import re
import uuid
import zipfile
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import select

from app.agents.kit_loader import steering_templates
from app.api.deps import Principal, current_principal, require_role
from app.db.models import Artifact, ArtifactKind, MemberRole, Project
from app.db.session import tenant_session
from app.services import quota, storage

router = APIRouter(prefix="/{tenant_slug}/projects", tags=["projects"])


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower().strip()).strip("-")
    return slug[:120] or f"projet-{uuid.uuid4().hex[:8]}"


class ProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    description: str | None = Field(default=None, max_length=4000)


class SteeringUpdate(BaseModel):
    product: str | None = None
    tech: str | None = None
    structure: str | None = None


class ProjectOut(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    description: str | None
    scale_level: int
    scenario: str
    steering: dict[str, Any]
    created_at: datetime

    model_config = {"from_attributes": True}


class ArtifactOut(BaseModel):
    id: uuid.UUID
    kind: ArtifactKind
    title: str
    version: str
    status: str
    size_bytes: int
    created_at: datetime

    model_config = {"from_attributes": True}


@router.post("", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
async def create_project(
    body: ProjectCreate,
    principal: Principal = Depends(require_role(MemberRole.contributor)),
) -> ProjectOut:
    try:
        await quota.check_can_create_project(principal.tenant)
    except quota.QuotaExceeded as exc:
        raise HTTPException(
            status.HTTP_402_PAYMENT_REQUIRED,
            detail={"quota": exc.quota, "used": exc.used, "limit": exc.limit},
        ) from exc

    async with tenant_session(principal.tenant.id) as session:
        project = Project(
            tenant_id=principal.tenant.id,
            created_by=principal.user.id,
            name=body.name,
            slug=slugify(body.name),
            description=body.description,
            # Gabarits de steering du kit (avec leurs sections « À COMPLÉTER ») :
            # l'utilisateur les remplit, ou les agents les alimentent au fil des
            # phases via le reversement automatique.
            steering=dict(steering_templates()),
        )
        session.add(project)
        await session.flush()
        await session.refresh(project)
        return ProjectOut.model_validate(project)


@router.get("", response_model=list[ProjectOut])
async def list_projects(principal: Principal = Depends(current_principal)) -> list[ProjectOut]:
    async with tenant_session(principal.tenant.id) as session:
        rows = (
            await session.execute(
                select(Project)
                .where(Project.archived.is_(False))
                .order_by(Project.created_at.desc())
            )
        ).scalars().all()
    return [ProjectOut.model_validate(p) for p in rows]


@router.get("/{project_id}", response_model=ProjectOut)
async def get_project(
    project_id: uuid.UUID, principal: Principal = Depends(current_principal)
) -> ProjectOut:
    async with tenant_session(principal.tenant.id) as session:
        project = await session.get(Project, project_id)
        if project is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Projet introuvable")
        return ProjectOut.model_validate(project)


@router.put("/{project_id}/steering", response_model=ProjectOut)
async def update_steering(
    project_id: uuid.UUID,
    body: SteeringUpdate,
    principal: Principal = Depends(require_role(MemberRole.contributor)),
) -> ProjectOut:
    """Le steering est la mémoire permanente du projet : les agents le lisent à chaque
    run et y reversent leurs décisions à la validation des gates."""
    async with tenant_session(principal.tenant.id) as session:
        project = await session.get(Project, project_id)
        if project is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Projet introuvable")
        steering = dict(project.steering or {})
        for field, value in body.model_dump(exclude_none=True).items():
            steering[field] = value
        project.steering = steering
        await session.flush()
        await session.refresh(project)
        return ProjectOut.model_validate(project)


@router.get("/{project_id}/artifacts", response_model=list[ArtifactOut])
async def list_artifacts(
    project_id: uuid.UUID, principal: Principal = Depends(current_principal)
) -> list[ArtifactOut]:
    async with tenant_session(principal.tenant.id) as session:
        rows = (
            await session.execute(
                select(Artifact)
                .where(Artifact.project_id == project_id)
                .order_by(Artifact.created_at.desc())
            )
        ).scalars().all()
    return [ArtifactOut.model_validate(a) for a in rows]


@router.get("/{project_id}/artifacts/{artifact_id}/content")
async def get_artifact_content(
    project_id: uuid.UUID,
    artifact_id: uuid.UUID,
    principal: Principal = Depends(current_principal),
) -> dict[str, Any]:
    async with tenant_session(principal.tenant.id) as session:
        artifact = await session.get(Artifact, artifact_id)
        if artifact is None or artifact.project_id != project_id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Artefact introuvable")
        key = artifact.s3_key
        meta = ArtifactOut.model_validate(artifact).model_dump()
    content = await storage.get_text(key)
    return {**meta, "content": content}


@router.get("/{project_id}/export")
async def export_workspace(
    project_id: uuid.UUID, principal: Principal = Depends(current_principal)
) -> StreamingResponse:
    """Télécharge tout le workspace du projet en une archive ZIP.

    Reproduit l'arborescence du kit — `steering/`, `docs/cadrage/`, `docs/specs/`,
    `docs/plans/`, `docs/estimates/` — pour que le livrable soit directement
    réutilisable dans un dépôt Git ou avec le kit Copilot.
    """
    async with tenant_session(principal.tenant.id) as session:
        project = await session.get(Project, project_id)
        if project is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Projet introuvable")
        artifacts = (
            await session.execute(
                select(Artifact)
                .where(Artifact.project_id == project_id)
                .order_by(Artifact.kind, Artifact.created_at.desc())
            )
        ).scalars().all()
        project_slug = project.slug
        steering = dict(project.steering or {})
        entries = [(a.kind.value, a.version, a.s3_key) for a in artifacts]

    # Une seule version par type de livrable : la plus récente.
    latest: dict[str, tuple[str, str]] = {}
    for kind, version, key in entries:
        latest.setdefault(kind, (version, key))

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in steering.items():
            if content:
                archive.writestr(f"{project_slug}/steering/{name}.md", content)

        folders = {
            "cadrage": "docs/cadrage", "spec": "docs/specs", "plan": "docs/plans",
            "tasks": "docs/plans", "estimation": "docs/estimates", "revue": "docs/reviews",
        }
        for kind, (version, key) in latest.items():
            try:
                content = await storage.get_text(key)
            except Exception:  # noqa: BLE001 — un objet manquant ne doit pas casser l'export
                continue
            folder = folders.get(kind, "docs")
            archive.writestr(f"{project_slug}/{folder}/{kind}-{version}.md", content)

        archive.writestr(
            f"{project_slug}/README.md",
            f"# {project_slug}\n\nWorkspace exporté depuis Cadrage SaaS le "
            f"{datetime.now(timezone.utc):%d/%m/%Y}.\n\n"
            f"Contient le steering du projet et la dernière version de chaque livrable.\n",
        )

    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{project_slug}-workspace.zip"'},
    )


@router.get("/{project_id}/artifacts/{artifact_id}/download")
async def download_artifact(
    project_id: uuid.UUID,
    artifact_id: uuid.UUID,
    principal: Principal = Depends(current_principal),
) -> dict[str, str]:
    """URL présignée courte : le navigateur télécharge sans transiter par l'API."""
    async with tenant_session(principal.tenant.id) as session:
        artifact = await session.get(Artifact, artifact_id)
        if artifact is None or artifact.project_id != project_id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Artefact introuvable")
        key = artifact.s3_key
    return {"url": await storage.presign_download(key)}
