"""Organisations : création, membres, invitations."""
from __future__ import annotations

import re
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select

from app.api.deps import Principal, current_principal, current_user, require_role
from app.db.models import Membership, MemberRole, Plan, Tenant, User
from app.db.session import system_session, tenant_session
from app.services import quota

router = APIRouter(tags=["tenants"])


class TenantCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)


class TenantOut(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    plan: Plan
    subscription_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class MemberOut(BaseModel):
    user_id: uuid.UUID
    email: str
    full_name: str | None
    role: MemberRole


class InviteRequest(BaseModel):
    email: EmailStr
    role: MemberRole = MemberRole.contributor


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower().strip()).strip("-")
    return slug[:70] or uuid.uuid4().hex[:8]


@router.post("/tenants", response_model=TenantOut, status_code=status.HTTP_201_CREATED)
async def create_tenant(body: TenantCreate, user: User = Depends(current_user)) -> TenantOut:
    """Crée une organisation ; le créateur en devient propriétaire.

    Hors contexte tenant (le tenant n'existe pas encore) : c'est l'un des rares
    endroits légitimes pour `system_session`.
    """
    slug = slugify(body.name)
    async with system_session() as session:
        exists = await session.scalar(select(Tenant.id).where(Tenant.slug == slug))
        if exists:
            slug = f"{slug}-{uuid.uuid4().hex[:6]}"

        tenant = Tenant(name=body.name, slug=slug, plan=Plan.free)
        session.add(tenant)
        await session.flush()

        session.add(
            Membership(tenant_id=tenant.id, user_id=user.id, role=MemberRole.owner)
        )
        await session.flush()
        await session.refresh(tenant)
        return TenantOut.model_validate(tenant)


@router.get("/tenants", response_model=list[TenantOut])
async def my_tenants(user: User = Depends(current_user)) -> list[TenantOut]:
    """Organisations auxquelles l'utilisateur appartient (sélecteur de l'UI)."""
    async with system_session() as session:
        rows = (
            await session.execute(
                select(Tenant)
                .join(Membership, Membership.tenant_id == Tenant.id)
                .where(Membership.user_id == user.id)
                .order_by(Tenant.created_at)
            )
        ).scalars().all()
    return [TenantOut.model_validate(t) for t in rows]


@router.get("/{tenant_slug}/members", response_model=list[MemberOut])
async def list_members(principal: Principal = Depends(current_principal)) -> list[MemberOut]:
    async with tenant_session(principal.tenant.id) as session:
        rows = (
            await session.execute(
                select(Membership, User).join(User, User.id == Membership.user_id)
            )
        ).all()
    return [
        MemberOut(
            user_id=user.id, email=user.email, full_name=user.full_name, role=membership.role
        )
        for membership, user in rows
    ]


@router.post("/{tenant_slug}/members", response_model=MemberOut, status_code=201)
async def invite_member(
    body: InviteRequest, principal: Principal = Depends(require_role(MemberRole.admin))
) -> MemberOut:
    """Ajoute un membre. L'utilisateur doit déjà exister (il se crée à sa première
    connexion Cognito) ; sinon on renvoie 404 plutôt que de créer un compte fantôme."""
    limits = quota.limits_for(principal.tenant)
    async with tenant_session(principal.tenant.id) as session:
        current = len(
            (await session.execute(select(Membership.id))).scalars().all()
        )
        if current >= limits.seats:
            raise HTTPException(
                status.HTTP_402_PAYMENT_REQUIRED,
                detail={"quota": "sièges", "used": current, "limit": limits.seats},
            )

    async with system_session() as session:
        user = (
            await session.execute(select(User).where(User.email == body.email))
        ).scalar_one_or_none()
        if user is None:
            raise HTTPException(
                status.HTTP_404_NOT_FOUND,
                "Cet utilisateur n'a pas encore de compte : demandez-lui de se connecter une fois.",
            )
        existing = await session.scalar(
            select(Membership.id).where(
                Membership.tenant_id == principal.tenant.id, Membership.user_id == user.id
            )
        )
        if existing:
            raise HTTPException(status.HTTP_409_CONFLICT, "Déjà membre")

        session.add(
            Membership(tenant_id=principal.tenant.id, user_id=user.id, role=body.role)
        )
    return MemberOut(
        user_id=user.id, email=user.email, full_name=user.full_name, role=body.role
    )
