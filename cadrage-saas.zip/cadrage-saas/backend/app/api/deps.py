"""Dépendances FastAPI : authentification, résolution du tenant, contrôle des rôles.

Le `tenant_id` n'est JAMAIS lu depuis le corps ou la query d'une requête : il est
dérivé du JWT et de l'appartenance en base. Un utilisateur ne peut donc pas viser
le tenant d'un autre en manipulant une requête.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from functools import lru_cache

import httpx
from fastapi import Depends, Header, HTTPException, Path, status
from jose import jwt
from jose.exceptions import JWTError
from sqlalchemy import select

from app.config import settings
from app.db.models import Membership, MemberRole, Tenant, User
from app.db.session import system_session

ROLE_ORDER = {
    MemberRole.viewer: 0,
    MemberRole.contributor: 1,
    MemberRole.admin: 2,
    MemberRole.owner: 3,
}


@dataclass(slots=True)
class Principal:
    """Identité effective d'une requête : qui, dans quel tenant, avec quel rôle."""

    user: User
    tenant: Tenant
    role: MemberRole

    def can(self, minimum: MemberRole) -> bool:
        return ROLE_ORDER[self.role] >= ROLE_ORDER[minimum]


@lru_cache(maxsize=1)
def _jwks_url() -> str:
    return (
        f"https://cognito-idp.{settings.aws_region}.amazonaws.com/"
        f"{settings.cognito_user_pool_id}/.well-known/jwks.json"
    )


_jwks_cache: dict | None = None


async def _get_jwks() -> dict:
    global _jwks_cache
    if _jwks_cache is None:
        async with httpx.AsyncClient(timeout=5) as client:
            response = await client.get(_jwks_url())
            response.raise_for_status()
            _jwks_cache = response.json()
    return _jwks_cache


async def _decode(token: str) -> dict:
    if settings.is_local and not settings.cognito_user_pool_id:
        # Mode développement : jeton signé localement, jamais accepté hors `local`.
        return jwt.decode(token, settings.jwt_secret_dev, algorithms=["HS256"])
    jwks = await _get_jwks()
    return jwt.decode(
        token,
        jwks,
        algorithms=["RS256"],
        audience=settings.cognito_client_id,
        options={"verify_at_hash": False},
    )


async def current_user(authorization: str = Header(...)) -> User:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "En-tête Authorization invalide")
    token = authorization.split(" ", 1)[1]

    try:
        claims = await _decode(token)
    except JWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Jeton invalide") from exc

    sub = claims.get("sub")
    async with system_session() as session:
        user = (
            await session.execute(select(User).where(User.cognito_sub == sub))
        ).scalar_one_or_none()
        if user is None:
            # Premier accès : provisionnement à la volée depuis les claims Cognito.
            user = User(
                cognito_sub=sub,
                email=claims.get("email", f"{sub}@unknown.local"),
                full_name=claims.get("name"),
                locale=claims.get("locale", "fr"),
            )
            session.add(user)
            await session.flush()
            await session.refresh(user)
    return user


async def current_principal(
    tenant_slug: str = Path(..., description="Identifiant d'organisation"),
    user: User = Depends(current_user),
) -> Principal:
    """Résout le tenant et vérifie l'appartenance. 404 si non membre — jamais 403 :
    on n'indique pas à un tiers qu'une organisation existe."""
    async with system_session() as session:
        tenant = (
            await session.execute(select(Tenant).where(Tenant.slug == tenant_slug))
        ).scalar_one_or_none()
        if tenant is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Organisation introuvable")

        membership = (
            await session.execute(
                select(Membership).where(
                    Membership.tenant_id == tenant.id, Membership.user_id == user.id
                )
            )
        ).scalar_one_or_none()
        if membership is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Organisation introuvable")

    return Principal(user=user, tenant=tenant, role=membership.role)


def require_role(minimum: MemberRole):
    """Garde de rôle : `Depends(require_role(MemberRole.admin))`."""

    async def _guard(principal: Principal = Depends(current_principal)) -> Principal:
        if not principal.can(minimum):
            raise HTTPException(
                status.HTTP_403_FORBIDDEN,
                f"Rôle {minimum.value} requis (vous êtes {principal.role.value})",
            )
        return principal

    return _guard


def parse_uuid(value: str, label: str = "identifiant") -> uuid.UUID:
    try:
        return uuid.UUID(value)
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"{label} invalide") from exc
