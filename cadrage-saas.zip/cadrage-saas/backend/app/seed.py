"""Amorçage : charge les prompts du kit en base et crée un tenant de démonstration.

    python -m app.seed
"""
from __future__ import annotations

import asyncio
import logging
import uuid

from sqlalchemy import select

from app.agents.kit_loader import AGENT_FILES, load_agent
from app.db.models import AgentPrompt, Membership, MemberRole, Plan, Project, Tenant, User
from app.db.session import system_session, tenant_session

logging.basicConfig(level=logging.INFO, format="%(levelname)s — %(message)s")
logger = logging.getLogger("seed")


async def seed_prompts() -> int:
    """Publie en base une copie de référence des agents du kit (idempotent).

    Les fichiers de `kit/` restent la source de vérité ; cette copie sert à
    l'historique et aux surcharges par tenant.
    """
    created = 0
    async with system_session() as session:
        for agent in AGENT_FILES:
            body = load_agent(agent).body
            exists = await session.scalar(
                select(AgentPrompt.id).where(
                    AgentPrompt.agent == agent,
                    AgentPrompt.version == 1,
                    AgentPrompt.tenant_id.is_(None),
                )
            )
            if exists:
                continue
            session.add(AgentPrompt(agent=agent, version=1, is_active=True, body=body))
            created += 1
    return created


async def seed_demo_tenant() -> uuid.UUID | None:
    async with system_session() as session:
        existing = await session.scalar(select(Tenant).where(Tenant.slug == "demo"))
        if existing:
            logger.info("Tenant de démonstration déjà présent")
            return existing.id

        user = User(
            cognito_sub=f"local-{uuid.uuid4().hex[:12]}",
            email="demo@cadrage.local",
            full_name="Utilisateur de démonstration",
        )
        tenant = Tenant(name="Organisation de démonstration", slug="demo", plan=Plan.pro)
        session.add_all([user, tenant])
        await session.flush()

        session.add(Membership(tenant_id=tenant.id, user_id=user.id, role=MemberRole.owner))
        await session.flush()
        tenant_id, user_id = tenant.id, user.id

    async with tenant_session(tenant_id) as session:
        session.add(
            Project(
                tenant_id=tenant_id,
                created_by=user_id,
                name="Projet de démonstration",
                slug="projet-demo",
                description="Projet vide pour éprouver le pipeline de cadrage.",
                steering={"product": "", "tech": "", "structure": ""},
            )
        )
    return tenant_id


async def main() -> None:
    prompts = await seed_prompts()
    tenant_id = await seed_demo_tenant()
    logger.info("%d prompts publiés · tenant de démonstration : %s", prompts, tenant_id)


if __name__ == "__main__":
    asyncio.run(main())
