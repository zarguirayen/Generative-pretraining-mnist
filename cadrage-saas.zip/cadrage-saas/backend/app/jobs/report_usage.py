"""Tâche planifiée : remontée de la consommation vers Stripe.

Exécutée toutes les heures par EventBridge (voir infra/lib/api-stack.ts).
Idempotente : les événements déjà remontés sont ignorés, un incident réseau
n'entraîne donc ni perte ni double facturation.
"""
from __future__ import annotations

import asyncio
import logging
import sys

from app.core.observability import configure_tracing
from app.services.billing import report_usage_to_stripe

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s — %(message)s")
logger = logging.getLogger("jobs.report_usage")


async def main() -> int:
    configure_tracing()
    try:
        count = await report_usage_to_stripe()
        logger.info("%d événements de consommation remontés à Stripe", count)
        return 0
    except Exception:
        logger.exception("Échec de la remontée d'usage")
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
