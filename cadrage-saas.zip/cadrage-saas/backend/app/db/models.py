"""Modèle de données multi-tenant.

Toute table métier porte `tenant_id` et est protégée par une politique RLS
(voir la migration `0001_initial`). Le `tenant_id` n'est jamais accepté depuis
une requête HTTP : il est dérivé du JWT et posé dans le contexte de session.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _uuid() -> uuid.UUID:
    return uuid.uuid4()


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, onupdate=_now
    )


# ─────────────────────────────────────────────────────────────────────
# Énumérations métier — reprises du kit de cadrage
# ─────────────────────────────────────────────────────────────────────
class Plan(str, enum.Enum):
    free = "free"
    pro = "pro"
    enterprise = "enterprise"


class MemberRole(str, enum.Enum):
    owner = "owner"          # facturation + suppression du tenant
    admin = "admin"          # gestion des membres et des projets
    contributor = "contributor"  # lance des runs, valide les gates
    viewer = "viewer"        # lecture seule


class Phase(str, enum.Enum):
    orchestration = "orchestration"
    cadrage = "cadrage"
    specification = "specification"
    plan = "plan"
    estimation = "estimation"
    revue = "revue"


class RunStatus(str, enum.Enum):
    pending = "pending"
    running = "running"
    waiting_human = "waiting_human"   # interrupt() LangGraph
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


class GateDecision(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    changes_requested = "changes_requested"
    rejected = "rejected"


class ArtifactKind(str, enum.Enum):
    cadrage = "cadrage"
    spec = "spec"
    plan = "plan"
    tasks = "tasks"
    estimation = "estimation"
    revue = "revue"
    steering = "steering"


# ─────────────────────────────────────────────────────────────────────
# Tenants et utilisateurs
# ─────────────────────────────────────────────────────────────────────
class Tenant(Base, TimestampMixin):
    """Organisation cliente. Racine de l'isolation."""

    __tablename__ = "tenants"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(200))
    slug: Mapped[str] = mapped_column(String(80), unique=True, index=True)

    plan: Mapped[Plan] = mapped_column(Enum(Plan, name="plan_enum"), default=Plan.free)
    stripe_customer_id: Mapped[str | None] = mapped_column(String(80), unique=True)
    stripe_subscription_id: Mapped[str | None] = mapped_column(String(80))
    subscription_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Quotas résolus du plan, surchargeables par tenant (négociation entreprise)
    quota_overrides: Mapped[dict] = mapped_column(JSON, default=dict)

    # Réglages hérités du kit : langue des livrables, constitution du tenant
    settings: Mapped[dict] = mapped_column(JSON, default=dict)

    members: Mapped[list[Membership]] = relationship(back_populates="tenant")
    projects: Mapped[list[Project]] = relationship(back_populates="tenant")


class User(Base, TimestampMixin):
    """Identité globale (une personne peut appartenir à plusieurs tenants)."""

    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    cognito_sub: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    full_name: Mapped[str | None] = mapped_column(String(200))
    locale: Mapped[str] = mapped_column(String(8), default="fr")


class Membership(Base, TimestampMixin):
    """Appartenance d'un utilisateur à un tenant, avec son rôle."""

    __tablename__ = "memberships"
    __table_args__ = (UniqueConstraint("tenant_id", "user_id", name="uq_membership"),)

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    role: Mapped[MemberRole] = mapped_column(
        Enum(MemberRole, name="member_role_enum"), default=MemberRole.contributor
    )

    tenant: Mapped[Tenant] = relationship(back_populates="members")
    user: Mapped[User] = relationship()


# ─────────────────────────────────────────────────────────────────────
# Projets et exécutions
# ─────────────────────────────────────────────────────────────────────
class Project(Base, TimestampMixin):
    """Un projet = un workspace du kit (steering + docs/)."""

    __tablename__ = "projects"
    __table_args__ = (
        UniqueConstraint("tenant_id", "slug", name="uq_project_slug"),
        Index("ix_projects_tenant", "tenant_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE")
    )
    created_by: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("users.id"))

    name: Mapped[str] = mapped_column(String(200))
    slug: Mapped[str] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(Text)

    # Niveau d'échelle 0-4 du kit ; détermine la profondeur du pipeline
    scale_level: Mapped[int] = mapped_column(Integer, default=2)
    scenario: Mapped[str] = mapped_column(String(32), default="greenfield")

    # Steering du projet (product/tech/structure) — miroir indexable de S3
    steering: Mapped[dict] = mapped_column(JSON, default=dict)
    archived: Mapped[bool] = mapped_column(Boolean, default=False)

    tenant: Mapped[Tenant] = relationship(back_populates="projects")
    runs: Mapped[list[Run]] = relationship(back_populates="project")


class Run(Base, TimestampMixin):
    """Une exécution du graphe d'agents sur un projet."""

    __tablename__ = "runs"
    __table_args__ = (Index("ix_runs_tenant_project", "tenant_id", "project_id"),)

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE")
    )
    project_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE")
    )
    started_by: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("users.id"))

    # thread_id du checkpointer LangGraph : c'est lui qui porte la reprise
    thread_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    entry_phase: Mapped[Phase] = mapped_column(Enum(Phase, name="phase_enum"))
    current_phase: Mapped[Phase] = mapped_column(Enum(Phase, name="phase_enum"))
    status: Mapped[RunStatus] = mapped_column(
        Enum(RunStatus, name="run_status_enum"), default=RunStatus.pending
    )

    initial_prompt: Mapped[str] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)

    # Code soumis pour une revue ou une correction de bug : { "chemin": "contenu" }.
    # Les agents de revue ne travaillent que sur ce contenu.
    code_context: Mapped[dict] = mapped_column(JSON, default=dict)
    review_scope: Mapped[str] = mapped_column(String(16), default="diff")

    # Session AgentCore (prod) et trace LangSmith, pour le support
    agentcore_session_id: Mapped[str | None] = mapped_column(String(128))
    langsmith_run_url: Mapped[str | None] = mapped_column(Text)

    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    project: Mapped[Project] = relationship(back_populates="runs")
    gates: Mapped[list[Gate]] = relationship(back_populates="run")
    messages: Mapped[list[RunMessage]] = relationship(back_populates="run")


class RunMessage(Base):
    """Journal conversationnel d'un run (streamé à l'UI)."""

    __tablename__ = "run_messages"
    __table_args__ = (Index("ix_run_messages_run", "run_id", "seq"),)

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("tenants.id"))
    run_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("runs.id", ondelete="CASCADE")
    )
    seq: Mapped[int] = mapped_column(Integer)
    role: Mapped[str] = mapped_column(String(24))       # agent | user | system
    agent: Mapped[str | None] = mapped_column(String(48))  # cadrage, elicitateur…
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    run: Mapped[Run] = relationship(back_populates="messages")


class Gate(Base, TimestampMixin):
    """Point d'arrêt de validation humaine (interrupt LangGraph)."""

    __tablename__ = "gates"
    __table_args__ = (Index("ix_gates_run", "run_id", "created_at"),)

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("tenants.id"))
    run_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("runs.id", ondelete="CASCADE")
    )

    phase: Mapped[Phase] = mapped_column(Enum(Phase, name="phase_enum"))
    title: Mapped[str] = mapped_column(String(300))
    # Critères de sortie du kit : [{"label": ..., "ok": bool, "evidence": ...}]
    checklist: Mapped[list] = mapped_column(JSON, default=list)
    summary: Mapped[str] = mapped_column(Text)
    artifact_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True))

    decision: Mapped[GateDecision] = mapped_column(
        Enum(GateDecision, name="gate_decision_enum"), default=GateDecision.pending
    )
    decided_by: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True), ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    feedback: Mapped[str | None] = mapped_column(Text)

    run: Mapped[Run] = relationship(back_populates="gates")


class Artifact(Base, TimestampMixin):
    """Livrable markdown versionné (le contenu vit dans S3)."""

    __tablename__ = "artifacts"
    __table_args__ = (
        UniqueConstraint("project_id", "kind", "version", name="uq_artifact_version"),
        Index("ix_artifacts_tenant_project", "tenant_id", "project_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("tenants.id"))
    project_id: Mapped[uuid.UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE")
    )
    run_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True), ForeignKey("runs.id"))

    kind: Mapped[ArtifactKind] = mapped_column(Enum(ArtifactKind, name="artifact_kind_enum"))
    title: Mapped[str] = mapped_column(String(300))
    version: Mapped[str] = mapped_column(String(16))        # v0.1, v1.0…
    status: Mapped[str] = mapped_column(String(24), default="brouillon")
    s3_key: Mapped[str] = mapped_column(String(512))
    checksum: Mapped[str] = mapped_column(String(64))
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)


# ─────────────────────────────────────────────────────────────────────
# Prompts (le kit, versionné en base) et usage
# ─────────────────────────────────────────────────────────────────────
class AgentPrompt(Base, TimestampMixin):
    """Corps d'un agent du kit. Permet de faire évoluer la méthode sans redéployer."""

    __tablename__ = "agent_prompts"
    __table_args__ = (UniqueConstraint("agent", "version", name="uq_agent_prompt_version"),)

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    agent: Mapped[str] = mapped_column(String(48), index=True)   # cadrage, elicitateur…
    version: Mapped[int] = mapped_column(Integer, default=1)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    body: Mapped[str] = mapped_column(Text)
    # Surcharge possible par tenant (méthode maison) — NULL = prompt global
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True), ForeignKey("tenants.id"))


class UsageEvent(Base):
    """Consommation facturable. Source de vérité : Stripe n'est qu'un miroir."""

    __tablename__ = "usage_events"
    __table_args__ = (
        Index("ix_usage_tenant_time", "tenant_id", "occurred_at"),
        UniqueConstraint("idempotency_key", name="uq_usage_idem"),
    )

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("tenants.id"))
    run_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True), ForeignKey("runs.id"))

    agent: Mapped[str] = mapped_column(String(48))
    model_id: Mapped[str] = mapped_column(String(120))
    input_tokens: Mapped[int] = mapped_column(BigInteger, default=0)
    output_tokens: Mapped[int] = mapped_column(BigInteger, default=0)
    cost_cents: Mapped[int] = mapped_column(Integer, default=0)   # prix client, pas coût AWS

    idempotency_key: Mapped[str] = mapped_column(String(128))
    reported_to_stripe: Mapped[bool] = mapped_column(Boolean, default=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class AuditLog(Base):
    """Trace immuable des décisions sensibles (validations, changements de plan)."""

    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_tenant_time", "tenant_id", "occurred_at"),)

    id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=_uuid)
    tenant_id: Mapped[uuid.UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("tenants.id"))
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(PGUUID(as_uuid=True))
    action: Mapped[str] = mapped_column(String(64))     # gate.approved, plan.changed…
    target_type: Mapped[str] = mapped_column(String(48))
    target_id: Mapped[str] = mapped_column(String(64))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
