"""Sessions SQLAlchemy avec contexte de tenant (Row-Level Security).

Règle : **aucune** requête métier ne s'exécute hors d'un contexte tenant.
`tenant_session()` pose `app.tenant_id` sur la connexion ; les politiques RLS
définies dans la migration initiale filtrent alors toutes les tables.

Le rôle applicatif ne possède pas les tables et n'a pas BYPASSRLS : un oubli de
filtre `WHERE tenant_id = ...` dans le code ne peut donc pas provoquer de fuite.
"""
from __future__ import annotations

import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import settings

engine = create_async_engine(
    str(settings.database_url),
    pool_size=settings.db_pool_size,
    max_overflow=settings.db_max_overflow,
    pool_pre_ping=True,
    echo=settings.is_local,
)

SessionFactory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


@asynccontextmanager
async def tenant_session(tenant_id: uuid.UUID) -> AsyncIterator[AsyncSession]:
    """Session applicative scopée à un tenant. À utiliser partout côté métier."""
    async with SessionFactory() as session:
        # set_config(..., true) = local à la transaction : pas de fuite entre
        # deux requêtes qui réutilisent la même connexion du pool.
        await session.execute(
            text("SELECT set_config('app.tenant_id', :tid, true)"),
            {"tid": str(tenant_id)},
        )
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


@asynccontextmanager
async def system_session() -> AsyncIterator[AsyncSession]:
    """Session sans tenant : réservée à l'inscription, aux webhooks Stripe et aux
    tâches d'agrégation. Les tables concernées (`users`, `tenants`) ne sont pas
    soumises à RLS ; toute autre écriture ici est un défaut de conception."""
    async with SessionFactory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
