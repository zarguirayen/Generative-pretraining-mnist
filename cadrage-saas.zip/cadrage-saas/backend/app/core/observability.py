"""Observabilité LangSmith.

Chaque nœud du graphe et chaque appel Bedrock produisent une trace. Ce qui est
exploité en pratique :
  - le **coût par run et par tenant** (tags `tenant:…`), pour vérifier que la
    tarification couvre le coût réel ;
  - les **runs en échec** et le nœud fautif, pour le support ;
  - les **jeux d'évaluation** : quand un prompt du kit évolue, on rejoue des cadrages
    de référence et on compare les sorties avant de publier la nouvelle version.

Le contenu métier des clients transite par LangSmith : ce point doit figurer dans
le registre des sous-traitants (RGPD) et peut être désactivé par tenant si le
contrat l'exige (`settings.langsmith_tracing`).
"""
from __future__ import annotations

import logging
import os

from app.config import settings

logger = logging.getLogger(__name__)


def configure_tracing() -> None:
    if not (settings.langsmith_tracing and settings.langsmith_api_key):
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
        logger.info("Traçage LangSmith désactivé")
        return

    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_API_KEY"] = settings.langsmith_api_key
    os.environ["LANGCHAIN_PROJECT"] = f"{settings.langsmith_project}-{settings.env}"
    logger.info("Traçage LangSmith actif (projet %s)", os.environ["LANGCHAIN_PROJECT"])


def run_url(run_id: str) -> str | None:
    """Lien direct vers la trace, stocké sur le run pour le support."""
    if not settings.langsmith_tracing:
        return None
    return f"https://smith.langchain.com/o/-/projects/p/{settings.langsmith_project}/r/{run_id}"
