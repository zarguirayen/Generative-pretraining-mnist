"""Tests d'isolation multi-tenant.

Ce sont les tests les plus importants du produit : une fuite entre organisations
est l'incident qui tue un SaaS B2B. Ils vérifient la barrière RLS elle-même, pas
la logique applicative — c'est-à-dire ce qui reste vrai même si une requête oublie
son `WHERE tenant_id = ...`.

Exécution : pytest tests/test_tenant_isolation.py (nécessite Docker pour testcontainers).
"""
from __future__ import annotations

import uuid

import pytest
from sqlalchemy import select, text

from app.db.models import Project, Tenant
from app.db.session import system_session, tenant_session


@pytest.fixture
async def two_tenants() -> tuple[uuid.UUID, uuid.UUID]:
    """Deux organisations avec un projet chacune."""
    async with system_session() as session:
        alpha = Tenant(name="Alpha", slug=f"alpha-{uuid.uuid4().hex[:6]}")
        beta = Tenant(name="Beta", slug=f"beta-{uuid.uuid4().hex[:6]}")
        session.add_all([alpha, beta])
        await session.flush()
        alpha_id, beta_id = alpha.id, beta.id

    for tenant_id, name in ((alpha_id, "Projet Alpha"), (beta_id, "Projet Beta")):
        async with tenant_session(tenant_id) as session:
            session.add(
                Project(
                    tenant_id=tenant_id,
                    created_by=uuid.uuid4(),
                    name=name,
                    slug=name.lower().replace(" ", "-"),
                    steering={},
                )
            )
    return alpha_id, beta_id


async def test_un_tenant_ne_voit_que_ses_projets(two_tenants):
    alpha_id, beta_id = two_tenants

    async with tenant_session(alpha_id) as session:
        projects = (await session.execute(select(Project))).scalars().all()

    assert len(projects) == 1
    assert projects[0].name == "Projet Alpha"
    assert all(p.tenant_id == alpha_id for p in projects)


async def test_requete_sans_filtre_ne_fuit_pas(two_tenants):
    """Le cas qui compte : une requête volontairement non filtrée.

    Sans RLS, `SELECT * FROM projects` renverrait les deux projets. La politique
    doit rendre cette fuite impossible même en cas de bug applicatif.
    """
    alpha_id, _ = two_tenants

    async with tenant_session(alpha_id) as session:
        rows = (await session.execute(text("SELECT id, name FROM projects"))).all()

    assert len(rows) == 1, "Fuite inter-tenant : la politique RLS ne s'applique pas"


async def test_ecriture_pour_un_autre_tenant_est_refusee(two_tenants):
    """Le WITH CHECK de la politique interdit d'écrire au nom d'un autre tenant."""
    alpha_id, beta_id = two_tenants

    with pytest.raises(Exception):  # violation de politique RLS
        async with tenant_session(alpha_id) as session:
            session.add(
                Project(
                    tenant_id=beta_id,  # tentative d'écriture croisée
                    created_by=uuid.uuid4(),
                    name="Injection",
                    slug="injection",
                    steering={},
                )
            )
            await session.flush()


async def test_lecture_croisee_par_identifiant_echoue(two_tenants):
    """Connaître l'UUID d'un projet d'un autre tenant ne donne aucun accès."""
    alpha_id, beta_id = two_tenants

    async with tenant_session(beta_id) as session:
        beta_project = (await session.execute(select(Project))).scalars().one()
        beta_project_id = beta_project.id

    async with tenant_session(alpha_id) as session:
        found = await session.get(Project, beta_project_id)

    assert found is None, "Fuite : un projet d'un autre tenant est accessible par son id"


async def test_session_sans_tenant_ne_voit_rien():
    """Sans `app.tenant_id`, la politique ne matche aucune ligne : échec fermé."""
    async with system_session() as session:
        rows = (await session.execute(text("SELECT id FROM projects"))).all()
    assert rows == [], "Une session sans contexte tenant voit des données"
