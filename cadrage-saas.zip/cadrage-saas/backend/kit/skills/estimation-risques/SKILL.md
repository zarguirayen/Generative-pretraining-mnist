---
name: estimation-risques
description: Identifier et coter les risques et hypothèses d'un projet — matrice probabilité × impact, parades, plan de vérification des hypothèses. À utiliser pendant le cadrage et la planification.
---

# Estimation des risques et hypothèses

## Différence risque / hypothèse

- **Risque** : événement incertain qui, s'il survient, nuit au projet. On le *mitige*.
- **Hypothèse** : croyance non vérifiée dont dépend le projet (« les utilisateurs ont un smartphone récent »). On la *vérifie* — une hypothèse non vérifiée est un risque déguisé.

## Checklist de détection (parcourir chaque famille)

1. **Adoption** : les utilisateurs visés veulent-ils vraiment ce produit ? Qui a validé le besoin, avec quelles données ?
2. **Parties prenantes** : sponsor absent, décideurs multiples, utilisateurs non consultés.
3. **Dépendances externes** : API tierces, fournisseurs, autres équipes, données à obtenir.
4. **Réglementaire et sécurité** : à lever **spontanément dès que le domaine est identifié**, sans attendre une question — c'est souvent le risque le plus coûteux découvert le plus tard. Table domaine → obligations :

   | Domaine détecté | Obligations à signaler d'office |
   |---|---|
   | Santé / médical | HDS (hébergement agréé, France), RGPD données de santé (art. 9), secret médical ; HIPAA si USA |
   | Paiement / e-commerce | PCI-DSS, DSP2/SCA (Europe), droit de rétractation |
   | Mineurs | Consentement parental (RGPD art. 8), COPPA si USA |
   | Finance / crédit | Agréments ACPR/AMF, LCB-FT (anti-blanchiment) |
   | Données personnelles (tout produit) | RGPD : base légale, registre, DPO éventuel, localisation des données |
   | RH / salariés | Consultation CSE, durée de conservation encadrée |

   Toute obligation applicable devient une contrainte réelle du cadrage ; son exclusion du périmètre (ex. « HDS hors scope MVP ») est un **arbitrage à faire valider explicitement**, jamais une omission silencieuse.
5. **Technique** : intégration à l'existant, dette, montée en charge, techno non maîtrisée par l'équipe.
6. **Délais et budget** : échéance imposée, équipe partagée, périmètre instable.

## Cotation

Matrice probabilité × impact, trois niveaux chacun :

| | Impact faible | Impact moyen | Impact élevé |
|---|---|---|---|
| **Prob. élevée** | Surveiller | Traiter | **Traiter en priorité** |
| **Prob. moyenne** | Accepter | Surveiller | Traiter |
| **Prob. faible** | Accepter | Accepter | Surveiller |

## Format de restitution

```markdown
| ID | Risque | Prob. | Impact | Décision | Parade |
|---|---|---|---|---|---|
| R1 | <événement redouté> | élevée | élevé | traiter | <action concrète + responsable> |

| ID | Hypothèse | Si fausse, conséquence | Plan de vérification |
|---|---|---|---|
| H1 | <croyance> | <impact> | <comment et quand on vérifie> |
```

## Règles

- Une parade est une **action concrète** (« prototyper l'intégration X en semaine 1 »), pas un vœu (« faire attention à X »).
- Tout risque « Traiter en priorité » doit apparaître dans les critères de décision go/no-go du cadrage.
- Réévaluer la matrice à chaque phase (cadrage → spec → plan) : le plan doit reprendre les risques techniques et les affiner.
