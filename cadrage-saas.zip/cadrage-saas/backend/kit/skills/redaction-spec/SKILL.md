---
name: redaction-spec
description: Gabarit et règles pour rédiger une spécification formelle à partir d'un document de cadrage — glossaire à vocabulaire contrôlé, user stories, critères d'acceptation au format EARS (THE/WHEN/IF-THEN/WHERE/WHILE + SHALL), valeurs par défaut chiffrées, marqueurs de clarification. À utiliser pour toute rédaction ou revue de spec.
---

# Rédaction de spécification

## Structure du document

```markdown
# Spécification — <Nom du projet>

| Champ | Valeur |
|---|---|
| Date | JJ/MM/AAAA |
| Statut | brouillon / en revue / validée |
| Cadrage source | docs/cadrage/<slug>-cadrage.md |

## 1. Introduction
<3 à 5 phrases : ce que fait le système, pour qui, et le bénéfice attendu.>

## 2. Glossaire
- **Système** : <le produit spécifié>
- **<Rôle>** : <définition + permissions>
- **<Entité>** : <définition ; attributs clés>
- **<État>** : énumération fermée, ex. : `À faire`, `En cours`, `Terminée`

## 3. Exigences fonctionnelles

### EF-001 : <Titre de la capacité> → Objectif O1

**User Story :** En tant que <Rôle>, je veux <action>, afin de <bénéfice>.

#### Critères d'acceptation
1. THE Système SHALL <comportement permanent, chiffré>.
2. WHEN <événement>, THE Système SHALL <réaction> [dans un délai de <n> secondes].
3. IF <condition d'erreur>, THEN THE Système SHALL <traitement du cas dégradé>.
4. WHERE <fonctionnalité optionnelle activée>, THE Système SHALL <comportement>.

## 4. Invariants métier
<Règles universelles qui doivent tenir à tout instant, quelle que soit l'opération — ex. « solde alloué = utilisé + en attente + restant ». Chaque invariant référence les EF concernées ; le plan en dérivera des tests de propriété.>
- **INV-001** — <invariant> → EF-003, EF-005

## 5. Exigences non fonctionnelles
- **ENF-001** — <exigence chiffrée : latence, dispo, volumétrie, accessibilité, sécurité> → Objectif O2

## 6. Clarifications
<Ouvertes : `[BESOIN DE CLARIFICATION : question]` — Résolues : question → réponse → date.>
```

## Le format EARS (obligatoire pour les critères d'acceptation)

| Motif | Syntaxe | Usage |
|---|---|---|
| Permanent | `THE <Système> SHALL <comportement>` | comportement toujours vrai |
| Événementiel | `WHEN <événement>, THE <Système> SHALL <réaction>` | réponse à un déclencheur |
| Cas indésirable | `IF <condition d'erreur>, THEN THE <Système> SHALL <traitement>` | erreurs, défaillances, abus |
| Optionnel | `WHERE <fonctionnalité activée>, THE <Système> SHALL <comportement>` | variantes de configuration |
| D'état | `WHILE <état>, THE <Système> SHALL <comportement>` | comportement pendant un état |

Un critère = une seule phrase EARS, testable isolément.

## Règles de rédaction

1. **Testable ou rien** : « l'interface doit être intuitive » est refusé ; « WHEN un nouvel Utilisateur démarre l'inscription, THE Système SHALL lui permettre de la terminer en moins de 3 minutes sans aide » est accepté.
2. **Défauts chiffrés plutôt que flou** : toute valeur paramétrique (délai, seuil, limite, durée de validité) reçoit une valeur par défaut précise, tracée dans le journal des hypothèses du cadrage. On ne demande pas à l'utilisateur « quel délai ? » — on propose « ≤ 2 secondes » qu'il peut corriger.
3. **Vocabulaire contrôlé** : chaque terme métier est défini une fois dans le Glossaire (capitalisé, énumérations fermées pour les états/rôles/niveaux) et réutilisé à l'identique. Un critère qui emploie un terme hors glossaire est un défaut.
4. **Quoi, pas comment** : aucun nom de framework, de table SQL ou de classe. Si un détail technique semble indispensable, c'est une contrainte à remonter au cadrage ou un élément du plan.
5. **Jamais deviner sur le périmètre** : une ambiguïté de périmètre devient `[BESOIN DE CLARIFICATION : <question précise>]`, posée par lots de 5 questions fermées maximum avec option recommandée. (Les ambiguïtés paramétriques, elles, reçoivent un défaut chiffré — règle 2.)
6. **Chaque EF couvre ses cas dégradés** : au moins un critère `IF/THEN` par exigence fonctionnelle (entrée invalide, ressource expirée, service indisponible, action sur un objet clos) et les règles de cycle de vie (suppression, départ d'un utilisateur, conservation de l'historique).
7. **Traçabilité** : chaque EF/ENF référence un objectif du cadrage (`→ O2`). Une exigence sans objectif parent est soit supprimée, soit le cadrage est mis à jour d'abord.
8. **Numérotation stable** : ne jamais renuméroter ; une exigence supprimée est marquée `[SUPPRIMÉE — <raison>]`.

## Checklist de validation avant handoff vers le plan

- [ ] Zéro marqueur `[BESOIN DE CLARIFICATION]`
- [ ] Chaque EF a une User Story et des critères EARS numérotés
- [ ] Chaque EF a au moins un critère de cas dégradé (IF/THEN)
- [ ] Toutes les valeurs paramétriques sont chiffrées
- [ ] Les invariants métier (règles vraies à tout instant) sont identifiés dans la section Invariants et tracés vers les EF
- [ ] Tous les termes métier sont dans le Glossaire et utilisés à l'identique
- [ ] Chaque exigence tracée vers un objectif
- [ ] Aucune décision d'implémentation
- [ ] Conforme à `.specify/memory/constitution.md`
