---
name: interview-cadrage
description: Méthode de cadrage « brouillon d'abord » pour clarifier un projet ou une fonctionnalité — triage fermé, brouillon complet avec hypothèses par défaut chiffrées, lots de questions fermées orientées périmètre, MoSCoW. À utiliser dès qu'il faut clarifier un besoin flou avant de spécifier ou coder.
---

# Cadrage « brouillon d'abord »

## Principes

1. **Brouillon d'abord, questions ensuite** : produire immédiatement un document de cadrage complet à partir d'hypothèses par défaut plausibles, puis faire réagir l'utilisateur. Critiquer du concret demande moins d'effort que répondre à un interrogatoire, et les hypothèses écrites noir sur blanc font émerger les désaccords.
2. **Questions fermées avec recommandation** : chaque question propose des options, dont une marquée **(Recommandé)** avec une ligne de justification. Jamais plus de 5 questions par lot, jamais de question ouverte sauf pour le problème initial.
3. **Paramètres = défauts chiffrés, jamais de questions** : les seuils, délais et limites reçoivent une valeur par défaut précise (« ≤ 2 s », « 5 tentatives », « 48 h ») consignée comme hypothèse `[défaut]`. Les questions ne portent que sur le **périmètre** (quoi inclure/exclure), pas sur les paramètres.
4. **Vocabulaire contrôlé** : construire un Glossaire (termes capitalisés, énumérations fermées pour les états/rôles/niveaux) et réutiliser ces termes à l'identique dans tout le document. Un concept = un mot.
5. **Le cadrage explore le problème, jamais la solution** : toute solution proposée est qualifiée par une question fermée (« contrainte ferme ou préférence ? ») — contrainte ferme → section Contraintes ; préférence → « Pistes de solution évoquées ». Dans les deux cas on remonte au problème qu'elle résout.
6. **Mobiliser la connaissance du domaine** : le brouillon s'enrichit d'office des concepts standards du métier concerné (ex. pour des congés : types de congés usuels, jours ouvrés hors fériés, délégation de validation, justificatifs). L'utilisateur confirme une liste proposée plutôt que de la produire lui-même (« cette liste vous convient-elle ? »).
7. **Tolérance au « je ne sais pas »** : ne jamais bloquer sur l'ignorance de l'utilisateur. Convertir la question ouverte en options concrètes reconnaissables (exemples vécus plutôt que concepts), et si l'utilisateur ne sait toujours pas, le dire explicitement (« c'est OK ») et poser l'hypothèse la plus probable comme `[défaut]` documenté.
8. **Quantifier pour rendre tangible** : traduire toute contrainte abstraite en grandeur concrète avant d'en discuter — « 99,99 % de dispo = 52 min d'indisponibilité/an », « 1 M d'utilisateurs = ~12 requêtes/s en pointe ». Une contrainte quantifiée se négocie ; un pourcentage abstrait s'avale.

## Couverture obligatoire du brouillon

Le brouillon initial doit remplir ces 8 blocs (les manques sont des hypothèses `[défaut]`, pas des trous) :

1. **Problème et contexte** — la douleur actuelle, le coût de l'inaction.
2. **Utilisateurs et rôles** — qui utilise, qui décide ; définir les rôles dans le Glossaire avec leurs permissions respectives.
3. **Objectifs mesurables** — 3 à 5 max, format : *verbe + métrique + valeur actuelle + cible + échéance*.
4. **Périmètre MoSCoW** — Must / Should / Could / Won't ; le hors-périmètre contient au moins 3 exclusions explicites. Question utile : « qu'est-ce que quelqu'un pourrait raisonnablement croire inclus, et qui ne l'est pas ? »
5. **Cas dégradés et cycle de vie** — pour chaque capacité du Must : que se passe-t-il en cas d'erreur de saisie, d'abandon en cours, de suppression, de départ d'un utilisateur, d'indisponibilité d'une dépendance ? Que conserve-t-on (historique, audit) ?
6. **Contraintes** — budget, délai, réglementaire, existant ; distinguer contrainte réelle et préférence.
7. **Risques et hypothèses** — appliquer le skill `estimation-risques` ; chaque hypothèse `[défaut]` structurante y figure avec son plan de confirmation.
8. **Critères de succès** — vérifiables par une personne extérieure, chacun relié à un objectif.

## Cas particulier : périmètre très large (multi-modules)

Quand la demande couvre plusieurs modules ou produits (ex. « un ERP complet : compta, RH, stocks, CRM, facturation, paie ») :

1. **Dimensionner avant de rédiger** : exceptionnellement, poser un lot de dimensionnement AVANT le brouillon (max 6 questions fermées ou chiffrées) — taille de l'organisation, secteur, priorités entre modules, multi-entités, intégrations existantes, utilisateurs simultanés. Si « je ne sais pas » : produire le brouillon quand même avec des défauts `[défaut]` (principe 7).
2. **Phaser obligatoirement** : un périmètre multi-modules ne se livre jamais à plat. Le brouillon propose un découpage en phases avec un ordre **recommandé et justifié** (dépendances + valeur + complexité réglementaire — ex. facturation + compta en phase 1, paie en dernier). Chaque module hors phase 1 va dans Won't avec la mention « phase N ».
3. **Alerter sur le déséquilibre périmètre/capacité** même si aucune contrainte n'est énoncée : estimer l'ordre de grandeur de l'effort total et le confronter à la capacité probable (contrôle de faisabilité de l'agent `cadrage`).

## Le lot de questions d'affinage

Après présentation du brouillon (résumé en 5 lignes max), poser 3 à 5 questions fermées choisies parmi les plus structurantes :
- extensions fonctionnelles limitrophes (ex. commentaires ? pièces jointes ? multi-équipes ?) ;
- plateformes cibles (web / mobile / les deux) ;
- intégrations avec l'existant (SSO, outils tiers) ;
- volumétrie attendue (ordre de grandeur suffisant : 10, 1 000, 100 000 utilisateurs ?).

Format : question courte + options + **(Recommandé)** justifié en une ligne. Intégrer les réponses, marquer les hypothèses confirmées `[validé]`, re-présenter uniquement les deltas.

## Gestion de la dérive de périmètre

Quand l'utilisateur ajoute un besoin en cours de cadrage : le signaler explicitement (« ceci élargit le périmètre initial »), puis proposer trois issues — intégrer au Must (et dire ce que ça coûte), reporter en phase 2 (section Won't avec mention « phase 2 »), ou arbitrer contre un élément existant du Must.

## Mode « cadrage express »

Si l'utilisateur refuse le processus complet, poser uniquement ces 5 questions, puis produire quand même le brouillon complet (les manques deviennent des hypothèses `[défaut]`) avec la mention « cadrage express » :
1. Quel problème, pour qui ?
2. À quoi ressemble le succès, chiffré ?
3. Qu'est-ce qui est explicitement hors périmètre ?
4. Quelle est la contrainte la plus dure (délai, budget, techno) ?
5. Quel est le plus gros risque ?
