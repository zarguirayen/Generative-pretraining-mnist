---
name: correction-bug
description: Méthode de diagnostic et de correction de bug — entonnoir d'interview tolérant au « je ne sais pas », condition formelle du bug, cas de régression à protéger, correction test-first (test d'exploration qui échoue avant, tests de préservation avant correctif). À utiliser pour tout signalement de dysfonctionnement.
---

# Correction de bug

## L'entonnoir de diagnostic

Du symptôme observable vers la condition formelle, un lot de 3-4 questions à la fois, reformulation entre chaque lot :

1. **Symptôme observable** — qu'avez-vous constaté concrètement ? Proposer des options reconnaissables : plainte d'un utilisateur, erreur dans les logs, mauvaise page affichée, test qui échoue, données incorrectes.
2. **Comportement actuel vs attendu** — que se passe-t-il, et que devrait-il se passer ?
3. **Localisation** — quelle partie du système (avec exemples : API, base de données, authentification, interface…) ?
4. **Déclencheur et population** — quand ça arrive (action précise, en permanence, après un délai) et pour qui (tous les utilisateurs, certains rôles, certains contextes) ?
5. **Pattern** — proposer des hypothèses plausibles comme options : paramètre absent/invalide, première utilisation vs habituelle, données incomplètes, provenance particulière, dépendance indisponible. Toujours offrir « je ne sais pas / aléatoire ».

**Tolérance au « je ne sais pas »** : ne jamais bloquer. Formuler explicitement : « c'est OK — je documente le bug de façon générale en ciblant <condition la plus probable d'après ce qui est connu> ». L'ignorance de l'utilisateur se convertit en hypothèse documentée, pas en impasse.

## Gabarit du document de diagnostic (`docs/bugfix/<slug>-bugfix.md`)

```markdown
# Correction de bug — <titre court>

| Champ | Valeur |
|---|---|
| Date | JJ/MM/AAAA |
| Statut | diagnostic / validé / corrigé |

## Condition du bug
<Prédicat formel : `role = "client" AND redirectUrl invalide ou absente`>

## Scénarios défectueux
<Ce qui se passe aujourd'hui, cas par cas.>

## Comportement attendu
<Ce qui devrait se passer pour chaque scénario défectueux.>

## Cas de régression à protéger
<Tout ce qui fonctionne et ne doit pas changer : autres rôles, chemins valides, gestions d'erreur existantes.>

## Hypothèses de diagnostic
<Ce qui a été supposé faute d'information, marqué [défaut].>
```

## La correction test-first (ordre non négociable)

| Étape | Action | Critère de passage |
|---|---|---|
| 1. Test d'exploration | Encoder le comportement attendu dans un test (property-based si logique pure) et l'exécuter sur le code NON corrigé | Le test ÉCHOUE — l'échec prouve le bug. S'il passe, le diagnostic est faux : retour à l'entonnoir |
| 2. Tests de préservation | Capturer le comportement de référence des cas à protéger, exécutés AVANT le correctif | Ils PASSENT sur le code non corrigé — baseline établie |
| 3. Correctif minimal | La plus petite modification qui corrige la condition du bug — pas de refactoring opportuniste | Compile, ciblé sur la condition du bug |
| 4. Vérification croisée | Ré-exécuter exploration puis préservation, puis la suite complète | Exploration passe désormais ; préservation passe toujours ; suite complète verte (rapporter les chiffres) |

## Règles

- La propriété du test d'exploration se dérive de la condition du bug : « pour tout X tel que <condition>, le système DOIT <comportement attendu> ».
- La propriété de préservation globale : « pour tout X tel que NON <condition>, le comportement est inchangé ».
- Ne jamais corriger du code qu'on n'a pas lu ; ne jamais inventer le code manquant — si le code incriminé est introuvable, le dire.
- Si le « bug » est en réalité une fonctionnalité manquante, basculer vers le pipeline de cadrage.
