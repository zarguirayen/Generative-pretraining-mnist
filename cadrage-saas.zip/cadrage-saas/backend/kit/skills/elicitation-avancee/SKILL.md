---
name: elicitation-avancee
description: Passe de ré-examen structuré d'un document généré (cadrage, spec, plan) — menu numéroté de méthodes de raisonnement nommées (pre-mortem, inversion, red team, socratique, premiers principes…) appliquées au brouillon pour surfacer ce qu'une relecture générique raterait. À proposer après chaque génération de document et avant sa validation.
---

# Élicitation avancée

## Principe

Après avoir généré un document (brouillon de cadrage, spec, plan), ne pas demander « voulez-vous des améliorations ? » — proposer un **menu numéroté de méthodes de raisonnement nommées**. Une méthode nommée force un angle d'attaque précis ; un « améliore » générique produit du polissage superficiel.

## Déroulé

1. Après présentation du brouillon, proposer : « Voulez-vous une passe d'examen critique ? Voici 5 méthodes adaptées à ce document (ou 0 pour passer, R pour d'autres méthodes) » — choisir les 5 les plus pertinentes pour le contenu.
2. L'utilisateur choisit un numéro. Appliquer la méthode au document existant et présenter **uniquement les constats et les modifications proposées** (pas une réécriture intégrale).
3. L'utilisateur accepte, rejette ou choisit une autre méthode. Intégrer les modifications acceptées, marquer dans le document `[élicitation : <méthode> — JJ/MM]`.
4. Boucler tant que l'utilisateur le souhaite ; recommander de s'arrêter après 2-3 passes (rendements décroissants).

## Catalogue de méthodes

| # | Méthode | Question directrice | Particulièrement utile pour |
|---|---|---|---|
| 1 | **Pre-mortem** | « Le projet a échoué dans 12 mois : qu'est-ce qui l'a tué ? » | cadrage (risques), plan |
| 2 | **Inversion** | « Comment garantir l'échec de cet objectif ? Faisons l'inverse » | objectifs, critères de succès |
| 3 | **Red team** | « Attaque ce document : failles de sécurité, cas limites, abus possibles » | spec, plan, exigences de sécurité |
| 4 | **Questionnement socratique** | « Pourquoi ? Comment le sait-on ? » sur chaque affirmation non sourcée | hypothèses `[défaut]`, objectifs |
| 5 | **Premiers principes** | « En repartant des besoins bruts, arriverait-on à la même solution ? » | plan, architecture |
| 6 | **Cartographie des parties prenantes** | « Qui n'a pas été consulté et pourrait bloquer ou être lésé ? » | cadrage (utilisateurs) |
| 7 | **Levée de contrainte** | « Si la contrainte X disparaissait, que ferait-on ? Elle est donc peut-être négociable » | contraintes, arbitrages |
| 8 | **Raisonnement analogique** | « Quel produit connu a déjà résolu ce problème, et qu'en apprendre ? » | périmètre, cas dégradés |
| 9 | **Chemin critique** | « Quelle est la seule chose qui, si elle échoue, bloque tout le reste ? » | plan, découpage en tâches |
| 10 | **Regard du nouvel arrivant** | « Qu'est-ce qu'une personne extérieure ne comprendrait pas dans ce document ? » | glossaire, clarté générale |

## Règles

- Toujours choisir les 5 méthodes proposées en fonction du document (un cadrage appelle 1/2/4/6/7 ; un plan appelle 1/3/5/9).
- Les constats d'une passe qui révèlent un manque structurel (objectif non mesurable, risque absent) se corrigent dans le document source, pas dans une annexe.
- Une passe d'élicitation ne remplace jamais la validation utilisateur des gates — elle la précède.
