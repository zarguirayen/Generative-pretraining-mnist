---
name: validation-transverse
description: Checklist maîtresse de cohérence inter-documents (cadrage ↔ spec ↔ plan) à exécuter avant de lancer l'implémentation — traçabilité complète, arbitrages validés, aucun artefact orphelin. À utiliser comme gate final du pipeline.
---

# Validation transverse (checklist maîtresse)

Gate final avant implémentation. Chaque item est vérifié document en main (citer la ligne ou la section qui le prouve), jamais de mémoire. Restituer le résultat en tableau : item / ✅-❌ / preuve ou manque.

## Traçabilité descendante

- [ ] Chaque objectif (O#) du cadrage est couvert par au moins une exigence (EF/ENF) de la spec.
- [ ] Chaque exigence de la spec est couverte par au moins une tâche du plan.
- [ ] Chaque invariant (INV-###) a une propriété de correction dans le plan, destinée à un test.
- [ ] Chaque risque « Traiter en priorité » du cadrage a une parade concrète reflétée dans le plan (tâche, checkpoint ou choix d'architecture).

## Traçabilité montante (pas d'orphelins)

- [ ] Aucune exigence de la spec sans objectif parent au cadrage.
- [ ] Aucune tâche du plan sans exigence parente.
- [ ] Aucun composant de l'architecture qui ne serve aucune exigence.

## Cohérence des décisions

- [ ] Tous les arbitrages et renégociations du cadrage sont cochés « validé par l'utilisateur ».
- [ ] Aucune hypothèse `[défaut]` structurante non confirmée dans le cadrage ou la spec.
- [ ] Zéro marqueur `[BESOIN DE CLARIFICATION]` restant.
- [ ] La stack du plan est celle du steering `tech.md` (ou l'écart figure dans « Dérogations »).
- [ ] Les obligations réglementaires du domaine (skill `estimation-risques`) sont soit couvertes, soit exclues par un arbitrage validé.
- [ ] Le plan respecte chaque article de `.specify/memory/constitution.md` (ou dérogation justifiée).

## Exécutabilité

- [ ] Chaque tâche du plan est une capsule de contexte autonome (exigences citées, fichiers concernés, critère de fin).
- [ ] Les checkpoints du plan encadrent chaque groupe de tâches.
- [ ] Les tâches `[optionnel — MVP]` sont identifiées et leur risque accepté est écrit.

## Verdict

- **GO** : tous les items ✅ → l'implémentation peut démarrer.
- **NO-GO** : lister les items ❌ avec le document à corriger et l'agent responsable (`cadrage`, `spec-writer` ou `planner`). Ne jamais prononcer un GO « avec réserves » : une réserve est un NO-GO avec un correctif à faire.
