---
name: revue-code
description: Discipline commune de revue de code — échelle de sévérité, format de preuve (fichier:ligne + scénario d'échec), règles anti-faux-positifs (vérifier avant de rapporter, tracer le chemin d'exécution), périmètre à ignorer, politique de merge. À charger par tout agent qui examine du code.
---

# Discipline de revue de code

## Règle d'or : pas de constat sans scénario d'échec

Un constat n'existe que s'il est accompagné de : **fichier:ligne** + **scénario d'échec concret** (« avec l'entrée X dans l'état Y, la ligne Z produit W au lieu de W' »). Un malaise diffus (« ce code semble fragile ») n'est pas un constat — soit on le concrétise, soit on le tait. Les faux positifs sont la première cause d'abandon des revues : un constat douteux coûte plus cher que un constat manqué.

## Vérifier avant de rapporter

Avant d'inscrire un constat au rapport, le vérifier contre le comportement réel du code :
1. **Tracer le chemin d'exécution** depuis un point d'entrée réel jusqu'à la ligne incriminée — le chemin existe-t-il vraiment ? Une garde en amont neutralise-t-elle le cas ?
2. **Vérifier les hypothèses** : le type peut-il réellement être nul ici ? La collection peut-elle réellement être vide ? Qui appelle cette fonction et avec quoi ?
3. Classer : **CONFIRMÉ** (chemin tracé, scénario reproductible) / **PLAUSIBLE** (probable mais chemin non tracé de bout en bout — à dire explicitement) / **REJETÉ** (ne pas rapporter, mais compter dans les statistiques de la passe).

## Échelle de sévérité

| Sévérité | Définition | Effet sur le verdict |
|---|---|---|
| **Bloquant** | Corruption de données, faille de sécurité exploitable, crash sur un chemin nominal, violation d'un invariant `INV-###`, exigence Must non implémentée | NO-GO tant que non corrigé |
| **Majeur** | Bug sur un chemin non nominal, cas limite non géré prévu par la spec, régression probable, dette de sécurité non exploitable en l'état | à corriger ou à consigner comme arbitrage validé |
| **Mineur** | Amélioration réelle mais sans risque (simplification, doublon, nommage trompeur) | recommandation, jamais bloquant |

Interdits de rapport : préférences stylistiques, reformulations cosmétiques, commentaires sur du code non modifié hors périmètre de la revue (sauf s'il interagit avec le changement).

## Périmètre

- Revue par défaut : le **diff** (changements + leur interaction avec l'existant). Revue de module ou de codebase entière : uniquement sur demande explicite.
- À ignorer d'office : code généré, vendors/node_modules, migrations figées, fichiers de lock — sauf si le changement les touche volontairement.

## Preuve par l'exécution

Quand un environnement d'exécution est disponible : exécuter la suite de tests et rapporter **les chiffres réels** (« 42/43 — 1 échec : <nom> »). Un verdict sans exécution des tests le mentionne explicitement (« tests non exécutés — verdict sur lecture seule »).

## Politique de merge (à écrire, pas implicite)

- Tout constat **Bloquant** est résolu ou explicitement refusé par l'utilisateur (décision consignée) avant merge.
- Les **Majeurs** sont corrigés ou consignés en arbitrage ; les **Mineurs** ne retardent jamais un merge.
- Le rapport se termine par un verdict binaire **GO / NO-GO** (pas de « GO avec réserves » : une réserve bloquante = NO-GO).
