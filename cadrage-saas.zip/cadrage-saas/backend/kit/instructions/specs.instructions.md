---
applyTo: ".specify/**"
---

# Règles pour les spécifications

- Une spec décrit le **quoi** et le **pourquoi**, jamais le **comment** (pas de choix de framework, de schéma de base de données ni de nom de classe — cela appartient au plan).
- Chaque exigence fonctionnelle est numérotée (`EF-001`, `EF-002`, …) et testable : une personne extérieure doit pouvoir dire objectivement si elle est satisfaite ou non.
- Chaque exigence non fonctionnelle (`ENF-001`, …) a une valeur chiffrée (latence, disponibilité, volumétrie, accessibilité).
- Les ambiguïtés de **périmètre** sont marquées `[BESOIN DE CLARIFICATION : <question>]` plutôt que résolues par une supposition. Une spec avec des marqueurs de clarification ne peut pas passer en phase de plan. Les ambiguïtés **paramétriques** (délais, seuils, limites), elles, reçoivent une valeur par défaut chiffrée que l'utilisateur peut corriger.
- Chaque exigence est traçable vers un objectif du document de cadrage (référence en fin de ligne, ex. `→ Objectif O2`).
- Chaque exigence fonctionnelle comporte une User Story (En tant que / je veux / afin de) et des critères d'acceptation au format **EARS** : `THE <Système> SHALL …`, `WHEN …, THE <Système> SHALL …`, `IF …, THEN THE <Système> SHALL …`, `WHERE …`, `WHILE …`. Un critère = une phrase testable.
- Chaque exigence fonctionnelle inclut au moins un critère de cas dégradé (`IF … THEN`).
- La spec commence par un Glossaire (termes capitalisés, énumérations fermées) et ces termes sont réutilisés à l'identique dans toutes les exigences.
- Respecte la `constitution.md` : toute exigence qui la contredit doit être signalée, pas intégrée.
