---
applyTo: "docs/**"
---

# Règles pour les documents de cadrage et la documentation

- Tout document de cadrage suit le gabarit `docs/cadrage/TEMPLATE-cadrage.md` : mêmes sections, même ordre. Aucune section ne peut être supprimée ; une section non applicable contient la mention « Non applicable — <raison> ».
- Nom de fichier : `docs/cadrage/<slug-projet>-cadrage.md` (kebab-case, sans accents).
- Chaque document commence par un bloc de métadonnées : date (JJ/MM/AAAA), auteur, statut (`brouillon` | `en revue` | `validé`), version.
- Les objectifs sont formulés au format : *verbe d'action + métrique + cible + échéance*. Exemple : « Réduire le temps de traitement d'une demande de 48 h à 4 h d'ici fin T3 2026 ». Un objectif sans métrique est refusé.
- Le périmètre distingue explicitement **In** et **Out** (hors périmètre) sous forme de listes.
- Chaque risque a une probabilité (faible/moyenne/élevée), un impact (faible/moyen/élevé) et une parade.
- Pas de solution technique dans un document de cadrage : le « comment » appartient au plan, pas au cadrage.
