# Steering — Structure du dépôt

> Organisation des fichiers, conventions de nommage et flux documentaire. Lu par les agents à chaque session.

## Flux documentaire (imposé)

1. **Cadrage** → `docs/cadrage/<slug>-cadrage.md` (agent `cadrage`, gabarit `docs/cadrage/TEMPLATE-cadrage.md`)
2. **Spécification** → `.specify/specs/<n>-<slug>/spec.md` si Spec Kit est installé, sinon `docs/specs/<slug>-spec.md` (agent `spec-writer`)
3. **Plan et tâches** → `.specify/specs/<n>-<slug>/plan.md` + `tasks.md`, sinon `docs/plans/` (agent `planner`)
4. **Implémentation** → code, uniquement après validation du plan

## Conventions de nommage

- Fichiers documentaires : kebab-case, sans accents (`refonte-onboarding-cadrage.md`).
- Statuts de document : `brouillon` → `en revue` → `validé`, dans le bloc de métadonnées.
- Identifiants d'exigences : `EF-###` (fonctionnelles), `ENF-###` (non fonctionnelles), `O#` (objectifs), `R#` (risques), `H#` (hypothèses).

## Organisation du code

<!-- À COMPLÉTER : arborescence source, conventions de nommage du code, organisation des tests, patterns d'import. -->
