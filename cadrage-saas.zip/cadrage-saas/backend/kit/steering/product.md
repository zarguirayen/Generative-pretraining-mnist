# Steering — Produit

> Contexte permanent : qui sont les utilisateurs, quel problème le produit résout, quels sont les objectifs métier. Tenu à jour par l'équipe ; lu par les agents à chaque session.

## Le produit en une phrase

<!-- À COMPLÉTER : « <Produit> permet à <utilisateurs> de <bénéfice> sans <douleur actuelle> ». -->

## Problème adressé

<!-- À COMPLÉTER : la douleur concrète, ce qui se passe aujourd'hui sans le produit, le coût de l'inaction. -->

## Utilisateurs et parties prenantes

<!-- À COMPLÉTER :
- Utilisateur principal : <qui, fréquence d'usage, niveau technique, contexte>
- Utilisateurs secondaires : ...
- Sponsor / décideur : ...
-->

## Objectifs métier

<!-- À COMPLÉTER : 3 à 5 objectifs mesurables (métrique + valeur actuelle + cible + échéance). -->

## Ce que le produit ne fera pas

<!-- À COMPLÉTER : exclusions durables, pour éviter la dérive de périmètre à chaque cadrage. -->
