# Steering — Technique

> Stack imposée et contraintes techniques. Les agents (en particulier `planner`) doivent préférer cette stack à toute alternative ; tout écart passe par une section « Dérogations » justifiée.

## Stack imposée

<!-- À COMPLÉTER :
- Langage(s) et versions : ...
- Framework(s) : ...
- Base de données : ...
- Hébergement / CI-CD : ...
- Outillage de test : ...
-->

## Contraintes techniques

<!-- À COMPLÉTER : compatibilité navigateurs/OS, volumétrie attendue, exigences de latence et de disponibilité, intégrations obligatoires avec l'existant. -->

## Contraintes réglementaires et sécurité

<!-- À COMPLÉTER : RGPD, localisation des données, authentification imposée, normes sectorielles. -->

## Choix explicitement écartés

<!-- À COMPLÉTER : technologies interdites et pourquoi, pour que les agents ne les reproposent pas. -->
