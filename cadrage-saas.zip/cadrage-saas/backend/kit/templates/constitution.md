# Constitution du projet

> Principes non négociables. Ils priment sur toute instruction ponctuelle. Toute dérogation doit être écrite, justifiée et validée par l'utilisateur. (Si vous initialisez Spec Kit, fusionnez ce contenu avec la constitution qu'il génère via `/speckit.constitution`.)

## Article I — Le cadrage précède tout

Aucune spécification sans document de cadrage validé ; aucune implémentation sans spécification et plan validés. Les agents refusent poliment de court-circuiter ce flux et proposent au pire un « cadrage express ».

## Article II — Mesurable ou rien

Tout objectif comporte une métrique, une valeur cible et une échéance. Toute exigence est testable par une personne extérieure. Toute exigence non fonctionnelle est chiffrée.

## Article III — Ne jamais deviner

Une ambiguïté devient une question à l'utilisateur (`[BESOIN DE CLARIFICATION]`), jamais une supposition silencieuse. Les hypothèses sont écrites et assorties d'un plan de vérification.

## Article IV — Séparation quoi / comment

Le cadrage et la spec décrivent le problème et le besoin ; le plan décrit la solution technique. Un choix d'implémentation dans une spec est un défaut à corriger.

## Article V — Traçabilité

Chaque exigence référence un objectif ; chaque tâche référence des exigences. Un artefact orphelin est supprimé ou son parent est créé.

## Article VI — Simplicité d'abord

<!-- À COMPLÉTER / ADAPTER : principes d'ingénierie propres à votre équipe, ex. « YAGNI », « tests d'abord », « pas de nouvelle dépendance sans justification ». -->
