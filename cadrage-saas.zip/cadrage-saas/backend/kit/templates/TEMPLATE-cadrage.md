# Cadrage — <Nom du projet>

| Champ | Valeur |
|---|---|
| Date | JJ/MM/AAAA |
| Auteur | <nom> |
| Type | nouvelle fonctionnalité / correctif / refonte / exploration |
| Niveau d'échelle | 1 (express) / 2 (standard) / 3 (produit) / 4 (multi-modules) |
| Statut | brouillon |
| Version | 0.1 |

## Contexte

<Le problème concret, ce qui se passe aujourd'hui, le coût de l'inaction, ce qui a déjà été tenté.>

## Glossaire

> Vocabulaire contrôlé : termes capitalisés, énumérations fermées, réutilisés à l'identique dans tout le document puis dans la spec.

- **<Terme>** : <définition>
- **<Rôle>** : <définition + permissions>
- **<État>** : énumération fermée, ex. : `À faire`, `En cours`, `Terminée`

## Utilisateurs et parties prenantes

| Rôle | Qui | Attentes | Influence |
|---|---|---|---|
| Utilisateur principal | | | |
| Sponsor | | | |

## Objectifs

| ID | Objectif (verbe + métrique + cible + échéance) | Valeur actuelle | Cible | Échéance |
|---|---|---|---|---|
| O1 | | | | |

## Périmètre

### Must (indispensable)
-

### Should (important, négociable)
-

### Could (si possible)
-

## Hors périmètre

> Au moins 3 exclusions explicites (Won't de cette itération).

-
-
-

## Cas dégradés et cycle de vie

> Pour chaque capacité du Must : erreur de saisie, abandon en cours, suppression, départ d'un utilisateur, indisponibilité d'une dépendance. Que conserve-t-on (historique, audit) ?

| Capacité | Cas dégradé | Comportement attendu |
|---|---|---|
| | | |

## Contraintes

| Type | Contrainte | Réelle ou préférence ? |
|---|---|---|
| Délai / Budget / Réglementaire / Technique / Équipe | | |

## Arbitrages et renégociations

> Contraintes de la demande initiale jugées incompatibles entre elles, renégociées avec l'utilisateur. Chaque ligne doit être validée explicitement — jamais renégociée en silence.

| Demande initiale | Valeur retenue | Justification | Validé par l'utilisateur ? |
|---|---|---|---|
| ex. dispo 99,99 % (52 min/an) | 99,5 % (44 h/an) | infra redondante multi-région incompatible avec budget/délai/équipe | ☐ |

## Risques

| ID | Risque | Prob. | Impact | Décision | Parade |
|---|---|---|---|---|---|
| R1 | | | | | |

## Hypothèses

> Origine `[défaut]` : posée par l'agent, en attente de confirmation. `[validé]` : confirmée par l'utilisateur. Toute valeur paramétrique (délai, seuil, limite) posée par défaut figure ici.

| ID | Hypothèse | Origine | Si fausse, conséquence | Plan de vérification |
|---|---|---|---|---|
| H1 | | [défaut] | | |

## Critères de succès

> Vérifiables par une personne extérieure ; chaque critère référence un objectif.

| Critère | Objectif lié | Qui constate, avec quelles données |
|---|---|---|
| | O1 | |

## Conditions de mise en service

> Portes à franchir avant la bascule en production — typiquement issues du pre-mortem : mesures de référence à capturer, parades des risques « traiter » à engager, obligations réglementaires à acter, décideurs à nommer.

- [ ] <condition> (lève <R# ou H#>)

## Pistes de solution évoquées (non engageantes)

<Solutions mentionnées pendant l'interview, notées pour mémoire — le choix appartient à la phase de plan.>

## Décision

- [ ] Go vers spécification — validé par : <nom>, le : JJ/MM/AAAA
