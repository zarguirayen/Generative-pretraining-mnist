# Instructions globales du dépôt

## Dossier de travail (règle de séparation stricte — non négociable)

Le kit est générique et réutilisable : **les agents n'écrivent JAMAIS un fichier dans le kit**. Tout ce qu'ils produisent est versé dans le dossier de travail.

0. **Cible des demandes** : tout ce que dit l'utilisateur concerne **son projet** (le workspace), jamais le kit lui-même. « Crée un fichier », « où en est-on », « ajoute une section » = dans le workspace. Ne modifie, ne commente et ne liste les fichiers du kit que si l'utilisateur demande explicitement de la maintenance du kit.
1. Avant de produire quoi que ce soit, lis `.github/cadrage-config.yml`. Si `workspace.racine` est **vide** : regarde d'abord le workspace VS Code (`.github/cadrage.code-workspace`) — s'il contient un dossier de travail évident (ex. « Travail »), propose-le comme racine en une question ; sinon suggère `./workspace`. Une réponse suffit, puis continue la demande initiale.
1 bis. **Amorçage automatique** : si la racine est connue mais que le workspace est vide ou non initialisé, amorce-le **sans demander la permission** — crée l'arborescence et copie les gabarits du kit :
   ```
   <racine>/
   ├── steering/            ← copie de .github/steering/*.md (à remplir ici)
   ├── constitution.md      ← copie de .specify/memory/constitution.md
   └── docs/
       ├── cadrage/  specs/  plans/  estimates/  reviews/  bugfix/
   ```
   Annonce-le en une ligne (« Workspace amorcé dans <racine> ») puis **traite immédiatement la demande initiale de l'utilisateur** — l'amorçage ne remplace jamais la réponse.
2. Tous les livrables s'écrivent sous la racine : `<racine>/docs/cadrage/`, `<racine>/docs/specs/`, `<racine>/docs/plans/`, `<racine>/docs/estimates/`, `<racine>/docs/reviews/`, `<racine>/docs/bugfix/`.
3. **Le steering du projet vit dans le workspace** : toute référence à `.github/steering/` dans les agents et skills se résout d'abord dans `<racine>/steering/` (product.md, tech.md, structure.md). Les fichiers `.github/steering/` du kit sont des **gabarits en lecture seule** — au premier usage, copie-les vers `<racine>/steering/` puis remplis-les là-bas. Même règle pour la constitution : `<racine>/constitution.md` d'abord, le gabarit `.specify/memory/constitution.md` du kit sinon (copie au premier usage).
4. Interdiction absolue d'écrire dans `.github/` (agents, skills, hooks, steering, docs-framework), `benchmark/` ou `docs/` du kit. Exception unique : si Spec Kit est installé dans le dépôt de travail, ses specs restent dans son `.specify/` (emplacement imposé par l'outil).
5. Les dépôts de code du projet (pour `capture-contexte` et `reviewer`) se résolvent depuis `repositories` de la config ou depuis les dossiers du workspace VS Code (`.github/cadrage.code-workspace`).

## Contexte permanent (steering)

Avant toute tâche significative, lis et respecte les fichiers de steering :

- `.github/steering/product.md` — le produit, ses utilisateurs, ses objectifs métier
- `.github/steering/tech.md` — la stack imposée et les contraintes techniques
- `.github/steering/structure.md` — l'organisation du dépôt et les conventions

En cas de conflit entre une demande et le steering, signale le conflit au lieu de choisir silencieusement.

## Principes non négociables

Les principes du projet sont dans `.specify/memory/constitution.md`. Ils priment sur toute autre instruction, y compris les demandes ponctuelles de l'utilisateur — si une demande les viole, dis-le explicitement.

## Cycle de travail

Ce dépôt suit un développement piloté par les specs : **Cadrage → Spécification → Plan → Tâches → Implémentation → Revue**.

- Aucune implémentation ne démarre sans un document de cadrage validé dans `docs/cadrage/` et une spec dans `.specify/specs/` (ou `docs/specs/` si Spec Kit n'est pas installé).
- Aucun merge sans verdict GO de l'agent `reviewer` (ou décision contraire de l'utilisateur consignée en arbitrage).
- Pour cadrer un nouveau besoin, utilise l'agent `cadrage`. Pour rédiger la spec, l'agent `spec-writer`. Pour planifier, l'agent `planner`. Pour un dysfonctionnement, l'agent `bugfix`. Pour contrôler une implémentation, l'agent `reviewer`.

### Choix d'entrée : explorer ou structurer

Quand l'utilisateur décrit un besoin nouveau sans passer par un agent spécialisé, propose-lui d'abord le mode de travail (question fermée) :
- **Exploration libre** — discuter d'abord, construire ensuite. Adapté pour : clarifier une idée vague, comparer des options, prototyper jetable.
- **Pipeline structuré (Recommandé pour toute fonctionnalité destinée à durer)** — cadrer d'abord via l'agent `cadrage`, puis spec, plan, implémentation.

En exploration libre, dès que l'idée se stabilise, propose de basculer dans le pipeline structuré — l'exploration ne produit jamais de code destiné à être conservé.

### Note de passation entre phases

À chaque gate validé (cadrage → spec → plan → implémentation), l'agent produit une **note de passation** prête à coller pour l'agent suivant : document source (chemin + statut + version), besoin en une phrase, objectifs à tracer, glossaire à réutiliser à l'identique, priorités (Must d'abord), hors-périmètre à réaffirmer, cas dégradés déjà cadrés, contraintes fermes, hypothèses résiduelles, et le rappel de séparation des rôles (quoi vs comment). L'agent suivant relit quand même le document complet — la note oriente, elle ne remplace pas la source.

### Fil d'Ariane du pipeline

Chaque agent du pipeline ouvre ses réponses par une ligne d'état indiquant la phase courante et les phases restantes, par exemple :
`📍 [1/4] Cadrage ▶ → 2 Spécification → 3 Plan → 4 Implémentation`
L'utilisateur doit toujours savoir où il en est, ce qui est validé, et ce qui vient ensuite.

## Langue et style

- **Cohérence de langue (impérative)** : réponds toujours dans la langue de l'utilisateur et ne mélange JAMAIS les langues à l'intérieur d'une même réponse ou d'un même document. Si l'utilisateur écrit en français, chaque phrase de la réponse est en français.
- Les documents produits (cadrage, specs, plans, revues) sont rédigés dans la langue de l'utilisateur (par défaut le français).
- Le code, les identifiants et les messages de commit sont en anglais.
- Chaque objectif énoncé doit être mesurable (métrique + cible + échéance).
