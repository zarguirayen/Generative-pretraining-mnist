# Contexte pour les agents IA

Ce dépôt suit un développement piloté par les specs : **Cadrage → Spécification → Plan → Tâches → Implémentation**. Aucune implémentation sans cadrage et spec validés.

## Dossier de travail (séparation stricte)

Le kit n'enregistre RIEN de ce que les agents produisent. **Toute demande de l'utilisateur concerne son projet (le workspace), jamais le kit.** `workspace.racine` (`.github/cadrage-config.yml`) : si vide, la déduire ou la demander en une question ; si le workspace n'est pas initialisé, l'**amorcer automatiquement** (copier les gabarits steering + constitution, créer `docs/{cadrage,specs,plans,estimates,reviews,bugfix}/`) puis traiter la demande. Tous les chemins `docs/...` ci-dessous s'entendent `<racine>/docs/...` ; le steering rempli vit dans `<racine>/steering/`, la constitution du projet dans `<racine>/constitution.md` — les fichiers du kit sont des gabarits en lecture seule.

## À lire avant d'agir

- `.github/steering/product.md` — produit, utilisateurs, objectifs métier
- `.github/steering/tech.md` — stack imposée et contraintes
- `.github/steering/structure.md` — organisation du dépôt et flux documentaire
- `.specify/memory/constitution.md` — principes non négociables (prioritaires sur tout le reste)

## Agents spécialisés disponibles

| Agent | Rôle | Livrable |
|---|---|---|
| `orchestrateur` | Point d'entrée : détecte l'état du pipeline, auto-capture le steering, route vers le bon agent | état du projet + steering pré-rempli |
| `cadrage` | Interview de cadrage, clarification du besoin | `docs/cadrage/<slug>-cadrage.md` |
| `spec-writer` | Spécification formelle (quoi/pourquoi) | `.specify/specs/` ou `docs/specs/` |
| `planner` | Plan technique et découpage en tâches | `.specify/specs/` ou `docs/plans/` |
| `estimateur` | Estimation d'effort en jours-homme (depuis plan, spec, cadrage ou SFD externe) | `docs/estimates/` (CSV + README) |
| `bugfix` | Diagnostic de bug et correction test-first (pipeline léger, sans cadrage complet) | `docs/bugfix/<slug>-bugfix.md` + correctif testé |
| `reviewer` | Revue de code : conformité au contrat, correction, sécurité, patterns → verdict GO/NO-GO | `docs/reviews/<slug>-revue.md` |

En cas de doute sur par où commencer : `orchestrateur`.

Cinq sous-agents spécialisés (`.github/agents/auxiliary/`, non sélectionnables, invoqués via l'outil `agent`) : `analyste-faisabilite`, `analyste-risques`, `capture-contexte`, `elicitateur`, `verificateur-transverse`. Règle : les sous-agents proposent et restituent ; les agents d'entrée et l'utilisateur décident. Organigramme complet : `.github/docs-framework/catalogue-agents.md`.

## Règles transverses

- Cohérence de langue impérative : répondre dans la langue de l'utilisateur, ne jamais mélanger deux langues dans une même réponse ou un même document. Code, identifiants et commits en anglais.
- Un objectif sans métrique, cible et échéance n'est pas un objectif.
- Toute ambiguïté dans une spec devient `[BESOIN DE CLARIFICATION : <question>]` — ne jamais deviner.
- En cas de conflit entre une demande et le steering ou la constitution, signaler le conflit au lieu de trancher silencieusement.
