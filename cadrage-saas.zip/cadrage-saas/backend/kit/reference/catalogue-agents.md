# Catalogue des agents

Organisation à deux niveaux, conforme à la configuration Copilot ([custom agents reference](https://docs.github.com/en/copilot/reference/custom-agents-configuration)) : les agents d'entrée sont sélectionnables par l'utilisateur ; les sous-agents (`user-invocable: false`, dossier `auxiliary/`) ne sont invocables que via l'outil `agent`, avec une liste `agents:` en moindre privilège.

## Organigramme

```
                          ┌────────────────┐
        utilisateur ───▶  │ orchestrateur  │  état du pipeline + routage
                          └───┬────────────┘
        ┌─────────────────────┼─────────────────────────┬───────────────┐
        ▼ handoff             ▼ handoff                  ▼ handoff       ▼ handoff
  ┌───────────┐   ┌─────────────┐   ┌──────────┐   ┌────────────┐  ┌────────┐
  │  cadrage  │──▶│ spec-writer │──▶│ planner  │──▶│ estimateur │  │ bugfix │
  └─────┬─────┘   └──────┬──────┘   └────┬─────┘   └────────────┘  └────────┘
        │                │               │            implémentation (agent standard)
        ▼ agent          ▼ agent         ▼ agent                │
  analyste-faisabilite   elicitateur     analyste-risques       ▼
  capture-contexte                       elicitateur      ┌──────────┐
  analyste-risques                       verificateur-    │ reviewer │ gate de sortie
  elicitateur                            transverse       └────┬─────┘
                                                               ▼ agent
                                                  revue-conformite · revue-correction
                                                  revue-securite · gardien-patterns
                                                  elicitateur
```

## Agents d'entrée (6)

| Agent | Rôle | Sous-agents | Livrable | Gate de sortie |
|---|---|---|---|---|
| `orchestrateur` | État du pipeline, auto-capture steering, scénario, routage | capture-contexte, analyste-faisabilite, verificateur-transverse | état + steering rempli | accord utilisateur avant chaque routage |
| `cadrage` | Brouillon d'abord, triage + niveau d'échelle 0-4, périmètre MoSCoW, arbitrages | analyste-faisabilite, capture-contexte, analyste-risques, elicitateur | `docs/cadrage/<slug>-cadrage.md` | objectifs mesurables, Out ≥ 3, hypothèses confirmées, validation utilisateur |
| `spec-writer` | Spec EARS + glossaire + invariants, clarifications de périmètre | elicitateur | `.specify/specs/` ou `docs/specs/` | zéro clarification ouverte, tout tracé, validation utilisateur |
| `planner` | Architecture, propriétés de correction, tâches-capsules, checkpoints | analyste-risques, elicitateur, verificateur-transverse | `docs/plans/` ou `.specify/specs/` | GO du verificateur-transverse + validation utilisateur |
| `estimateur` | Jours-homme (CSV + README, confiance, décotes migration) | — | `docs/estimates/` | totaux cohérents, zéro placeholder, fidélité stricte au périmètre |
| `bugfix` | Diagnostic entonnoir + correction test-first | — | `docs/bugfix/` + correctif | exploration passe, préservation passe, suite verte |
| `reviewer` | Revue de code : orchestre 4 revues, contre-vérifie, exécute les tests, verdict | revue-conformite, revue-correction, revue-securite, gardien-patterns, elicitateur | `docs/reviews/<slug>-revue.md` | verdict GO/NO-GO binaire, statistiques anti-faux-positifs |

## Sous-agents (5, `auxiliary/`, non sélectionnables)

| Sous-agent | Spécialité | Invoqué par | Écrit des fichiers ? |
|---|---|---|---|
| `analyste-faisabilite` | Incompatibilités quantifiées + réglementaire + reformulation MVP | orchestrateur, cadrage | non — restitue |
| `capture-contexte` | Faits du code : steering auto-rempli, carte de l'existant, analyse d'impact | orchestrateur, cadrage | steering uniquement |
| `analyste-risques` | Matrices risques/hypothèses, parades concrètes | cadrage, planner | non — restitue |
| `elicitateur` | Ré-examen par méthode nommée (pre-mortem, red team, socratique…) | cadrage, spec-writer, planner | non — restitue |
| `verificateur-transverse` | Checklist maîtresse cadrage↔spec↔plan, verdict GO/NO-GO | planner, orchestrateur | non — restitue |
| `revue-conformite` | Code ↔ contrat : critères EARS implémentés/testés, invariants, sur-implémentation | reviewer | non — restitue |
| `revue-correction` | Chasse aux bugs (7 classes), scénarios d'échec tracés | reviewer | non — restitue |
| `revue-securite` | OWASP/CWE + qualification d'exploitabilité réelle | reviewer | non — restitue |
| `gardien-patterns` | Cohérence avec le code existant, règles écrites prioritaires | reviewer | non — restitue |

## Principes de l'organisation

1. **Les sous-agents proposent, les agents d'entrée et l'utilisateur décident** : aucun sous-agent ne modifie un livrable (exception : `capture-contexte` sur le steering) ni ne prononce un arbitrage.
2. **Moindre privilège** : chaque agent liste explicitement ses sous-agents (`agents:`) et ses outils ; les agents autonomes portent `agents: []`.
3. **Un constat « bloquant » d'un sous-agent ne peut pas être absorbé silencieusement** par l'agent appelant — il est présenté à l'utilisateur.
4. **Les skills restent la méthode partagée** : les sous-agents opérationnalisent les skills (`estimation-risques`, `elicitation-avancee`, `validation-transverse`) — la méthode vit dans le skill, l'exécution dans le sous-agent.
5. Les handoffs (boutons) enchaînent les phases ; l'outil `agent` délègue à l'intérieur d'une phase. Rappel : handoffs non supportés par le cloud agent github.com.
6. **Deux niveaux de profondeur, jamais plus** : les sous-agents portent tous `agents: []` et ne délèguent jamais. Ce n'est pas un hasard mais une règle anti-dégradation : l'information relayée à travers des chaînes d'agents imbriqués se déforme à chaque maillon (le « deep-frying » documenté par l'équipe Onyx sur leur Deep Research). Toute extension du kit respecte cette limite — un nouveau besoin de délégation se branche sur un agent d'entrée, pas sur un sous-agent. Corollaire : quand un agent d'entrée invoque plusieurs sous-agents indépendants (ex. faisabilité + risques), il peut les lancer en parallèle.
