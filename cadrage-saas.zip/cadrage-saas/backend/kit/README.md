# kit/ — la méthode de cadrage, source de vérité du service

Ce dossier contient **toute la méthode** appliquée par la plateforme : agents,
sous-agents, skills, gabarits et règles de rédaction, en Markdown.

Il fait partie intégrante du service : versionné avec le code, embarqué dans l'image
Docker (`/app/kit`), déployé avec lui. **Le service ne dépend d'aucun dossier
extérieur** — ni dépôt annexe, ni poste de développement.

## Règle absolue

**Ces fichiers ne sont jamais réécrits en code.** `app/agents/kit_loader.py` les charge
à l'exécution : il retire le frontmatter YAML, assemble chaque agent avec les skills
qu'il référence, et ajoute un préambule d'adaptation au contexte web (pas d'écriture de
fichiers, pas d'invocation de sous-agents, pas de handoffs).

Conséquence : **pour faire évoluer la méthode, on modifie les `.md` ici**, et rien
d'autre. Aucune duplication en Python, donc aucune divergence possible.

## Contenu (30 fichiers)

```
agents/            7 agents d'entrée (*.agent.md)
agents/auxiliary/  9 sous-agents
skills/            7 méthodes (SKILL.md) : interview-cadrage, redaction-spec,
                   estimation-risques, elicitation-avancee, validation-transverse,
                   correction-bug, revue-code
instructions/      règles par type de livrable (docs, specs)
steering/          gabarits vierges product/tech/structure
templates/         TEMPLATE-cadrage.md, constitution.md, global-instructions.md
reference/         AGENTS.md (contexte transverse), catalogue-agents.md, hooks
```

## Comment chaque élément est utilisé

| Fichier du kit | Usage dans la plateforme |
|---|---|
| `agents/*.agent.md` | corps du prompt système, intégral |
| `skills/*/SKILL.md` | chargés d'office pour l'agent qui les référence |
| `reference/AGENTS.md` | injecté à **tous** les agents (contexte transverse) |
| `instructions/*.md` | injectées selon le livrable produit (cadrage → docs, spec/plan → specs) |
| `templates/TEMPLATE-cadrage.md` | fourni à l'agent cadrage comme gabarit à suivre |
| `templates/constitution.md` | principes non négociables, injectés partout |
| `steering/*.md` | gabarits d'initialisation d'un nouveau projet |
| **cases `- [ ]` des agents et skills** | **deviennent la checklist du gate affichée à l'utilisateur** — jamais recopiées en Python |

## Faire évoluer la méthode

1. Modifier le ou les fichiers concernés dans ce dossier.
2. Vérifier le chargement : `GET /kit` renvoie les agents trouvés, les skills, les
   instructions et le nombre de critères de sortie extraits par agent.
3. Rejouer un cadrage de référence et comparer la sortie avant de déployer.

L'API **refuse de démarrer** si le kit est incomplet (agent manquant, skill absent,
gabarit vide) : mieux vaut un déploiement bloqué que des documents produits avec une
méthode amputée.

## Origine

Cette méthode a été mise au point et éprouvée séparément avant d'être intégrée ici.
Les fichiers ont été repris **sans réécriture** ; les seules adaptations (préambule
d'exécution web, bloc de contrôle pour piloter l'interface) sont ajoutées à la volée
par le loader et ne modifient jamais le contenu de ce dossier.
