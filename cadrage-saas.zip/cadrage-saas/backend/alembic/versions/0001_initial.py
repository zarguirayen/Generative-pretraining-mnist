"""Schéma initial + Row-Level Security multi-tenant.

Revision ID: 0001_initial
"""
from alembic import op

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

# Tables portant tenant_id et donc soumises à RLS.
TENANT_TABLES = [
    "memberships",
    "projects",
    "runs",
    "run_messages",
    "gates",
    "artifacts",
    "usage_events",
    "audit_logs",
]


def upgrade() -> None:
    # Le schéma des tables est généré par `alembic revision --autogenerate` à
    # partir de app/db/models.py. Cette migration ajoute ce que l'autogénération
    # ne sait pas produire : le rôle applicatif et les politiques RLS.

    # ── Rôle applicatif : aucun privilège de contournement ──────────────
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cadrage_app') THEN
                CREATE ROLE cadrage_app NOLOGIN NOBYPASSRLS;
            END IF;
        END $$;
        """
    )
    op.execute("GRANT USAGE ON SCHEMA public TO cadrage_app;")
    op.execute(
        "GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO cadrage_app;"
    )
    op.execute(
        "ALTER DEFAULT PRIVILEGES IN SCHEMA public "
        "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO cadrage_app;"
    )

    # ── Politiques RLS ─────────────────────────────────────────────────
    for table in TENANT_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        # FORCE : s'applique aussi au propriétaire des tables, pour que les
        # migrations ne créent pas un angle mort en production.
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
                USING (tenant_id = current_setting('app.tenant_id', true)::uuid)
                WITH CHECK (tenant_id = current_setting('app.tenant_id', true)::uuid);
            """
        )

    # `audit_logs` : insertion seule, jamais de modification ni suppression.
    op.execute("REVOKE UPDATE, DELETE ON audit_logs FROM cadrage_app;")

    # ── Checkpointer LangGraph ─────────────────────────────────────────
    # Les tables `checkpoints*` sont créées par `AsyncPostgresSaver.setup()`.
    # On isole par convention de thread_id (tenant:{uuid}:run:{uuid}) et par
    # vérification applicative : le thread_id d'un run est validé contre le
    # tenant courant avant toute reprise (voir app/agents/runner.py).


def downgrade() -> None:
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {table};")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY;")
