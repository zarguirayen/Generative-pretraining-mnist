'use client';

/**
 * Lancement d'une exécution.
 *
 * Trois entrées possibles : cadrage d'un besoin (le cas courant), revue de code,
 * correction de bug. Les deux dernières exigent du code — les agents de revue ne
 * travaillent que sur ce qui leur est réellement soumis.
 */
import { useRef, useState } from 'react';
import type { Phase } from '@/lib/api';

type Mode = 'cadrage' | 'revue' | 'bug';

interface StartPayload {
  prompt: string;
  entry_phase?: Phase;
  code_context?: Record<string, string>;
  review_scope?: 'diff' | 'module' | 'codebase';
}

interface Props {
  open: boolean;
  onClose: () => void;
  onStart: (payload: StartPayload) => Promise<void>;
}

const MODES: { id: Mode; label: string; hint: string; phase: Phase }[] = [
  {
    id: 'cadrage',
    label: 'Cadrer un besoin',
    hint: "Décrivez l'idée, même floue. Le pipeline complet démarre au cadrage.",
    phase: 'orchestration',
  },
  {
    id: 'revue',
    label: 'Revue de code',
    hint: 'Conformité au contrat, correction, sécurité et cohérence — verdict GO/NO-GO.',
    phase: 'revue',
  },
  {
    id: 'bug',
    label: 'Corriger un bug',
    hint: 'Diagnostic en entonnoir puis correction test-first, sans pipeline complet.',
    phase: 'revue',
  },
];

export function NewRunDialog({ open, onClose, onStart }: Props) {
  const [mode, setMode] = useState<Mode>('cadrage');
  const [prompt, setPrompt] = useState('');
  const [files, setFiles] = useState<Record<string, string>>({});
  const [scope, setScope] = useState<'diff' | 'module' | 'codebase'>('diff');
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  if (!open) return null;

  const current = MODES.find((m) => m.id === mode)!;
  const needsCode = mode !== 'cadrage';
  const fileCount = Object.keys(files).length;
  const canSubmit = prompt.trim().length >= 10 && (!needsCode || fileCount > 0);

  async function handleFiles(list: FileList | null) {
    if (!list) return;
    const next: Record<string, string> = { ...files };
    for (const file of Array.from(list).slice(0, 60)) {
      next[file.name] = await file.text();
    }
    setFiles(next);
  }

  async function submit() {
    setBusy(true);
    try {
      await onStart({
        prompt,
        entry_phase: current.phase,
        ...(needsCode ? { code_context: files, review_scope: scope } : {}),
      });
      setPrompt('');
      setFiles({});
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-xl border border-slate-700 bg-slate-900 p-6"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 className="mb-4 text-lg font-semibold">Nouvelle exécution</h2>

        <div className="mb-4 grid grid-cols-3 gap-2">
          {MODES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setMode(item.id)}
              className={[
                'rounded-lg border p-3 text-left text-sm transition',
                mode === item.id
                  ? 'border-cyan-600 bg-cyan-500/10 text-cyan-200'
                  : 'border-slate-800 text-slate-300 hover:border-slate-700',
              ].join(' ')}
            >
              {item.label}
            </button>
          ))}
        </div>

        <p className="mb-4 text-xs text-slate-500">{current.hint}</p>

        <textarea
          autoFocus
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
          rows={5}
          placeholder={
            mode === 'cadrage'
              ? "Ex. : je veux une application pour gérer les demandes de congés de mon équipe…"
              : mode === 'bug'
                ? 'Décrivez ce que vous observez. « Je ne sais pas » est une réponse acceptable.'
                : 'Que faut-il examiner ? (fonctionnalité concernée, points de vigilance)'
          }
          className="field mb-4 resize-y"
        />

        {needsCode && (
          <div className="mb-4 space-y-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="btn-ghost text-xs"
              >
                Joindre des fichiers
              </button>
              <input
                ref={inputRef}
                type="file"
                multiple
                hidden
                onChange={(event) => handleFiles(event.target.files)}
              />
              <span className="text-xs text-slate-500">
                {fileCount ? `${fileCount} fichier(s) joint(s)` : 'aucun fichier — requis'}
              </span>
              {fileCount > 0 && (
                <button
                  type="button"
                  onClick={() => setFiles({})}
                  className="ml-auto text-xs text-slate-500 hover:text-slate-300"
                >
                  Vider
                </button>
              )}
            </div>

            {fileCount > 0 && (
              <ul className="max-h-28 space-y-0.5 overflow-auto rounded-lg border border-slate-800 bg-slate-950 p-2 font-mono text-[11px] text-slate-400">
                {Object.entries(files).map(([path, content]) => (
                  <li key={path} className="flex justify-between gap-3">
                    <span className="truncate">{path}</span>
                    <span className="shrink-0 text-slate-600">
                      {(content.length / 1024).toFixed(1)} ko
                    </span>
                  </li>
                ))}
              </ul>
            )}

            {mode === 'revue' && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500">Périmètre :</span>
                {(['diff', 'module', 'codebase'] as const).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setScope(value)}
                    className={[
                      'rounded-full border px-2.5 py-0.5 transition',
                      scope === value
                        ? 'border-cyan-600 bg-cyan-500/15 text-cyan-200'
                        : 'border-slate-700 text-slate-400 hover:border-slate-600',
                    ].join(' ')}
                  >
                    {value === 'diff' ? 'Changements' : value === 'module' ? 'Module' : 'Base entière'}
                    {value === 'diff' && <span className="ml-1 opacity-60">(recommandé)</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex justify-end gap-2">
          <button type="button" onClick={onClose} className="btn-ghost">
            Annuler
          </button>
          <button type="button" onClick={submit} disabled={!canSubmit || busy} className="btn-primary">
            {busy ? 'Démarrage…' : 'Lancer'}
          </button>
        </div>
      </div>
    </div>
  );
}
