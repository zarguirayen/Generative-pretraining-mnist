'use client';

/**
 * Trace d'activité des agents, insérée dans le fil de conversation.
 *
 * C'est l'équivalent des « Searched workspace » / « Editing… » de Copilot et Kiro :
 * sans elle, l'utilisateur regarde un écran figé pendant qu'une phase travaille et
 * ne sait pas si le système réfléchit ou s'il est planté.
 *
 * Le bloc se replie automatiquement une fois l'étape terminée : la trace reste
 * consultable, mais ne noie pas la conversation.
 */
import { useState } from 'react';
import type { ProgressEvent } from '@/lib/api';

export interface ActivityItem extends ProgressEvent {
  finished?: boolean;
  result?: string;
}

const GLYPHS: Record<string, string> = {
  step: '◆',
  subagent: '⌁',
  writing: '✎',
  checking: '⌾',
  done_step: '✓',
};

export function AgentActivity({
  items,
  running,
}: {
  items: ActivityItem[];
  running: boolean;
}) {
  const [open, setOpen] = useState(true);
  if (items.length === 0) return null;

  const done = items.filter((item) => item.finished).length;

  return (
    <div className="msg-enter ml-11 rounded-xl border border-slate-800/70 bg-slate-900/30">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left"
      >
        <span
          className={[
            'h-1.5 w-1.5 rounded-full',
            running ? 'animate-pulse bg-cyan-400' : 'bg-emerald-500',
          ].join(' ')}
          aria-hidden
        />
        <span className="text-[11px] font-medium uppercase tracking-[0.14em] text-slate-500">
          {running ? 'Agents au travail' : 'Étapes exécutées'}
        </span>
        <span className="font-mono text-[10px] text-slate-600">
          {done}/{items.length}
        </span>
        <span className="ml-auto text-slate-600" aria-hidden>
          {open ? '▾' : '▸'}
        </span>
      </button>

      {open && (
        <ol className="space-y-1 px-3.5 pb-3 font-mono text-[12px]">
          {items.map((item, index) => {
            const active = !item.finished;
            return (
              <li
                key={index}
                className={[
                  'flex items-start gap-2.5 rounded-md px-2 py-1 transition-colors',
                  active ? 'bg-cyan-500/[0.06]' : '',
                ].join(' ')}
              >
                <span
                  className={[
                    'mt-px shrink-0',
                    active ? 'animate-pulse text-cyan-400' : 'text-emerald-500',
                  ].join(' ')}
                  aria-hidden
                >
                  {active ? (GLYPHS[item.kind] ?? '◆') : '✓'}
                </span>

                <span className="min-w-0 flex-1">
                  <span className={active ? 'text-cyan-100' : 'text-slate-400'}>
                    {item.label}
                  </span>
                  {item.detail && <span className="text-slate-600"> — {item.detail}</span>}
                  {item.result && (
                    <span className="ml-1.5 rounded bg-slate-800/80 px-1.5 py-px text-[10px] text-slate-300">
                      {item.result}
                    </span>
                  )}
                </span>

                {active && <span className="caret shrink-0" aria-hidden />}
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}

/** Applique un événement de progression à la liste (fusionne les fins d'étape). */
export function reduceActivity(
  items: ActivityItem[],
  event: ProgressEvent,
): ActivityItem[] {
  if (event.kind === 'done_step') {
    const reversedIndex = [...items]
      .reverse()
      .findIndex((item) => item.agent === event.agent && !item.finished);
    if (reversedIndex !== -1) {
      const target = items.length - 1 - reversedIndex;
      const next = [...items];
      next[target] = { ...next[target], finished: true, result: event.detail };
      return next;
    }
    return [...items, { ...event, finished: true, result: event.detail }];
  }
  return [...items, { ...event, finished: false }];
}
