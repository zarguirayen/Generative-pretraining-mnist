'use client';

/**
 * Panneau de validation d'un gate.
 *
 * Reprend fidèlement la discipline du kit : la checklist des critères de sortie
 * avec leur preuve, les questions fermées avec option recommandée, et trois
 * décisions possibles. « Valider » reste désactivé tant qu'un critère est rouge —
 * l'utilisateur peut toujours passer outre, mais consciemment.
 */
import { useState } from 'react';
import type { Gate, GateDecision } from '@/lib/api';

interface Props {
  gate: Gate;
  onDecide: (
    decision: GateDecision,
    feedback: string,
    answers: Record<string, string>,
  ) => Promise<void>;
}

export function GatePanel({ gate, onDecide }: Props) {
  const [feedback, setFeedback] = useState('');
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [force, setForce] = useState(false);

  const blocking = gate.checklist.filter(
    (item) => !item.ok && !item.label.toLowerCase().includes('validation explicite'),
  );
  const canApprove = blocking.length === 0 || force;

  async function submit(decision: GateDecision) {
    setSubmitting(true);
    try {
      await onDecide(decision, feedback, answers);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="glass glow-cyan ml-11 rounded-2xl p-5">
      <header className="mb-4 flex items-start gap-3">
        <span
          className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-cyan-500/20 text-sm ring-1 ring-cyan-500/40"
          aria-hidden
        >
          ⏸
        </span>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-cyan-400">
            Décision requise — phase {gate.phase}
          </p>
          <h2 className="text-base font-semibold text-slate-100">{gate.title}</h2>
        </div>
      </header>

      {/* Critères de sortie */}
      <div className="mb-4 space-y-1.5">
        {gate.checklist.map((item, index) => (
          <div key={index} className="flex items-start gap-2 text-sm">
            <span aria-hidden>{item.ok ? '✅' : '⏳'}</span>
            <div>
              <span className={item.ok ? 'text-slate-300' : 'font-medium text-amber-300'}>
                {item.label}
              </span>
              {item.evidence && (
                <span className="ml-2 text-xs text-slate-500">— {item.evidence}</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Questions fermées, option recommandée en premier */}
      {gate.questions.length > 0 && (
        <div className="mb-4 space-y-3">
          {gate.questions.map((question, index) => (
            <fieldset key={index} className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
              <legend className="px-1 text-sm font-medium text-slate-200">
                {question.question}
              </legend>
              <div className="mt-2 flex flex-wrap gap-2">
                {(question.options.length ? question.options : ['Répondre en texte libre']).map(
                  (option) => {
                    const selected = answers[question.question] === option;
                    const recommended = option === question.recommended;
                    return (
                      <button
                        key={option}
                        type="button"
                        onClick={() =>
                          setAnswers((prev) => ({ ...prev, [question.question]: option }))
                        }
                        className={[
                          'rounded-full border px-3 py-1 text-xs transition',
                          selected
                            ? 'border-cyan-500 bg-cyan-500/20 text-cyan-200'
                            : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-cyan-700',
                        ].join(' ')}
                      >
                        {option}
                        {recommended && (
                          <span className="ml-1 opacity-70">(Recommandé)</span>
                        )}
                      </button>
                    );
                  },
                )}
              </div>
            </fieldset>
          ))}
        </div>
      )}

      <textarea
        value={feedback}
        onChange={(event) => setFeedback(event.target.value)}
        placeholder="Retour facultatif — vous pouvez aussi écrire dans la barre du bas."
        rows={2}
        className="mb-3 w-full rounded-lg border border-slate-800 bg-slate-950/70 p-2.5 text-sm text-slate-200 placeholder:text-slate-600 focus:border-cyan-700 focus:outline-none"
      />

      {blocking.length > 0 && (
        <label className="mb-3 flex items-start gap-2 rounded-lg border border-amber-900/50 bg-amber-950/30 p-2.5 text-xs text-amber-200">
          <input
            type="checkbox"
            checked={force}
            onChange={(event) => setForce(event.target.checked)}
            className="mt-0.5"
          />
          <span>
            {blocking.length} critère(s) non satisfait(s). Je valide quand même — cette
            dérogation sera tracée dans les arbitrages du projet.
          </span>
        </label>
      )}

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={!canApprove || submitting}
          onClick={() => submit('approved')}
          className="rounded-lg bg-cyan-500 px-4 py-2 text-sm font-medium text-slate-950 transition hover:bg-cyan-400 disabled:opacity-30"
        >
          Valider et poursuivre
        </button>
        <button
          type="button"
          disabled={submitting}
          onClick={() => submit('changes_requested')}
          className="rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-sm text-slate-200 transition hover:border-slate-600"
        >
          Demander des modifications
        </button>
        <button
          type="button"
          disabled={submitting}
          onClick={() => submit('rejected')}
          className="rounded-lg border border-red-900/60 bg-red-950/30 px-4 py-2 text-sm text-red-300 transition hover:bg-red-950/50"
        >
          Arrêter le pipeline
        </button>
      </div>
    </section>
  );
}
