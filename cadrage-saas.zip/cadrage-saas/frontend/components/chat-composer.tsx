'use client';

/**
 * Barre de saisie de la console.
 *
 * Elle s'adapte à l'état du run, pour qu'il n'y ait jamais de champ inerte :
 *   • agent au travail  → verrouillée, avec l'étape en cours ;
 *   • décision attendue → le texte devient le retour joint à la décision ;
 *   • run terminé       → le texte lance une nouvelle exécution sur le projet.
 */
import { useEffect, useRef, useState } from 'react';

export type ComposerMode = 'busy' | 'gate' | 'idle';

interface Props {
  mode: ComposerMode;
  busyLabel?: string;
  onSubmit: (text: string) => void | Promise<void>;
  quickActions?: { label: string; onClick: () => void; primary?: boolean }[];
}

const PLACEHOLDERS: Record<ComposerMode, string> = {
  busy: 'Les agents travaillent…',
  gate: 'Ajoutez un retour, une correction attendue, une contrainte oubliée…',
  idle: 'Décrivez un nouveau besoin, ou posez une question sur ce projet…',
};

export function ChatComposer({ mode, busyLabel, onSubmit, quickActions = [] }: Props) {
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const areaRef = useRef<HTMLTextAreaElement>(null);

  // Hauteur automatique : la zone grandit avec le texte, jusqu'à 8 lignes.
  useEffect(() => {
    const area = areaRef.current;
    if (!area) return;
    area.style.height = 'auto';
    area.style.height = `${Math.min(area.scrollHeight, 200)}px`;
  }, [text]);

  const disabled = mode === 'busy' || sending;

  async function send() {
    const value = text.trim();
    if (!value || disabled) return;
    setSending(true);
    try {
      await onSubmit(value);
      setText('');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="sticky bottom-0 z-30 pb-5 pt-3">
      {/* Dégradé de fondu : les messages disparaissent sous la barre */}
      <div
        className="pointer-events-none absolute inset-x-0 -top-10 h-10 bg-gradient-to-t from-slate-950 to-transparent"
        aria-hidden
      />

      {quickActions.length > 0 && (
        <div className="mb-2.5 flex flex-wrap gap-2">
          {quickActions.map((action) => (
            <button
              key={action.label}
              type="button"
              onClick={action.onClick}
              className={[
                'rounded-full px-3.5 py-1.5 text-xs transition',
                action.primary
                  ? 'bg-cyan-500 font-medium text-slate-950 hover:bg-cyan-400'
                  : 'border border-slate-700 bg-slate-900/80 text-slate-300 hover:border-cyan-700 hover:text-cyan-200',
              ].join(' ')}
            >
              {action.label}
            </button>
          ))}
        </div>
      )}

      <div
        className={[
          'glass relative overflow-hidden rounded-2xl transition',
          mode === 'gate' && 'glow-cyan',
          disabled && 'opacity-70',
        ]
          .filter(Boolean)
          .join(' ')}
      >
        {mode === 'busy' && (
          <span className="thinking-bar absolute inset-x-0 top-0 h-[2px]" aria-hidden />
        )}

        <div className="flex items-end gap-2 p-2.5">
          <textarea
            ref={areaRef}
            rows={1}
            value={text}
            disabled={disabled}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                void send();
              }
            }}
            placeholder={mode === 'busy' ? (busyLabel ?? PLACEHOLDERS.busy) : PLACEHOLDERS[mode]}
            className="scrollbar-none max-h-[200px] flex-1 resize-none bg-transparent px-2 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none disabled:cursor-not-allowed"
          />

          <button
            type="button"
            onClick={send}
            disabled={disabled || !text.trim()}
            aria-label="Envoyer"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-cyan-500 text-slate-950 transition hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-600"
          >
            {sending ? (
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-slate-950/30 border-t-slate-950" />
            ) : (
              <svg viewBox="0 0 20 20" fill="currentColor" className="h-4 w-4">
                <path d="M2.5 10 17 3.2 12.8 17l-3-5.2-5.2-1z" />
              </svg>
            )}
          </button>
        </div>
      </div>

      <p className="mt-1.5 px-1 text-[10px] text-slate-600">
        <kbd className="font-mono">Entrée</kbd> pour envoyer ·{' '}
        <kbd className="font-mono">Maj+Entrée</kbd> pour aller à la ligne
      </p>
    </div>
  );
}
