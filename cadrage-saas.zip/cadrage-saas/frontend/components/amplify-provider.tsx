'use client';

/** Configuration Amplify (Cognito) et garde d'authentification. */
import { Amplify } from 'aws-amplify';
import { Authenticator, translations } from '@aws-amplify/ui-react';
import { I18n } from 'aws-amplify/utils';
import '@aws-amplify/ui-react/styles.css';

Amplify.configure(
  {
    Auth: {
      Cognito: {
        userPoolId: process.env.NEXT_PUBLIC_COGNITO_USER_POOL_ID ?? '',
        userPoolClientId: process.env.NEXT_PUBLIC_COGNITO_CLIENT_ID ?? '',
      },
    },
  },
  { ssr: true },
);

I18n.putVocabularies(translations);
I18n.setLanguage('fr');

export function AmplifyProvider({ children }: { children: React.ReactNode }) {
  return (
    <Authenticator.Provider>
      <Authenticator
        variation="modal"
        signUpAttributes={['email', 'name']}
        components={{
          Header: () => (
            <div className="px-6 pb-2 pt-6 text-center">
              <p className="text-lg font-semibold text-slate-100">Cadrage</p>
              <p className="text-sm text-slate-400">
                Du besoin flou au plan validé
              </p>
            </div>
          ),
        }}
      >
        {children}
      </Authenticator>
    </Authenticator.Provider>
  );
}
