'use client';

/** Livrables produits, avec aperçu markdown, téléchargement unitaire et export ZIP. */
import { useState } from 'react';
import { api, type Artifact } from '@/lib/api';
import { MarkdownViewer } from '@/components/markdown-viewer';

const KIND_LABELS: Record<string, string> = {
  cadrage: 'Cadrage',
  spec: 'Spécification',
  plan: 'Plan technique',
  tasks: 'Découpage en tâches',
  estimation: 'Estimation',
  revue: 'Revue',
};

interface Props {
  artifacts: Artifact[];
  tenant: string;
  projectId: string;
}

export function ArtifactList({ artifacts, tenant, projectId }: Props) {
  const [preview, setPreview] = useState<{ title: string; content: string } | null>(null);
  const [exporting, setExporting] = useState(false);

  async function open(artifact: Artifact) {
    const full = await api.getArtifact(tenant, projectId, artifact.id);
    setPreview({
      title: `${KIND_LABELS[full.kind] ?? full.kind} ${full.version}`,
      content: full.content,
    });
  }

  async function download(artifact: Artifact) {
    const { url } = await api.downloadArtifact(tenant, projectId, artifact.id);
    window.open(url, '_blank', 'noopener');
  }

  async function exportAll() {
    setExporting(true);
    try {
      await api.exportWorkspace(tenant, projectId);
    } finally {
      setExporting(false);
    }
  }

  return (
    <>
      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
        <header className="mb-3 flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">
            Livrables
          </h2>
          {artifacts.length > 0 && (
            <button
              type="button"
              onClick={exportAll}
              disabled={exporting}
              className="rounded-md border border-cyan-800/60 bg-cyan-500/10 px-2.5 py-1 text-[11px] text-cyan-300 transition hover:bg-cyan-500/20 disabled:opacity-50"
            >
              {exporting ? 'Préparation…' : '↓ Workspace (.zip)'}
            </button>
          )}
        </header>

        {artifacts.length === 0 ? (
          <p className="text-sm text-slate-500">Aucun livrable pour l'instant.</p>
        ) : (
          <ul className="space-y-2">
            {artifacts.map((artifact) => (
              <li
                key={artifact.id}
                className="rounded-lg border border-slate-800 bg-slate-950/50 p-3 transition hover:border-slate-700"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-medium text-slate-200">
                    {KIND_LABELS[artifact.kind] ?? artifact.kind}
                  </span>
                  <span className="rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[11px] text-cyan-300">
                    {artifact.version}
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  {(artifact.size_bytes / 1024).toFixed(1)} ko · {artifact.status}
                </p>
                <div className="mt-2 flex gap-3 text-[11px]">
                  <button type="button" onClick={() => open(artifact)} className="text-cyan-400 hover:underline">
                    Aperçu
                  </button>
                  <button type="button" onClick={() => download(artifact)} className="text-slate-400 hover:underline">
                    Télécharger .md
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {preview && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-8 backdrop-blur-sm"
          onClick={() => setPreview(null)}
        >
          <div
            className="max-h-full w-full max-w-4xl overflow-auto rounded-xl border border-slate-700 bg-slate-900 p-6"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-semibold text-slate-100">{preview.title}</h3>
              <button
                type="button"
                onClick={() => setPreview(null)}
                className="text-slate-500 hover:text-slate-300"
              >
                ✕
              </button>
            </div>
            <MarkdownViewer content={preview.content} />
          </div>
        </div>
      )}
    </>
  );
}
