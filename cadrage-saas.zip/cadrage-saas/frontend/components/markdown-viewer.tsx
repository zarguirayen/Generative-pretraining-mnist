'use client';

/**
 * Rendu des livrables Markdown.
 *
 * Les documents du kit contiennent beaucoup de tableaux (objectifs, risques,
 * hypothèses, traçabilité) : le rendu GFM est indispensable, un `<pre>` rendrait
 * les livrables illisibles.
 */
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface Props {
  content: string;
  className?: string;
}

export function MarkdownViewer({ content, className = '' }: Props) {
  return (
    <div className={`prose-doc ${className}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Les tableaux larges (traçabilité, estimation) défilent horizontalement
          // au lieu de casser la mise en page.
          table: ({ children }) => (
            <div className="overflow-x-auto">
              <table>{children}</table>
            </div>
          ),
          input: ({ checked }) => (
            <span className="mr-1.5" aria-hidden>
              {checked ? '✅' : '⬜'}
            </span>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}

/** Extrait le titre principal d'un document (première ligne `# …`). */
export function documentTitle(content: string, fallback = 'Document'): string {
  const match = content.match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : fallback;
}
