/**
 * Fil d'Ariane du pipeline — repris du kit : l'utilisateur doit toujours savoir
 * où il en est, ce qui est validé et ce qui vient ensuite.
 */
const STEPS = [
  { key: 'cadrage', label: 'Cadrage' },
  { key: 'spec_writer', label: 'Spécification' },
  { key: 'planner', label: 'Plan' },
  { key: 'estimateur', label: 'Estimation' },
] as const;

// Parcours indépendants : ils ne suivent pas les quatre phases du pipeline.
const STANDALONE: Record<string, string> = {
  reviewer: 'Revue de code',
  bugfix: 'Correction de bug',
};

export function PipelineBreadcrumb({ current }: { current: string }) {
  if (STANDALONE[current]) {
    return (
      <nav aria-label="Parcours" className="flex items-center gap-2 text-sm">
        <span aria-hidden>📍</span>
        <span className="rounded-full bg-cyan-500/20 px-2.5 py-0.5 font-medium text-cyan-200 ring-1 ring-cyan-600/50">
          {STANDALONE[current]}
        </span>
        <span className="text-xs text-slate-600">parcours indépendant du pipeline</span>
      </nav>
    );
  }

  const index = STEPS.findIndex((step) => step.key === current);

  return (
    <nav aria-label="Progression du pipeline" className="flex items-center gap-2 text-sm">
      <span aria-hidden>📍</span>
      {STEPS.map((step, position) => {
        const done = index > position;
        const active = index === position;
        return (
          <span key={step.key} className="flex items-center gap-2">
            <span
              className={[
                'rounded-full px-2.5 py-0.5 transition',
                active && 'bg-cyan-500/20 font-medium text-cyan-200 ring-1 ring-cyan-600/50',
                done && 'text-emerald-400',
                !active && !done && 'text-slate-600',
              ]
                .filter(Boolean)
                .join(' ')}
            >
              {done ? '✓ ' : `${position + 1} `}
              {step.label}
            </span>
            {position < STEPS.length - 1 && <span className="text-slate-700">→</span>}
          </span>
        );
      })}
    </nav>
  );
}
