'use client';

/**
 * Bulle de conversation.
 *
 * Les messages d'agents portent la couleur de leur rôle : on suit d'un coup d'œil
 * qui parle quand quatre agents se relaient dans un même fil. Le contenu est rendu
 * en Markdown — les livrables sont denses en tableaux.
 */
import { MarkdownViewer } from '@/components/markdown-viewer';

export interface ChatAgent {
  label: string;
  initials: string;
  accent: string;   // couleur de l'anneau et de la barre latérale
  glow: string;
}

export const AGENTS: Record<string, ChatAgent> = {
  orchestrateur: { label: 'Orchestrateur', initials: 'OR', accent: 'text-violet-300 ring-violet-500/40', glow: 'bg-violet-500' },
  cadrage: { label: 'Cadrage', initials: 'CA', accent: 'text-cyan-300 ring-cyan-500/40', glow: 'bg-cyan-500' },
  spec_writer: { label: 'Spécification', initials: 'SP', accent: 'text-sky-300 ring-sky-500/40', glow: 'bg-sky-500' },
  planner: { label: 'Plan technique', initials: 'PL', accent: 'text-emerald-300 ring-emerald-500/40', glow: 'bg-emerald-500' },
  estimateur: { label: 'Estimation', initials: 'ES', accent: 'text-amber-300 ring-amber-500/40', glow: 'bg-amber-500' },
  reviewer: { label: 'Revue de code', initials: 'RV', accent: 'text-rose-300 ring-rose-500/40', glow: 'bg-rose-500' },
  bugfix: { label: 'Correction de bug', initials: 'BF', accent: 'text-orange-300 ring-orange-500/40', glow: 'bg-orange-500' },
};

const FALLBACK: ChatAgent = {
  label: 'Agent',
  initials: 'AI',
  accent: 'text-slate-300 ring-slate-600/40',
  glow: 'bg-slate-500',
};

export function AgentMessage({
  agent,
  content,
  timestamp,
}: {
  agent: string;
  content: string;
  timestamp?: string;
}) {
  const meta = AGENTS[agent] ?? FALLBACK;

  return (
    <article className="msg-enter flex gap-3.5">
      <div className="relative shrink-0">
        <span
          className={`grid h-8 w-8 place-items-center rounded-lg bg-slate-900 font-mono text-[10px] font-semibold ring-1 ${meta.accent}`}
        >
          {meta.initials}
        </span>
        <span
          className={`absolute inset-0 -z-10 rounded-lg opacity-20 blur-md ${meta.glow}`}
          aria-hidden
        />
      </div>

      <div className="min-w-0 flex-1">
        <header className="mb-1.5 flex items-baseline gap-2">
          <span className={`text-xs font-medium ${meta.accent.split(' ')[0]}`}>
            {meta.label}
          </span>
          {timestamp && (
            <time className="font-mono text-[10px] text-slate-600">{timestamp}</time>
          )}
        </header>

        <div className="rounded-2xl rounded-tl-sm border border-slate-800/80 bg-slate-900/50 px-4 py-3">
          <MarkdownViewer content={content} />
        </div>
      </div>
    </article>
  );
}

export function UserMessage({ content }: { content: string }) {
  return (
    <article className="msg-enter flex justify-end gap-3.5">
      <div className="max-w-[75%] rounded-2xl rounded-tr-sm bg-cyan-500/15 px-4 py-2.5 ring-1 ring-cyan-500/25">
        <p className="whitespace-pre-wrap text-sm leading-relaxed text-cyan-50">{content}</p>
      </div>
    </article>
  );
}

/** Le système parle : amorçage, changement de phase, mise à jour du contexte. */
export function SystemNote({ children }: { children: React.ReactNode }) {
  return (
    <p className="msg-enter flex items-center gap-3 py-1 text-center text-[11px] text-slate-600">
      <span className="h-px flex-1 bg-slate-800" aria-hidden />
      <span>{children}</span>
      <span className="h-px flex-1 bg-slate-800" aria-hidden />
    </p>
  );
}
