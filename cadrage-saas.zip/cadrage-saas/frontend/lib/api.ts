/**
 * Client API typé.
 *
 * Le `tenantSlug` est présent dans toutes les URL : l'utilisateur peut appartenir
 * à plusieurs organisations, et le backend vérifie systématiquement l'appartenance.
 */
import { fetchAuthSession } from 'aws-amplify/auth';

const BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000/api/v1';

export type RunStatus =
  | 'pending' | 'running' | 'waiting_human' | 'completed' | 'failed' | 'cancelled';
export type Phase =
  | 'orchestration' | 'cadrage' | 'specification' | 'plan' | 'estimation' | 'revue';
export type GateDecision = 'approved' | 'changes_requested' | 'rejected';

export interface Project {
  id: string; name: string; slug: string; description: string | null;
  scale_level: number; scenario: string;
  steering: Record<string, string>; created_at: string;
}

export interface Run {
  id: string; status: RunStatus; current_phase: Phase;
  initial_prompt: string; review_scope: string;
  created_at: string; finished_at: string | null; error: string | null;
}

export interface ChecklistItem { label: string; ok: boolean; evidence: string }

export interface GatePayload {
  phase: Phase; title: string; summary: string;
  checklist: ChecklistItem[];
  questions: { question: string; options: string[]; recommended: string | null }[];
  artifact_kind: string | null;
}

export interface Gate extends GatePayload {
  id: string; decision: 'pending' | GateDecision; created_at: string;
}

export interface Artifact {
  id: string; kind: string; title: string; version: string;
  status: string; size_bytes: number; created_at: string;
}

export interface ProgressEvent {
  type: 'progress';
  kind: 'step' | 'subagent' | 'thinking' | 'writing' | 'checking' | 'done_step';
  agent: string;
  label: string;
  detail: string;
  verdict?: string | null;
  findings?: number;
}

export interface UsageSummary {
  plan: 'free' | 'pro' | 'enterprise';
  subscription_active: boolean;
  usage: { runs: number; input_tokens: number; output_tokens: number; cost_cents: number; projects: number };
  limits: { runs_per_month: number; tokens_per_month: number; projects: number; seats: number };
}

async function authHeaders(): Promise<HeadersInit> {
  const session = await fetchAuthSession();
  const token = session.tokens?.idToken?.toString();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE}${path}`, {
    ...init,
    headers: { ...(await authHeaders()), ...(init?.headers ?? {}) },
  });

  if (response.status === 402) {
    const detail = await response.json();
    throw new QuotaError(detail.quota ?? 'quota', detail.used ?? 0, detail.limit ?? 0);
  }
  if (!response.ok) {
    throw new Error(`${response.status} — ${await response.text()}`);
  }
  return response.status === 204 ? (undefined as T) : response.json();
}

export class QuotaError extends Error {
  constructor(readonly quota: string, readonly used: number, readonly limit: number) {
    super(`Quota « ${quota} » atteint : ${used}/${limit}`);
  }
}

export const api = {
  // ── Organisations ────────────────────────────────────────────
  myTenants: () => request<{ id: string; name: string; slug: string; plan: string }[]>('/tenants'),
  createTenant: (name: string) =>
    request<{ slug: string }>('/tenants', { method: 'POST', body: JSON.stringify({ name }) }),

  // ── Projets ──────────────────────────────────────────────────
  listProjects: (t: string) => request<Project[]>(`/${t}/projects`),
  getProject: (t: string, id: string) => request<Project>(`/${t}/projects/${id}`),
  createProject: (t: string, name: string, description?: string) =>
    request<Project>(`/${t}/projects`, {
      method: 'POST',
      body: JSON.stringify({ name, description }),
    }),
  updateSteering: (t: string, id: string, steering: Partial<Record<string, string>>) =>
    request<Project>(`/${t}/projects/${id}/steering`, {
      method: 'PUT',
      body: JSON.stringify(steering),
    }),

  // ── Runs ─────────────────────────────────────────────────────
  listRuns: (t: string, p: string) => request<Run[]>(`/${t}/projects/${p}/runs`),

  /** Démarre une exécution. `code_context` n'est requis que pour revue et bugfix. */
  startRun: (
    t: string,
    p: string,
    payload: {
      prompt: string;
      entry_phase?: Phase;
      code_context?: Record<string, string>;
      review_scope?: 'diff' | 'module' | 'codebase';
    },
  ) =>
    request<Run>(`/${t}/projects/${p}/runs`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  listGates: (t: string, p: string, r: string) =>
    request<Gate[]>(`/${t}/projects/${p}/runs/${r}/gates`),
  decideGate: (t: string, p: string, r: string, g: string, body: {
    decision: GateDecision; feedback?: string; answers?: Record<string, string>;
  }) =>
    request<Run>(`/${t}/projects/${p}/runs/${r}/gates/${g}`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // ── Artefacts ────────────────────────────────────────────────
  listArtifacts: (t: string, p: string) => request<Artifact[]>(`/${t}/projects/${p}/artifacts`),
  getArtifact: (t: string, p: string, a: string) =>
    request<Artifact & { content: string }>(`/${t}/projects/${p}/artifacts/${a}/content`),
  downloadArtifact: (t: string, p: string, a: string) =>
    request<{ url: string }>(`/${t}/projects/${p}/artifacts/${a}/download`),

  /** Télécharge tout le workspace (steering + livrables) en ZIP. */
  exportWorkspace: async (t: string, p: string) => {
    const response = await fetch(`${BASE}/${t}/projects/${p}/export`, {
      headers: await authHeaders(),
    });
    if (!response.ok) throw new Error(`Export impossible (${response.status})`);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `workspace-${p}.zip`;
    link.click();
    URL.revokeObjectURL(url);
  },

  // ── Facturation ──────────────────────────────────────────────
  usage: (t: string) => request<UsageSummary>(`/${t}/billing/usage`),
  checkout: (t: string, plan: 'pro' | 'enterprise') =>
    request<{ url: string }>(`/${t}/billing/checkout`, {
      method: 'POST',
      body: JSON.stringify({
        plan,
        success_url: `${window.location.origin}/${t}/settings/billing?ok=1`,
        cancel_url: `${window.location.origin}/${t}/settings/billing`,
      }),
    }),
};

/**
 * Flux SSE d'un run. `EventSource` n'accepte pas d'en-tête d'autorisation :
 * on lit donc le flux via `fetch` + ReadableStream.
 */
export async function* streamRun(
  tenant: string,
  projectId: string,
  runId: string,
  mode: 'stream' | 'resume' = 'stream',
): AsyncGenerator<{ type: string; [k: string]: unknown }> {
  const response = await fetch(
    `${BASE}/${tenant}/projects/${projectId}/runs/${runId}/${mode}`,
    { headers: await authHeaders() },
  );
  if (!response.body) return;

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const frames = buffer.split('\n\n');
    buffer = frames.pop() ?? '';
    for (const frame of frames) {
      const line = frame.split('\n').find((l) => l.startsWith('data:'));
      if (!line) continue;
      try {
        yield JSON.parse(line.slice(5).trim());
      } catch {
        /* trame partielle : ignorée */
      }
    }
  }
}
