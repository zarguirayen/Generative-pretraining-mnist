import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import { AmplifyProvider } from '@/components/amplify-provider';
import './globals.css';

const sans = Inter({ subsets: ['latin'], variable: '--font-sans' });
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
  title: 'Cadrage — plateforme de cadrage projet',
  description:
    'Du besoin flou au plan validé : cadrage, spécification, plan, estimation et revue, pilotés par des agents.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${sans.variable} ${mono.variable}`}>
      <body className="min-h-screen bg-slate-950 font-sans text-slate-100 antialiased">
        <AmplifyProvider>{children}</AmplifyProvider>
      </body>
    </html>
  );
}
