'use client';

/** Point d'entrée : redirige vers l'organisation, ou propose d'en créer une. */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';

export default function HomePage() {
  const router = useRouter();
  const [tenants, setTenants] = useState<{ slug: string; name: string }[] | null>(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.myTenants().then((list) => {
      if (list.length === 1) {
        router.replace(`/${list[0].slug}`);
        return;
      }
      setTenants(list);
    });
  }, [router]);

  async function create(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      const tenant = await api.createTenant(name);
      router.push(`/${tenant.slug}`);
    } finally {
      setBusy(false);
    }
  }

  if (tenants === null) {
    return (
      <div className="grid min-h-screen place-items-center">
        <p className="animate-pulse text-sm text-slate-500">Chargement…</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-20">
      <h1 className="mb-2 text-2xl font-semibold tracking-tight">
        {tenants.length ? 'Vos organisations' : 'Créez votre organisation'}
      </h1>
      <p className="mb-8 text-sm text-slate-400">
        Une organisation regroupe vos projets, vos livrables et votre abonnement.
      </p>

      {tenants.length > 0 && (
        <ul className="mb-8 space-y-2">
          {tenants.map((tenant) => (
            <li key={tenant.slug}>
              <button
                type="button"
                onClick={() => router.push(`/${tenant.slug}`)}
                className="card w-full p-4 text-left transition hover:border-cyan-800"
              >
                <span className="text-slate-100">{tenant.name}</span>
                <span className="ml-2 font-mono text-xs text-slate-600">/{tenant.slug}</span>
              </button>
            </li>
          ))}
        </ul>
      )}

      <form onSubmit={create} className="card space-y-3 p-5">
        <label htmlFor="tenant-name" className="block text-sm text-slate-300">
          {tenants.length ? 'Nouvelle organisation' : 'Nom de votre organisation'}
        </label>
        <input
          id="tenant-name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Ex. Direction produit"
          className="field"
          minLength={2}
          required
        />
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? 'Création…' : 'Créer'}
        </button>
      </form>
    </div>
  );
}
