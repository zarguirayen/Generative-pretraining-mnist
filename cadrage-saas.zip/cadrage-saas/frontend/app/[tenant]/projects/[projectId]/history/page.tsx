'use client';

/**
 * Historique du projet : toutes les versions de tous les livrables, et les
 * décisions prises aux gates.
 *
 * C'est la trace d'audit : qui a validé quoi, quand, et ce que le document
 * contenait à ce moment-là.
 */
import { useState } from 'react';
import { useParams } from 'next/navigation';
import useSWR from 'swr';
import { api, type Artifact } from '@/lib/api';
import { MarkdownViewer } from '@/components/markdown-viewer';

const KIND_LABELS: Record<string, string> = {
  cadrage: 'Cadrage',
  spec: 'Spécification',
  plan: 'Plan technique',
  tasks: 'Tâches',
  estimation: 'Estimation',
  revue: 'Revue',
  steering: 'Contexte projet',
};

export default function HistoryPage() {
  const { tenant, projectId } = useParams<{ tenant: string; projectId: string }>();
  const { data: artifacts } = useSWR(`artifacts:${projectId}`, () =>
    api.listArtifacts(tenant, projectId),
  );
  const { data: runs } = useSWR(`runs:${projectId}`, () => api.listRuns(tenant, projectId));
  const [preview, setPreview] = useState<{ artifact: Artifact; content: string } | null>(null);

  // Regroupement par type, du plus récent au plus ancien.
  const byKind = new Map<string, Artifact[]>();
  for (const artifact of artifacts ?? []) {
    byKind.set(artifact.kind, [...(byKind.get(artifact.kind) ?? []), artifact]);
  }

  async function open(artifact: Artifact) {
    const full = await api.getArtifact(tenant, projectId, artifact.id);
    setPreview({ artifact, content: full.content });
  }

  return (
    <div className="space-y-6">
      <section className="card p-5">
        <h2 className="mb-1 text-sm font-semibold text-slate-200">Exécutions</h2>
        <p className="mb-4 text-xs text-slate-500">
          {runs?.length ?? 0} exécution(s) — chaque passage dans le pipeline.
        </p>
        <ol className="relative space-y-3 border-l border-slate-800 pl-5">
          {runs?.map((run) => (
            <li key={run.id} className="relative">
              <span
                className={[
                  'absolute -left-[1.4rem] top-1.5 h-2 w-2 rounded-full',
                  run.status === 'completed'
                    ? 'bg-emerald-400'
                    : run.status === 'failed'
                      ? 'bg-red-400'
                      : run.status === 'waiting_human'
                        ? 'bg-amber-400'
                        : 'bg-slate-600',
                ].join(' ')}
                aria-hidden
              />
              <div className="flex items-baseline gap-3">
                <span className="text-sm text-slate-300">
                  {KIND_LABELS[run.current_phase] ?? run.current_phase}
                </span>
                <span className="font-mono text-[11px] text-slate-600">
                  {new Date(run.created_at).toLocaleString('fr-FR')}
                </span>
              </div>
              {run.error && (
                <p className="mt-0.5 text-xs text-red-400">{run.error}</p>
              )}
            </li>
          ))}
        </ol>
      </section>

      <section className="card p-5">
        <h2 className="mb-1 text-sm font-semibold text-slate-200">Versions des livrables</h2>
        <p className="mb-4 text-xs text-slate-500">
          Chaque itération est conservée : on peut relire ce qui a été validé à un
          instant donné.
        </p>

        <div className="space-y-5">
          {[...byKind.entries()].map(([kind, versions]) => (
            <div key={kind}>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">
                {KIND_LABELS[kind] ?? kind}
              </h3>
              <ul className="flex flex-wrap gap-2">
                {versions.map((artifact, index) => (
                  <li key={artifact.id}>
                    <button
                      type="button"
                      onClick={() => open(artifact)}
                      className={[
                        'rounded-lg border px-3 py-2 text-left transition',
                        index === 0
                          ? 'border-cyan-800 bg-cyan-500/10 hover:border-cyan-600'
                          : 'border-slate-800 hover:border-slate-700',
                      ].join(' ')}
                    >
                      <span className="font-mono text-xs text-slate-200">{artifact.version}</span>
                      {index === 0 && (
                        <span className="ml-1.5 text-[10px] text-cyan-400">actuelle</span>
                      )}
                      <span className="mt-0.5 block text-[10px] text-slate-500">
                        {new Date(artifact.created_at).toLocaleDateString('fr-FR')} ·{' '}
                        {(artifact.size_bytes / 1024).toFixed(1)} ko
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          {byKind.size === 0 && (
            <p className="text-sm text-slate-500">Aucun livrable pour l'instant.</p>
          )}
        </div>
      </section>

      {preview && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-8 backdrop-blur-sm"
          onClick={() => setPreview(null)}
        >
          <div
            className="max-h-full w-full max-w-4xl overflow-auto rounded-xl border border-slate-700 bg-slate-900"
            onClick={(event) => event.stopPropagation()}
          >
            <header className="sticky top-0 flex items-center justify-between border-b border-slate-800 bg-slate-900 px-6 py-3">
              <h3 className="text-sm font-semibold">
                {KIND_LABELS[preview.artifact.kind] ?? preview.artifact.kind}{' '}
                <span className="font-mono text-xs text-slate-500">
                  {preview.artifact.version}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setPreview(null)}
                className="text-slate-500 hover:text-slate-300"
              >
                ✕
              </button>
            </header>
            <div className="px-6 py-5">
              <MarkdownViewer content={preview.content} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
