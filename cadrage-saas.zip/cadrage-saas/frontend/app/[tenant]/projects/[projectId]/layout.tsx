'use client';

import Link from 'next/link';
import { usePathname, useParams } from 'next/navigation';
import useSWR from 'swr';
import { api } from '@/lib/api';

const TABS = [
  { href: '', label: 'Exécutions' },
  { href: '/deliverables', label: 'Livrables' },
  { href: '/steering', label: 'Contexte projet' },
  { href: '/history', label: 'Historique' },
];

export default function ProjectLayout({ children }: { children: React.ReactNode }) {
  const { tenant, projectId } = useParams<{ tenant: string; projectId: string }>();
  const pathname = usePathname();
  const { data: project } = useSWR(`project:${projectId}`, () =>
    api.getProject(tenant, projectId),
  );

  const base = `/${tenant}/projects/${projectId}`;
  // La console d'un run occupe tout l'écran : pas d'onglets par-dessus.
  const isRunConsole = pathname.includes('/runs/');
  if (isRunConsole) return <>{children}</>;

  return (
    <div className="mx-auto max-w-[1400px] px-6 py-5">
      <nav className="mb-1 text-xs text-slate-500">
        <Link href={`/${tenant}`} className="hover:text-slate-300">
          Projets
        </Link>
        <span className="mx-1.5" aria-hidden>
          /
        </span>
        <span className="text-slate-400">{project?.name ?? '…'}</span>
      </nav>

      <h1 className="mb-5 text-xl font-semibold tracking-tight">
        {project?.name ?? 'Chargement…'}
      </h1>

      <div className="mb-6 flex gap-1 border-b border-slate-800">
        {TABS.map((tab) => {
          const href = `${base}${tab.href}`;
          const active = tab.href === '' ? pathname === base : pathname.startsWith(href);
          return (
            <Link
              key={tab.href}
              href={href}
              className={[
                '-mb-px border-b-2 px-3.5 py-2 text-sm transition',
                active
                  ? 'border-cyan-500 text-cyan-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200',
              ].join(' ')}
            >
              {tab.label}
            </Link>
          );
        })}
      </div>

      {children}
    </div>
  );
}
