'use client';

/**
 * Récupération des livrables : la page de sortie du produit.
 *
 * L'utilisateur y trouve tout ce que le pipeline a produit — lecture, copie,
 * téléchargement fichier par fichier ou en archive reproduisant l'arborescence
 * d'un dépôt (steering/ + docs/…).
 */
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import useSWR from 'swr';
import { api, type Artifact } from '@/lib/api';
import { MarkdownViewer } from '@/components/markdown-viewer';

const KINDS: { id: string; label: string; path: string; hint: string }[] = [
  { id: 'cadrage', label: 'Cadrage', path: 'docs/cadrage/', hint: 'Problème, objectifs, périmètre, risques' },
  { id: 'spec', label: 'Spécification', path: 'docs/specs/', hint: 'Exigences EARS, invariants, traçabilité' },
  { id: 'plan', label: 'Plan technique', path: 'docs/plans/', hint: 'Architecture, propriétés de correction' },
  { id: 'tasks', label: 'Tâches', path: 'docs/plans/', hint: 'Capsules autonomes, checkpoints' },
  { id: 'estimation', label: 'Estimation', path: 'docs/estimates/', hint: 'Jours-homme, confiance, variantes' },
  { id: 'revue', label: 'Revue', path: 'docs/reviews/', hint: 'Constats, verdict GO/NO-GO' },
];

export default function DeliverablesPage() {
  const { tenant, projectId } = useParams<{ tenant: string; projectId: string }>();
  const { data: artifacts } = useSWR(`artifacts:${projectId}`, () =>
    api.listArtifacts(tenant, projectId),
  );
  const [selected, setSelected] = useState<Artifact | null>(null);
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [copied, setCopied] = useState(false);

  // Dernière version de chaque type de livrable.
  const latest = new Map<string, Artifact>();
  for (const artifact of artifacts ?? []) {
    if (!latest.has(artifact.kind)) latest.set(artifact.kind, artifact);
  }

  useEffect(() => {
    const first = KINDS.map((k) => latest.get(k.id)).find(Boolean);
    if (first && !selected) setSelected(first);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [artifacts]);

  useEffect(() => {
    if (!selected) return;
    setLoading(true);
    api
      .getArtifact(tenant, projectId, selected.id)
      .then((full) => setContent(full.content))
      .finally(() => setLoading(false));
  }, [selected, tenant, projectId]);

  async function copy() {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  async function exportAll() {
    setExporting(true);
    try {
      await api.exportWorkspace(tenant, projectId);
    } finally {
      setExporting(false);
    }
  }

  const produced = KINDS.filter((kind) => latest.has(kind.id));

  if (!artifacts?.length) {
    return (
      <div className="card p-10 text-center">
        <p className="text-slate-300">Aucun livrable produit.</p>
        <p className="mt-1 text-sm text-slate-500">
          Lancez une exécution : chaque phase validée dépose son document ici.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="card flex flex-wrap items-center gap-4 p-4">
        <div className="flex-1">
          <p className="text-sm font-medium text-slate-200">
            {produced.length} livrable(s) — dernière version de chacun
          </p>
          <p className="mt-0.5 text-xs text-slate-500">
            L'archive reproduit l'arborescence d'un dépôt : <code className="font-mono">steering/</code>,{' '}
            <code className="font-mono">docs/cadrage/</code>, <code className="font-mono">docs/specs/</code>…
          </p>
        </div>
        <button type="button" onClick={exportAll} disabled={exporting} className="btn-primary">
          {exporting ? 'Préparation…' : '↓ Tout télécharger (.zip)'}
        </button>
      </div>

      <div className="flex gap-5">
        {/* Sélecteur de livrable */}
        <nav className="w-64 shrink-0 space-y-1.5">
          {KINDS.map((kind) => {
            const artifact = latest.get(kind.id);
            const active = selected?.id === artifact?.id;
            return (
              <button
                key={kind.id}
                type="button"
                disabled={!artifact}
                onClick={() => artifact && setSelected(artifact)}
                className={[
                  'w-full rounded-lg border p-3 text-left transition',
                  !artifact && 'cursor-default border-slate-900 opacity-35',
                  artifact && !active && 'border-slate-800 hover:border-slate-700',
                  active && 'border-cyan-700 bg-cyan-500/10',
                ]
                  .filter(Boolean)
                  .join(' ')}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className={active ? 'text-sm text-cyan-200' : 'text-sm text-slate-200'}>
                    {kind.label}
                  </span>
                  {artifact && (
                    <span className="rounded bg-slate-800 px-1.5 font-mono text-[10px] text-slate-400">
                      {artifact.version}
                    </span>
                  )}
                </div>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  {artifact ? kind.hint : 'non produit'}
                </p>
              </button>
            );
          })}
        </nav>

        {/* Lecture du document */}
        <section className="card min-w-0 flex-1">
          {selected && (
            <header className="flex items-center gap-3 border-b border-slate-800 px-5 py-3">
              <span className="font-mono text-xs text-slate-500">
                {KINDS.find((k) => k.id === selected.kind)?.path}
                {selected.kind}-{selected.version}.md
              </span>
              <div className="ml-auto flex gap-2">
                <button type="button" onClick={copy} className="btn-ghost px-3 py-1 text-xs">
                  {copied ? 'Copié ✓' : 'Copier'}
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const { url } = await api.downloadArtifact(tenant, projectId, selected.id);
                    window.open(url, '_blank', 'noopener');
                  }}
                  className="btn-ghost px-3 py-1 text-xs"
                >
                  Télécharger .md
                </button>
              </div>
            </header>
          )}

          <div className="max-h-[calc(100vh-20rem)] overflow-auto px-6 py-5">
            {loading ? (
              <p className="animate-pulse text-sm text-slate-500">Chargement…</p>
            ) : (
              <MarkdownViewer content={content} />
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
