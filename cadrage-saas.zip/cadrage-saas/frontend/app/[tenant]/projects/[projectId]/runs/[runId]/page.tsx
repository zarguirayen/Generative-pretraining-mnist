'use client';

/**
 * Console conversationnelle d'une exécution.
 *
 * Un seul fil : la demande de l'utilisateur, la trace d'activité des agents, leurs
 * réponses, et le panneau de décision quand une phase atteint son point de
 * validation. La barre de saisie reste toujours accessible et s'adapte à l'état.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import useSWR from 'swr';
import {
  api,
  streamRun,
  type Artifact,
  type Gate,
  type GateDecision,
  type ProgressEvent,
} from '@/lib/api';
import { AgentActivity, reduceActivity, type ActivityItem } from '@/components/agent-activity';
import { AgentMessage, SystemNote, UserMessage } from '@/components/chat-message';
import { ChatComposer, type ComposerMode } from '@/components/chat-composer';
import { GatePanel } from '@/components/gate-panel';
import { PipelineBreadcrumb } from '@/components/pipeline-breadcrumb';
import { ArtifactList } from '@/components/artifact-list';

type Entry =
  | { kind: 'user'; content: string }
  | { kind: 'agent'; agent: string; content: string; at: string }
  | { kind: 'activity'; items: ActivityItem[] }
  | { kind: 'note'; content: string };

export default function RunConsolePage() {
  const { tenant, projectId, runId } = useParams<{
    tenant: string; projectId: string; runId: string;
  }>();
  const router = useRouter();

  const [entries, setEntries] = useState<Entry[]>([]);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [gate, setGate] = useState<Gate | null>(null);
  const [phase, setPhase] = useState('orchestration');
  const [running, setRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [panelOpen, setPanelOpen] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: run } = useSWR(`run:${runId}`, async () => {
    const runs = await api.listRuns(tenant, projectId);
    return runs.find((item) => item.id === runId) ?? null;
  });

  // La demande initiale ouvre le fil.
  useEffect(() => {
    if (run?.initial_prompt && entries.length === 0) {
      setEntries([{ kind: 'user', content: run.initial_prompt }]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [run]);

  /** Ajoute un événement de progression dans le dernier bloc d'activité ouvert. */
  const pushActivity = useCallback((event: ProgressEvent) => {
    setEntries((prev) => {
      const last = prev[prev.length - 1];
      if (last?.kind === 'activity') {
        const next = [...prev];
        next[next.length - 1] = { kind: 'activity', items: reduceActivity(last.items, event) };
        return next;
      }
      return [...prev, { kind: 'activity', items: reduceActivity([], event) }];
    });
    if (event.kind !== 'done_step') setCurrentStep(event.label);
  }, []);

  const consume = useCallback(
    async (mode: 'stream' | 'resume') => {
      setRunning(true);
      setError(null);
      try {
        for await (const event of streamRun(tenant, projectId, runId, mode)) {
          switch (event.type) {
            case 'progress':
              pushActivity(event as unknown as ProgressEvent);
              break;

            case 'message':
              setEntries((prev) => [
                ...prev,
                {
                  kind: 'agent',
                  agent: String(event.agent),
                  content: String(event.content),
                  at: new Date().toLocaleTimeString('fr-FR', {
                    hour: '2-digit', minute: '2-digit',
                  }),
                },
              ]);
              setPhase(String(event.agent));
              break;

            case 'artifact':
              setArtifacts(await api.listArtifacts(tenant, projectId));
              break;

            case 'steering':
              setEntries((prev) => [
                ...prev,
                {
                  kind: 'note',
                  content: `Contexte du projet mis à jour (${(event.keys as string[])?.join(', ')})`,
                },
              ]);
              break;

            case 'gate': {
              const gates = await api.listGates(tenant, projectId, runId);
              const pending = gates.find((item) => item.decision === 'pending');
              if (pending) {
                setGate({ ...pending, ...(event.data as object) } as Gate);
                setPanelOpen(true);
              }
              break;
            }

            case 'error':
              setError(String(event.message));
              break;
          }
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setRunning(false);
        setCurrentStep('');
      }
    },
    [tenant, projectId, runId, pushActivity],
  );

  useEffect(() => {
    void consume('stream');
  }, [consume]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [entries, gate]);

  async function decide(
    decision: GateDecision,
    feedback: string,
    answers: Record<string, string>,
  ) {
    if (!gate) return;
    if (feedback.trim()) {
      setEntries((prev) => [...prev, { kind: 'user', content: feedback }]);
    }
    await api.decideGate(tenant, projectId, runId, gate.id, { decision, feedback, answers });
    setGate(null);
    setEntries((prev) => [
      ...prev,
      {
        kind: 'note',
        content:
          decision === 'approved'
            ? 'Phase validée — passage à la suivante'
            : decision === 'changes_requested'
              ? 'Modifications demandées — reprise de la phase'
              : 'Pipeline arrêté',
      },
    ]);
    if (decision !== 'rejected') await consume('resume');
  }

  /** La barre de saisie : retour joint au gate, ou nouvelle exécution. */
  async function submitText(text: string) {
    if (gate) {
      await decide('changes_requested', text, {});
      return;
    }
    const created = await api.startRun(tenant, projectId, { prompt: text });
    router.push(`/${tenant}/projects/${projectId}/runs/${created.id}`);
  }

  const mode: ComposerMode = running ? 'busy' : gate ? 'gate' : 'idle';

  return (
    <div className="bg-aurora min-h-screen">
      <div className="mx-auto flex max-w-[1500px] gap-6 px-6">
        {/* ── Fil de conversation ─────────────────────────────── */}
        <main className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 -mx-2 flex items-center gap-4 bg-slate-950/70 px-2 py-4 backdrop-blur">
            <PipelineBreadcrumb current={phase} />
            <Link
              href={`/${tenant}/projects/${projectId}`}
              className="ml-auto text-xs text-slate-500 transition hover:text-slate-300"
            >
              ← Projet
            </Link>
          </header>

          <div className="flex-1 space-y-5 py-2">
            {entries.map((entry, index) => {
              switch (entry.kind) {
                case 'user':
                  return <UserMessage key={index} content={entry.content} />;
                case 'agent':
                  return (
                    <AgentMessage
                      key={index}
                      agent={entry.agent}
                      content={entry.content}
                      timestamp={entry.at}
                    />
                  );
                case 'activity':
                  return (
                    <AgentActivity
                      key={index}
                      items={entry.items}
                      running={running && index === entries.length - 1}
                    />
                  );
                case 'note':
                  return <SystemNote key={index}>{entry.content}</SystemNote>;
              }
            })}

            {gate && panelOpen && (
              <div className="msg-enter">
                <GatePanel gate={gate} onDecide={decide} />
              </div>
            )}

            {error && (
              <p className="msg-enter rounded-xl border border-red-900/60 bg-red-950/30 p-4 text-sm text-red-300">
                {error}
              </p>
            )}

            <div ref={bottomRef} className="h-2" />
          </div>

          <ChatComposer
            mode={mode}
            busyLabel={currentStep ? `${currentStep}…` : undefined}
            onSubmit={submitText}
            quickActions={
              gate && !panelOpen
                ? [{ label: 'Voir la décision à prendre', onClick: () => setPanelOpen(true), primary: true }]
                : []
            }
          />
        </main>

        {/* ── Livrables ───────────────────────────────────────── */}
        <aside className="hidden w-[330px] shrink-0 py-4 lg:block">
          <div className="sticky top-4 space-y-4">
            <ArtifactList artifacts={artifacts} tenant={tenant} projectId={projectId} />
            <Link
              href={`/${tenant}/projects/${projectId}/deliverables`}
              className="block rounded-xl border border-slate-800 bg-slate-900/40 p-3 text-center text-xs text-slate-400 transition hover:border-cyan-800 hover:text-cyan-300"
            >
              Tous les livrables et l'export →
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
