'use client';

/**
 * Contexte permanent du projet (steering).
 *
 * C'est la mémoire que les agents lisent à chaque exécution. Elle se remplit de
 * deux façons : à la main ici, ou automatiquement — le cadrage validé alimente
 * `product`, le plan validé alimente `tech` et `structure`.
 */
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import useSWR from 'swr';
import { api } from '@/lib/api';
import { MarkdownViewer } from '@/components/markdown-viewer';

const SECTIONS = [
  { id: 'product', label: 'Produit', hint: 'Utilisateurs, problème, objectifs métier, exclusions durables' },
  { id: 'tech', label: 'Technique', hint: 'Stack, contraintes, réglementaire, choix écartés' },
  { id: 'structure', label: 'Structure', hint: 'Organisation du code, conventions, flux documentaire' },
] as const;

export default function SteeringPage() {
  const { tenant, projectId } = useParams<{ tenant: string; projectId: string }>();
  const { data: project, mutate } = useSWR(`project:${projectId}`, () =>
    api.getProject(tenant, projectId),
  );

  const [active, setActive] = useState<(typeof SECTIONS)[number]['id']>('product');
  const [draft, setDraft] = useState('');
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDraft(project?.steering?.[active] ?? '');
    setEditing(false);
  }, [project, active]);

  async function save() {
    setSaving(true);
    try {
      await api.updateSteering(tenant, projectId, { [active]: draft });
      await mutate();
      setEditing(false);
    } finally {
      setSaving(false);
    }
  }

  const value = project?.steering?.[active] ?? '';
  const incomplete = !value || value.includes('À COMPLÉTER');

  return (
    <div className="flex gap-5">
      <nav className="w-60 shrink-0 space-y-1.5">
        {SECTIONS.map((section) => {
          const content = project?.steering?.[section.id] ?? '';
          const filled = content && !content.includes('À COMPLÉTER');
          return (
            <button
              key={section.id}
              type="button"
              onClick={() => setActive(section.id)}
              className={[
                'w-full rounded-lg border p-3 text-left transition',
                active === section.id
                  ? 'border-cyan-700 bg-cyan-500/10'
                  : 'border-slate-800 hover:border-slate-700',
              ].join(' ')}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-200">{section.label}</span>
                <span aria-hidden>{filled ? '✅' : '⬜'}</span>
              </div>
              <p className="mt-0.5 text-[11px] text-slate-500">{section.hint}</p>
            </button>
          );
        })}
      </nav>

      <section className="card min-w-0 flex-1">
        <header className="flex items-center gap-3 border-b border-slate-800 px-5 py-3">
          <h2 className="text-sm font-medium text-slate-200">
            {SECTIONS.find((s) => s.id === active)?.label}
          </h2>
          {incomplete && (
            <span className="rounded bg-amber-500/15 px-2 py-0.5 text-[11px] text-amber-300">
              à compléter
            </span>
          )}
          <div className="ml-auto flex gap-2">
            {editing ? (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setDraft(value);
                    setEditing(false);
                  }}
                  className="btn-ghost px-3 py-1 text-xs"
                >
                  Annuler
                </button>
                <button type="button" onClick={save} disabled={saving} className="btn-primary px-3 py-1 text-xs">
                  {saving ? 'Enregistrement…' : 'Enregistrer'}
                </button>
              </>
            ) : (
              <button type="button" onClick={() => setEditing(true)} className="btn-ghost px-3 py-1 text-xs">
                Modifier
              </button>
            )}
          </div>
        </header>

        <div className="px-6 py-5">
          {editing ? (
            <textarea
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              rows={26}
              className="field resize-y font-mono text-xs leading-relaxed"
            />
          ) : value ? (
            <MarkdownViewer content={value} />
          ) : (
            <p className="text-sm text-slate-500">
              Vide. Les agents poseront les questions nécessaires, ou vous pouvez
              remplir cette section dès maintenant.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
