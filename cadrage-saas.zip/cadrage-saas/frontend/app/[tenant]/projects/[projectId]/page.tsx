'use client';

/** Liste des exécutions du projet + lancement d'un nouveau run. */
import { useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import useSWR from 'swr';
import { api, QuotaError, type Run, type RunStatus } from '@/lib/api';
import { NewRunDialog } from '@/components/new-run-dialog';

const STATUS: Record<RunStatus, { label: string; className: string }> = {
  pending: { label: 'En attente', className: 'text-slate-400 bg-slate-800' },
  running: { label: 'En cours', className: 'text-cyan-300 bg-cyan-500/15' },
  waiting_human: { label: 'Décision requise', className: 'text-amber-300 bg-amber-500/15' },
  completed: { label: 'Terminé', className: 'text-emerald-300 bg-emerald-500/15' },
  failed: { label: 'Échec', className: 'text-red-300 bg-red-500/15' },
  cancelled: { label: 'Annulé', className: 'text-slate-500 bg-slate-800' },
};

const PHASE_LABELS: Record<string, string> = {
  orchestration: 'Orchestration',
  cadrage: 'Cadrage',
  specification: 'Spécification',
  plan: 'Plan',
  estimation: 'Estimation',
  revue: 'Revue',
};

export default function ProjectRunsPage() {
  const { tenant, projectId } = useParams<{ tenant: string; projectId: string }>();
  const router = useRouter();
  const { data: runs, mutate } = useSWR(
    `runs:${projectId}`,
    () => api.listRuns(tenant, projectId),
    { refreshInterval: 15_000 },   // un run en cours progresse pendant qu'on regarde
  );
  const [dialogOpen, setDialogOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function start(payload: Parameters<typeof api.startRun>[2]) {
    setError(null);
    try {
      const run = await api.startRun(tenant, projectId, payload);
      await mutate();
      router.push(`/${tenant}/projects/${projectId}/runs/${run.id}`);
    } catch (err) {
      setError(
        err instanceof QuotaError
          ? `${err.message} — augmentez votre plan ou attendez le mois prochain.`
          : String(err),
      );
    }
  }

  const pending = runs?.find((run) => run.status === 'waiting_human');

  return (
    <>
      <div className="mb-5 flex items-center justify-between">
        <p className="text-sm text-slate-400">
          Une exécution = un passage dans le pipeline, avec ses points de validation.
        </p>
        <button type="button" onClick={() => setDialogOpen(true)} className="btn-primary">
          Lancer une exécution
        </button>
      </div>

      {pending && (
        <Link
          href={`/${tenant}/projects/${projectId}/runs/${pending.id}`}
          className="mb-5 flex items-center gap-3 rounded-xl border border-amber-800/60 bg-amber-950/20 p-4 transition hover:border-amber-700"
        >
          <span className="text-lg" aria-hidden>
            ⏸
          </span>
          <div>
            <p className="text-sm font-medium text-amber-200">
              Une exécution attend votre décision
            </p>
            <p className="text-xs text-amber-200/70">
              Phase {PHASE_LABELS[pending.current_phase] ?? pending.current_phase} — reprendre
            </p>
          </div>
        </Link>
      )}

      {error && (
        <p className="mb-4 rounded-lg border border-red-900/60 bg-red-950/30 p-3 text-sm text-red-300">
          {error}
        </p>
      )}

      {runs?.length ? (
        <ul className="space-y-2">
          {runs.map((run) => (
            <RunRow key={run.id} run={run} tenant={tenant} projectId={projectId} />
          ))}
        </ul>
      ) : (
        <div className="card p-10 text-center">
          <p className="text-slate-300">Aucune exécution.</p>
          <p className="mt-1 text-sm text-slate-500">
            Décrivez votre besoin en quelques phrases : l'orchestrateur détermine le
            scénario et le niveau d'échelle, puis lance la bonne phase.
          </p>
        </div>
      )}

      <NewRunDialog open={dialogOpen} onClose={() => setDialogOpen(false)} onStart={start} />
    </>
  );
}

function RunRow({ run, tenant, projectId }: { run: Run; tenant: string; projectId: string }) {
  const status = STATUS[run.status];
  return (
    <li>
      <Link
        href={`/${tenant}/projects/${projectId}/runs/${run.id}`}
        className="card flex items-center gap-4 p-4 transition hover:border-slate-700"
      >
        <span className={`rounded px-2 py-0.5 text-[11px] ${status.className}`}>
          {status.label}
        </span>
        <span className="text-sm text-slate-300">
          {PHASE_LABELS[run.current_phase] ?? run.current_phase}
        </span>
        <span className="ml-auto font-mono text-[11px] text-slate-600">
          {new Date(run.created_at).toLocaleString('fr-FR', {
            day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
          })}
        </span>
      </Link>
    </li>
  );
}
