'use client';

/** Tableau de bord : projets de l'organisation et création. */
import { useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import useSWR from 'swr';
import { api, QuotaError, type Project } from '@/lib/api';

const SCENARIO_LABELS: Record<string, string> = {
  greenfield: 'Nouveau produit',
  feature: 'Fonctionnalité',
  migration: 'Migration',
  bug: 'Correctif',
};

export default function DashboardPage() {
  const { tenant } = useParams<{ tenant: string }>();
  const { data: projects, mutate, isLoading } = useSWR(`projects:${tenant}`, () =>
    api.listProjects(tenant),
  );
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function create(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    try {
      await api.createProject(tenant, name);
      setName('');
      setCreating(false);
      await mutate();
    } catch (err) {
      setError(
        err instanceof QuotaError
          ? `${err.message} — passez à un plan supérieur pour créer plus de projets.`
          : String(err),
      );
    }
  }

  return (
    <div className="mx-auto max-w-[1400px] p-6">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Projets</h1>
          <p className="mt-1 text-sm text-slate-400">
            Chaque projet porte son steering, ses livrables et son historique.
          </p>
        </div>
        <button type="button" onClick={() => setCreating((v) => !v)} className="btn-primary">
          {creating ? 'Annuler' : 'Nouveau projet'}
        </button>
      </div>

      {creating && (
        <form onSubmit={create} className="card mb-6 flex gap-3 p-4">
          <input
            autoFocus
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Nom du projet (ex. Portail de facturation client)"
            className="field flex-1"
            minLength={2}
            required
          />
          <button type="submit" className="btn-primary">
            Créer
          </button>
        </form>
      )}

      {error && (
        <p className="mb-4 rounded-lg border border-red-900/60 bg-red-950/30 p-3 text-sm text-red-300">
          {error}
        </p>
      )}

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((index) => (
            <div key={index} className="card h-32 animate-pulse" />
          ))}
        </div>
      ) : projects?.length ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <ProjectCard key={project.id} tenant={tenant} project={project} />
          ))}
        </div>
      ) : (
        <div className="card p-10 text-center">
          <p className="text-slate-300">Aucun projet pour l'instant.</p>
          <p className="mt-1 text-sm text-slate-500">
            Créez-en un, puis décrivez votre besoin : le cadrage démarre par un
            brouillon complet, pas par un interrogatoire.
          </p>
        </div>
      )}
    </div>
  );
}

function ProjectCard({ tenant, project }: { tenant: string; project: Project }) {
  const steeringFilled = Object.values(project.steering ?? {}).filter(
    (value) => value && !value.includes('À COMPLÉTER'),
  ).length;

  return (
    <Link
      href={`/${tenant}/projects/${project.id}`}
      className="card group p-5 transition hover:border-cyan-800"
    >
      <div className="mb-2 flex items-start justify-between gap-3">
        <h2 className="font-medium text-slate-100 group-hover:text-cyan-300">{project.name}</h2>
        <span className="shrink-0 rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[10px] text-slate-400">
          N{project.scale_level}
        </span>
      </div>
      <p className="mb-4 line-clamp-2 text-sm text-slate-500">
        {project.description || SCENARIO_LABELS[project.scenario] || '—'}
      </p>
      <div className="flex items-center gap-3 text-[11px] text-slate-500">
        <span>{SCENARIO_LABELS[project.scenario] ?? project.scenario}</span>
        <span aria-hidden>·</span>
        <span className={steeringFilled === 3 ? 'text-emerald-400' : 'text-amber-400'}>
          steering {steeringFilled}/3
        </span>
      </div>
    </Link>
  );
}
