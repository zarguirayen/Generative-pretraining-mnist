'use client';

import Link from 'next/link';
import { usePathname, useParams } from 'next/navigation';
import { signOut } from 'aws-amplify/auth';
import useSWR from 'swr';
import { api } from '@/lib/api';

const NAV = [
  { href: '', label: 'Projets' },
  { href: '/settings/billing', label: 'Abonnement' },
];

export default function TenantLayout({ children }: { children: React.ReactNode }) {
  const { tenant } = useParams<{ tenant: string }>();
  const pathname = usePathname();
  const { data: usage } = useSWR(`usage:${tenant}`, () => api.usage(tenant));

  const tokensUsed = usage ? usage.usage.input_tokens + usage.usage.output_tokens : 0;
  const tokenRatio = usage ? Math.min(100, (tokensUsed / usage.limits.tokens_per_month) * 100) : 0;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-[1400px] items-center gap-6 px-6 py-3">
          <Link href={`/${tenant}`} className="flex items-center gap-2">
            <span
              className="grid h-7 w-7 place-items-center rounded-md bg-cyan-500 font-mono text-sm font-bold text-slate-950"
              aria-hidden
            >
              C
            </span>
            <span className="font-semibold tracking-tight">Cadrage</span>
          </Link>

          <nav className="flex items-center gap-1 text-sm">
            {NAV.map((item) => {
              const href = `/${tenant}${item.href}`;
              const active = item.href === '' ? pathname === href : pathname.startsWith(href);
              return (
                <Link
                  key={item.href}
                  href={href}
                  className={[
                    'rounded-md px-3 py-1.5 transition',
                    active ? 'bg-slate-800 text-slate-100' : 'text-slate-400 hover:text-slate-200',
                  ].join(' ')}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-4">
            {usage && (
              <Link
                href={`/${tenant}/settings/billing`}
                className="hidden items-center gap-2 text-xs text-slate-400 sm:flex"
                title={`${tokensUsed.toLocaleString('fr-FR')} tokens consommés ce mois`}
              >
                <span className="uppercase tracking-wide">{usage.plan}</span>
                <span className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-800">
                  <span
                    className={[
                      'block h-full rounded-full transition-all',
                      tokenRatio > 90 ? 'bg-red-500' : tokenRatio > 70 ? 'bg-amber-500' : 'bg-cyan-500',
                    ].join(' ')}
                    style={{ width: `${tokenRatio}%` }}
                  />
                </span>
              </Link>
            )}
            <button
              type="button"
              onClick={() => signOut()}
              className="text-xs text-slate-500 transition hover:text-slate-300"
            >
              Déconnexion
            </button>
          </div>
        </div>
      </header>

      {usage && !usage.subscription_active && (
        <p className="border-b border-amber-900/50 bg-amber-950/30 px-6 py-2 text-center text-xs text-amber-200">
          Abonnement inactif — les nouveaux runs sont bloqués.{' '}
          <Link href={`/${tenant}/settings/billing`} className="underline">
            Régulariser
          </Link>
        </p>
      )}

      <main>{children}</main>
    </div>
  );
}
