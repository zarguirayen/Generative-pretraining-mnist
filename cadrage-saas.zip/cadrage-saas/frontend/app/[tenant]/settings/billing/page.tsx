'use client';

/** Abonnement, consommation du mois et changement de plan. */
import { useState } from 'react';
import { useParams } from 'next/navigation';
import useSWR from 'swr';
import { api } from '@/lib/api';

const PLANS = [
  {
    id: 'free' as const,
    name: 'Découverte',
    price: 'Gratuit',
    features: ['5 exécutions / mois', '1 projet', '2 sièges', '1 passe d\'examen critique'],
  },
  {
    id: 'pro' as const,
    name: 'Pro',
    price: '49 € / mois + usage',
    features: ['100 exécutions / mois', '20 projets', '15 sièges', 'Revue de code et correction de bug', 'Export illimité'],
    highlight: true,
  },
  {
    id: 'enterprise' as const,
    name: 'Entreprise',
    price: 'Sur devis',
    features: ['Volumes négociés', 'Méthode personnalisable', 'SSO', 'Support dédié'],
  },
];

export default function BillingPage() {
  const { tenant } = useParams<{ tenant: string }>();
  const { data } = useSWR(`usage:${tenant}`, () => api.usage(tenant));
  const [busy, setBusy] = useState<string | null>(null);

  async function subscribe(plan: 'pro' | 'enterprise') {
    setBusy(plan);
    try {
      const { url } = await api.checkout(tenant, plan);
      window.location.href = url;
    } finally {
      setBusy(null);
    }
  }

  const tokens = data ? data.usage.input_tokens + data.usage.output_tokens : 0;

  return (
    <div className="mx-auto max-w-[1400px] p-6">
      <h1 className="mb-1 text-2xl font-semibold tracking-tight">Abonnement</h1>
      <p className="mb-6 text-sm text-slate-400">
        Facturation à l'usage réel : vous ne payez que les tokens consommés par vos
        exécutions, en plus de l'abonnement.
      </p>

      {data && (
        <section className="card mb-8 p-5">
          <h2 className="mb-4 text-sm font-semibold text-slate-200">Ce mois-ci</h2>
          <div className="grid gap-5 sm:grid-cols-4">
            <Metric
              label="Exécutions"
              value={data.usage.runs}
              limit={data.limits.runs_per_month}
            />
            <Metric label="Tokens" value={tokens} limit={data.limits.tokens_per_month} compact />
            <Metric label="Projets" value={data.usage.projects} limit={data.limits.projects} />
            <div>
              <p className="text-xs uppercase tracking-wide text-slate-500">Coût à l'usage</p>
              <p className="mt-1 font-mono text-lg text-slate-100">
                {(data.usage.cost_cents / 100).toFixed(2)} €
              </p>
              <p className="mt-0.5 text-[11px] text-slate-600">hors abonnement</p>
            </div>
          </div>
        </section>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        {PLANS.map((plan) => {
          const current = data?.plan === plan.id;
          return (
            <section
              key={plan.id}
              className={[
                'card flex flex-col p-5',
                plan.highlight && !current && 'border-cyan-800',
                current && 'border-emerald-700',
              ]
                .filter(Boolean)
                .join(' ')}
            >
              <div className="mb-4">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-slate-100">{plan.name}</h3>
                  {current && (
                    <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] text-emerald-300">
                      plan actuel
                    </span>
                  )}
                </div>
                <p className="mt-1 text-sm text-slate-400">{plan.price}</p>
              </div>

              <ul className="mb-5 flex-1 space-y-1.5 text-sm text-slate-400">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex gap-2">
                    <span className="text-cyan-500" aria-hidden>
                      ·
                    </span>
                    {feature}
                  </li>
                ))}
              </ul>

              {plan.id !== 'free' && !current && (
                <button
                  type="button"
                  onClick={() => subscribe(plan.id)}
                  disabled={busy === plan.id}
                  className={plan.highlight ? 'btn-primary' : 'btn-ghost'}
                >
                  {busy === plan.id ? 'Redirection…' : 'Choisir ce plan'}
                </button>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}

function Metric({
  label,
  value,
  limit,
  compact = false,
}: {
  label: string;
  value: number;
  limit: number;
  compact?: boolean;
}) {
  const ratio = Math.min(100, (value / limit) * 100);
  const format = (n: number) =>
    compact && n >= 1000 ? `${(n / 1000).toFixed(0)} k` : n.toLocaleString('fr-FR');

  return (
    <div>
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 font-mono text-lg text-slate-100">
        {format(value)}
        <span className="text-sm text-slate-600"> / {format(limit)}</span>
      </p>
      <span className="mt-2 block h-1 overflow-hidden rounded-full bg-slate-800">
        <span
          className={[
            'block h-full rounded-full transition-all',
            ratio > 90 ? 'bg-red-500' : ratio > 70 ? 'bg-amber-500' : 'bg-cyan-500',
          ].join(' ')}
          style={{ width: `${ratio}%` }}
        />
      </span>
    </div>
  );
}
