"""The generated GenAI monitor runs: metrics from records, thresholds, alerts in the journal.

    python -m pytest tests/test_genai_monitor.py -v

The plan says what to monitor; these tests check that the generated code actually does it
on a record journal - and that an alert lands in the same hash-chained journal the
record-keeping skill verifies.
"""

from __future__ import annotations

import hashlib
import importlib.machinery
import importlib.util
import json
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = PLUGIN_ROOT / "tests" / "fixtures"
GENAI = PLUGIN_ROOT / "skills" / "aida-genai-monitoring" / "scripts"
VERIFY = PLUGIN_ROOT / "skills" / "aida-record-keeping" / "scripts" / "verify_chain.py"
END = datetime(2026, 9, 28, tzinfo=timezone.utc)


def load_monitor(path: Path):
    name = f"genai_monitor_{abs(hash(path))}"
    # an explicit loader, so the .template asset can be imported as well as the copy
    loader = importlib.machinery.SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(name, loader)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def generated(tmp_path_factory) -> Path:
    """The agentic fixture, evaluated, with feedback wired: plan + generated monitor."""
    project = tmp_path_factory.mktemp("monitor") / "agentic_assistant"
    shutil.copytree(FIXTURES / "agentic_assistant", project)
    run = project / "eval" / "outputs" / "run1"
    run.mkdir(parents=True)
    (run / "summary.json").write_text(json.dumps(
        {"metrics": {"task_completion": 0.9, "tool_correctness": 0.95, "latency": 1200}}),
        encoding="utf-8")
    (project / "feedback.py").write_text("def thumbs_up(request_id): ...\n", encoding="utf-8")
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(project)],
                   check=True, capture_output=True)
    subprocess.run([sys.executable, str(GENAI / "generate_monitor.py")], cwd=project,
                   check=True, capture_output=True)
    return project


def write_journal(monitor, journal: Path, n: int, success: float, *, pii: bool = False,
                  task_type: str = "close", start: datetime = END - timedelta(days=5)):
    """n inference records inside the monitored period, chained like aida_records.py."""
    prev = monitor.GENESIS
    with journal.open("w", encoding="utf-8") as handle:
        for i in range(n):
            ok = i < round(n * success)
            entry = {"schema": 1, "seq": i + 1, "event": "inference", "actor": "user-1",
                     "at": (start + timedelta(minutes=i)).isoformat(timespec="seconds"),
                     "payload": {
                         "request_id": f"r{i}", "session_id": "s1", "model_version": "haiku",
                         "input": "Close ticket 42 and tell the owner", "task_type": task_type,
                         "output": "Done, ticket closed." + (" Mail jo@example.com"
                                                             if pii and i == 0 else ""),
                         "outcome": "success" if ok else "failed", "latency_ms": 1000,
                         "tokens": {"input": 300, "output": 80},
                         "tool_calls": [{"name": "close_ticket",
                                         "status": "ok" if ok else "error"}]},
                     "prev": prev}
            canonical = json.dumps({k: entry[k] for k in monitor.HASHED_KEYS}, sort_keys=True,
                                   ensure_ascii=False, separators=(",", ":"))
            entry["hash"] = prev = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


@pytest.fixture
def setup(generated, tmp_path):
    out = generated / "aida" / "monitoring"
    work = tmp_path / "monitoring"
    shutil.copytree(out, work)
    config = json.loads((work / "genai_monitor_config.json").read_text(encoding="utf-8"))
    return load_monitor(work / "genai_monitor.py"), config, work


# ---------------------------------------------------------------- generation --
def test_everything_the_monitor_needs_is_generated(generated):
    out = generated / "aida" / "monitoring"
    for name in ("genai_monitor.py", "genai_monitor_config.json", "alert_rules_quality.json",
                 "schedule/crontab.txt", "schedule/gitlab-ci.yml"):
        assert (out / name).exists(), name


def test_scope_is_decided_with_evidence(generated):
    config = json.loads((generated / "aida" / "monitoring" / "genai_monitor_config.json")
                        .read_text(encoding="utf-8"))
    assert config["variant"] == "ground_truth"          # the feedback control was found
    ruled = {r["family"]: r["evidence"] for r in config["ruled_out"]}
    assert "rag" in ruled and "0 retrieval signal" in ruled["rag"]


def test_schedule_follows_mon_frequency(generated):
    out = generated / "aida" / "monitoring" / "schedule"
    assert "0 6 * * 1" in (out / "crontab.txt").read_text(encoding="utf-8")   # daily -> weekly
    gitlab = (out / "gitlab-ci.yml").read_text(encoding="utf-8")
    assert '$CI_PIPELINE_SOURCE == "schedule"' in gitlab and "genai_monitor.py" in gitlab


def test_alert_rules_cover_quality_safety_and_drift(generated):
    rules = json.loads((generated / "aida" / "monitoring" / "alert_rules_quality.json")
                       .read_text(encoding="utf-8"))
    by_metric = {r["metric"]: r for r in rules}
    assert by_metric["task_completion"]["condition"] == "value < 0.81"
    assert by_metric["latency"]["condition"] == "value > 1320.0"     # lower is better
    assert "pii_leakage_detection" in by_metric and "query_distribution" in by_metric
    assert "explanation" in by_metric["task_completion"]["payload_fields"]


# ------------------------------------------------------------------- running --
def test_a_clean_period_raises_nothing(setup, tmp_path):
    monitor, config, work = setup
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=1.0)
    result = monitor.run(config, journal, work / "history.jsonl", END)
    values = {m["metric"]: m["value"] for m in result["metrics"]}
    assert values["task_completion"] == 1.0 and values["latency"] == 1000
    assert values["total_tokens"] == 380
    assert result["alerts"] == []


def test_a_quality_drop_is_alerted_explained_and_journaled(setup, tmp_path):
    monitor, config, work = setup
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=0.6)
    result = monitor.run(config, journal, work / "history.jsonl", END)
    alert = next(a for a in result["alerts"] if a["metric"] == "task_completion")
    assert alert["rule"] == "MON-THRESHOLD-AGENTIC" and alert["value"] == 0.6
    assert "-33.3%" in alert["explanation"] and alert["requests_to_review"]
    journaled = [json.loads(l) for l in journal.read_text(encoding="utf-8").splitlines()]
    assert journaled[-1]["event"] == "alert" or journaled[-2]["event"] == "alert"
    check = subprocess.run([sys.executable, str(VERIFY), str(journal)], capture_output=True)
    assert check.returncode == 0, "the alert must keep the record journal chain intact"


def test_too_few_inferences_is_insufficient_data_not_a_pass(setup, tmp_path):
    monitor, config, work = setup
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 5, success=0.0)
    result = monitor.run(config, journal, work / "history.jsonl", END, write=False)
    assert result["alerts"] == []
    assert any("insufficient data" in gap for gap in result["coverage_gaps"])


def test_consecutive_breaches_are_honoured(setup, tmp_path):
    monitor, config, work = setup
    config["window"]["consecutive_breaches"] = 2
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=0.6)
    first = monitor.run(config, journal, work / "history.jsonl", END)
    assert not any(a["metric"] == "task_completion" for a in first["alerts"])
    second = monitor.run(config, journal, work / "history.jsonl", END)
    assert any(a["metric"] == "task_completion" and a["consecutive_breaches"] == 2
               for a in second["alerts"])


def test_pii_in_an_answer_is_a_critical_alert(setup, tmp_path):
    monitor, config, work = setup
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=1.0, pii=True)
    result = monitor.run(config, journal, work / "history.jsonl", END, write=False)
    pii = next(a for a in result["alerts"] if a["kind"] == "pii_leakage")
    assert pii["severity"] == "critical" and pii["requests_to_review"] == ["r0"]


def test_ground_truth_and_feedback_are_joined_by_request_id(setup, tmp_path):
    monitor, config, work = setup
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=1.0)
    for i in range(10):
        monitor.append_record(journal, "ground_truth", "user-1", {
            "request_id": f"r{i}", "source": "user",
            "observed": {"feedback": "down" if i < 4 else "up", "reason": "tools",
                         "answer": "Done, ticket closed."}})
    result = monitor.run(config, journal, work / "history.jsonl", END, write=False)
    values = {m["metric"]: m["value"] for m in result["metrics"]}
    assert values["answer_correctness"] == 0.6


def test_a_judge_metric_without_a_judge_is_a_gap_and_with_one_is_computed(setup, tmp_path):
    monitor, config, work = setup
    config["metrics"].append({"metric": "reasoning_quality", "baseline": 0.8, "limit": 0.72,
                              "direction": "higher", "method": "judge"})
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=1.0)
    before = monitor.run(config, journal, work / "history.jsonl", END, write=False)
    assert any(g.startswith("reasoning_quality") for g in before["coverage_gaps"])
    monitor.register_judge("reasoning_quality", lambda record: 0.5)
    after = monitor.run(config, journal, work / "history.jsonl", END, write=False)
    assert any(a["metric"] == "reasoning_quality" for a in after["alerts"])


def test_query_drift_is_tested_against_the_reference(setup, tmp_path):
    monitor, config, work = setup
    config["query_reference"] = {"close": 25, "lookup": 25}
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 40, success=1.0, task_type="purge")
    result = monitor.run(config, journal, work / "history.jsonl", END, write=False)
    assert any(a["kind"] == "query_drift" for a in result["alerts"])


def test_retrieval_metrics_from_ids():
    monitor = load_monitor(PLUGIN_ROOT / "skills" / "aida-genai-monitoring" / "assets"
                           / "genai_monitor.py.template")
    scores = monitor.ranking(["d3", "d1", "d9"], ["d1"], 3)
    assert scores["mrr"] == 0.5 and scores["recall"] == 1.0
    assert round(monitor.upper_gamma(1, 3.841), 3) == 0.05


def test_the_monitor_cli_exits_1_on_an_alert(setup, tmp_path):
    monitor, config, work = setup
    journal = tmp_path / "records.jsonl"
    write_journal(monitor, journal, 30, success=0.5)
    done = subprocess.run([sys.executable, str(work / "genai_monitor.py"), "--config",
                           str(work / "genai_monitor_config.json"), "--journal", str(journal),
                           "--period-end", "2026-09-28"], capture_output=True, text=True)
    assert done.returncode == 1 and '"quality_drop"' in done.stdout


def test_section_3_8_describes_what_runs_not_what_is_intended(generated):
    values = json.loads((generated / "aida" / "values.json").read_text(encoding="utf-8"))
    drops = values["Procedures for identifying and addressing performance drops."]["value"]
    assert "aida/monitoring/genai_monitor.py" in drops and "hash-chained journal" in drops
    metrics = values["List and justification of the choice of the metrics used for model "
                     "monitoring"]["value"]
    assert "Monitoring variant: ground truth" in metrics and "Ruled out" in metrics


def test_no_monitor_is_generated_for_a_system_that_is_not_genai(tmp_path):
    plan = tmp_path / "plan.json"
    plan.write_text(json.dumps({"family": "unknown", "metrics": []}), encoding="utf-8")
    done = subprocess.run([sys.executable, str(GENAI / "generate_monitor.py"), "--plan",
                           str(plan), "--out", str(tmp_path / "monitoring")],
                          capture_output=True, text=True)
    assert done.returncode == 0 and "no monitor generated" in done.stdout
    assert not (tmp_path / "monitoring").exists()
