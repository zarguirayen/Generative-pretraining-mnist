"""Section 4: the substantial changes since the last documented state, from the git diff.

    python -m pytest tests/test_detect_changes.py -v
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
TECHDOC = PLUGIN_ROOT / "skills" / "aida-technical-documentation" / "scripts"
sys.path.insert(0, str(TECHDOC))

from detect_changes import UPDATE_FIELD, VERSION_FIELD, describe, detect  # noqa: E402

AGENT = textwrap.dedent('''
    from langchain_core.tools import tool
    MODEL = "anthropic.claude-haiku-4-5-20251001-v1:0"

    @tool
    def lookup(ticket_id: str) -> str:
        """Read a ticket."""
        return ticket_id
''')


def git(project: Path, *args: str) -> None:
    subprocess.run(["git", "-C", str(project), "-c", "user.email=t@t", "-c", "user.name=t",
                    *args], check=True, capture_output=True)


def commit(project: Path, message: str, date: str | None = None) -> None:
    git(project, "add", "-A")
    env = {**os.environ, "GIT_COMMITTER_DATE": date, "GIT_AUTHOR_DATE": date} if date else None
    subprocess.run(["git", "-C", str(project), "-c", "user.email=t@t", "-c", "user.name=t",
                    "commit", "-q", "-m", message], env=env, check=True, capture_output=True)


@pytest.fixture
def repo(tmp_path) -> Path:
    project = tmp_path / "repo"
    project.mkdir()
    (project / "agent.py").write_text(AGENT, encoding="utf-8")
    (project / "requirements.txt").write_text("langgraph==0.2.45\n", encoding="utf-8")
    git(project, "init", "-q")
    commit(project, "v1")
    git(project, "tag", "v1.0.0")
    return project


def change_the_system(project: Path, date: str | None = None) -> None:
    agent = project / "agent.py"
    text = agent.read_text(encoding="utf-8").replace(
        "claude-haiku-4-5-20251001-v1:0", "claude-sonnet-5-20260101-v1:0")
    agent.write_text(text + textwrap.dedent('''
        @tool
        def wire_transfer(iban: str, amount: float) -> str:
            """Send money."""
            return "sent"
    '''), encoding="utf-8")
    (project / "requirements.txt").write_text("langgraph==0.3.0\n", encoding="utf-8")
    (project / "system_prompt.txt").write_text("You are an assistant.\n", encoding="utf-8")
    commit(project, "switch model, add transfer tool", date)


def test_changes_since_the_last_version_tag_are_classified(repo):
    change_the_system(repo)
    result = detect(repo, {}, {}, None)
    assert result["reference_kind"] == "last version tag" and result["reference"] == "v1.0.0"
    kinds = {item["kind"] for item in result["substantial"]}
    assert {"model added", "model removed", "tool added", "dependencies changed",
            "prompt changed"} <= kinds
    assert any("wire_transfer" in t for t in result["change_of_usage_triggers"])


def test_the_documented_state_is_the_reference_when_recorded(repo):
    # documented after v1, then the system changed: the change is compared to the document
    change_the_system(repo, date="2027-01-01T00:00:00")
    result = detect(repo, {}, {}, {"recorded_at": "2026-12-01T00:00:00+00:00"})
    assert result["reference_kind"] == "documented state"
    assert any(f["rule"] == "DOC-UPDATE-ON-CHANGE" and "since the documentation was recorded"
               in f["summary"] for f in result["findings"])


def test_a_cited_file_that_moved_is_named(repo):
    change_the_system(repo)
    values = {"x": {"value": "v", "evidence": ["agent.py:3"]}}
    assert detect(repo, {}, values, None)["cited_files_changed"] == ["agent.py"]


def test_both_section_4_fields_are_written_with_git_evidence(repo):
    change_the_system(repo)
    fields = describe(detect(repo, {}, {}, None))
    update = fields[UPDATE_FIELD]
    assert update["source"] == "code" and update["evidence"][0].startswith("git log ")
    assert "check_freshness.py" in update["value"]
    assert "[A CONFIRMER - outcome of the change-of-usage procedure]" in update["value"]
    assert "switch model, add transfer tool" in fields[VERSION_FIELD]["value"]


def test_no_change_means_no_trigger(repo):
    (repo / "README.md").write_text("docs\n", encoding="utf-8")
    commit(repo, "docs only")
    result = detect(repo, {}, {}, None)
    assert result["substantial"] == [] and result["change_of_usage_triggers"] == []
    assert "no change-of-usage trigger" in describe(result)[UPDATE_FIELD]["value"]


def test_without_git_nothing_is_asserted(tmp_path):
    result = detect(tmp_path, {}, {}, None)
    assert result["available"] is False


def test_the_chain_records_the_state_and_journals_the_trigger(repo):
    change_the_system(repo)
    subprocess.run([sys.executable, str(PLUGIN_ROOT / "run_all.py"), str(repo)],
                   check=True, capture_output=True)
    aida = repo / "aida"
    assert (aida / "doc_state.json").exists(), "the next run needs a documented state"
    rows = json.loads((aida / "journal.json").read_text(encoding="utf-8"))
    assert any("DOC-UPDATE-ON-CHANGE" in r["event"] for r in rows)
