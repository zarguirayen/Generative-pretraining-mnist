#!/usr/bin/env python3
"""Find the substantial changes since the system was last documented (section 4).

    python detect_changes.py . --context aida/context.json --values aida/values.json --map aida/placeholders.json

Section 4 of the template asks for the documentation to be updated on any substantial
change, and for the change-of-usage procedure whenever a change may move the AI Act risk
category (DOC-UPDATE-ON-CHANGE). Both start with a question the git history answers:
what changed since the last documented state?

The reference is the state `check_freshness.py record` stored when the document was last
written; before any record, the last version tag. Between that reference and HEAD, the
changes that count as substantial are read from the diff itself:

* a model identifier added or removed;
* a model-callable tool added, removed, or with changed parameters (tool-set drift);
* a dependency manifest, a prompt file, an endpoint file, or the deployment configuration
  changed;
* any file this document cites as evidence.

A new tool, model or endpoint changes what the system can do, so it is listed as a trigger
for the change-of-usage procedure; the procedure's outcome stays an open point. Without a
git history nothing is asserted. Writes aida/changes.json. Standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
sys.path.insert(0, str(HERE.parent.parent / "aida-genai-monitoring" / "scripts"))
from scan_codebase import MODEL_ID  # noqa: E402
from section_values import entry, merge, report  # noqa: E402
from detect_tool_drift import diff as tool_diff, tools_at  # noqa: E402

UPDATE_FIELD = ("Update the documentation, if any substantial changes have been made on the "
                "AI system.")
VERSION_FIELD = ("Explain how the current version improves upon or differs from previous "
                 "versions of the AI system")
MANIFESTS = re.compile(r"(^|/)(requirements[^/]*\.txt|pyproject\.toml|poetry\.lock|Pipfile"
                       r"(\.lock)?|package(-lock)?\.json|environment\.ya?ml)$")
DEPLOYMENT = re.compile(r"(^|/)(Dockerfile[^/]*|docker-compose[^/]*\.ya?ml|\.gitlab-ci\.yml|"
                        r"\.github/workflows/.*|[^/]*\.tf|helm/.*|k8s/.*)$")
PROMPT = re.compile(r"prompt", re.I)
EVIDENCE_REF = re.compile(r"^(?P<path>.+?):\d+$")
HISTORY_DAYS = 90


def git(project: Path, *args: str) -> str | None:
    try:
        done = subprocess.run(["git", "-C", str(project), *args], capture_output=True,
                              text=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return None
    return done.stdout.strip() if done.returncode == 0 else None


def load(path: Path) -> dict | None:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def reference(project: Path, state: dict | None) -> tuple[str | None, str, str]:
    """(git ref, what it is, when) - the last documented state, else the last version."""
    recorded = (state or {}).get("recorded_at")
    if recorded:
        ref = git(project, "rev-list", "-1", f"--before={recorded}", "HEAD")
        if ref:
            return ref, "documented state", recorded
    tag = git(project, "describe", "--tags", "--abbrev=0")
    if tag and git(project, "rev-parse", f"{tag}^{{commit}}") != git(project, "rev-parse", "HEAD"):
        return tag, "last version tag", git(project, "log", "-1", "--format=%cI", tag) or ""
    since = (datetime.now(timezone.utc) - timedelta(days=HISTORY_DAYS)).date().isoformat()
    ref = git(project, "rev-list", "--max-parents=0", "HEAD")
    return (ref.splitlines()[-1] if ref else None), f"first commit ({HISTORY_DAYS}-day history)", since


def cited_paths(values: dict) -> set[str]:
    paths = set()
    for item in values.values():
        for evidence in (item.get("evidence") or []) if isinstance(item, dict) else []:
            match = EVIDENCE_REF.match(evidence.strip())
            if match:
                paths.add(match.group("path"))
    return paths


def model_changes(project: Path, ref: str) -> tuple[list[str], list[str]]:
    patch = git(project, "diff", "-U0", ref, "HEAD") or ""
    added, removed = set(), set()
    for line in patch.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("+"):
            added.update(MODEL_ID.findall(line))
        elif line.startswith("-"):
            removed.update(MODEL_ID.findall(line))
    return sorted(added - removed), sorted(removed - added)


def detect(project: Path, ctx: dict, values: dict, state: dict | None) -> dict:
    head = git(project, "rev-parse", "HEAD")
    if not head:
        return {"available": False, "reason": "no git history - nothing can be said about "
                                              "what changed"}
    ref, kind, when = reference(project, state)
    if not ref:
        return {"available": False, "reason": "git history has no usable reference"}

    log = git(project, "log", "--format=%h|%cI|%s", f"{ref}..HEAD") or ""
    commits = [dict(zip(("hash", "date", "subject"), line.split("|", 2)))
               for line in log.splitlines() if line]
    files = (git(project, "diff", "--name-only", ref, "HEAD") or "").splitlines()
    span = f"git diff {ref[:12]}..{head[:12]}"

    substantial: list[dict] = []
    triggers: list[str] = []
    added, removed = model_changes(project, ref)
    for model in added:
        substantial.append({"kind": "model added", "detail": model, "evidence": span})
        triggers.append(f"new model {model}")
    for model in removed:
        substantial.append({"kind": "model removed", "detail": model, "evidence": span})

    try:
        drift = tool_diff(tools_at(project, ref), tools_at(project, "HEAD"))
    except RuntimeError:
        drift = {"alerts": []}
    for alert in drift["alerts"]:
        substantial.append({"kind": f"tool {alert['kind']}" if not alert["kind"].startswith("tool")
                            else alert["kind"], "detail": f"{alert['tool']}: {alert['detail']}",
                            "evidence": span, "rule": "MON-DRIFT-TOOLSET"})
        if alert["severity"] == "critical":
            triggers.append(f"{alert['kind']} {alert['tool']}")

    endpoint_files = {e["evidence"].rsplit(":", 1)[0] for e in ctx.get("endpoints") or []}
    groups = (("dependencies changed", [f for f in files if MANIFESTS.search(f)]),
              ("deployment changed", [f for f in files if DEPLOYMENT.search(f)]),
              ("prompt changed", [f for f in files if PROMPT.search(f)]),
              ("endpoint file changed", [f for f in files if f in endpoint_files]))
    for label, hits in groups:
        if hits:
            substantial.append({"kind": label, "detail": ", ".join(hits[:6]),
                                "evidence": f"git diff --name-only {ref[:12]}..{head[:12]}"})
            if label == "endpoint file changed":
                triggers.append(f"endpoint changed in {', '.join(hits[:3])}")

    cited = sorted(cited_paths(values) & set(files))
    findings = []
    if substantial and kind == "documented state":
        findings.append({"rule": "DOC-UPDATE-ON-CHANGE", "severity": "blocking",
                         "summary": f"{len(substantial)} substantial change(s) since the "
                                    f"documentation was recorded on {when[:10]}",
                         "detail": "; ".join(f"{s['kind']}: {s['detail']}" for s in substantial[:6])
                                   + " - regenerate the affected sections and record the new state."})
    if triggers:
        findings.append({"rule": "DOC-UPDATE-ON-CHANGE", "severity": "blocking",
                         "summary": f"{len(triggers)} change(s) that may move the AI Act risk "
                                    f"category - complete the change-of-usage procedure",
                         "detail": "; ".join(triggers)})
    return {"available": True, "head": head, "reference": ref, "reference_kind": kind,
            "reference_date": when, "commits": commits, "changed_files": len(files),
            "substantial": substantial, "cited_files_changed": cited,
            "change_of_usage_triggers": triggers, "findings": findings}


def describe(result: dict) -> dict[str, dict]:
    head, ref = result["head"][:12], result["reference"][:12]
    evidence = [f"git log {ref}..{head}"]
    since = f"since the {result['reference_kind']} ({result['reference'][:12]}, {result['reference_date'][:10]})"
    text = (f"This documentation describes the code at commit {head}. {len(result['commits'])} "
            f"commit(s) and {result['changed_files']} changed file(s) {since}. ")
    if result["substantial"]:
        text += ("Substantial changes read from the diff: "
                 + "; ".join(f"{s['kind']} - {s['detail']}" for s in result["substantial"]) + ". ")
    else:
        text += "No substantial change (model, tool, dependency, prompt, endpoint, deployment) in that span. "
    if result["cited_files_changed"]:
        text += (f"{len(result['cited_files_changed'])} file(s) cited as evidence in this document "
                 f"changed ({', '.join(result['cited_files_changed'][:5])}); the fields citing "
                 f"them were regenerated from the current code. ")
    text += ("Mechanism: check_freshness.py records a hash of every cited file with the document "
             "and fails a CI job when one moves, so an update is triggered by the change itself. ")
    if result["change_of_usage_triggers"]:
        text += ("Changes that may alter the AI Act risk category, requiring the Change of usage "
                 "procedure: " + "; ".join(result["change_of_usage_triggers"])
                 + " [A CONFIRMER - outcome of the change-of-usage procedure].")
    else:
        text += "No change in that span alters what the system can do; no change-of-usage trigger."
    fields = {UPDATE_FIELD: entry(text, source="code", evidence=evidence)}

    if result["reference_kind"] == "last version tag" and result["commits"]:
        subjects = "; ".join(c["subject"] for c in result["commits"][:8])
        version = (f"Since version {result['reference']}: {len(result['commits'])} commit(s) - "
                   f"{subjects}"
                   + (f" (+{len(result['commits']) - 8} more)" if len(result["commits"]) > 8 else "")
                   + ". "
                   + ("Substantial: " + "; ".join(f"{s['kind']} {s['detail']}"
                                                  for s in result["substantial"]) + "."
                      if result["substantial"] else "No substantial change in the code."))
        fields[VERSION_FIELD] = entry(version, source="code", evidence=evidence)
    return fields


def main() -> int:
    parser = argparse.ArgumentParser(description="Detect substantial changes since the last documented state.")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json")
    parser.add_argument("--state", default="aida/doc_state.json",
                        help="state recorded by check_freshness.py when the document was last written")
    parser.add_argument("--out", default="aida/changes.json")
    args = parser.parse_args()

    project = Path(args.project).resolve()
    ctx = load(Path(args.context)) or {}
    values = load(Path(args.values)) or {}
    result = detect(project, ctx, values, load(Path(args.state)))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    if not result["available"]:
        print(f"changes: {result['reason']} - section 4 stays an open point")
        return 0
    print(f"reference : {result['reference_kind']} {result['reference'][:12]} "
          f"({result['reference_date'][:10]}) -> HEAD {result['head'][:12]}")
    print(f"changes   : {len(result['commits'])} commit(s), {result['changed_files']} file(s), "
          f"{len(result['substantial'])} substantial, {len(result['cited_files_changed'])} cited")
    for item in result["substantial"]:
        print(f"  {item['kind']:<24} {item['detail'][:80]}")
    for finding in result["findings"]:
        print(f"  [{finding['severity'].upper()}] {finding['summary']}")
    print(report(merge(Path(args.values), describe(result), Path(args.routing)),
                 "4 Updates and changes", Path(args.values)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
