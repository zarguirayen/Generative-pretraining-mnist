#!/usr/bin/env python3
"""Turn the monitoring plan into a monitor that runs: code, configuration, alert rules, schedule.

    python generate_monitor.py --plan aida/monitoring_plan.json --out aida/monitoring

A plan is a promise; the guideline asks for monitoring implemented before the end of the
build phase (MON-TIMING). This writes, under aida/monitoring/:

  genai_monitor.py            the monitor - reads the record journal, computes the metrics,
                              compares them with the thresholds, explains and records alerts
  genai_monitor_config.json   the plan made executable: metrics, limits, window, variant
  alert_rules_quality.json    one machine-readable rule per quality metric and safety signal
  schedule/crontab.txt        the run at the frequency MON-FREQUENCY sets
  schedule/gitlab-ci.yml      the same, as a scheduled CI job that turns red on an alert

It never edits the project's source. Where the monitor runs is a deployment decision; the
schedule files are ready to drop in. Standard library only.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "assets" / "genai_monitor.py.template"

FROM_RECORDS = {"task_completion", "tool_correctness", "tool_call_accuracy", "latency",
                "total_tokens"}
FROM_GROUND_TRUTH = {"correctness", "recall", "precision", "mrr", "ndcg"}
FROM_FEEDBACK = {"answer_correctness"}
CRON = {"weekly": "0 6 * * 1", "monthly": "0 6 1 * *", "quarterly": "0 6 1 1,4,7,10 *",
        "yearly": "0 6 2 1 *"}
ALERT_PROCEDURE = [
    "Investigate: new topics, untrained users, changed usage, a prompt or model update",
    "Justify whether corrective measures are taken, and if not, why",
    "Correct: user training, prompt or guardrail update, dataset refresh, retraining",
    "Record the investigation and the measures in the AI System Journal (DOC-JOURNAL)",
]
PAYLOAD_FIELDS = ["kind", "severity", "rule", "metric", "value", "baseline", "alert_threshold",
                  "relative_change_pct", "consecutive_breaches", "period_start", "period_end",
                  "samples", "family", "variant", "explanation", "negative_feedback_by_cause",
                  "requests_to_review", "next_steps", "assigned_to"]
# What each record must carry for the monitor to compute its metrics.
RECORD_FIELDS = {
    "inference": ["request_id", "session_id", "model_version", "input", "output",
                  "outcome", "latency_ms", "tokens", "tool_calls", "retrieved_ids", "task_type"],
    "ground_truth": ["request_id", "observed.answer", "observed.feedback (up/down)",
                     "observed.reason (generation / retrieval / tools)", "observed.relevant_ids"],
}


def method_for(metric: str, variant: str) -> str:
    if metric in FROM_RECORDS:
        return "records"
    if metric in FROM_FEEDBACK:
        return "user_feedback"
    if metric in FROM_GROUND_TRUTH and variant == "ground_truth":
        return "ground_truth"
    return "judge"


def build_config(plan: dict, journal: str) -> dict:
    scope = plan.get("scope") or {}
    variant = scope.get("variant", "no_ground_truth")
    metrics = [{"metric": m["metric"], "baseline": m["baseline"],
                "limit": m["alert_threshold"], "direction": m.get("direction", "higher"),
                "method": method_for(m["metric"], variant)} for m in plan["metrics"]]
    if variant == "ground_truth" and not any(m["metric"] == "answer_correctness" for m in metrics):
        metrics.append({"metric": "answer_correctness", "baseline": None, "limit": None,
                        "direction": "higher", "method": "user_feedback"})
    return {
        "generated_from": "aida/monitoring_plan.json",
        "family": plan["family"], "level": plan.get("agentic_level"),
        "variant": variant, "ruled_out": scope.get("ruled_out", []),
        "threshold_rule": plan["threshold_rule"],
        "relative_drop_pct": plan["relative_drop_pct"],
        "baseline_source": plan.get("baseline_source"),
        "window": plan["window"],
        "metrics": metrics,
        "safety_signals": [s["metric"] for s in plan.get("safety_signals", [])],
        "drift": {"test": "chi-square on query types", "p_value_below": 0.05},
        "retrieval_k": 5,
        "journal": journal,
        "alert_procedure": ALERT_PROCEDURE,
        "assigned_to": "risk owner - name to be confirmed",
    }


def alert_rules(config: dict) -> list[dict]:
    window = config["window"]
    rules = []
    for m in config["metrics"]:
        if m["limit"] is None:
            continue
        rules.append({
            "id": f"genai-{m['metric']}", "rule": config["threshold_rule"],
            "metric": m["metric"], "computed_from": m["method"],
            "condition": f"value {'<' if m['direction'] == 'higher' else '>'} {m['limit']}",
            "baseline": m["baseline"], "window": window["period"],
            "consecutive_breaches": window["consecutive_breaches"],
            "min_samples": window["min_samples"], "severity": "high",
            "payload_fields": PAYLOAD_FIELDS, "sink": "record journal, event=alert"})
    rules.append({"id": "genai-pii-leakage", "rule": "MON-GENAI-QUALITY-MINIMUM",
                  "metric": "pii_leakage_detection", "computed_from": "records",
                  "condition": "any occurrence", "severity": "critical",
                  "payload_fields": PAYLOAD_FIELDS, "sink": "record journal, event=alert"})
    rules.append({"id": "genai-query-drift", "rule": "MON queries drift",
                  "metric": "query_distribution", "computed_from": "records",
                  "condition": f"chi-square p < {config['drift']['p_value_below']}",
                  "severity": "medium", "payload_fields": PAYLOAD_FIELDS,
                  "sink": "record journal, event=alert"})
    return rules


def schedules(config: dict, out: Path) -> dict[str, str]:
    period = config["window"]["period"] or "weekly"
    cron = CRON.get(period, CRON["weekly"])
    command = f"python {out.as_posix()}/genai_monitor.py --config {out.as_posix()}/genai_monitor_config.json"
    crontab = (f"# AIDA GenAI monitoring - {period} ({config['window']['period_days']} days), "
               f"MON-FREQUENCY\n# exit code 1 = an alert was raised and recorded in the journal\n"
               f"{cron} cd /path/to/project && {command}\n")
    gitlab = (f"# AIDA GenAI monitoring - add to .gitlab-ci.yml and create a pipeline schedule\n"
              f"# with the cron \"{cron}\" ({period}, MON-FREQUENCY).\n"
              f"aida-genai-monitoring:\n"
              f"  stage: monitor\n"
              f"  rules:\n"
              f"    - if: '$CI_PIPELINE_SOURCE == \"schedule\"'\n"
              f"  script:\n"
              f"    - {command}\n"
              f"  artifacts:\n"
              f"    when: always\n"
              f"    paths:\n"
              f"      - {out.as_posix()}/monitoring_history.jsonl\n")
    return {"crontab.txt": crontab, "gitlab-ci.yml": gitlab, "cron": cron}


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the runnable GenAI monitor.")
    parser.add_argument("--plan", default="aida/monitoring_plan.json")
    parser.add_argument("--out", default="aida/monitoring")
    parser.add_argument("--journal", default="logs/aida_records.jsonl",
                        help="record journal the monitor reads and writes alerts to")
    args = parser.parse_args()

    plan_path = Path(args.plan)
    if not plan_path.exists():
        print(f"error: plan not found: {plan_path}\n       run plan_monitoring.py first",
              file=sys.stderr)
        return 2
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if plan.get("family") in (None, "unknown"):
        # Monitoring a system the scan could not establish as GenAI would be inventing one.
        print("no GenAI system established from the code (family: unknown) - no monitor "
              "generated. Confirm the classification with aida-core, then re-run.")
        return 0
    out = Path(args.out)
    (out / "schedule").mkdir(parents=True, exist_ok=True)

    config = build_config(plan, args.journal)
    shutil.copyfile(TEMPLATE, out / "genai_monitor.py")
    (out / "genai_monitor_config.json").write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    rules = alert_rules(config)
    (out / "alert_rules_quality.json").write_text(
        json.dumps(rules, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    sched = schedules(config, out)
    for name in ("crontab.txt", "gitlab-ci.yml"):
        (out / "schedule" / name).write_text(sched[name], encoding="utf-8")

    by_method: dict[str, list[str]] = {}
    for metric in config["metrics"]:
        by_method.setdefault(metric["method"], []).append(metric["metric"])
    print(f"GenAI monitor written to {out}/")
    print(f"  scope    : {config['family']}, {config['variant']}"
          + (f"; ruled out: {', '.join(r['family'] for r in config['ruled_out'])}"
             if config["ruled_out"] else ""))
    print(f"  window   : {config['window']['period'] or 'weekly (frequency to confirm)'}, "
          f"{config['window']['consecutive_breaches']} period(s) to alert, "
          f"min {config['window']['min_samples']} inferences")
    print(f"  schedule : cron \"{sched['cron']}\" - schedule/crontab.txt, schedule/gitlab-ci.yml")
    print(f"  rules    : {len(rules)} in alert_rules_quality.json")
    for method, names in sorted(by_method.items()):
        print(f"  {method:<13}: {', '.join(names)}")
    if by_method.get("judge"):
        print("  -> register a judge for each 'judge' metric (genai_monitor.register_judge);"
              " until then they are reported as coverage gaps, never as passes")
    print("  records must carry: " + "; ".join(f"{k}: {', '.join(v)}"
                                               for k, v in RECORD_FIELDS.items()))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
