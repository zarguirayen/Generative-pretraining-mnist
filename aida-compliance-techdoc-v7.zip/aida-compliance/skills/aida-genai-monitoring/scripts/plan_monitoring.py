#!/usr/bin/env python3
"""Turn the build-phase evaluation into a production monitoring plan.

    python plan_monitoring.py --context aida/context.json \
        [--inference-frequency daily] [--out aida/monitoring_plan.json]

The guideline is explicit that monitoring is the continuation of the evaluation, not a
separate exercise: the metrics are the same, and the baseline is what evaluation measured.
So this reads the classification, selects the metrics the family requires, and — when the
project has actually run an evaluation — derives each alert threshold from the score that
was observed rather than from a number someone liked.

A threshold with no baseline behind it is guesswork dressed as governance, and is
reported as an open point instead.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RULES = HERE.parent.parent / "aida-core" / "references" / "aida_rules.json"

DROP_RULE = {"prompt": "MON-THRESHOLD-PROMPT", "rag": "MON-THRESHOLD-RAG",
             "agentic": "MON-THRESHOLD-AGENTIC", "hybrid": "MON-THRESHOLD-RAG"}

# Metrics the guideline expects per family, beyond the shared quality set.
FAMILY_METRICS: dict[str, list[str]] = {
    "rag": ["faithfulness", "relevancy", "correctness",
            "recall", "precision", "contextual_relevancy", "mrr", "ndcg"],
    "prompt": ["faithfulness", "relevancy", "correctness"],
    "agentic": ["task_completion", "step_efficiency", "stability",
                "tool_correctness", "tool_argument_correctness", "reasoning_quality",
                "latency", "total_tokens"],
}
FAMILY_METRICS["hybrid"] = FAMILY_METRICS["rag"] + FAMILY_METRICS["agentic"]

# Drift the guideline asks for, per family.
DRIFT_PLAN: dict[str, list[tuple[str, str]]] = {
    "rag": [
        ("knowledge base drift", "the corpus is updated in production; compare it against "
                                 "its pre-production state and review beyond the threshold"),
        ("question test set drift", "user questions move; keep a set of edge cases the "
                                    "system struggled with"),
    ],
    "agentic": [
        ("tool set drift", "any tool or tool parameter added or removed raises an alert - "
                           "it is critical (MON-DRIFT-TOOLSET). Run detect_tool_drift.py "
                           "between two refs"),
        ("tool description drift", "descriptions change behaviour; monitor them as NLP drift"),
        ("tool response drift", "responses from black-box tools vary; monitor like a "
                                "knowledge base"),
        ("queries drift", "cluster production queries into task types and compare the "
                          "distribution against pre-production (chi-square, p < 0.05)"),
    ],
    "prompt": [],
}
DRIFT_PLAN["hybrid"] = DRIFT_PLAN["rag"] + DRIFT_PLAN["agentic"]

# Lower is better for these: the alert fires on a rise, not a drop.
LOWER_IS_BETTER = {"latency", "total_tokens"}
PERIOD_DAYS = {"weekly": 7, "monthly": 30, "quarterly": 91, "yearly": 365}
# A period with fewer inferences than the evaluation guideline asks of a test set cannot
# be read as a pass or a failure (EVAL-RAG-QUERIES 50, EVAL-AGENTIC-QUERIES 20).
MIN_SAMPLES = {"rag": 50, "hybrid": 50, "agentic": 20, "prompt": 20}
ANALYTICS_DEPS = ("scikit-learn", "sklearn", "xgboost", "lightgbm", "catboost")

BASELINE_GLOBS = ("eval/outputs/*/summary.json", "**/outputs/*/summary.json",
                  "eval/**/summary.json", "aida/baseline.json")
SCORE_KEYS = ("score", "value", "mean", "avg", "average")


def rule(rules: dict, rule_id: str) -> dict:
    for item in rules["rules"]:
        if item["id"] == rule_id:
            return item
    return {}


def find_baseline(project: Path) -> tuple[dict, str | None]:
    """Look for an evaluation summary the project already produced.

    The shape is not standardised, so only the two forms actually seen are read:
    {"metric": 0.87, ...} and {"metric": {"score": 0.87}, ...}. Anything else is reported
    as not understood rather than guessed at.
    """
    for pattern in BASELINE_GLOBS:
        for path in sorted(project.glob(pattern)):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            scores: dict[str, float] = {}
            source = data.get("metrics", data) if isinstance(data, dict) else {}
            for name, value in (source or {}).items():
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    scores[name.lower()] = float(value)
                elif isinstance(value, dict):
                    for key in SCORE_KEYS:
                        if isinstance(value.get(key), (int, float)):
                            scores[name.lower()] = float(value[key])
                            break
            if scores:
                return scores, path.as_posix()
    return {}, None


def build_plan(ctx: dict, rules: dict, project: Path, inference_frequency: str | None,
               records: dict | None = None) -> dict:
    family = (ctx.get("classification") or {}).get("family", "unknown")
    level = (ctx.get("classification") or {}).get("agentic_level")

    drop_item = rule(rules, DROP_RULE.get(family, "MON-THRESHOLD-PROMPT"))
    drop_pct = float(drop_item.get("threshold", {}).get("relative_drop_pct", 20))

    baseline, baseline_source = find_baseline(project)
    quality = rule(rules, "MON-GENAI-QUALITY-MINIMUM")
    candidates = FAMILY_METRICS.get(family, quality.get("prompt_metrics", []))

    metrics = []
    for name in candidates:
        observed = baseline.get(name)
        entry = {"metric": name, "baseline": observed}
        if observed is None:
            entry["alert_threshold"] = None
            entry["note"] = ("no baseline measured - establish it before the end of the "
                             "build phase, the guideline requires it")
        elif name in LOWER_IS_BETTER:
            entry["direction"] = "lower"
            entry["alert_threshold"] = round(observed * (1 + drop_pct / 100), 4)
            entry["note"] = (f"alert above {entry['alert_threshold']} - a {drop_pct:g}% "
                             f"relative degradation from the measured {observed}")
        else:
            entry["alert_threshold"] = round(observed * (1 - drop_pct / 100), 4)
            entry["note"] = (f"alert below {entry['alert_threshold']} - a {drop_pct:g}% "
                             f"relative drop from the measured {observed}")
        metrics.append(entry)

    frequency_item = rule(rules, "MON-FREQUENCY")
    mapping = frequency_item.get("mapping", {})
    schedule = mapping.get(inference_frequency) if inference_frequency else None

    safety = [{"metric": name, "note": "LLM-as-judge or human feedback; no baseline needed - "
                                       "any occurrence is a signal"}
              for name in quality.get("genai_specific", [])]

    return {
        "family": family,
        "agentic_level": level,
        "scope": scope(ctx, records),
        "window": {
            "period": schedule,
            "period_days": PERIOD_DAYS.get(schedule or "", 7),
            "consecutive_breaches": 1,
            "consecutive_rule": f"{drop_item.get('id')}: one monitoring period at or past the "
                                f"drop triggers the alert. Requiring several periods would "
                                f"loosen the guideline, so it needs a justification to the "
                                f"validation stakeholders (MON-FREQUENCY).",
            "min_samples": MIN_SAMPLES.get(family, 20),
            "min_samples_rule": "a period with fewer inferences than the evaluation minimum "
                                "(EVAL-*) is reported as insufficient data, never as a pass",
        },
        "threshold_rule": drop_item.get("id"),
        "relative_drop_pct": drop_pct,
        "baseline_source": baseline_source,
        "metrics": metrics,
        "safety_signals": safety,
        "drift": [{"kind": kind, "how": how} for kind, how in DRIFT_PLAN.get(family, [])],
        "schedule": {
            "inference_frequency": inference_frequency,
            "monitoring_frequency": schedule,
            "rule": frequency_item.get("id"),
            "mapping": mapping,
        },
        "user_feedback": rule(rules, "MON-USER-FEEDBACK").get("requirement"),
        "findings": build_findings(family, metrics, baseline_source, schedule),
    }


def scope(ctx: dict, records: dict | None) -> dict:
    """Which variant the monitoring runs in, and which families are ruled out - each
    decision with the code evidence behind it, so the scope is enforced, not assumed."""
    cls = ctx.get("classification") or {}
    counts = cls.get("signal_counts") or {}
    record = ((records or {}).get("records") or {}).get("observed_ground_truth_collection") or {}
    feedback = (ctx.get("oversight_signals") or {}).get("feedback") or {}
    gt_evidence = (record.get("evidence") or []) + (feedback.get("evidence") or [])
    if record.get("present") or feedback:
        variant = {"variant": "ground_truth", "evidence": gt_evidence[:4],
                   "consequence": "correctness is measured against the observed ground truth "
                                  "and user feedback, joined to each inference by request_id"}
    else:
        variant = {"variant": "no_ground_truth",
                   "evidence": ["records audit: observed_ground_truth_collection not present",
                                "scan: no feedback control"],
                   "consequence": "quality comes from registered judges (LLM-as-judge) and "
                                  "drift analysis becomes necessary; collecting user feedback "
                                  "is the first gap to close (MON-USER-FEEDBACK)"}

    family = cls.get("family")
    deps = ctx.get("dependencies") or {}
    checks = {
        "rag": (counts.get("retrieval", 0), not ctx.get("vector_stores"),
                f"scan: {counts.get('retrieval', 0)} retrieval signal(s), "
                f"{len(ctx.get('vector_stores') or {})} vector store(s)"),
        "agentic": (counts.get("tools", 0) + counts.get("react", 0), True,
                    f"scan: {counts.get('tools', 0)} tool definition(s), "
                    f"{counts.get('react', 0)} agent-loop signal(s)"),
        "analytics": (sum(1 for d in deps if d.lower() in ANALYTICS_DEPS), True,
                      "dependencies: no scikit-learn / xgboost / lightgbm / catboost"),
    }
    ruled_out = [{"family": name, "evidence": evidence,
                  "consequence": f"no {name} metric or drift monitor is generated"}
                 for name, (hits, absent, evidence) in checks.items()
                 if name != family and not (family == "hybrid" and name in ("rag", "agentic"))
                 and hits == 0 and absent]
    return {"family": family, "level": cls.get("agentic_level"),
            "family_evidence": (cls.get("family_evidence") or [])[:3], **variant,
            "ruled_out": ruled_out}


def build_findings(family, metrics, baseline_source, schedule) -> list[dict]:
    findings = []
    if family == "unknown":
        findings.append({
            "rule": "MON-GENAI-QUALITY-MINIMUM", "severity": "blocking",
            "summary": "the system family is unknown, so no metric set can be selected",
            "detail": "Confirm the classification with aida-core first; the family decides "
                      "which metrics are mandatory and which drop threshold applies."})
    if not baseline_source:
        findings.append({
            "rule": "MON-GENAI-QUALITY-MINIMUM", "severity": "blocking",
            "summary": "no build-phase evaluation baseline found",
            "detail": "Monitoring compares production scores against the evaluation. "
                      "Without a baseline, no threshold can be justified. The "
                      "evaluation-pipeline plugin produces one."})
    if not schedule:
        findings.append({
            "rule": "MON-FREQUENCY", "severity": "blocking",
            "summary": "monitoring frequency not determined",
            "detail": "It follows inference frequency: daily to weekly, weekly to monthly, "
                      "monthly to quarterly, quarterly to yearly. Ask the risk owner how "
                      "often the system is called."})
    return findings


def render(plan: dict) -> str:
    lines = [
        f"System family        : {plan['family']}"
        + (f" / {plan['agentic_level']}" if plan["agentic_level"] else ""),
        f"Alert threshold rule : {plan['threshold_rule']} - "
        f"{plan['relative_drop_pct']:g}% relative drop",
        f"Baseline             : {plan['baseline_source'] or 'NOT FOUND'}",
        f"Variant              : {plan['scope']['variant']} - {plan['scope']['consequence']}",
        "Ruled out            : " + (", ".join(f"{r['family']} ({r['evidence']})"
                                              for r in plan["scope"]["ruled_out"]) or "none"),
        f"Monitoring frequency : {plan['schedule']['monitoring_frequency'] or 'to determine'}"
        f"  (inference: {plan['schedule']['inference_frequency'] or 'unknown'})",
        "",
        f"{'METRIC':<26} {'BASELINE':<10} {'ALERT BELOW':<12} NOTE",
    ]
    for metric in plan["metrics"]:
        baseline = f"{metric['baseline']}" if metric["baseline"] is not None else "-"
        threshold = f"{metric['alert_threshold']}" if metric["alert_threshold"] is not None else "-"
        lines.append(f"{metric['metric'][:25]:<26} {baseline:<10} {threshold:<12} "
                     f"{metric['note'][:52]}")

    if plan["safety_signals"]:
        lines.append("\nSAFETY SIGNALS (any occurrence is a signal)")
        for signal in plan["safety_signals"]:
            lines.append(f"  {signal['metric'].replace('_', ' ')}")

    if plan["drift"]:
        lines.append("\nDRIFT TO MONITOR")
        for drift in plan["drift"]:
            lines.append(f"  {drift['kind']}")
            lines.append(f"      {drift['how']}")

    if plan["findings"]:
        lines.append(f"\nFINDINGS ({len(plan['findings'])})")
        for finding in plan["findings"]:
            lines.append(f"  [{finding['rule']}] {finding['summary']}")
            lines.append(f"      {finding['detail']}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the GenAI monitoring plan.")
    parser.add_argument("--context", default="aida/context.json")
    parser.add_argument("--project", default=".")
    parser.add_argument("--rules", default=str(DEFAULT_RULES))
    parser.add_argument("--inference-frequency",
                        choices=["daily", "weekly", "monthly", "quarterly"],
                        help="how often the system is called in production")
    parser.add_argument("--records", default="aida/records_audit.json",
                        help="record-keeping audit, used to decide the ground-truth variant")
    parser.add_argument("--out", default="aida/monitoring_plan.json")
    args = parser.parse_args()

    context_path = Path(args.context)
    if not context_path.exists():
        print(f"error: context not found: {context_path}\n"
              f"       run the aida-core skill first", file=sys.stderr)
        return 2

    ctx = json.loads(context_path.read_text(encoding="utf-8"))
    rules = json.loads(Path(args.rules).read_text(encoding="utf-8"))
    records_path = Path(args.records)
    records = (json.loads(records_path.read_text(encoding="utf-8"))
               if records_path.exists() else None)
    plan = build_plan(ctx, rules, Path(args.project), args.inference_frequency, records)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(plan, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(render(plan))
    print(f"\nplan written to {out}")
    return 1 if any(f["severity"] == "blocking" for f in plan["findings"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
