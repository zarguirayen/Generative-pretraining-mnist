#!/usr/bin/env python3
"""Inventory what the agent can do irreversibly, and whether a human can stop it.

    python audit_oversight.py [project] [--out aida/oversight_audit.json] [--json]

The guideline asks whether humans can oversee the system. That question is unanswerable
in the abstract and very answerable per tool: an agent that can send mail, delete a
directory or move money needs an override and a stop control, and either the code has
them or it does not.

The analysis is done on the syntax tree, not with text search: a tool is a function the
model can call, and what matters is what that function's body does. Grep would report
that the file mentions `shutil.rmtree` somewhere; this reports which callable tool
reaches it.

Standard library only.
"""

from __future__ import annotations

import argparse
import ast
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "aida-core" / "scripts"))
from ast_utils import dotted  # noqa: E402  (shared with the other syntax-tree audits)

SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env", "dist", "build",
    ".mypy_cache", ".pytest_cache", "site-packages", "aida", ".tox",
}

# effect -> (severity, what a human would lose if it ran wrongly)
EFFECTS = {
    "message": ("high", "sends a message to a person - it cannot be unsent"),
    "delete": ("high", "deletes data"),
    "payment": ("high", "moves money or executes a transaction"),
    "external_write": ("medium", "writes to an external system over the network"),
    "db_write": ("medium", "writes to a database"),
    "file_write": ("low", "writes to the local filesystem"),
}
SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "none": 3}

# Call signatures, matched on the dotted name of the callee.
CALL_SIGNATURES: list[tuple[str, tuple[str, ...]]] = [
    ("message", ("smtplib.smtp", "sendmail", "send_email", "send_message", "send_mail",
                 "ses.send_email", "post_message", "chat_postmessage", "notify")),
    ("delete", ("os.remove", "os.unlink", "shutil.rmtree", "path.unlink", "delete_object",
                "delete_many", "drop_table", "os.rmdir")),
    ("payment", ("transfer", "wire", "charge", "capture", "refund", "place_order",
                 "execute_trade", "submit_payment")),
    ("external_write", ("requests.post", "requests.put", "requests.patch", "requests.delete",
                        "httpx.post", "httpx.put", "httpx.patch", "httpx.delete",
                        "session.post", "client.post", "urlopen")),
    ("db_write", ("cursor.execute", "conn.execute", "session.commit", "conn.commit",
                  "session.add", "engine.execute")),
    ("file_write", ("write_text", "write_bytes", "to_csv", "to_excel", "savefig",
                    "shutil.copy", "shutil.move", "json.dump")),
]
SQL_WRITE = ("insert into", "update ", "delete from", "drop table", "alter table")

TOOL_DECORATORS = ("tool", "function_tool", "structuredtool", "kernel_function", "agent_tool")
APPROVAL_MARKERS = ("require_approval", "requires_approval", "human_in_the_loop", "hitl",
                    "confirm", "approval", "ask_user", "interrupt", "needs_confirmation")
STOP_MARKERS = ("kill_switch", "emergency_stop", "disable_system", "circuit_breaker",
                "is_enabled", "feature_flag", "shutdown")

# A project-wide approval policy - an allowlist of permitted commands, a permission
# layer - is a real gate even though no decorator sits on the tool. Reporting such a
# project as fully ungated would be a false positive, so it is detected separately and
# reported as context rather than folded into the per-tool verdict.
POLICY_MARKERS = ("allowlist", "allow_list", "allowed_commands", "approved_commands",
                  "denylist", "permission_policy", "tool_policy", "policy_engine",
                  "confirm_before", "require_confirmation", "auto_approve")
# Isolated execution does not remove the need for a gate, but it changes what an
# unreviewed action can reach, and the evaluation guideline explicitly wants tool calls
# sandboxed during evaluation. Stated, never used to excuse a missing control.
SANDBOX_MARKERS = ("docker", "container", "sandbox", "firejail", "gvisor", "singularity",
                   "isolated_env", "e2b", "daytona", "modal.", "nsjail")
# Tools reached through an MCP server are declared outside the codebase, so this audit
# cannot see them. The monitoring guideline names them as black-box tools.
MCP_CONFIG_NAMES = (".mcp.json", "mcp.json", "mcp_servers.json", ".mcp.yaml", "mcp.yaml")
MCP_KEYS = ("mcpservers", "mcp_servers", "servers")
CONFIG_SUFFIXES = (".yaml", ".yml", ".json", ".toml", ".cfg", ".ini", ".env")


def decorator_names(func: ast.AST) -> list[str]:
    names = []
    for decorator in getattr(func, "decorator_list", []):
        target = decorator.func if isinstance(decorator, ast.Call) else decorator
        name = dotted(target)
        if name:
            names.append(name)
    return names


def string_constants(node: ast.AST) -> list[str]:
    return [n.value.lower() for n in ast.walk(node)
            if isinstance(n, ast.Constant) and isinstance(n.value, str)]


def is_tool(func: ast.AST) -> bool:
    return any(any(marker == name or name.endswith("." + marker) or marker in name
                   for marker in TOOL_DECORATORS)
               for name in decorator_names(func))


def analyse_function(func: ast.AST, source_file: str) -> dict:
    """What does this tool do, and is a human asked before it does it?"""
    effects: dict[str, list[int]] = {}

    for node in ast.walk(func):
        if not isinstance(node, ast.Call):
            continue
        name = dotted(node.func)
        if not name:
            continue
        for effect, signatures in CALL_SIGNATURES:
            if any(name == sig or name.endswith("." + sig.split(".")[-1]) and sig in name
                   or name.endswith(sig) for sig in signatures):
                effects.setdefault(effect, []).append(node.lineno)
                break
        else:
            # A raw SQL write shows up as a string argument, not as a call name.
            if "execute" in name:
                for text in string_constants(node):
                    if any(keyword in text for keyword in SQL_WRITE):
                        effects.setdefault("db_write", []).append(node.lineno)
                        break

    body_names = {dotted(n.func) for n in ast.walk(func) if isinstance(n, ast.Call)}
    body_names |= {n.id.lower() for n in ast.walk(func) if isinstance(n, ast.Name)}
    decorators = decorator_names(func)
    has_gate = any(marker in name for name in list(body_names) + decorators
                   for marker in APPROVAL_MARKERS)

    severity = "none"
    for effect in effects:
        if SEVERITY_ORDER[EFFECTS[effect][0]] < SEVERITY_ORDER[severity]:
            severity = EFFECTS[effect][0]

    signature = func.args
    parameters = [a.arg for a in (list(signature.posonlyargs) + list(signature.args)
                                  + list(signature.kwonlyargs))]

    return {
        "name": func.name,
        "file": source_file,
        "line": func.lineno,
        "parameters": parameters,
        "docstring": (ast.get_docstring(func) or "").split("\n")[0][:100],
        "effects": {effect: sorted(set(lines)) for effect, lines in effects.items()},
        "severity": severity,
        "irreversible": severity in ("high", "medium"),
        "approval_gate": has_gate,
    }


def iter_python(root: Path):
    for path in root.rglob("*.py"):
        # Relative parts only - an absolute-path filter skips every file of a project
        # that lives under a directory called build, env or venv.
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        yield path


def declared_tools(root: Path) -> list[dict]:
    """Tools declared as a schema rather than as a decorated function.

    The OpenAI-style `{"type": "function", "function": {"name": ..., "parameters": ...}}`
    is the most common way to expose a tool to a model, and a decorator-based audit sees
    none of it. The implementation is dispatched by name elsewhere, so the body cannot be
    analysed here - these are reported by name, with their irreversibility left open.
    """
    found: list[dict] = []

    def names_in(node: ast.Dict) -> str | None:
        keys = {k.value for k in node.keys
                if isinstance(k, ast.Constant) and isinstance(k.value, str)}
        if not ({"name"} <= keys and keys & {"parameters", "input_schema", "description"}):
            return None
        for key, value in zip(node.keys, node.values):
            if isinstance(key, ast.Constant) and key.value == "name" \
                    and isinstance(value, ast.Constant) and isinstance(value.value, str):
                return value.value
        return None

    for path in iter_python(root):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
        except (OSError, SyntaxError):
            continue
        relative = path.relative_to(root).as_posix()
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict):
                name = names_in(node)
                if name and not any(t["name"] == name for t in found):
                    found.append({"name": name, "file": relative, "line": node.lineno})
    return found


def mcp_servers(root: Path) -> list[dict]:
    """Servers whose tools are declared outside this codebase, so outside this audit."""
    found: list[dict] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.name.lower() not in MCP_CONFIG_NAMES:
            continue
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        relative = path.relative_to(root).as_posix()
        names: list[str] = []
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
            for key in MCP_KEYS:
                block = next((v for k, v in data.items() if k.lower() == key), None)
                if isinstance(block, dict):
                    names = sorted(block)
                    break
                if isinstance(block, list):
                    names = [str(item.get("name", item)) for item in block]
                    break
        except (OSError, json.JSONDecodeError, AttributeError):
            pass
        found.append({"config": relative, "servers": names})
    return found


def scan_python(root: Path, signals: dict[str, list[str]]) -> list[dict]:
    """Tools from the syntax tree, control signals from the source lines."""
    tools: list[dict] = []
    for path in iter_python(root):
        try:
            source = path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source)
        except (OSError, SyntaxError):
            continue
        relative = path.relative_to(root).as_posix()
        tools += [analyse_function(node, relative) for node in ast.walk(tree)
                  if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and is_tool(node)]
        for lineno, line in enumerate(source.lower().splitlines(), 1):
            where = f"{relative}:{lineno}"
            if any(marker in line for marker in STOP_MARKERS):
                signals["stop_control"].append(where)
            if "thumbs" in line or "feedback" in line or "flag_output" in line:
                signals["user_feedback"].append(where)
            if "source_document" in line or "citation" in line:
                signals["source_citation"].append(where)
            match_policy_and_sandbox(line, where, signals)
    return tools


def scan_config(root: Path, signals: dict[str, list[str]]) -> None:
    """An approval policy or a sandbox is usually declared in configuration, not in code,
    so a Python-only pass would miss both and report a governed project as ungoverned."""
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in CONFIG_SUFFIXES:
            continue
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        relative = path.relative_to(root).as_posix()
        try:
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
        except OSError:
            continue
        for lineno, line in enumerate(text.splitlines(), 1):
            match_policy_and_sandbox(line, f"{relative}:{lineno}", signals)


def match_policy_and_sandbox(line: str, where: str, signals: dict[str, list[str]]) -> None:
    if any(marker in line for marker in POLICY_MARKERS):
        signals["approval_policy"].append(where)
    if any(marker in line for marker in SANDBOX_MARKERS):
        signals["sandboxing"].append(where)


def audit(root: Path) -> dict:
    signals: dict[str, list[str]] = {key: [] for key in (
        "stop_control", "user_feedback", "source_citation", "approval_policy", "sandboxing")}
    tools = scan_python(root, signals)
    scan_config(root, signals)

    ungated = [t for t in tools if t["irreversible"] and not t["approval_gate"]]
    mcp = mcp_servers(root)
    # Schema-declared tools whose implementation is dispatched by name; only report the
    # ones no decorated function already covers.
    known = {t["name"] for t in tools}
    schema_tools = [t for t in declared_tools(root) if t["name"] not in known]
    return {
        "project": str(root.resolve()),
        "tools": sorted(tools, key=lambda t: (SEVERITY_ORDER[t["severity"]], t["name"])),
        "declared_tools": schema_tools,
        "mcp": mcp,
        "counts": {
            "tools": len(tools),
            "irreversible": sum(1 for t in tools if t["irreversible"]),
            "gated": sum(1 for t in tools if t["irreversible"] and t["approval_gate"]),
            "ungated": len(ungated),
        },
        "controls": {key: found[:5] for key, found in signals.items()},
        "findings": build_findings(tools, ungated, signals["stop_control"],
                                   signals["user_feedback"], signals["source_citation"],
                                   signals["approval_policy"], signals["sandboxing"],
                                   mcp, schema_tools),
    }


def build_findings(tools, ungated, stop_control, feedback, citation,
                   policy, sandbox, mcp, schema_tools=()) -> list[dict]:
    """Every gap the audit can state, tool findings first, then the controls around them."""
    return (tool_findings(ungated, policy, sandbox, schema_tools, mcp)
            + control_findings(tools, stop_control, feedback, citation))


def tool_findings(ungated, policy, sandbox, schema_tools, mcp) -> list[dict]:
    """What the model can do without a human: ungated tools, tools this audit cannot read."""
    findings: list[dict] = []
    if ungated:
        detail = ", ".join(f"{t['name']} ({t['file']}:{t['line']})" for t in ungated)
        if policy:
            detail += (f". A project-level approval policy was found at {policy[0]} - "
                       f"confirm whether it covers these tools; this audit checks the tool "
                       f"itself, not the policy's coverage.")
        if sandbox:
            detail += (f" A containerisation marker was found at {sandbox[0]} - confirm "
                       f"whether tool calls actually execute in isolation. If they do it "
                       f"limits what an unreviewed action can reach, but isolation never "
                       f"replaces the approval the guideline requires.")
        findings.append({
            "rule": "OVERSIGHT-INTERVENTION",
            "severity": "blocking",
            "summary": f"{len(ungated)} irreversible tool(s) run with no human approval gate",
            "detail": detail,
        })
    if schema_tools:
        findings.append({
            "rule": "OVERSIGHT-INTERVENTION",
            "severity": "advisory",
            "summary": f"{len(schema_tools)} tool(s) declared as a schema, implementation "
                       f"not linked",
            "detail": (", ".join(f"{t['name']} ({t['file']}:{t['line']})"
                                 for t in schema_tools[:6])
                       + ". These are exposed to the model as JSON schemas and dispatched "
                         "by name, so this audit cannot read their bodies and cannot judge "
                         "whether they are irreversible. Confirm each one's effect with the "
                         "developer before writing section 3.9."),
        })
    if mcp:
        servers = sorted({name for entry in mcp for name in entry["servers"]})
        findings.append({
            "rule": "OVERSIGHT-INTERVENTION",
            "severity": "advisory",
            "summary": f"{len(mcp)} MCP configuration(s) found - their tools are not visible "
                       f"to this audit",
            "detail": (f"Servers: {', '.join(servers) or 'not named in the config'}. Tools "
                       f"reached through an MCP server are declared outside this codebase, so "
                       f"the tool count above is a floor, not a total. The monitoring "
                       f"guideline treats them as black-box tools whose responses must be "
                       f"monitored for drift, and their irreversibility has to be assessed "
                       f"with the server owner."),
        })
    return findings


def control_findings(tools, stop_control, feedback, citation) -> list[dict]:
    """The oversight controls the guideline requires around the tools: stop, feedback, sources."""
    findings: list[dict] = []
    if tools and not stop_control:
        findings.append({
            "rule": "OVERSIGHT-CAPABILITIES",
            "severity": "blocking",
            "summary": "no stop or disable control found",
            "detail": "The guideline requires overseers to be able to interrupt the "
                      "system's operations via a stop button or equivalent procedure.",
        })
    if not feedback:
        findings.append({
            "rule": "MON-USER-FEEDBACK",
            "severity": "blocking",
            "summary": "no user feedback or flag control found",
            "detail": "Users must be able to flag an output, and on a negative signal say "
                      "whether the problem is the generated answer or the retrieval / tool path.",
        })
    if not citation:
        findings.append({
            "rule": "OVERSIGHT-EXPLAINABILITY",
            "severity": "blocking",
            "summary": "no explainability measure found",
            "detail": "At least one is required. For GenAI the guideline names showing the "
                      "retrieved sources behind an answer.",
        })
    return findings


def render(result: dict) -> str:
    counts = result["counts"]
    lines = [
        f"Tools callable by the model : {counts['tools']}",
        f"  irreversible             : {counts['irreversible']}",
        f"  with a human approval gate: {counts['gated']}",
        f"  WITHOUT a gate            : {counts['ungated']}",
        "",
    ]
    if result["tools"]:
        lines.append(f"{'TOOL':<24} {'SEVERITY':<9} {'GATE':<6} WHAT IT DOES")
        for tool in result["tools"]:
            effects = ", ".join(EFFECTS[e][1] for e in tool["effects"]) or "read-only"
            gate = "yes" if tool["approval_gate"] else ("NO" if tool["irreversible"] else "-")
            lines.append(f"{tool['name'][:23]:<24} {tool['severity']:<9} {gate:<6} {effects[:60]}")
            lines.append(f"{'':<24} {tool['file']}:{tool['line']}")
    elif not result.get("declared_tools"):
        lines.append("No model-callable tool found. If the system is agentic, the tools "
                     "are declared in a way this audit does not recognise - say so rather "
                     "than concluding there are none.")

    if result.get("declared_tools"):
        lines.append("")
        lines.append("DECLARED AS A SCHEMA (body not linked - effect to confirm)")
        for tool in result["declared_tools"]:
            lines.append(f"  {tool['name'][:30]:<32} {tool['file']}:{tool['line']}")

    if result.get("mcp"):
        lines.append("")
        lines.append("MCP SERVERS (tools declared outside this codebase)")
        for entry in result["mcp"]:
            names = ", ".join(entry["servers"]) or "not named in the config"
            lines.append(f"  {entry['config']}: {names}")

    controls = result.get("controls", {})
    for label, key in (("approval policy", "approval_policy"), ("isolated execution", "sandboxing")):
        if controls.get(key):
            lines.append(f"\n{label}: {controls[key][0]}")

    if result["findings"]:
        lines.append(f"\nFINDINGS ({len(result['findings'])})")
        for finding in result["findings"]:
            lines.append(f"  [{finding['rule']}] {finding['summary']}")
            lines.append(f"      {finding['detail']}")
    else:
        lines.append("\nNo blocking finding.")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit human oversight of an agentic system.")
    parser.add_argument("project", nargs="?", default=".")
    parser.add_argument("--out", default="aida/oversight_audit.json")
    parser.add_argument("--json", action="store_true", help="print the JSON instead of the report")
    args = parser.parse_args()

    root = Path(args.project).expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    result = audit(root)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(result, indent=2, ensure_ascii=False) if args.json else render(result))
    print(f"\naudit written to {out}")
    return 1 if any(f["severity"] == "blocking" for f in result["findings"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
