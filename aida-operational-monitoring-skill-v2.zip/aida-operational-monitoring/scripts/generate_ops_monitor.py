#!/usr/bin/env python3
"""Turn the operational plan into a monitor that runs: code, configuration, schedule.

    python generate_ops_monitor.py --plan aida/operational_plan.json --out aida/monitoring

The operational plan says which metrics of the guideline's Table 5 the records can feed.
This writes, under aida/monitoring/, what measures them (MON-TIMING: in place before the
end of the build phase):

  ops_monitor.py              reads the record journal, computes the Table 5 metrics,
                              compares them with the thresholds, journals each alert
  ops_monitor_config.json     one rule per metric: threshold and its justification, unit,
                              feeding record, severity, noise guard; the alert channels
  schedule/ops-crontab.txt    the run at the frequency MON-FREQUENCY sets
  schedule/ops-gitlab-ci.yml  the same, as a scheduled CI job that turns red on an alert

Thresholds are the guideline's defaults. The guideline asks for them to be tailored to the
system and validated before the end of the build phase: a tailored value is set in the
config with its justification, and the validation stays an open point. The daily token
quota has no default - without --token-quota, token usage is reported as a coverage gap.

Alerts are sent to the channels given here (--email-to with --smtp-host, --webhook-url);
none by default, in which case they stay in the journal and the scheduled job turns red.
The SMTP password is never written: the config names the environment variable holding it.
Standard library only.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "assets" / "ops_monitor.py.template"

# metric -> (kind, default threshold, unit, feeding record, severity), from Table 5.
RULES: dict[str, tuple[str, float | None, str, str, str]] = {
    "average_inference_latency": ("above", 3000, "ms", "inference (latency_ms)", "high"),
    "data_processing_duration": ("above", 3000, "ms", "inference (processing_ms)", "medium"),
    "output_size": ("above", 2000, "tokens", "inference (tokens.output)", "medium"),
    "uptime_pct": ("below", 99.0, "%", "uptime_probe", "high"),
    "timeout_rate": ("above", 5.0, "%", "inference outcome or timeout_event", "high"),
    "error_rate": ("above", 2.0, "%", "inference outcome or error_event", "high"),
    "system_crashes": ("above", 1, "crash(es) in 24h", "incident (kind crash)", "critical"),
    "resource_utilization": ("above", 90.0, "% peak CPU / GPU / memory", "resource_usage", "high"),
    "unauthorized_access_pct": ("above", 3, "failed logins within 1 min", "access (status failed)", "critical"),
    "token_usage": ("above", None, "tokens per day", "inference (tokens)", "medium"),
    "request_spike": ("above", 3.0, "x the hourly mean", "inference", "medium"),
    "active_users_trend": ("versus_history", 30, "users", "inference (actor)", "medium"),
    "average_usage_duration_per_user": ("versus_history", None, "s", "inference (session_id)", "low"),
}
# metric -> why the Table 5 default is the right starting value; a tailored value replaces
# it in the config with its own justification.
JUSTIFICATION = {
    "average_inference_latency": "beyond 3 s an interactive user abandons or retries, and each "
                                 "retry adds load",
    "data_processing_duration": "past 3 s the pre- and post-processing, not the model, is the "
                                "bottleneck",
    "output_size": "2000 output tokens signals a runaway generation, and it drives cost",
    "uptime_pct": "99 % a week allows 1 h 41 min of downtime, what a business service is "
                  "expected to hold",
    "timeout_rate": "one call in twenty timing out means a dependency is saturated or down",
    "error_rate": "past one call in fifty, failures are no longer incidental",
    "system_crashes": "a crash is never noise: the first one in 24 h is the alert",
    "resource_utilization": "at 90 % there is no headroom left for a peak",
    "unauthorized_access_pct": "three failed logins from one actor within a minute is the "
                               "signature of credential guessing",
    "token_usage": "only the team knows its budget: the daily quota it sets (FinOps / GreenOps)",
    "request_spike": "three times the hourly mean in one hour exceeds any organic growth",
    "active_users_trend": "a 30 % fall month over month means users are leaving the system",
    "average_usage_duration_per_user": "under a fifth or over three times the usual session, "
                                       "the system no longer serves its use",
}

# metric -> what keeps an isolated event from paging anyone. consecutive_breaches is 1:
# the period aggregate is already the guideline's smoothing, and requiring more periods
# would alert later than Table 5 sets - raise it only with the risk owner's justification.
ON_REQUESTS = {"min_samples": 20, "consecutive_breaches": 1,
               "why": "a rate or an average over fewer than 20 requests crosses the "
                      "threshold on a single event"}
IMMEDIATE = {"consecutive_breaches": 1,
             "why": "a single occurrence is the signal, as Table 5 sets it"}
NOISE_GUARDS = {
    "average_inference_latency": ON_REQUESTS, "data_processing_duration": ON_REQUESTS,
    "output_size": ON_REQUESTS, "timeout_rate": ON_REQUESTS, "error_rate": ON_REQUESTS,
    "active_users_trend": ON_REQUESTS, "average_usage_duration_per_user": ON_REQUESTS,
    "uptime_pct": {"min_samples": 6, "consecutive_breaches": 1,
                   "why": "availability over fewer than 6 probes is one outage, not a rate"},
    "resource_utilization": {"sustained": 3, "consecutive_breaches": 1,
                             "why": "one sample at the threshold is a peak; three in a row "
                                    "is saturation"},
    "request_spike": {"min_hourly_mean": 5, "consecutive_breaches": 1,
                      "why": "tripling a handful of requests an hour is not a spike"},
    "system_crashes": IMMEDIATE, "unauthorized_access_pct": IMMEDIATE,
    "token_usage": IMMEDIATE,
}
CRON = {"weekly": "0 6 * * 1", "monthly": "0 6 1 * *", "quarterly": "0 6 1 1,4,7,10 *",
        "yearly": "0 6 2 1 *"}
ALERT_PROCEDURE = [
    "Investigate: new usage pattern, dependency outage, deployment, capacity",
    "Justify whether corrective measures are taken, and if not, why",
    "Correct: scale, fix, roll back, tighten access",
    "Record the investigation and the measures in the AI System Journal (DOC-JOURNAL)",
]


def channels(email_to: list[str], smtp_host: str | None, webhook_url: str | None) -> list[dict]:
    """The alert channels asked for on the command line; none unless given."""
    found = []
    if email_to and smtp_host:
        found.append({"type": "email", "to": email_to, "smtp_host": smtp_host, "port": 25,
                      "sender": "aida-monitoring@" + smtp_host, "starttls": False,
                      "user": None, "password_env": "AIDA_SMTP_PASSWORD"})
    if webhook_url:
        if not webhook_url.startswith("https://"):
            raise SystemExit("error: the webhook must be https")
        found.append({"type": "webhook", "url": webhook_url})
    return found


def build_config(plan: dict, journal: str, token_quota: float | None,
                 alert_channels: list[dict] | None = None,
                 known_ip_prefixes: list[str] | None = None) -> dict:
    """The plan made executable: one justified, guarded rule per Table 5 metric, the
    window, the alert channels, and the additions the rated risk turned on (§5)."""
    table = {m["metric"]: m for m in plan["metrics"]}
    rules = []
    for metric, (kind, limit, unit, feeds, severity) in RULES.items():
        if metric == "token_usage":
            limit = token_quota
        rules.append({
            "metric": metric, "kind": kind, "limit": limit, "unit": unit, "feeds": feeds,
            "severity": severity,
            "condition": table.get(metric, {}).get("alert", ""),
            "source": "Table 5 default (MON-OPERATIONAL-MINIMUM)",
            "justification": JUSTIFICATION[metric],
            "noise_guard": NOISE_GUARDS[metric],
            "selected": metric in plan.get("selected", []),
            "note": ("no daily token quota defined - set it with --token-quota"
                     if metric == "token_usage" and limit is None else ""),
        })
    period = plan["schedule"].get("monitoring_frequency") or "weekly"
    additions = {d["flag"]: d["applied"] for d in plan.get("adaptation", [])}
    return {
        "generated_from": "aida/operational_plan.json", "rule": plan["rule"],
        "window": {"period": period,
                   "period_days": {"weekly": 7, "monthly": 30, "quarterly": 91, "yearly": 365}[period]},
        "rules": rules, "journal": journal, "alert_procedure": ALERT_PROCEDURE,
        "notify": {"min_severity": "medium" if additions.get("notify_from_medium", True) else "high",
                   "channels": alert_channels or []},
        "additions": {k: v for k, v in additions.items() if k != "notify_from_medium"},
        "access": {"known_ip_prefixes": known_ip_prefixes or []},
        "risk": plan.get("risk", {}), "adaptation": plan.get("adaptation", []),
        "assigned_to": "operations owner - name to be confirmed",
        "thresholds_validated_by": "[A CONFIRMER - thresholds tailored and validated before the "
                                   "end of the build phase (MON-OPERATIONAL-MINIMUM)]",
    }


def schedules(config: dict, out: Path) -> dict[str, str]:
    """The crontab line and the scheduled GitLab CI job, at the monitoring frequency."""
    period = config["window"]["period"]
    cron = CRON.get(period, CRON["weekly"])
    command = (f"python {out.as_posix()}/ops_monitor.py --config "
               f"{out.as_posix()}/ops_monitor_config.json")
    return {
        "cron": cron,
        "ops-crontab.txt": (f"# AIDA operational monitoring - {period}, MON-FREQUENCY\n"
                            f"# exit code 1 = an alert was raised and recorded in the journal\n"
                            f"{cron} cd /path/to/project && {command}\n"),
        "ops-gitlab-ci.yml": (f"# AIDA operational monitoring - add to .gitlab-ci.yml and create a\n"
                              f"# pipeline schedule with the cron \"{cron}\" ({period}, MON-FREQUENCY).\n"
                              f"aida-operational-monitoring:\n  stage: monitor\n  rules:\n"
                              f"    - if: '$CI_PIPELINE_SOURCE == \"schedule\"'\n"
                              f"  script:\n    - {command}\n"),
    }


def main() -> int:
    """Command line: write the operational monitor, its config and schedule."""
    parser = argparse.ArgumentParser(description="Generate the runnable operational monitor.")
    parser.add_argument("--plan", default="aida/operational_plan.json")
    parser.add_argument("--out", default="aida/monitoring")
    parser.add_argument("--journal", default="logs/aida_records.jsonl")
    parser.add_argument("--token-quota", type=float, help="daily token quota (finops)")
    parser.add_argument("--email-to", action="append", default=[],
                        help="overseer address alerts are mailed to (repeatable)")
    parser.add_argument("--smtp-host", help="SMTP relay for --email-to")
    parser.add_argument("--webhook-url", help="https webhook alerts are posted to (chat, incident tool)")
    parser.add_argument("--known-ip-prefix", action="append", default=[],
                        help="address range users come from, e.g. 10.12. (repeatable)")
    args = parser.parse_args()

    plan_path = Path(args.plan)
    if not plan_path.exists():
        print(f"error: plan not found: {plan_path}\n       run plan_operational.py first",
              file=sys.stderr)
        return 2
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    out = Path(args.out)
    (out / "schedule").mkdir(parents=True, exist_ok=True)
    config = build_config(plan, args.journal, args.token_quota,
                          channels(args.email_to, args.smtp_host, args.webhook_url),
                          args.known_ip_prefix)
    shutil.copyfile(TEMPLATE, out / "ops_monitor.py")
    (out / "ops_monitor_config.json").write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    sched = schedules(config, out)
    for name in ("ops-crontab.txt", "ops-gitlab-ci.yml"):
        (out / "schedule" / name).write_text(sched[name], encoding="utf-8")

    print(f"Operational monitor written to {out}/")
    print(f"  window   : {config['window']['period']}, cron \"{sched['cron']}\"")
    sent_to = ", ".join(c["type"] for c in config["notify"]["channels"]) or "none - journal only"
    print(f"  alerts   : sent from {config['notify']['min_severity']} severity to {sent_to}")
    print(f"  rules    : {len(config['rules'])} Table 5 metrics, "
          f"{sum(r['selected'] for r in config['rules'])} selected by the plan")
    for rule in config["rules"]:
        limit = "no default" if rule["limit"] is None else f"{rule['limit']:g} {rule['unit']}"
        print(f"  {rule['metric']:<32} {rule['kind']:<15} {limit:<32} <- {rule['feeds']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
