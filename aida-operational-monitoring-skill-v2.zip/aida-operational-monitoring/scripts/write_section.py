#!/usr/bin/env python3
"""Write the AI System Operational Monitoring half of section 3.8.

    python write_section.py --plan aida/operational_plan.json \
        [--resilience aida/resilience.json] --values aida/values.json

The plan knows which metrics the project's records can actually feed; the resilience check
knows which outbound calls can hang. Both belong in this section, because a latency
commitment over an unbounded call is not a commitment.

Quality metrics are not written here - they belong to the AI Model Monitoring half, owned
by `aida-genai-monitoring`.

Standard library only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "aida-core" / "scripts"))
from section_values import entry, merge, report  # noqa: E402

METRICS = ("List and justification of the choice of the metrics used for the operational "
           "system monitoring.")
TOOLS = "Description of the tools and processes put in place."
LOGGING = "Details of the logging mechanisms for system actions and decisions."
ALERTS = ("Alert mechanism: document the implemented alerts for potential unintended "
          "outcomes, including elements related to risks to health, safety, and fundamental "
          "rights of individuals or any potential discrimination.")
PROCEDURES = "Proposed procedures for addressing alerts."


def implemented(monitor: dict | None) -> str:
    """What runs, once generate_ops_monitor.py has written the monitor."""
    if not monitor:
        return (" [A CONFIRMER - the monitor is not generated yet: run generate_ops_monitor.py; "
                "MON-TIMING requires it before the end of the build phase]")
    measured = [r["metric"] for r in monitor["rules"] if r["limit"] is not None or r["kind"] != "above"]
    sent_to = ", ".join(c["type"] for c in (monitor.get("notify") or {}).get("channels", []))
    return (f" Implemented by aida/monitoring/ops_monitor.py, scheduled {monitor['window']['period']} "
            f"(aida/monitoring/schedule/): each run computes {len(measured)} metrics of Table 5 "
            f"from the record journal, compares them with thresholds that each carry their "
            f"justification, holds an isolated event back with a noise guard (minimum sample, "
            f"sustained peak, minimum volume, consecutive periods), reports a metric whose "
            f"record is missing as a coverage gap, and appends each alert - value, threshold, "
            f"trend, probable cause, next steps - to the same hash-chained journal. Alerts are "
            f"sent to " + (sent_to or "[A CONFIRMER - the channel the overseers read: "
                                   "e-mail or webhook, given to generate_ops_monitor.py]")
            + ".")


ALERTS_TEXT = (
    "A threshold crossing raises an automated alert - mail or system notification - to "
    "the named human overseers. Thresholds and alerts must not trigger a "
    "disproportionate reaction to an isolated event; on a major alert the governance "
    "bodies are informed and decide on suspension or on validating corrective "
    "measures. Alerts related to risks to health, safety, fundamental rights or "
    "potential discrimination are escalated immediately and recorded in the AI System "
    "Journal (DOC-JOURNAL).")

PROCEDURES_TEXT = (
    "On an alert: analyse the cause - resource saturation, misconfiguration, a security "
    "incident - and confirm it with engineering or business input. Document the finding "
    "and whether corrective measures are taken, including the justification when they "
    "are not. Corrective measures include scaling infrastructure, redistributing "
    "workloads, optimising code, cleaning up storage and tightening access controls, so "
    "the system returns within its SLA. Every substantial alert, its investigation and "
    "its outcome are recorded in the AI System Journal.")


def scaling_text(plan: dict) -> str:
    """How the monitoring was scaled to the rated risk (§5): each addition, applied or not."""
    if not plan.get("risk"):
        return ""
    ratings = "; ".join(f"{dimension} {rated['rating']} ({rated['why']})"
                        for dimension, rated in plan["risk"].items())
    added = [d["addition"] for d in plan.get("adaptation", []) if d["applied"]]
    left = [f"{d['addition']} ({d['why']})" for d in plan.get("adaptation", []) if not d["applied"]]
    return (f" The monitoring is proportionate to the risk: {ratings}. Added beyond Table 5: "
            f"{', '.join(added) or 'nothing'}." + (f" Not added: {'; '.join(left)}." if left else ""))


def metrics_text(plan: dict) -> str:
    """The metrics selected, how each is computed, and which ones lack their record."""
    computable = [m for m in plan["metrics"] if m["computable_today"] is True]
    blocked = [m for m in plan["metrics"] if m["computable_today"] is False]
    selected = plan["selected"]
    return (
        f"At least one metric must be selected from the guideline table ({plan['rule']}, "
        f"{plan['source']}). Selected: {', '.join(selected) or 'none'}. "
        + "; ".join(f"{m['metric']} - alert {m['alert']}, computed as {m['how']}, fed by "
                    f"the {m['needs_record'].replace('_', ' ')} record"
                    for m in plan["metrics"] if m["metric"] in selected)
        + ". "
        + (f"{len(computable)} metric(s) are computable from the records the project keeps "
           f"today. " if computable else
           "None of the table's metrics is computable today, because none of the records "
           "that feed them is kept. ")
        + (f"The following need a record the project does not keep, and are gaps to close "
           f"in record keeping first: {', '.join(m['metric'] for m in blocked)}."
           if blocked else "")
        + scaling_text(plan))


def tools_text(plan: dict, monitor: dict | None) -> str:
    """How and how often the metrics are collected, and the monitor that computes them."""
    schedule = plan["schedule"]
    return (
        "Metrics are collected continuously and computed at the frequency set by "
        f"{schedule['rule']}"
        + (f": this system is called {schedule['inference_frequency']}, so monitoring runs "
           f"{schedule['monitoring_frequency']}. " if schedule.get("monitoring_frequency")
           else ", which cannot be derived until the inference frequency is confirmed. ")
        + "Implementation uses a monitoring platform with scheduled collection, dashboards "
          "accessible to human overseers, risk challengers and assessors, and alert rules "
          "wired to the on-call path. Time-series data is retained for trend analysis. "
          "The machine-readable alert rules produced with this plan are in "
          "aida/alert_rules.json." + implemented(monitor))


def logging_text(resilience: dict | None) -> tuple[str, list[str]]:
    """What is recorded for the metrics, and the outbound calls with their protections."""
    lines = [
        "Operational events are recorded so that each metric has an input: latency, "
        "usage, timeouts, errors, incidents, uptime, resource utilisation and security "
        "events. Records are structured, timestamped and standardised (REC-FORMAT), and "
        "retained per REC-RETENTION."]
    if resilience:
        counts = resilience["counts"]
        lines.append(
            f"Outbound dependencies: {counts['outbound']} call(s) - "
            f"{counts['with_timeout']} with a timeout, {counts['with_retry']} with a retry, "
            f"{counts['with_fallback']} with a fallback or error handling.")
        unprotected = [c for c in resilience["calls"] if not c["timeout"]]
        if unprotected:
            lines.append(
                "Calls with no timeout have no bounded latency, so the latency and "
                "timeout-rate metrics cannot hold until they are set: "
                + ", ".join(f"{c['call']} [{c['file']}:{c['line']}]"
                            for c in unprotected[:5]) + ".")
    evidence = [f"{c['file']}:{c['line']}" for c in (resilience or {}).get("calls", [])[:4]]
    return " ".join(lines), evidence


def build(plan: dict, resilience: dict | None, monitor: dict | None = None) -> dict[str, dict]:
    """The operational fields of section 3.8, from the plan and the resilience check.

    The routing map is not needed here: merge(), in main(), applies it to decide which of
    these answers each field may receive.
    """
    logging, evidence = logging_text(resilience)
    return {
        METRICS: entry(metrics_text(plan), source="rule"),
        TOOLS: entry(tools_text(plan, monitor), source="rule"),
        LOGGING: entry(logging, source="code" if evidence else "rule", evidence=evidence),
        ALERTS: entry(ALERTS_TEXT, source="rule"),
        PROCEDURES: entry(PROCEDURES_TEXT, source="rule"),
    }


def main() -> int:
    """Command line: merge section 3.8 (operational monitoring) into aida/values.json."""
    parser = argparse.ArgumentParser(
        description="Write the operational half of section 3.8.")
    parser.add_argument("--plan", default="aida/operational_plan.json")
    parser.add_argument("--resilience", default="aida/resilience.json")
    parser.add_argument("--monitor", default="aida/monitoring/ops_monitor_config.json",
                        help="configuration written by generate_ops_monitor.py, when it has run")
    parser.add_argument("--values", default="aida/values.json")
    parser.add_argument("--map", dest="routing", default="aida/placeholders.json",
                        help="placeholder map - the authority on where an answer may come from")
    args = parser.parse_args()

    plan_path = Path(args.plan)
    if not plan_path.exists():
        print(f"error: plan not found: {plan_path}\n"
              f"       run plan_operational.py first", file=sys.stderr)
        return 2

    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    resilience_path = Path(args.resilience)
    resilience = (json.loads(resilience_path.read_text(encoding="utf-8"))
                  if resilience_path.exists() else None)

    values_path = Path(args.values)
    monitor_path = Path(args.monitor)
    monitor = (json.loads(monitor_path.read_text(encoding="utf-8"))
               if monitor_path.exists() else None)
    result = merge(values_path, build(plan, resilience, monitor), Path(args.routing))
    print(report(result, "3.8 AI System Operational Monitoring", values_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
