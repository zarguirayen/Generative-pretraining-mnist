---
name: aida-operational-monitoring
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: ready
compatibility: Requires Python 3.10+
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*)
description: >-
  Plans the operational system monitoring of an AI system and writes the AI System
  Operational Monitoring part of section 3.8 of the AIDA technical documentation.
  Selects metrics from the guideline table, checks for each one whether the record that
  feeds it actually exists, emits the alert rules, sets the monitoring frequency, and
  checks whether outbound calls have a timeout, a retry and a fallback. Use it when
  asked about operational monitoring, system health, uptime, latency, error rate,
  timeouts, resource usage, token cost or FinOps of an AI system, when asked what
  happens if a dependency goes down, and when writing the operational monitoring
  section of AIDA documentation.
tags:
  - aida
  - monitoring
  - operational
  - sre
  - uptime
  - latency
  - finops
  - eu-ai-act
---

# aida-operational-monitoring

Covers the health of the system, not the quality of its answers. Its job is to make sure
the metrics chosen can actually be computed, and that a dependency going down degrades the
system instead of ending it.

---

## Absolute rules

- **Never select a metric the project cannot compute.** Every metric is fed by a record;
  without the record, the metric is a sentence in a document and nothing more.
- **Never state a threshold that is not the guideline's.** Latency ≥ 3 s, uptime < 99% per
  week, timeout ≥ 5%, error rate ≥ 2%, one crash, resources ≥ 90%, and a token quota.
- **Model quality is not this section.** Faithfulness and task completion belong to AI
  Model Monitoring. The two halves of 3.8 stay separate.
- **A call with no timeout has no bounded latency.** Report it as blocking; a latency
  metric over an unbounded call means nothing.
- **Never report a system as having no dependencies** because the check did not recognise
  its client. Say what was not recognised.

---

## Purpose

Section 3.8 of the AIDA template has two halves; this skill owns the second one, **AI
System Operational Monitoring**: reliability, availability, usage deviation and cost.

The guideline's table holds thirteen metrics and requires at least one
(`MON-OPERATIONAL-MINIMUM`). Choosing from a list is easy; choosing one the system can
measure is the step that gets skipped, so each metric is reported with the record that
feeds it and whether that record exists — which is why this skill reads the record keeping
audit.

The three categories, in the guideline's own terms: **operational usage** (deviation in
how much the system is used), **operational reliability** (latency, uptime, errors,
resources, unauthorised access), and **FinOps / GreenOps** (token consumption against a
quota).

### When not to use

- Model quality (faithfulness, task completion, drift) - use `aida-genai-monitoring`.
- What the system must log - use `aida-record-keeping`; this skill only reads that audit.

### Prerequisites

- Python 3.10+. Standard library only, in the generated monitor too.
- The `aida-core` skill of the same plugin (`depends_on`), at `../aida-core/` from this
  folder. This skill uses exactly these files from it:

| `aida-core` file | Used by | For |
|---|---|---|
| `scripts/scan_codebase.py` → `aida/context.json` | `plan_operational.py`, `scale_to_risk.py` (`--context`) | the classified system, its tools, side effects and endpoints, which rate the risk |
| `references/aida_rules.json` | `plan_operational.py` (`--rules`) | Table 5 metrics and thresholds (`MON-OPERATIONAL-MINIMUM`), frequency (`MON-FREQUENCY`) |
| `scripts/ast_utils.py` (`dotted`) | imported by `check_resilience.py` | the dotted name of each outbound call read on the syntax tree |
| `scripts/section_values.py` | imported by `write_section.py` | writing into `aida/values.json`: never a `human` field, never over a confirmed answer |
| `scripts/placeholder_map.py` → `aida/placeholders.json` | `write_section.py` (`--map`) | where each field's answer may come from |
| `scripts/validate_values.py`, `scripts/fill_docx.py` | Phase 5 | the blocking checks, then the Word document |

- From `aida-record-keeping`: `aida/records_audit.json` (Phase 1, `--records`) says which
  records exist, so which metrics can be computed. The generated monitor reads the record
  journal (`logs/aida_records.jsonl`) that skill defines and appends its alerts to it,
  where `verify_chain.py` checks them.

---

## Workflow

Copy this checklist and tick items off as you go:

```
Operational monitoring:
- [ ] Phase 1: record keeping audit available; ask the three questions
- [ ] Phase 1b: rate stakes, complexity and exposure; scale the monitoring to them
- [ ] Phase 2: build the plan and the alert rules
- [ ] Phase 2b: generate the runnable monitor and its schedule
- [ ] Phase 3: check dependency resilience
- [ ] Phase 4: report
- [ ] Phase 5: write section 3.8, operational monitoring
```

### Phase 1 — Record keeping audit available

Run the `aida-record-keeping` skill first. Without it, computability is unknown and the
plan degrades to a list of good intentions.

Then ask, in one block, what the code cannot answer:

> 1. How often is the system called in production — daily, weekly, monthly or quarterly?
> 2. What is its AI Act risk category — high, limited or minimal?
> 3. Who uses it — internal staff, or external users?
> 4. Where should alerts go — the overseers' e-mail addresses and SMTP relay, or a chat
>    or incident-tool webhook? And the address ranges users come from, if any?

### Phase 1b — Rate the risk and scale the monitoring to it (template §5)

```bash
python scripts/scale_to_risk.py --context aida/context.json --risk-category high --users external --inference-frequency daily
```

The thirteen metrics of Table 5 and their thresholds are never scaled away. What the
rating decides is what comes on top:

| Dimension | Rated from | High when | Adds when not rated low |
|---|---|---|---|
| **Stakes** | the AI Act category (question 2), irreversible side effects in `aida/context.json` | high-risk category, or the code can send, delete or write | alerts sent from medium severity, not only high and critical |
| **Complexity** | autonomy level and tool signals from the classification | autonomy L2/L3, or more than one tool | latency, errors and timeouts broken down per dependency or tool |
| **Exposure** | endpoints in the code, frequency (question 1), users (question 3) | external users, or an endpoint called daily | requests and tokens per consumer (per-tenant cost); access from an unrecognised address range, as Table 5 counts it |

A dimension nobody rated is "to confirm" and keeps its additions until the risk owner
rates it low. The ratings are the same as `aida-genai-monitoring`'s, so both halves of
section 3.8 rest on one assessment. Every decision, applied or not, is written with its
reason in the plan, the monitor's config and section 3.8.

### Phase 2 — Build the plan and the alert rules

```bash
python scripts/plan_operational.py --context aida/context.json --records aida/records_audit.json --inference-frequency daily --risk-category high --users external
```

Writes the plan and `aida/alert_rules.json`, ready to load into a monitoring platform.
Each rule carries its condition, the record it needs, and what to do when it fires.

### Phase 2b — Generate the runnable monitor

```bash
python scripts/generate_ops_monitor.py --plan aida/operational_plan.json --out aida/monitoring --token-quota 2000000 --email-to overseer@example.com --smtp-host smtp.internal [--webhook-url https://chat.internal/hook] [--known-ip-prefix 10.12.]
```

The plan becomes code (`MON-TIMING`: monitoring in place before the end of the build phase):
`aida/monitoring/ops_monitor.py` reads the record journal and computes the 13 metrics of
Table 5 — latency, processing time, output size, uptime, timeout and error rates, crashes
in 24 h, resource peak, failed logins per minute, request spike, daily tokens against the
quota, active users and session length against the previous periods. A metric whose record
is missing is a **coverage gap, never a pass**.

- **Every threshold is justified.** Each rule in `ops_monitor_config.json` carries the
  Table 5 default, its source and why that value ("at 90 % there is no headroom left for
  a peak"). Tailor a value with its own justification, and have the thresholds validated
  before the end of the build phase — the config keeps that validation as an open point.
- **Noise never pages anyone.** Each rule has a noise guard, with its reason: at least 20
  requests behind a rate or an average (fewer is insufficient data, not an alert and not a
  pass), three consecutive samples for a resource peak, a minimum hourly volume for a
  spike, and a count of consecutive breached periods — 1 by default, since the period
  aggregate is already the guideline's smoothing; raising it needs a justification.
- **An alert explains itself and reaches a person.** It carries the value, the threshold
  and its justification, the trend over the previous periods, the probable cause read from
  the records (most frequent errors, the dependency timing out, the largest consumers…)
  and the next steps. It is appended to the hash-chained journal (`verify_chain.py`
  audits it) and sent by e-mail or webhook to the channels given here — the SMTP password
  is read from `AIDA_SMTP_PASSWORD`, never written, and a webhook must be https. With no
  channel it stays in the journal and exit code 1 turns the scheduled job red.

`schedule/ops-crontab.txt` and `schedule/ops-gitlab-ci.yml` run it at the `MON-FREQUENCY`
cadence.

### Phase 3 — Check dependency resilience

```bash
python scripts/check_resilience.py . --out aida/resilience.json
```

For every outbound call — model endpoint, vector store, HTTP — it reports whether there is
a timeout, a retry, and a fallback:

```
DEPENDENCY       CALL                T   R   F   WHERE
model endpoint   agent.invoke        -   -   -   agent.py:44
HTTP             requests.post       -   -   -   agent.py:50
HTTP             requests.get        y   -   -   agent.py:20
```

### Phase 4 — Report

Lead with what can be measured today, not with the full table:

```
3 of 13 metrics computable today; the rest need records the project does not keep.
Selected: error_rate, average_inference_latency, uptime_pct
Schedule: weekly (inference: daily)
2 outbound calls with no timeout - latency and timeout-rate cannot hold until fixed.
```

### Phase 5 — Write the section

```bash
python scripts/write_section.py --plan aida/operational_plan.json --resilience aida/resilience.json --monitor aida/monitoring/ops_monitor_config.json --values aida/values.json --map aida/placeholders.json
```

It writes this section's fields into the shared values file. The placeholder map decides
where each answer may come from: a field the template routes to a human is left as an open
point, and one routed to the codebase is skipped unless there is something to cite. Answers
carrying `confirmed_by` are never overwritten.

Then run the shared chain from `aida-core`:
`validate_values.py`, then `fill_docx.py`. State the metrics selected and why, the
thresholds with their justification, the tools and processes, the logging mechanisms, and
the alert procedure.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/write_section.py`](scripts/write_section.py) | Writes section 3.8 operational monitoring into `aida/values.json` |
| [`scripts/plan_operational.py`](scripts/plan_operational.py) | Metric selection by computability, alert rules, schedule |
| [`scripts/generate_ops_monitor.py`](scripts/generate_ops_monitor.py) | Writes the runnable monitor, its config and schedule under `aida/monitoring/` |
| [`assets/ops_monitor.py.template`](assets/ops_monitor.py.template) | The monitor: Table 5 metrics from the record journal, explained alerts into it |
| [`scripts/check_resilience.py`](scripts/check_resilience.py) | Timeout, retry and fallback on every outbound call |
| [`scripts/scale_to_risk.py`](scripts/scale_to_risk.py) | §5: stakes, complexity and exposure rated with evidence; each addition applied or not, and why |
| [`references/operational_monitoring.md`](references/operational_monitoring.md) | The thirteen metrics, their thresholds, and the record each one needs |

The `aida-core` files this skill relies on are listed under [Prerequisites](#prerequisites).

---

## Quality checklist

- [ ] At least one metric is selected, and it is computable today
- [ ] Every metric is reported with the record that feeds it
- [ ] Thresholds are the guideline's numbers, not rounded ones, each with its justification and noise guard
- [ ] Stakes, complexity and exposure were rated with evidence, and each addition is reported applied or not, with its reason
- [ ] Alerts reach a person: a channel is configured, or its absence is reported as an open point
- [ ] The schedule follows the inference frequency, and both are stated
- [ ] Alert rules were written to `aida/alert_rules.json`
- [ ] Every outbound call was checked for timeout, retry and fallback
- [ ] Quality metrics were not mixed into this section
