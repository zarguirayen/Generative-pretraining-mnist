# Operational system monitoring

Source: AI Factory, *Monitoring and Human Oversight* guideline, section 5 — EU AI Act
Article 72. Applies to all risk categories.

## Contents

- [What it covers](#what-it-covers)
- [The thirteen metrics](#the-thirteen-metrics)
- [Every metric needs a record](#every-metric-needs-a-record)
- [Method](#method)
- [Resilience, which no metric can replace](#resilience-which-no-metric-can-replace)
- [Thresholds, noise and alerts](#thresholds-noise-and-alerts)
- [Scaling to the risk (template §5)](#scaling-to-the-risk-template-5)
- [Not this section](#not-this-section)

---

## What it covers

The continuous tracking of the system's health and reliability over its run phase: error
rates, inference latency, usage duration, uptime. Three concerns:

- **usage deviation** — an abnormal increase or reduction in how much the system is used;
- **system anomalies** — latency growth, errors, crashes;
- **FinOps and GreenOps** — token and resource consumption.

Metrics are computed continuously, at the frequency set by `MON-FREQUENCY`, and their
thresholds must be validated before the end of the build phase.

## The thirteen metrics

`MON-OPERATIONAL-MINIMUM`. **At least one must be selected**, proportionate to the risk of
the system. The thresholds below are the guideline's own examples.

| Metric | Category | Alert |
|---|---|---|
| Average usage duration per user | usage | < 20% of baseline, or > 3× baseline |
| Active users trend | usage | continuous drop of 30% month over month |
| Request spike | usage | +200% requests within one hour |
| Average inference latency | reliability | ≥ 3 s |
| Data processing duration | reliability | ≥ 3 s |
| Output size | reliability | ≥ 100 Mo, or ≥ 2000 tokens |
| Percentage of uptime | reliability | < 99% per week |
| Time-out rate | reliability | ≥ 5% per week |
| Error rate | reliability | ≥ 2% per week |
| System crashes | reliability | immediate alert after one crash in 24h |
| Resource utilisation | reliability | ≥ 90% |
| Unauthorised access | reliability | ≥ 3 failed logins in 1 min, or an unrecognised IP range |
| Token usage | FinOps / GreenOps | daily tokens above the defined quota |

Additional metrics may be proposed, and stricter thresholds adopted. Risk challengers may
require more during review.

## Every metric needs a record

This is the part that decides whether the section describes something real. A metric is
computed from a record; if the record is not kept, the metric cannot be produced.

| Metric | Record that feeds it |
|---|---|
| Average inference latency | Inference Latency |
| Data processing duration | Data Processing Duration |
| Output size | System Output Size |
| Uptime | System Uptime |
| Time-out rate | Timeout Event |
| Error rate | Error Event |
| System crashes | Incident Event |
| Resource utilisation | Resource Utilisation |
| Unauthorised access | Security Event |
| Token usage | Inference record, tokens field |
| Usage duration | System Usage |
| Active users, request spike | System Access Log, Inference Request |

Those records are the *recommended* rows of Table 2 in the Record Keeping guideline. They
are recommended as records and required in practice: skipping the record makes the
corresponding metric uncomputable. `plan_operational.py` reads the record keeping audit for
exactly this reason.

## Method

1. **Collect continuously**, at the frequency `MON-FREQUENCY` sets.
2. **Set thresholds** tailored to the system's real operational and business expectations,
   justified and validated before the end of the build phase.
3. **Alert** automatically — mail or system notification — to the human overseers.
4. **Investigate and justify** — resource saturation, misconfiguration, a security
   incident — with engineering or business input, and document the finding.
5. **Correct** — scale, redistribute, optimise, clean up, tighten access — so the system
   returns within its SLA.
6. **Record** — metrics pushed to a database or MLflow, incidents and logs kept, so
   recurring issues surface and the audit trail exists.

Implementation platforms named by the guideline: CloudWatch, Grafana, dashboards and alert
rules wired to an on-call system, with time-series history retained for trend analysis.

## Resilience, which no metric can replace

A latency metric over a call that can hang forever measures nothing, and an uptime
percentage does not bring a dependency back. Before the metrics, three questions per
outbound call — the model endpoint, the vector store, any tool behind an API:

- is there a **timeout**, so the call cannot hang;
- is there a **retry**, so a transient failure does not surface;
- is there a **fallback**, so the system degrades instead of failing.

`check_resilience.py` answers all three per call site. A call with none of them turns a
dependency incident into an outage, and that is an operational risk the documentation
should state rather than discover.

## Thresholds, noise and alerts

The guideline asks for thresholds tailored to the system and validated before the end of
the build phase, and for alerts that do not trigger a disproportionate reaction to an
isolated event. So every threshold is written with its justification, and every metric
with a noise guard: a minimum sample (20 requests, 6 uptime probes), a sustained peak for
resources (three samples in a row), a minimum hourly volume before a spike counts, and a
number of consecutive breached periods. That number is 1 by default: the period aggregate
is the guideline's own smoothing, and waiting longer would alert later than Table 5.
Crashes and unauthorised access have no guard — one occurrence is the signal.

An alert carries its trend over the previous periods and the probable cause the records
show, and it is sent — by e-mail or webhook — to the named overseers, as well as journaled.

## Scaling to the risk (template §5)

| Addition | Turned on by | Why |
|---|---|---|
| alerts sent from medium severity | stakes | where a failure costs most, the overseers see more |
| per-dependency breakdown | complexity | an agent with several tools fails one dependency at a time |
| per-consumer usage and cost | exposure | with many users, cost and abuse concentrate on a few |
| unrecognised address check | exposure | Table 5 counts access from an unrecognised range as unauthorised |

A dimension nobody rated keeps its additions. `scale_to_risk.py` applies this table.

## Not this section

Faithfulness, task completion, tool correctness and the other quality metrics belong to
**AI Model Monitoring**, the first half of section 3.8, owned by the
`aida-genai-monitoring` skill. Mixing the two is the most common way this section gets
written badly: it ends up describing model quality and saying nothing about whether the
system stays up.
