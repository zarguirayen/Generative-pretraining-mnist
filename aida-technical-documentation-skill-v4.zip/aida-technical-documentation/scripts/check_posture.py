#!/usr/bin/env python3
"""Check this skill's own security posture before relying on it.

    python check_posture.py

Reads every script of the skill on its syntax tree - nothing is executed - and exits 1 on
anything that would contradict what SKILL.md promises:

- a network module imported (nothing leaves the machine);
- eval, exec or compile called, or pickle, marshal, shelve or yaml imported (JSON only);
- a subprocess given a shell, os.system or os.popen, or a command other than git;
- a git subcommand that writes: the scripts only ever read the history.

Standard library only.
"""

from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
NETWORK = {"socket", "ssl", "requests", "httpx", "aiohttp", "urllib3", "ftplib", "smtplib",
           "paramiko", "urllib.request", "http.client"}
UNSAFE_MODULES = {"pickle", "marshal", "shelve", "yaml"}
UNSAFE_CALLS = {"eval", "exec", "compile"}
READ_ONLY_GIT = {"rev-parse", "log", "describe", "for-each-ref", "rev-list"}


def imported(node: ast.AST) -> list[str]:
    """The module names an import statement brings in; [] for any other node."""
    if isinstance(node, ast.Import):
        return [alias.name for alias in node.names]
    if isinstance(node, ast.ImportFrom) and node.module:
        return [node.module]
    return []


def call_problem(call: ast.Call) -> str | None:
    """What is wrong with one call, or None."""
    name = call.func.id if isinstance(call.func, ast.Name) else None
    dotted = (f"{call.func.value.id}.{call.func.attr}" if isinstance(call.func, ast.Attribute)
              and isinstance(call.func.value, ast.Name) else None)
    words = [a.value for a in call.args if isinstance(a, ast.Constant)
             and isinstance(a.value, str) and re.fullmatch(r"[a-z][a-z-]*", a.value)]
    if name in UNSAFE_CALLS:
        return f"calls {name}"
    if dotted in ("os.system", "os.popen"):
        return f"calls {dotted}"
    if any(k.arg == "shell" and getattr(k.value, "value", False) is True for k in call.keywords):
        return "gives a subprocess a shell"
    if dotted and dotted.startswith("subprocess.") and call.args:
        command = call.args[0]
        first = command.elts[0] if isinstance(command, ast.List) and command.elts else command
        if getattr(first, "value", None) != "git":
            return "runs a command other than git"
    if name == "git" and words and words[0] not in READ_ONLY_GIT:
        return f"runs git {words[0]}, which is not a read-only subcommand"
    return None


def problems(script: Path) -> list[str]:
    """Every breach of the posture in one script, with its line."""
    found = []
    for node in ast.walk(ast.parse(script.read_text(encoding="utf-8"))):
        line = f"{script.name}:{getattr(node, 'lineno', 0)}"
        for module in imported(node):
            if module in NETWORK or module.split(".")[0] in NETWORK:
                found.append(f"{line}: imports {module} - a network module")
            if module.split(".")[0] in UNSAFE_MODULES:
                found.append(f"{line}: imports {module} - unsafe deserialisation")
        if isinstance(node, ast.Call) and (problem := call_problem(node)):
            found.append(f"{line}: {problem}")
    return found


def main() -> int:
    """Command line: check every script of this folder; exit 1 on any breach."""
    scripts = sorted(HERE.glob("*.py"))
    found = [p for script in scripts for p in problems(script)]
    for problem in found:
        print(f"BREACH  {problem}")
    print(f"{len(scripts)} scripts checked: "
          f"{'posture holds' if not found else f'{len(found)} breach(es)'}")
    return 1 if found else 0


if __name__ == "__main__":
    raise SystemExit(main())
