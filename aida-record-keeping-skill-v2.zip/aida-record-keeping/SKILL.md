---
name: aida-record-keeping
version: 0.1.0
domain: evaluation
risk_tier: L1
depends_on:
  - aida-core
status: ready
compatibility: Requires Python 3.10+
license: Internal - CACIB / DS Community
allowed-tools: shell(python:*) shell(python3:*)
description: >-
  Audits what an AI project actually records against the nine records the AI Factory
  guideline makes mandatory, checks which fields the inference log really carries,
  and writes section 3.7 of the AIDA technical documentation. Generates the missing
  record keeping as a hash-chained, tamper-evident journal that an auditor can verify
  with nothing but the file. Use it when asked about record keeping, logging,
  traceability, audit trails, log retention or EU AI Act Article 12, when asked
  whether a system's logs would survive an audit, and when writing or reviewing the
  record keeping section of AIDA documentation.
tags:
  - aida
  - record-keeping
  - eu-ai-act
  - article-12
  - logging
  - audit-trail
  - traceability
---

# aida-record-keeping

Answers what a log file cannot answer on its own: are the mandatory records kept, do they
carry the fields that make them useful, and could anyone tell if they had been edited?

---

## Absolute rules

- **A span attribute is a field.** A project instrumented to the OpenTelemetry
  GenAI conventions records through `set_attribute`, not through log keywords;
  reporting it as recording nothing would penalise the teams who followed the
  standard.
- **A message string is not a field.** Only real keyword arguments and dictionary keys
  count as recorded fields; `logger.info("session=%s", sid)` records nothing structured.
- **Never call retention satisfied because logs exist.** The guideline sets ten years for
  documentation and at least one year for automatic logs, in immutable storage.
- **Never write a credential, a token or a personal datum into a record.** The generated
  module redacts by key name; that is a safety net, not a licence to pass secrets.
- **Never edit the project's own source.** The module goes to `aida/generated/`; where the
  calls belong is an application decision.
- **A broken chain is an incident, not a warning.** Report it as such.
- **Report what was found and where.** If records are kept in a way the audit does not
  recognise, say so rather than concluding there are none.

---

## Purpose

Section 3.7 of the AIDA template asks how inputs, outputs and ground truth are collected
and historised, how main events are logged, how user feedback is captured, and with what
tools. Behind it, the Record Keeping guideline (EU AI Act Article 12) marks **nine
records mandatory** for internally developed systems — six model records, two operational,
one oversight — and requires them structured, timestamped, automatic, and stored so they
cannot be altered unnoticed.

This skill checks all four things separately, because a project usually satisfies some and
not others:

| Question | Rule |
|---|---|
| Do the nine mandatory records have a mechanism? | `REC-MODEL-MANDATORY`, `REC-OPERATIONAL-MANDATORY`, `REC-OVERSIGHT-MANDATORY` |
| Do inference records carry the fields monitoring needs? | `REC-FORMAT` |
| Is the format structured? | `REC-FORMAT` |
| Is retention set, and is storage tamper-evident? | `REC-RETENTION` |

### When not to use

- The question is what to alert on - that is monitoring (`aida-genai-monitoring`, `aida-operational-monitoring`).
- The question is who can stop or approve an action - use `aida-human-oversight`.

### Prerequisites

- Python 3.10+. Standard library only, in the generated module too.
- The `aida-core` skill of the same plugin (`depends_on`), at `../aida-core/` from this
  folder. This skill uses exactly these files from it:

| `aida-core` file | Used by | For |
|---|---|---|
| `scripts/ast_utils.py` (`dotted`) | imported by `audit_records.py` | the dotted name of each call read on the syntax tree |
| `scripts/scan_codebase.py` → `aida/context.json` | `scale_records.py`, `generate_records.py` (`--context`) | the system's tools, side effects and endpoints, which rate the risk |
| `scripts/section_values.py` | imported by `write_section.py` | writing into `aida/values.json`: never a `human` field, never over a confirmed answer |
| `scripts/placeholder_map.py` → `aida/placeholders.json` | `write_section.py` (`--map`) | where each field's answer may come from |
| `scripts/validate_values.py`, `scripts/fill_docx.py` | Phase 5 | the blocking checks, then the Word document |

- `verify_chain.py` and the generated `aida_records.py` need nothing else: an auditor runs
  the verifier on the journal file alone.
- The journal this skill defines is shared: the oversight controls
  (`aida-human-oversight`) and both monitors (`aida-genai-monitoring`,
  `aida-operational-monitoring`) append to it, and `verify_chain.py` checks them all.

---

## Workflow

Copy this checklist and tick items off as you go:

```
Record keeping:
- [ ] Phase 1: audit the records and the fields
- [ ] Phase 1b: rate stakes, complexity and exposure; scale the record keeping to them
- [ ] Phase 2: report the coverage
- [ ] Phase 3: generate the missing record keeping
- [ ] Phase 4: verify the chain
- [ ] Phase 5: write section 3.7
```

### Phase 1 — Audit

```bash
python scripts/audit_records.py . --out aida/records_audit.json
```

Exits 1 on any blocking finding. Field names are read from the syntax tree, so the count
reflects what is really recorded.

### Phase 1b — Rate the risk and scale the record keeping to it (template §5)

Ask, in one block, what the code cannot answer: the AI Act risk category (high, limited,
minimal), who uses the system (internal staff or external users), and how often it is
called. Then:

```bash
python scripts/scale_records.py --context aida/context.json --risk-category high --users external --inference-frequency daily
```

The nine mandatory records, their fields, the format and the retention are never scaled
away. What the rating decides is what comes on top — written into the generated module,
so it runs:

| Dimension | Rated from | High when | Adds when not rated low |
|---|---|---|---|
| **Stakes** | the AI Act category, irreversible side effects in `aida/context.json` | high-risk category, or the code can send, delete or write | an anchor every hour instead of every day; `irreversible_action()` records each irreversible action with its approver and flags one without |
| **Complexity** | autonomy level and tool signals from the classification | autonomy L2/L3, or more than one tool | one `tool_step` record per tool call of the agent, written by the decorator |
| **Exposure** | endpoints in the code, frequency, users | external users, or an endpoint called daily | the source address on every access record — a missing one is recorded as missing |

A dimension nobody rated is "to confirm" and keeps its additions until the risk owner
rates it low. The ratings are the same as the monitoring skills', so the whole of AIDA
rests on one assessment.

### Phase 2 — Report the coverage

Two numbers first, then the detail:

```
Mandatory records with a mechanism : 2/9
Required fields actually logged    : 0/12
  MISSING: timestamp, session_id, request_id, actor, input, output,
           model_version, prompt_version, latency, tokens, tool_calls, outcome
  structured format        NO
  retention policy         NO
  tamper-evident storage   NO
```

If the field count is zero while logging clearly happens, explain why: `%`-style log
messages carry no fields, which is exactly the gap the guideline is aimed at.

### Phase 3 — Generate the missing record keeping

```bash
python scripts/generate_records.py --audit aida/records_audit.json --project . --context aida/context.json --risk-category high --users external
```

Writes `aida/generated/aida_records.py` — one helper per mandatory record, over an
append-only journal where each entry carries the hash of the previous one — and prints the
call site for every missing record. Recording is embedded in the architecture, as
`REC-FORMAT` asks, so no call site can forget it:

- `@records.logged_inference(model_version=...)` on the inference function records input,
  output, latency, tokens and outcome of every call, failures included;
- `records.RecordHandler()` added to `logging` sends the application's log lines into the
  same journal as structured records;
- the recommended operational records (`error_event`, `timeout_event`, `incident`,
  `uptime_probe`, `resource_usage`) are what the operational monitor computes from.

Credentials are redacted by field name before anything is written; token counts are kept.

### Phase 4 — Verify the chain

```bash
python scripts/verify_chain.py logs/aida_records.jsonl
```

Editing an entry changes its own hash; removing one breaks the next link. Both are
reported with the entry number. Run it in CI, and at startup through
`records.require_intact()`.

A chain cannot see its **last** entries being cut off. `records.anchor()` copies the head
of the chain to `logs/aida_anchors.jsonl` — keep that file on write-once storage — and
`verify_chain.py journal --anchors anchors` then fails on a truncated or rewritten journal.

### Phase 5 — Write section 3.7

```bash
python scripts/write_section.py --audit aida/records_audit.json --scaling aida/records_scaling.json --values aida/values.json --map aida/placeholders.json
```

It writes this section's fields into the shared values file. The placeholder map decides
where each answer may come from: a field the template routes to a human is left as an open
point, and one routed to the codebase is skipped unless there is something to cite. Answers
carrying `confirmed_by` are never overwritten.

Then run the shared chain from `aida-core`:
`validate_values.py`, then `fill_docx.py`. The section must state which records are kept,
by what mechanism, with what retention, and which ones are still gaps to close **before
the end of the build phase** — the guideline's own deadline.

---

## Resources

| Resource | Purpose |
|---|---|
| [`scripts/write_section.py`](scripts/write_section.py) | Writes section 3.7 into `aida/values.json` |
| [`scripts/audit_records.py`](scripts/audit_records.py) | Coverage of the nine mandatory records and the twelve required fields |
| [`scripts/generate_records.py`](scripts/generate_records.py) | Writes the journal module and the call site for each gap |
| [`scripts/verify_chain.py`](scripts/verify_chain.py) | Standalone integrity check — needs only the file |
| [`scripts/scale_records.py`](scripts/scale_records.py) | §5: stakes, complexity and exposure rated with evidence; each addition applied or not, and why |
| [`references/record_requirements.md`](references/record_requirements.md) | The three record tables, retention, and what code can and cannot show |
| [`assets/aida_records.py.template`](assets/aida_records.py.template) | The module that gets generated |

The `aida-core` files this skill relies on are listed under [Prerequisites](#prerequisites).

---

## Quality checklist

- [ ] All nine mandatory records were checked, each reported present or missing
- [ ] Field coverage was read from the syntax tree, not from log message text
- [ ] Structured format, retention and immutability were checked separately
- [ ] The generated module went to `aida/generated/`, project source untouched
- [ ] `verify_chain.py` was run and its result reported
- [ ] Retention is stated in the guideline's numbers: 10 years and 1 year
- [ ] Stakes, complexity and exposure were rated with evidence, and each addition is reported applied or not, with its reason
- [ ] Remaining gaps are named as gaps, with the build-phase deadline
