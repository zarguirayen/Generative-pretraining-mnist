#!/usr/bin/env python3
"""Merge one deliverable's answers into the shared `aida/values.json`.

Each section skill analyses its own area and then has to put the result *into the
document* - that is the deliverable, not the audit. They all merge through here so the
same two rules hold everywhere:

* an answer a human confirmed is never overwritten by a regeneration;
* an answer derived from the code carries the `path:line` that proves it, or it is not
  written at all.

Imported by the section skills; not run directly. Standard library only.
"""

from __future__ import annotations

import json
from pathlib import Path


def load(values_path: Path) -> dict:
    if not values_path.exists():
        return {}
    data = json.loads(values_path.read_text(encoding="utf-8"))
    return data.get("values", data) if isinstance(data, dict) else {}


def entry(value: str, *, source: str = "rule", evidence: list[str] | None = None) -> dict:
    """One answer. `code` answers must cite something; `rule` answers quote a rule id."""
    payload: dict = {"value": value, "source": source}
    if evidence:
        payload["evidence"] = evidence[:4]
    return payload


def routing_of(map_path: Path | None) -> dict:
    if not map_path or not map_path.exists():
        return {}
    data = json.loads(map_path.read_text(encoding="utf-8"))
    return {p["placeholder"]: p for p in data.get("placeholders", [])}


def merge(values_path: Path, entries: dict[str, dict],
          map_path: Path | None = None) -> dict:
    """Write `entries` into the values file. Returns a small report for the caller.

    The placeholder map is the authority on where an answer may come from, not the
    calling skill: a section script that believes it is writing a guideline-derived
    answer onto a field the template routes to `code` would produce a claim with no
    evidence behind it, and a `human` field written by any script at all is the
    fabrication this plugin exists to prevent.
    """
    values = load(values_path)
    routing = routing_of(map_path)
    written, kept, no_evidence, human_only = [], [], [], []

    for placeholder, payload in entries.items():
        current = values.get(placeholder)
        if isinstance(current, dict) and current.get("confirmed_by"):
            kept.append(placeholder)
            continue

        route = routing.get(placeholder, {})
        source = route.get("source", payload.get("source", "rule"))
        if source in ("human", "external"):
            human_only.append(placeholder)
            continue
        if source == "code" and not payload.get("evidence"):
            no_evidence.append(placeholder)
            continue

        values[placeholder] = {**payload, "source": source}
        written.append(placeholder)

    values_path.parent.mkdir(parents=True, exist_ok=True)
    values_path.write_text(json.dumps(values, indent=2, ensure_ascii=False) + "\n",
                           encoding="utf-8")
    return {"written": written, "kept_confirmed": kept, "skipped_no_evidence": no_evidence,
            "left_to_human": human_only, "total": len(values)}


def report(result: dict, section: str, values_path: Path) -> str:
    lines = [f"Section {section}: {len(result['written'])} field(s) written into "
             f"{values_path}"]
    if result["kept_confirmed"]:
        lines.append(f"  {len(result['kept_confirmed'])} human-confirmed answer(s) kept "
                     f"untouched")
    if result["skipped_no_evidence"]:
        lines.append(f"  {len(result['skipped_no_evidence'])} skipped - the template routes "
                     f"them to the codebase and there was nothing to cite")
    if result.get("left_to_human"):
        lines.append(f"  {len(result['left_to_human'])} left as an open point - only the "
                     f"risk owner can answer them")
    lines.append(f"  {result['total']} field(s) in the file in total")
    lines.append("\nNext: validate_values.py, then fill_docx.py.")
    return "\n".join(lines)


if __name__ == "__main__":
    raise SystemExit("section_values.py is a library: the section skills import merge() and "
                     "report(). Run a section's write_section.py instead.")
